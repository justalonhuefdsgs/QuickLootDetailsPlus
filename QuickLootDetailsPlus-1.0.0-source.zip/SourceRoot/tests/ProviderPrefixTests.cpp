// SPDX-License-Identifier: GPL-3.0-or-later
// Optional local-only evidence; no provider prefix is distributed in this source.
#include "qld/LegacyBinaryEvidence.h"
#include <fstream>
#include <iostream>
int main(int argc,char** argv){
    if(argc!=2)return 2;std::ifstream in(argv[1],std::ios::binary);unsigned checks{};
    for(const auto& proof:qld::legacyBinaryEvidence)for(int slot:{4,5}){
        std::array<unsigned char,32> code{};
        if(!in.read(reinterpret_cast<char*>(code.data()),code.size()) || !qld::legacyCodeMatches(proof,slot,code))return 3;++checks;
        for(auto& b:code){b^=1;if(qld::legacyCodeMatches(proof,slot,code))return 4;b^=1;++checks;}
        if(qld::legacyCodeMatches(proof,3,code))return 5;++checks;
    }
    if(in.peek()!=std::char_traits<char>::eof())return 6;
    std::cout<<"Actual provider-prefix hash PASS: "<<checks<<" checks; no runtime loading.\n";
}
