#pragma once
#include <array>
#include <cstdint>
#include <string_view>

namespace qld {
enum class ItemIconCategory : std::uint8_t { misc, weapon, armor, alchemy, ingredient, book, ammo, soulGem, key, scroll, light };
enum class ItemIconVariant : std::uint8_t {
    generic,
    sword, greatsword, dagger, warAxe, battleAxe, mace, bow, staff, crossbow, warhammer, pickaxe, woodAxe,
    lightHead, lightBody, lightHands, lightForearms, lightFeet, lightCalves, lightShield,
    heavyHead, heavyBody, heavyHands, heavyForearms, heavyFeet, heavyCalves, heavyShield,
    clothingHead, clothingBody, clothingHands, clothingForearms, clothingFeet, clothingCalves, clothingShield,
    amulet, ring, circlet,
    health, magicka, stamina, fireResist, shockResist, frostResist, poison, food, drink,
    note, spellTome, bolt,
    soulEmpty, soulPartial, soulFull, grandSoulEmpty, grandSoulPartial, grandSoulFull, azuraSoul,
    gem, dragonClaw, artifact, leather, leatherStrips, hide, remains, ingot, childrenClothes, firewood, clutter, lockpick, gold
};
enum class SoulGemQuality : std::uint8_t { unknown, petty, lesser, common, greater, grand, azura };
enum class EnchantmentMarker : std::uint8_t { none = 0, enchanted = 1, known = 2, special = 3 };
enum class ArmorWeightClass : std::uint8_t { none, light, heavy };
enum class ArmorIconClass : std::uint8_t { other, light, heavy, clothing, jewelry };
enum class ArmorPart : std::uint8_t { other, head, hair, longHair, body, hands, forearms, feet, calves, shield, amulet, ring, circlet, ears, tail };

constexpr EnchantmentMarker enchantmentMarker(bool hasEnchantment, bool isKnown, bool cannotDisenchant) noexcept {
    if (!hasEnchantment) return EnchantmentMarker::none;
    if (cannotDisenchant) return EnchantmentMarker::special;
    if (isKnown) return EnchantmentMarker::known;
    return EnchantmentMarker::enchanted;
}
constexpr bool isGold001Form(std::uint32_t objectFormId, std::uint32_t resolvedGold001FormId) noexcept {
    return resolvedGold001FormId != 0 && objectFormId == resolvedGold001FormId;
}

struct ItemIconSpec {
    std::string_view label{"default_misc"};
    std::uint32_t tint{};
    bool hasTint{};
    bool gold001{};
};

constexpr std::string_view itemIconLabel(ItemIconCategory category, ItemIconVariant variant = ItemIconVariant::generic) noexcept {
    switch (category) {
    case ItemIconCategory::weapon:
        switch (variant) {
        case ItemIconVariant::sword: return "weapon_sword";
        case ItemIconVariant::greatsword: return "weapon_greatsword";
        case ItemIconVariant::dagger: return "weapon_dagger";
        case ItemIconVariant::warAxe: return "weapon_waraxe";
        case ItemIconVariant::battleAxe: return "weapon_battleaxe";
        case ItemIconVariant::mace: return "weapon_mace";
        case ItemIconVariant::bow: return "weapon_bow";
        case ItemIconVariant::staff: return "weapon_staff";
        case ItemIconVariant::crossbow: return "weapon_crossbow";
        case ItemIconVariant::warhammer: return "weapon_hammer";
        case ItemIconVariant::pickaxe: return "weapon_pickaxe";
        case ItemIconVariant::woodAxe: return "weapon_woodaxe";
        default: return "default_weapon";
        }
    case ItemIconCategory::armor:
        switch (variant) {
        case ItemIconVariant::lightHead: return "lightarmor_head";
        case ItemIconVariant::lightBody: return "lightarmor_body";
        case ItemIconVariant::lightHands: return "lightarmor_hands";
        case ItemIconVariant::lightForearms: return "lightarmor_forearms";
        case ItemIconVariant::lightFeet: return "lightarmor_feet";
        case ItemIconVariant::lightCalves: return "lightarmor_calves";
        case ItemIconVariant::lightShield: return "lightarmor_shield";
        case ItemIconVariant::heavyHead: return "armor_head";
        case ItemIconVariant::heavyBody: return "armor_body";
        case ItemIconVariant::heavyHands: return "armor_hands";
        case ItemIconVariant::heavyForearms: return "armor_forearms";
        case ItemIconVariant::heavyFeet: return "armor_feet";
        case ItemIconVariant::heavyCalves: return "armor_calves";
        case ItemIconVariant::heavyShield: return "armor_shield";
        case ItemIconVariant::clothingHead: return "clothing_head";
        case ItemIconVariant::clothingBody: return "clothing_body";
        case ItemIconVariant::clothingHands: return "clothing_hands";
        case ItemIconVariant::clothingForearms: return "clothing_forearms";
        case ItemIconVariant::clothingFeet: return "clothing_feet";
        case ItemIconVariant::clothingCalves: return "clothing_calves";
        case ItemIconVariant::clothingShield: return "clothing_shield";
        case ItemIconVariant::amulet: return "armor_amulet";
        case ItemIconVariant::ring: return "armor_ring";
        case ItemIconVariant::circlet: return "armor_circlet";
        default: return "default_armor";
        }
    case ItemIconCategory::alchemy:
        switch (variant) {
        case ItemIconVariant::health: return "potion_health";
        case ItemIconVariant::magicka: return "potion_magic";
        case ItemIconVariant::stamina: return "potion_stam";
        case ItemIconVariant::fireResist: return "potion_fire";
        case ItemIconVariant::shockResist: return "potion_shock";
        case ItemIconVariant::frostResist: return "potion_frost";
        case ItemIconVariant::poison: return "potion_poison";
        case ItemIconVariant::food: return "default_food";
        case ItemIconVariant::drink: return "food_wine";
        default: return "default_potion";
        }
    case ItemIconCategory::ingredient: return "default_ingredient";
    case ItemIconCategory::book:
        if (variant == ItemIconVariant::spellTome) return "book_tome";
        if (variant == ItemIconVariant::note) return "book_note";
        return "default_book";
    case ItemIconCategory::ammo: return variant == ItemIconVariant::bolt ? "weapon_bolt" : "weapon_arrow";
    case ItemIconCategory::soulGem:
        switch (variant) {
        case ItemIconVariant::soulEmpty: return "soulgem_empty";
        case ItemIconVariant::soulPartial: return "soulgem_partial";
        case ItemIconVariant::soulFull: return "soulgem_full";
        case ItemIconVariant::grandSoulEmpty: return "soulgem_grandempty";
        case ItemIconVariant::grandSoulPartial: return "soulgem_grandpartial";
        case ItemIconVariant::grandSoulFull: return "soulgem_grandfull";
        case ItemIconVariant::azuraSoul: return "soulgem_azura";
        default: return "misc_soulgem";
        }
    case ItemIconCategory::key: return "default_key";
    case ItemIconCategory::scroll: return "default_scroll";
    case ItemIconCategory::light: return "misc_torch";
    case ItemIconCategory::misc:
    default:
        switch (variant) {
        case ItemIconVariant::gem: return "misc_gem";
        case ItemIconVariant::dragonClaw: return "misc_dragonclaw";
        case ItemIconVariant::artifact: return "misc_artifact";
        case ItemIconVariant::leather: return "misc_leather";
        case ItemIconVariant::leatherStrips: return "misc_strips";
        case ItemIconVariant::hide: return "misc_hide";
        case ItemIconVariant::remains: return "misc_remains";
        case ItemIconVariant::ingot: return "misc_ingot";
        case ItemIconVariant::childrenClothes: return "clothing_body";
        case ItemIconVariant::firewood: return "misc_wood";
        case ItemIconVariant::clutter: return "misc_clutter";
        case ItemIconVariant::lockpick: return "misc_lockpick";
        case ItemIconVariant::gold: return "misc_gold";
        default: return "default_misc";
        }
    }
}

// Mirrors QuickLoot IE's armor-class order: ArmorType wins, then the two
// vendor keywords (clothing before jewelry), then its slot-based fallback.
constexpr ArmorIconClass armorIconClass(ArmorWeightClass weight, bool clothingKeyword, bool jewelryKeyword,
                                        ArmorPart mainPart, bool weddingWreath = false) noexcept {
    ArmorIconClass result = ArmorIconClass::other;
    if (weight == ArmorWeightClass::light) result = ArmorIconClass::light;
    else if (weight == ArmorWeightClass::heavy) result = ArmorIconClass::heavy;
    else if (clothingKeyword) result = ArmorIconClass::clothing;
    else if (jewelryKeyword) result = ArmorIconClass::jewelry;
    else {
        switch (mainPart) {
        case ArmorPart::head: case ArmorPart::hair: case ArmorPart::longHair:
        case ArmorPart::body: case ArmorPart::hands: case ArmorPart::forearms:
        case ArmorPart::feet: case ArmorPart::calves: case ArmorPart::shield: case ArmorPart::tail:
            result = ArmorIconClass::clothing; break;
        case ArmorPart::amulet: case ArmorPart::ring: case ArmorPart::circlet: case ArmorPart::ears:
            result = ArmorIconClass::jewelry; break;
        default: break;
        }
    }
    // QuickLoot IE applies this known-form override after its slot fallback.
    return weddingWreath ? ArmorIconClass::jewelry : result;
}

constexpr ItemIconVariant armorIconVariant(ArmorIconClass armorClass, ArmorPart part) noexcept {
    using V = ItemIconVariant;
    const auto jewelry = [part]() constexpr {
        switch (part) {
        case ArmorPart::amulet: return V::amulet;
        case ArmorPart::ring: return V::ring;
        case ArmorPart::circlet: return V::circlet;
        default: return V::generic;
        }
    };
    if (armorClass == ArmorIconClass::light || armorClass == ArmorIconClass::heavy) {
        const bool light = armorClass == ArmorIconClass::light;
        switch (part) {
        case ArmorPart::head: case ArmorPart::hair: case ArmorPart::longHair: return light ? V::lightHead : V::heavyHead;
        case ArmorPart::body: case ArmorPart::tail: return light ? V::lightBody : V::heavyBody;
        case ArmorPart::hands: return light ? V::lightHands : V::heavyHands;
        case ArmorPart::forearms: return light ? V::lightForearms : V::heavyForearms;
        case ArmorPart::feet: return light ? V::lightFeet : V::heavyFeet;
        case ArmorPart::calves: return light ? V::lightCalves : V::heavyCalves;
        case ArmorPart::shield: return light ? V::lightShield : V::heavyShield;
        default: return jewelry();
        }
    }
    if (armorClass == ArmorIconClass::jewelry) return jewelry();
    if (armorClass != ArmorIconClass::clothing) return V::generic;
    switch (part) {
    case ArmorPart::head: case ArmorPart::hair: case ArmorPart::longHair: return V::clothingHead;
    case ArmorPart::body: case ArmorPart::tail: return V::clothingBody;
    case ArmorPart::hands: return V::clothingHands;
    case ArmorPart::forearms: return V::clothingForearms;
    case ArmorPart::feet: return V::clothingFeet;
    case ArmorPart::calves: return V::clothingCalves;
    case ArmorPart::shield: return V::clothingShield;
    default: return V::generic;
    }
}

constexpr ItemIconSpec itemIconSpec(ItemIconCategory category, ItemIconVariant variant = ItemIconVariant::generic,
                                    SoulGemQuality soulQuality = SoulGemQuality::unknown) noexcept {
    ItemIconSpec out{itemIconLabel(category, variant), 0, false, category == ItemIconCategory::misc && variant == ItemIconVariant::gold};
    if (category == ItemIconCategory::weapon) { out.tint = 0xA4A5BF; out.hasTint = true; }
    else if (category == ItemIconCategory::ammo) { out.tint = 0xA89E8C; out.hasTint = true; }
    else if (category == ItemIconCategory::armor) {
        out.tint = 0xEDDA87; out.hasTint = true;
        if (variant >= ItemIconVariant::lightHead && variant <= ItemIconVariant::lightShield) out.tint = 0x756000;
        else if (variant >= ItemIconVariant::heavyHead && variant <= ItemIconVariant::heavyShield) out.tint = 0x6B7585;
    } else if (category == ItemIconCategory::alchemy) {
        switch (variant) {
        case ItemIconVariant::health: out.tint = 0xDB2E73; out.hasTint = true; break;
        case ItemIconVariant::magicka: out.tint = 0x2E9FDB; out.hasTint = true; break;
        case ItemIconVariant::stamina: out.tint = 0x51DB2E; out.hasTint = true; break;
        case ItemIconVariant::fireResist: out.tint = 0xC73636; out.hasTint = true; break;
        case ItemIconVariant::shockResist: out.tint = 0xEAAB00; out.hasTint = true; break;
        case ItemIconVariant::frostResist: out.tint = 0x1FFBFF; out.hasTint = true; break;
        case ItemIconVariant::poison: out.tint = 0xAD00B3; out.hasTint = true; break;
        default: break;
        }
    } else if (category == ItemIconCategory::scroll) {
        if (variant == ItemIconVariant::fireResist) { out.tint = 0xC73636; out.hasTint = true; }
        else if (variant == ItemIconVariant::shockResist) { out.tint = 0xFFFF00; out.hasTint = true; }
        else if (variant == ItemIconVariant::frostResist) { out.tint = 0x1FFBFF; out.hasTint = true; }
    } else if (category == ItemIconCategory::soulGem) {
        switch (soulQuality) {
        case SoulGemQuality::petty: out.tint = 0xD7D4FF; out.hasTint = true; break;
        case SoulGemQuality::lesser: out.tint = 0xC0BAFF; out.hasTint = true; break;
        case SoulGemQuality::common: out.tint = 0xABA3FF; out.hasTint = true; break;
        case SoulGemQuality::greater: out.tint = 0x948BFC; out.hasTint = true; break;
        case SoulGemQuality::grand: case SoulGemQuality::azura: out.tint = 0x7569FF; out.hasTint = true; break;
        default: out.tint = 0xE3E0FF; out.hasTint = true; break;
        }
    } else if (category == ItemIconCategory::misc) {
        switch (variant) {
        case ItemIconVariant::gem: out.tint = 0xFFB0D1; out.hasTint = true; break;
        case ItemIconVariant::leather: case ItemIconVariant::leatherStrips: out.tint = 0xBA8D23; out.hasTint = true; break;
        case ItemIconVariant::hide: out.tint = 0xDBB36E; out.hasTint = true; break;
        case ItemIconVariant::ingot: out.tint = 0x828282; out.hasTint = true; break;
        case ItemIconVariant::childrenClothes: out.tint = 0xEDDA87; out.hasTint = true; break;
        case ItemIconVariant::firewood: out.tint = 0xA89E8C; out.hasTint = true; break;
        case ItemIconVariant::gold: out.tint = 0xCCCC33; out.hasTint = true; break;
        default: break;
        }
    }
    return out;
}

constexpr ItemIconSpec armorIconSpec(ArmorIconClass armorClass, ArmorPart part) noexcept {
    const auto variant = armorIconVariant(armorClass, part);
    auto out = itemIconSpec(ItemIconCategory::armor, variant);
    out.tint = armorClass == ArmorIconClass::light ? 0x756000 :
               armorClass == ArmorIconClass::heavy ? 0x6B7585 : 0xEDDA87;
    out.hasTint = true;
    return out;
}

constexpr bool isKnownItemIconLabel(std::string_view label) noexcept {
    constexpr std::array labels{
        "default_misc", "default_weapon", "weapon_sword", "weapon_dagger", "weapon_waraxe", "weapon_mace",
        "weapon_greatsword", "weapon_battleaxe", "weapon_hammer", "weapon_bow", "weapon_crossbow", "weapon_staff",
        "weapon_pickaxe", "weapon_woodaxe", "weapon_arrow", "weapon_bolt", "default_armor",
        "lightarmor_head", "lightarmor_body", "lightarmor_hands", "lightarmor_forearms", "lightarmor_feet", "lightarmor_calves", "lightarmor_shield",
        "armor_head", "armor_body", "armor_hands", "armor_forearms", "armor_feet", "armor_calves", "armor_shield", "armor_amulet", "armor_ring", "armor_circlet",
        "clothing_head", "clothing_body", "clothing_hands", "clothing_forearms", "clothing_feet", "clothing_calves", "clothing_shield",
        "default_potion", "potion_health", "potion_magic", "potion_stam", "potion_fire", "potion_shock", "potion_frost", "potion_poison", "default_food", "food_wine",
        "default_ingredient", "default_book", "book_note", "book_tome", "misc_soulgem", "soulgem_empty", "soulgem_partial", "soulgem_full",
        "soulgem_grandempty", "soulgem_grandpartial", "soulgem_grandfull", "soulgem_azura", "default_key", "default_scroll", "misc_torch",
        "misc_gem", "misc_dragonclaw", "misc_artifact", "misc_leather", "misc_strips", "misc_hide", "misc_remains", "misc_ingot", "misc_wood", "misc_clutter", "misc_lockpick", "misc_gold"
    };
    for (const auto candidate : labels) if (label == candidate) return true;
    return false;
}
}  // namespace qld
