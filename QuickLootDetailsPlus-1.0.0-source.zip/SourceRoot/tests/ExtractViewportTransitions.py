"""Compile exact Plugin transition statements with host boundary doubles, not GFx."""
import sys
from pathlib import Path
p=Path(sys.argv[1]).read_text(encoding='utf-8')
def function(signature):
 start=p.index(signature)
 opening=p.index('{',start)
 depth=1
 end=opening+1
 while depth:
  depth+=(p[end]=='{')-(p[end]=='}')
  end+=1
 return p[start:end]
sync=function('bool syncViewport(RE::GFxMovieView* source)')
start=p.index('if(visible && useWorld){')
end=p.index('auto& item=*frame.selected;',start)
transition=p[start:end]
commit='wasVisible_=true; lastRevision_=frame.revision; lastBounds_=panel;'
assert commit in p
assert transition.count('uiMovie->Invoke("_root.qldRender"')==1
out=Path(sys.argv[2])
out.parent.mkdir(parents=True,exist_ok=True)
out.write_text(sync+'\nvoid advance(bool visible,bool useWorld){\n'+transition+
 '\n++draws;uiMovie->shown=true;\n'+commit+'\n}\n',encoding='utf-8')
print('Extracted exact syncViewport, AdvanceMovie visibility/placement/guard and success commit.')
