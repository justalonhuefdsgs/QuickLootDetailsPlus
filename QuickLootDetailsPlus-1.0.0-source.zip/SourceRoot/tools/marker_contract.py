"""Compare native expected marker, AS2 qldProbe return, and compiled AVM1 qldProbe return."""
from __future__ import annotations
import argparse
import hashlib
import json
import re
import struct
import sys
import zipfile
import zlib
from pathlib import Path


class MarkerContractError(ValueError):
    pass


def _cstring(data: bytes, pos: int) -> tuple[str, int]:
    end = data.find(b'\0', pos)
    if end < 0:
        raise MarkerContractError('unterminated AVM1 string')
    try:
        value = data[pos:end].decode('utf-8')
    except UnicodeDecodeError as exc:
        raise MarkerContractError(f'invalid AVM1 UTF-8 string: {exc}') from exc
    return value, end + 1


def _parse_push(record: bytes, pool: tuple[str, ...]) -> list[tuple[str, object]]:
    pos = 0
    values: list[tuple[str, object]] = []
    while pos < len(record):
        kind = record[pos]
        pos += 1
        if kind == 0:
            value, pos = _cstring(record, pos)
            values.append(('string', value))
        elif kind in (2, 3):
            values.append(('other', 'null' if kind == 2 else 'undefined'))
        elif kind == 4:
            if pos + 1 > len(record): raise MarkerContractError('truncated Push register')
            values.append(('other', 'register'))
            pos += 1
        elif kind == 5:
            if pos + 1 > len(record): raise MarkerContractError('truncated Push bool')
            values.append(('other', 'bool'))
            pos += 1
        elif kind in (1, 7):
            if pos + 4 > len(record): raise MarkerContractError('truncated Push number')
            values.append(('other', 'number'))
            pos += 4
        elif kind == 6:
            if pos + 8 > len(record): raise MarkerContractError('truncated Push double')
            values.append(('other', 'double'))
            pos += 8
        elif kind in (8, 9):
            width = 1 if kind == 8 else 2
            if pos + width > len(record): raise MarkerContractError('truncated Push constant index')
            index = int.from_bytes(record[pos:pos + width], 'little')
            pos += width
            if index >= len(pool): raise MarkerContractError(f'Push references missing constant-pool index {index}')
            values.append(('string', pool[index]))
        else:
            raise MarkerContractError(f'unsupported AVM1 Push value type {kind}')
    return values


def _walk_actions(data: bytes, pool: tuple[str, ...], name: str, functions: dict[str, dict[str, object]], depth: int = 0, require_end: bool = True) -> None:
    if depth > 64:
        raise MarkerContractError('AVM1 function nesting is too deep')
    pos = 0
    while pos < len(data):
        code = data[pos]
        pos += 1
        size = 0
        if code >= 0x80:
            if pos + 2 > len(data): raise MarkerContractError(f'{name}: short AVM1 action header')
            size = struct.unpack_from('<H', data, pos)[0]
            pos += 2
        end = pos + size
        if end > len(data): raise MarkerContractError(f'{name}: action payload exceeds block')
        record = data[pos:end]
        pos = end
        if name in functions and code not in (0, 0x88):
            functions[name]['opcodes'].append(code)
        if code == 0:
            if pos != len(data): raise MarkerContractError(f'{name}: trailing bytes after ActionEnd')
            return
        if code == 0x88:  # ActionConstantPool
            if len(record) < 2: raise MarkerContractError(f'{name}: short ActionConstantPool')
            count = struct.unpack_from('<H', record)[0]
            q = 2
            values = []
            for _ in range(count):
                value, q = _cstring(record, q)
                values.append(value)
            if q != len(record): raise MarkerContractError(f'{name}: malformed ActionConstantPool')
            pool = tuple(values)
        elif code == 0x96:  # ActionPush
            values = _parse_push(record, pool)
            if name in functions:
                functions[name]['push_values'].extend(values)
        elif code == 0x3E:  # ActionReturn
            if size != 0: raise MarkerContractError(f'{name}: malformed ActionReturn')
            if name in functions:
                functions[name]['return_count'] += 1
        elif code in (0x99, 0x9D):  # ActionJump/ActionIf
            if size != 2: raise MarkerContractError(f'{name}: malformed branch action')
            if name in functions:
                functions[name]['branch_count'] += 1
        elif code in (0x9B, 0x8E):  # ActionDefineFunction / Function2
            function_name, q = _cstring(record, 0)
            if q + 2 > len(record): raise MarkerContractError(f'{name}: short function header')
            parameter_count = struct.unpack_from('<H', record, q)[0]
            q += 2
            if code == 0x8E:
                if q + 3 > len(record): raise MarkerContractError(f'{name}: short Function2 flags')
                q += 3
            parameters = []
            for _ in range(parameter_count):
                if code == 0x8E:
                    if q + 1 > len(record): raise MarkerContractError(f'{name}: short parameter register')
                    q += 1
                parameter, q = _cstring(record, q)
                parameters.append(parameter)
            if q + 2 != len(record): raise MarkerContractError(f'{name}: malformed function header size')
            body_size = struct.unpack_from('<H', record, q)[0]
            if pos + body_size > len(data): raise MarkerContractError(f'{name}: function body exceeds action block')
            if not function_name:
                function_name = f'{name}/anonymous@{pos}'
            if function_name in functions:
                raise MarkerContractError(f'duplicate AVM1 function {function_name}')
            functions[function_name] = {
                'parameters': parameters, 'opcodes': [], 'push_values': [],
                'return_count': 0, 'branch_count': 0,
            }
            _walk_actions(data[pos:pos + body_size], pool, function_name, functions, depth + 1, False)
            pos += body_size
        elif code == 0x94:  # ActionWith
            if size != 2: raise MarkerContractError(f'{name}: malformed ActionWith')
            body_size = struct.unpack('<H', record)[0]
            if pos + body_size > len(data): raise MarkerContractError(f'{name}: ActionWith body exceeds action block')
            _walk_actions(data[pos:pos + body_size], pool, name + '/with', functions, depth + 1, False)
            pos += body_size

    if require_end and (not data or data[-1] != 0):
        raise MarkerContractError(f'{name}: AVM1 action block has no ActionEnd')


def swf_probe_return(data: bytes) -> str:
    if len(data) < 12 or data[:3] not in (b'FWS', b'CWS'):
        raise MarkerContractError('unsupported or truncated SWF header')
    declared_size = struct.unpack_from('<I', data, 4)[0]
    try:
        body = zlib.decompress(data[8:]) if data[:3] == b'CWS' else data[8:]
    except zlib.error as exc:
        raise MarkerContractError(f'compressed SWF body is invalid: {exc}') from exc
    if declared_size != len(body) + 8:
        raise MarkerContractError('SWF declared uncompressed size does not match body')
    if not body:
        raise MarkerContractError('SWF body is empty')
    nbits = body[0] >> 3
    pos = (5 + 4 * nbits + 7) // 8 + 4
    action_blocks = []
    tags = []
    while pos < len(body):
        if pos + 2 > len(body): raise MarkerContractError('truncated SWF tag header')
        header = struct.unpack_from('<H', body, pos)[0]
        pos += 2
        size = header & 63
        if size == 63:
            if pos + 4 > len(body): raise MarkerContractError('truncated extended SWF tag length')
            size = struct.unpack_from('<I', body, pos)[0]
            pos += 4
        end = pos + size
        if end > len(body): raise MarkerContractError('SWF tag exceeds body')
        tag = header >> 6
        tags.append(tag)
        if tag == 12:
            action_blocks.append(body[pos:end])
        pos = end
        if tag == 0:
            break
    if pos != len(body) or tags[-1:] != [0]:
        raise MarkerContractError('SWF tag stream does not end cleanly')
    if len(action_blocks) != 1:
        raise MarkerContractError(f'expected exactly one DoAction block; found {len(action_blocks)}')
    functions: dict[str, dict[str, object]] = {}
    _walk_actions(action_blocks[0], (), '<root>', functions)
    probe = functions.get('qldProbe')
    if probe is None:
        raise MarkerContractError('compiled SWF has no qldProbe function')
    if probe['parameters']:
        raise MarkerContractError('compiled qldProbe unexpectedly has parameters')
    values = probe['push_values']
    if len(values) != 1 or values[0][0] != 'string':
        raise MarkerContractError('compiled qldProbe does not push exactly one string literal')
    if probe['opcodes'] != [0x96, 0x3E] or probe['return_count'] != 1 or probe['branch_count'] != 0:
        raise MarkerContractError('compiled qldProbe is not a direct, single-literal return')
    marker = values[0][1]
    if not isinstance(marker, str) or not marker.startswith('QLD_UI_'):
        raise MarkerContractError(f'compiled qldProbe returned an invalid marker: {marker!r}')
    return marker


def source_contract(root: Path) -> dict[str, str]:
    plugin = (root / 'src' / 'Plugin.cpp').read_text(encoding='utf-8-sig')
    panel = (root / 'ui' / 'panel.as').read_text(encoding='utf-8-sig')
    native = re.findall(r'\bconstexpr\s+auto\s+expectedProbe\s*=\s*"([^"]+)"\s*;', plugin)
    if len(native) != 1:
        raise MarkerContractError(f'expected exactly one native expectedProbe literal; found {len(native)}')
    probes = re.findall(r'\bfunction\s+qldProbe\s*\(\s*\)\s*\{\s*return\s+"([^"\\]+)"\s*;\s*\}', panel, re.S)
    if len(probes) != 1:
        raise MarkerContractError(f'expected one qldProbe direct string return in AS2 source; found {len(probes)}')
    routes = re.findall(r'(?m)^\s*var\s+QLD_CATEGORY_ICON_ROUTE\s*=\s*"([^"]+)"\s*;', panel)
    if len(routes) != 1:
        raise MarkerContractError(f'expected one QLD_CATEGORY_ICON_ROUTE selector; found {len(routes)}')
    return {'native_expected': native[0], 'as2_return': probes[0], 'route': routes[0]}


def verify_marker_contract(root: Path, swf_data: bytes) -> dict[str, object]:
    source = source_contract(root)
    actual = swf_probe_return(swf_data)
    values = [source['native_expected'], source['as2_return'], actual]
    if len(set(values)) != 1:
        raise MarkerContractError(
            'marker mismatch: native=' + repr(values[0]) + ', AS2=' + repr(values[1]) + ', compiled_SWF_qldProbe_return=' + repr(values[2])
        )
    return {
        'status': 'PASS', 'native_expected': values[0], 'as2_source_qldProbe_return': values[1],
        'compiled_swf_qldProbe_return': actual, 'marker': actual, 'category_route': source['route'],
        'compiled_swf_sha256': hashlib.sha256(swf_data).hexdigest(),
    }


def verify_dll_binding(root: Path, swf_data: bytes, icon_swf_data: bytes, dll_data: bytes) -> dict[str, object]:
    from build_identity import read_identity_data, verify_binary
    contract = verify_marker_contract(root, swf_data)
    identity = read_identity_data(root, swf_data, icon_swf_data)
    verify_binary(dll_data, identity)
    if contract['marker'] != identity['ui_probe_marker']:
        raise MarkerContractError('compiled DLL identity marker differs from source/SWF marker')
    return {'marker_contract': contract, 'identity': identity, 'dll_sha256': hashlib.sha256(dll_data).hexdigest(), 'status': 'PASS'}


def verify_runtime_zip(root: Path, archive_path: Path) -> dict[str, object]:
    with zipfile.ZipFile(archive_path) as archive:
        bad = archive.testzip()
        if bad:
            raise MarkerContractError(f'runtime ZIP CRC failure: {bad}')
        names = archive.namelist()
        if len(names) != len(set(names)):
            raise MarkerContractError('runtime ZIP has duplicate member names')
        swf_name = 'Interface/QuickLootDetails.swf'
        icon_swf_name = 'Interface/QuickLootDetails_CategoryIcons.swf'
        dll_name = 'SKSE/Plugins/QuickLootDetails.dll'
        if swf_name not in names or icon_swf_name not in names or dll_name not in names:
            raise MarkerContractError('runtime ZIP is missing the paired main SWF, category-icon SWF, or DLL')
        swf_data = archive.read(swf_name)
        icon_swf_data = archive.read(icon_swf_name)
        dll_data = archive.read(dll_name)
    result = verify_dll_binding(root, swf_data, icon_swf_data, dll_data)
    result['category_icon_swf_sha256'] = hashlib.sha256(icon_swf_data).hexdigest()
    result['runtime_zip'] = archive_path.name
    result['runtime_zip_sha256'] = hashlib.sha256(archive_path.read_bytes()).hexdigest()
    result['runtime_swf_sha256'] = hashlib.sha256(swf_data).hexdigest()
    result['runtime_dll_sha256'] = hashlib.sha256(dll_data).hexdigest()
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument('--swf', type=Path)
    parser.add_argument('--icon-swf', type=Path)
    parser.add_argument('--dll', type=Path)
    parser.add_argument('--runtime-zip', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    try:
        if args.runtime_zip:
            result = verify_runtime_zip(args.root, args.runtime_zip)
        else:
            if not args.swf:
                raise MarkerContractError('provide --swf or --runtime-zip')
            if not args.icon_swf:
                raise MarkerContractError('--icon-swf is required to bind both 065 UI movies')
            swf_data = args.swf.read_bytes()
            icon_swf_data = args.icon_swf.read_bytes()
            result = verify_marker_contract(args.root, swf_data)
            result['category_icon_swf_sha256'] = hashlib.sha256(icon_swf_data).hexdigest()
            if args.dll:
                result = verify_dll_binding(args.root, swf_data, icon_swf_data, args.dll.read_bytes())
        text = json.dumps(result, indent=2, ensure_ascii=False)
        if args.output:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(text + '\n', encoding='utf-8')
        print('MARKER_GATE_PASS ' + ' '.join(f'{k}={result[k]}' for k in ('status', 'marker') if k in result))
        print(text)
        return 0
    except (OSError, ValueError, AssertionError, KeyError, zipfile.BadZipFile, zlib.error) as exc:
        print(f'MARKER_GATE_FAIL {exc}', file=sys.stderr)
        return 1

if __name__ == '__main__':
    raise SystemExit(main())
