# QuickLoot Details candidate 065 build

This candidate is a private, un-deployed integration scaffold. Its current 061 individual SVGs remain provisional pending the user's later review; 060-v3 establishes the design direction only. Build outputs belong in this candidate copy. Do not point the build at another task's source or build directory.

## UI movies

Set `QLD_JAVA` and `QLD_FFDEC` to existing local tools. The build accepts only the explicitly recorded JPEXS FFDec 23.0.1 JAR (`84088e1c955ae649c22ca3e3d8ac8bfa59eeba6f10a18fa77eccd2f91d801a84`) or 26.3.0 JAR (`1587e60b2ec2c0e4f5721fd5f2aaaf2379f6d416569de99054b5c5d1e9ba841c`). The direct 057 parent and its actual marker-build record use 23.0.1; the earlier 049 record uses 26.3.0. This candidate uses the available exact 057 toolchain for both movies, with no version split. No tool is installed or downloaded. From this source root, run `python tools/build_assets.py --ui-only`. The command imports the 80 item SVGs and four overlay SVGs from `assets/category-icons/svg/individual` and `assets/category-icons/svg/overlays`, creates `build/assets/Interface/QuickLootDetails_CategoryIcons.swf`, replaces the four existing marker slots with the 061 overlay SVGs, builds `QuickLootDetails.swf`, and exports its compiled AS2 source. It refuses to overwrite an existing main SWF.

## Native build and tests

Run `python tools/render_icon_previews.py --root . --preview ../../preview --temp ../../temp`, then `tools/build.ps1 -ExitDiagnostics -Jobs 2 -BuildRoot <candidate-local-build-root> -UiSwf <exact-main-SWF> -IconSwf <exact-category-icon-SWF>`. The selected job limit is intentionally small. Native source defaults remain `QLD_EXIT_DIAGNOSTICS=OFF` and `QLD_DIAGNOSTIC_LOGGING=OFF`; the private review build enables bounded exit diagnostics and keeps generic logging off. Full CTest includes the AS2 route, all-label frame mapping, imported-vector, marker binding, and inherited native regressions.

## Private package

`tools/pe_pdb_identity_065.py` checks the DLL CodeView RSDS GUID/age against the PDB MSF Info stream. `tools/package_private_065.py` accepts only the 057 parent source/runtime archives, candidate-local build evidence, the matching DLL/PDB identity, both tested SWFs, and the source manifest. It writes private source and runtime review ZIPs under the candidate `dist` directory, then verifies member allowlists, CRCs, member hashes, re-extraction bytes, both SWF hashes, and DLL/PDB CodeView identity. These ZIPs are not deployed or published.

The 061 symbol mapping and source provenance do not grant external distribution permission. No Skyrim Scaleform or game test is claimed.
