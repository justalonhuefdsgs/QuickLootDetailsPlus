"""Build the owned category-icon SWF from the 061 individual SVG files."""
from __future__ import annotations

import hashlib
import json
import shutil
import struct
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Callable

SVG_NS = "http://www.w3.org/2000/svg"
SHAPE_IDS_START = 1000
FORBIDDEN_SWF_TAGS = {
    6, 8, 10, 11, 13, 14, 17, 18, 19, 20, 21, 35, 36, 37, 48, 60, 73, 75,
}


class IconLibraryError(ValueError):
    pass


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _local_name(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def validate_svg(path: Path) -> None:
    try:
        root = ET.parse(path).getroot()
    except (ET.ParseError, OSError) as exc:
        raise IconLibraryError(f"invalid SVG {path}: {exc}") from exc
    if root.tag != f"{{{SVG_NS}}}svg" or root.get("viewBox") != "0 0 64 64":
        raise IconLibraryError(f"SVG root/viewBox differs from the 061 contract: {path.name}")
    for element in root.iter():
        name = _local_name(element.tag)
        if name in {"text", "image", "foreignObject", "style", "font", "font-face"}:
            raise IconLibraryError(f"non-static or text SVG element {name!r} in {path.name}")
        for key, value in element.attrib.items():
            local = _local_name(key).lower()
            if local == "href" or local in {"font-family", "font-size"}:
                raise IconLibraryError(f"external reference or font property {key!r} in {path.name}")
            if "url(" in value.casefold():
                raise IconLibraryError(f"URL reference in {key!r} in {path.name}")


def _tag(tag_id: int, payload: bytes) -> bytes:
    if len(payload) < 63:
        return struct.pack("<H", (tag_id << 6) | len(payload)) + payload
    return struct.pack("<HI", (tag_id << 6) | 63, len(payload)) + payload


def _rect_64px() -> bytes:
    # 64 px at 20 twips per pixel, using the same 16-bit RECT coordinate
    # width as the established 057 seed-SWF builder.
    bits = "10000" + "0" * 16 + format(1280, "016b") + "0" * 16 + format(1280, "016b")
    bits += "0" * (-len(bits) % 8)
    return int(bits, 2).to_bytes(len(bits) // 8, "big")


def _empty_shape(shape_id: int) -> bytes:
    # SVG import scales to this rectangle; zero bounds collapse every vector edge.
    return _tag(2, struct.pack("<H", shape_id) + _rect_64px() + b"\0" * 4)


def _shape_has_area(payload: bytes) -> bool:
    if len(payload) < 3:
        return False
    bits = "".join(f"{byte:08b}" for byte in payload[2:])
    n = int(bits[:5], 2)
    if n == 0 or len(bits) < 5 + 4 * n:
        return False
    values = [int(bits[5+i*n:5+(i+1)*n], 2) for i in range(4)]
    values = [v-(1 << n) if v & (1 << (n-1)) else v for v in values]
    return values[1] > values[0] and values[3] > values[2]


def _frame_label(label: str) -> bytes:
    return _tag(43, label.encode("ascii") + b"\0")


def _place(shape_id: int, depth: int = 1) -> bytes:
    return _tag(26, b"\x02" + struct.pack("<HH", depth, shape_id))


def _remove(depth: int = 1) -> bytes:
    return _tag(28, struct.pack("<H", depth))


def _build_seed(shape_ids: list[int], active: list[tuple[str, int]]) -> bytes:
    frame_count = 1 + len(active)
    body = bytearray(_rect_64px())
    body.extend(struct.pack("<HH", 24 * 256, frame_count))
    body.extend(_tag(69, b"\0" * 4))  # FileAttributes
    for shape_id in shape_ids:
        body.extend(_empty_shape(shape_id))
    body.extend(_tag(1, b""))  # Frame 1 intentionally blank for the legacy AS2 frame guard.
    for label, shape_id in active:
        body.extend(_frame_label(label))
        body.extend(_remove())
        body.extend(_place(shape_id))
        body.extend(_tag(1, b""))
    body.extend(_tag(0, b""))
    return b"FWS\x08" + struct.pack("<I", 8 + len(body)) + bytes(body)


def swf_tags(data: bytes) -> tuple[int, list[tuple[int, bytes]]]:
    if len(data) < 12 or data[:3] not in (b"FWS", b"CWS"):
        raise IconLibraryError("unsupported or truncated SWF")
    declared = struct.unpack_from("<I", data, 4)[0]
    try:
        body = __import__("zlib").decompress(data[8:]) if data[:3] == b"CWS" else data[8:]
    except Exception as exc:
        raise IconLibraryError(f"invalid SWF compression: {exc}") from exc
    if len(body) + 8 != declared:
        raise IconLibraryError("SWF declared size does not match its body")
    nbits = body[0] >> 3
    pos = (5 + 4 * nbits + 7) // 8
    if pos + 4 > len(body):
        raise IconLibraryError("SWF header is truncated")
    frame_count = struct.unpack_from("<H", body, pos + 2)[0]
    pos += 4
    tags: list[tuple[int, bytes]] = []
    while pos < len(body):
        if pos + 2 > len(body):
            raise IconLibraryError("truncated SWF tag header")
        header = struct.unpack_from("<H", body, pos)[0]
        pos += 2
        length = header & 63
        if length == 63:
            if pos + 4 > len(body):
                raise IconLibraryError("truncated extended SWF tag length")
            length = struct.unpack_from("<I", body, pos)[0]
            pos += 4
        end = pos + length
        if end > len(body):
            raise IconLibraryError("SWF tag exceeds body")
        tag_id = header >> 6
        tags.append((tag_id, body[pos:end]))
        pos = end
        if tag_id == 0:
            break
    if pos != len(body) or not tags or tags[-1][0] != 0:
        raise IconLibraryError("SWF tag stream does not end cleanly")
    return frame_count, tags


def inventory(data: bytes) -> dict[str, object]:
    frame_count, tags = swf_tags(data)
    shapes: dict[int, int] = {}
    labels: dict[str, int] = {}
    frame_shapes: dict[int, int] = {}
    frame = 1
    label: str | None = None
    display: dict[int, int] = {}
    for tag_id, payload in tags:
        if tag_id in (2, 22, 32, 83):
            if len(payload) < 2:
                raise IconLibraryError("truncated DefineShape tag")
            shape_id = struct.unpack_from("<H", payload)[0]
            if shape_id in shapes:
                raise IconLibraryError(f"duplicate SWF shape ID {shape_id}")
            shapes[shape_id] = len(payload)
        elif tag_id in FORBIDDEN_SWF_TAGS:
            raise IconLibraryError(f"embedded image/font/text SWF tag {tag_id} is forbidden")
        elif tag_id == 43:
            raw = payload.split(b"\0", 1)[0]
            try:
                label = raw.decode("ascii")
            except UnicodeDecodeError as exc:
                raise IconLibraryError("non-ASCII category frame label") from exc
        elif tag_id == 26:
            if len(payload) < 3:
                raise IconLibraryError("truncated PlaceObject2")
            flags = payload[0]
            depth = struct.unpack_from("<H", payload, 1)[0]
            offset = 3
            if flags & 2:
                if offset + 2 > len(payload):
                    raise IconLibraryError("truncated PlaceObject2 character ID")
                display[depth] = struct.unpack_from("<H", payload, offset)[0]
                offset += 2
            if flags & 4:
                offset += 1
            if flags & 8:
                offset += 4
            if flags & 16:
                offset += 2
            if flags & 32:
                end = payload.find(b"\0", offset)
                if end < 0:
                    raise IconLibraryError("truncated PlaceObject2 instance name")
        elif tag_id == 28:
            if len(payload) != 2:
                raise IconLibraryError("malformed RemoveObject2")
            display.pop(struct.unpack_from("<H", payload)[0], None)
        elif tag_id == 1:
            if label is not None:
                if label in labels:
                    raise IconLibraryError(f"duplicate frame label {label}")
                labels[label] = frame
                if 1 in display:
                    frame_shapes[frame] = display[1]
                label = None
            frame += 1
    if frame - 1 != frame_count:
        raise IconLibraryError(f"frame count mismatch: header {frame_count}, tags {frame - 1}")
    return {"frame_count": frame_count, "shape_payload_bytes": shapes, "frame_labels": labels, "label_shape_ids": frame_shapes,
            "forbidden_tag_count": sum(tag_id in FORBIDDEN_SWF_TAGS for tag_id, _ in tags)}


def build_icon_movie(root: Path, out_dir: Path, import_shapes: Callable[..., None], tool_identity: dict[str, object]) -> dict[str, object]:
    """Reproducibly convert all 84 061 SVGs into a labelled, static-vector SWF."""
    asset_root = root / "assets" / "category-icons"
    mapping = json.loads((asset_root / "manifest" / "icon_mapping.json").read_text(encoding="utf-8-sig"))
    overlays = json.loads((asset_root / "manifest" / "overlay_mapping.json").read_text(encoding="utf-8-sig"))
    items = mapping.get("items")
    source_labels = mapping.get("source_labels")
    if not isinstance(items, list) or len(items) != 80 or not isinstance(source_labels, list) or len(source_labels) != 78:
        raise IconLibraryError("061 mapping must contain 80 base assets and 78 active source labels")
    if not isinstance(overlays, list) or len(overlays) != 4:
        raise IconLibraryError("061 mapping must contain four independent overlays")
    active = [item["label"] for item in items if item.get("source_label") is True]
    if active != source_labels or len(set(active)) != 78:
        raise IconLibraryError("061 active label order/count differs from the mapping")
    symbols = [item.get("symbol_id") for item in items] + [item.get("symbol_id") for item in overlays]
    if len(symbols) != 84 or len(set(symbols)) != 84:
        raise IconLibraryError("061 must provide 84 unique source symbol IDs")

    shape_records: list[dict[str, object]] = []
    source_dir = out_dir / "icon-shape-svg"
    source_dir.mkdir(parents=True, exist_ok=False)
    for offset, entry in enumerate(items + overlays):
        relative = entry.get("asset_path")
        if not isinstance(relative, str) or relative.startswith(("/", "\\")) or ".." in Path(relative).parts:
            raise IconLibraryError(f"unsafe SVG mapping path: {relative!r}")
        source_svg = asset_root / relative
        validate_svg(source_svg)
        svg_data = source_svg.read_bytes()
        shape_id = SHAPE_IDS_START + offset
        (source_dir / f"{shape_id}.svg").write_bytes(svg_data)
        shape_records.append({"shape_id": shape_id, "symbol_id": entry["symbol_id"], "label": entry.get("label"),
                             "source_label": bool(entry.get("source_label", False)), "overlay_only": bool(entry.get("overlay_only", False)),
                             "source_svg": f"assets/category-icons/{relative}", "source_svg_sha256": sha256(svg_data),
                             "source_svg_bytes": len(svg_data)})
    by_label = {str(record["label"]): int(record["shape_id"]) for record in shape_records if record["label"] is not None}
    active_frames = [(label, by_label[label]) for label in source_labels]
    seed = out_dir / "category-icons-seed.swf"
    shaped = out_dir / "category-icons-shaped.swf"
    target = out_dir / "assets" / "Interface" / "QuickLootDetails_CategoryIcons.swf"
    seed.write_bytes(_build_seed([int(record["shape_id"]) for record in shape_records], active_frames))
    import_shapes(seed, shaped, source_dir)
    swf_data = shaped.read_bytes()
    info = inventory(swf_data)
    _, imported_tags = swf_tags(swf_data)
    if any(not _shape_has_area(payload) for tag, payload in imported_tags if tag in (2, 22, 32, 83)):
        raise IconLibraryError("imported category vector has zero-area bounds")
    payloads = info["shape_payload_bytes"]
    expected_ids = {int(record["shape_id"]) for record in shape_records}
    if set(payloads) != expected_ids or any(payloads[shape_id] <= 8 for shape_id in expected_ids):
        raise IconLibraryError("FFDec did not import every 061 source as a non-empty static vector shape")
    if list(info["frame_labels"].keys()) != active or len(info["frame_labels"]) != 78:
        raise IconLibraryError("compiled sidecar frame labels do not match all 78 active source labels in order")
    expected_frame_map = {label: index + 2 for index, label in enumerate(active)}
    if info["frame_labels"] != expected_frame_map:
        raise IconLibraryError("compiled sidecar frame indices do not preserve the blank first frame and active order")
    expected_frame_shapes = {index + 2: by_label[label] for index, label in enumerate(active)}
    if info["label_shape_ids"] != expected_frame_shapes:
        raise IconLibraryError("compiled sidecar frame label-to-shape route differs from the full mapping")
    if info["forbidden_tag_count"]:
        raise IconLibraryError("compiled sidecar contains a bitmap, font, or text SWF tag")
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(shaped, target)
    record = {
        "status": "PASS", "converter": "JPEXS Free Flash Decompiler", "tool_version": tool_identity["version"],
        "tool_jar_name": tool_identity["jar_name"], "tool_jar_sha256": tool_identity["jar_sha256"],
        "operation": "-importShapes", "source_mapping_sha256": sha256((asset_root / "manifest" / "icon_mapping.json").read_bytes()),
        "overlay_mapping_sha256": sha256((asset_root / "manifest" / "overlay_mapping.json").read_bytes()),
        "source_label_count": 78, "source_labels": active, "base_asset_count": 80, "overlay_asset_count": 4,
        "symbol_count": 84, "shape_records": shape_records, "frame_labels": info["frame_labels"],
        "frame_shape_ids": {label: by_label[label] for label in active}, "blank_first_frame": True,
        "frame_count": info["frame_count"], "sidecar_relative_path": "Interface/QuickLootDetails_CategoryIcons.swf",
        "sidecar_sha256": sha256(swf_data), "sidecar_bytes": len(swf_data),
        "embedded_font_text_bitmap_or_external_reference": False,
        "limits": "Static vector import and SWF frame-label drawing are verified; Skyrim Scaleform and in-game placement remain unverified.",
    }
    report_path = out_dir / "category-icon-build-record.json"
    report_path.write_text(json.dumps(record, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return record
