// Run the compiled SWF's AVM1/AS2 with synthetic TextField metrics; not game GFx.
const fs=require('fs'),vm=require('vm'),assert=require('assert');
let iconLoadCount=0;
const ctx={Math,isFinite,stop(){},_global:{},Color:function(target){this.target=target;this.setRGB=v=>{target.tint=v;};},MovieClipLoader:function(){this.addListener=function(listener){this.listener=listener;};this.loadClip=function(source,target){iconLoadCount++;this.source=source;this.target=target;return true;};}};
function metrics(text,font,width,wrap){
 let x=0,max=0,lines=text===''?0:1;
 for(const c of text){
  if(c==='\n'){max=Math.max(max,x);x=0;lines++;continue;}
  if(c==='\r')continue;
  const cp=c.codePointAt(0);
  if(/\p{Mark}/u.test(c)||cp===0x200d||cp===0xfe0f)continue;
  const w=font*(cp<128?.6:1);
  if(wrap&&x>0&&x+w>width){max=Math.max(max,x);x=0;lines++;}
  x+=w;
 }
 return {width:Math.max(max,x),height:lines*(font+2)};
}
function clip(){
 return {_visible:true,_currentframe:1,_totalframes:100,labelFrames:{default_misc:73,default_food:31},ops:[],
  createEmptyMovieClip(name){return this[name]=clip();},
  gotoAndStop(label){this.frameLabel=label;this._currentframe=this.labelFrames[label]||1;},
  createTextField(name,depth,x,y,width,height){
   const field={testName:name,_x:x,_y:y,_width:width,_visible:true,text:'',html:false,wordWrap:false,selectable:false,
    setNewTextFormat(f){this.format=f;},setTextFormat(f){this.format=f;}};
   let boxHeight=height,auto='none';
   Object.defineProperty(field,'_height',{get(){return boxHeight;},set(v){boxHeight=v;}});
   Object.defineProperty(field,'autoSize',{get(){return auto;},set(v){auto=v;if(v!=='none'){const m=metrics(this.text,this.format.size,Math.max(1,this._width-4),this.wordWrap);if(!this.wordWrap)this._width=m.width+4;boxHeight=m.height+4;}}});
   for(const property of ['textWidth','textHeight'])Object.defineProperty(field,property,{get(){const m=metrics(this.text,this.format.size,Math.max(1,this._width-4),this.wordWrap);return m[property==='textWidth'?'width':'height'];}});
   this[name]=field;
   return field;
  },
  clear(){this.ops=[];},lineStyle(...a){this.ops.push(['style',...a]);},beginFill(...a){this.ops.push(['fill',...a]);},
  moveTo(...a){this.ops.push(['move',...a]);},lineTo(...a){this.ops.push(['line',...a]);},endFill(){this.ops.push(['end']);}
 };
}
ctx.createEmptyMovieClip=name=>clip();
ctx.TextFormat=function(font,size,color){this.font=font;this.size=size;this.color=color;};
for(const n of ['qldMarkerEnchant','qldMarkerKnown','qldMarkerSpecial','qldMarkerRead'])ctx[n]=clip();
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(process.argv[2],'utf8'),ctx);
assert.strictEqual(ctx.qldProbe(),'QLD_UI_0.1.20-065');ctx.InitExtensions();ctx.SetPlatform(1,false);
const fixtureDoc=JSON.parse(fs.readFileSync(process.argv[3],'utf8'));
assert.strictEqual(fixtureDoc.requested_font_px,18);
assert.strictEqual(fixtureDoc.adaptive_enchantment_floor_px,12);
const fitRows=[];
function countCodePoints(text){return Array.from(text).length;}
function makeEnchant(text){
 return {name:'Flamebound dagger',count:1,type:2,weight:5.1,value:154,damage:23,categoryText:'Weapon',
  showCategory:true,showIcons:false,enchantMarker:1,effectsPlain:text,detailText:''};
}
for(const fixture of fixtureDoc.fixtures){
 const text=fixture.phrase.repeat(fixture.repeat);
 const actual=countCodePoints(text);
 assert.strictEqual(actual,fixture.expected_unicode_code_points,fixture.id+' source fixture count');
 const card=makeEnchant(text),width=335;
 const measured=ctx.qldMeasure(card,width,fixtureDoc.requested_font_px);
 const minimum=ctx.qldMinimumHeight(card,width,fixtureDoc.requested_font_px);
 const allocated=ctx.qldPreferredHeight(card,width,18); // exact production preference, not a test-only larger box
 const rendered=ctx.qldRender(true,card,722.27,440.67,width,1,18,.35,1,allocated);
 assert.strictEqual(ctx.panel._visible,true,fixture.id+' retains the core card');
 assert.strictEqual(ctx.content.title._visible,true,fixture.id+' retains title');
 assert.strictEqual(ctx.content.stats._visible,true,fixture.id+' retains stats');
 assert.strictEqual(ctx.content.description.text,text,fixture.id+' retains the complete source text');
 const row={id:fixture.id,unicode_code_points:actual,logical_width_px:width,requested_font_px:18,
  minimum_panel_height_px:minimum,measured_panel_height_px:measured,allocated_panel_height_px:allocated,
  rendered,font_px:ctx.panel.descriptionFontSize,full_text_preserved:ctx.content.description.text===text,
  description_omitted:ctx.panel.descriptionOmitted,description_field_height_px:ctx.content.description._height,
  panel_visible:ctx.panel._visible};
 fitRows.push(row);
 if(fixture.expected_unicode_code_points===48){
  assert.strictEqual(ctx.panel.descriptionOmitted,false,fixture.id+' full body visible');
 }else if(fixture.locale==='ja'){
  assert.ok(minimum<=allocated,fixture.id+' 12px-floor panel fits available lower space');
  assert.strictEqual(ctx.panel.descriptionOmitted,false,fixture.id+' full body fits in available lower panel space');
  assert.ok(ctx.panel.descriptionFontSize>=12 && ctx.panel.descriptionFontSize<18,fixture.id+' adapts only the enchantment body');
  assert.ok(ctx.panel.requiredHeight<=allocated,fixture.id+' required fit stays inside the allocation');
 }else{
  assert.ok(ctx.panel.descriptionFontSize>=12 && ctx.panel.descriptionFontSize<=18,fixture.id+' stays at or above the configured 12px floor');
  assert.strictEqual(ctx.panel.descriptionOmitted,false,fixture.id+' full body visible');
 }
 ctx.qldRender(false);
}
const jp192=fixtureDoc.fixtures.find(x=>x.id==='ja-192');
const jpLong=makeEnchant(jp192.phrase.repeat(jp192.repeat));
const shortBudget=172;
ctx.qldRender(true,jpLong,722.27,440.67,335,1,18,.35,1,shortBudget);
assert.strictEqual(ctx.panel._visible,true,'172px short-space boundary keeps title/stats card visible');
assert.strictEqual(ctx.content.title._visible,true,'172px boundary keeps title');
assert.strictEqual(ctx.content.stats._visible,true,'172px boundary keeps value/weight stats');
assert.strictEqual(ctx.content.description.text,jpLong.effectsPlain,'172px boundary does not replace or mutate body text');
assert.strictEqual(ctx.panel.descriptionFontSize,12,'172px boundary stops at the tested 12px enchantment floor');
assert.strictEqual(ctx.panel.descriptionOmitted,true,'172px boundary is recorded as clipped and is not a fit pass');
fitRows.push({id:'ja-192-172px-insufficient',unicode_code_points:countCodePoints(jpLong.effectsPlain),logical_width_px:335,
 requested_font_px:18,font_px:ctx.panel.descriptionFontSize,allocated_panel_height_px:shortBudget,
 full_text_preserved:ctx.content.description.text===jpLong.effectsPlain,description_omitted:ctx.panel.descriptionOmitted,
 panel_visible:ctx.panel._visible,status:'LIMITED_UNRESOLVED'});
ctx.qldRender(false);
const ordinary={name:'Plain blade',count:1,type:2,weight:4,value:30,damage:12,categoryText:'Weapon',
 showCategory:true,showIcons:false,enchantMarker:0,effectsPlain:jp192.phrase.repeat(jp192.repeat),detailText:''};
const ordinaryMinimum=ctx.qldMinimumHeight(ordinary,335,18),ordinaryPreferred=ctx.qldMeasure(ordinary,335,18);
assert.ok(ordinaryMinimum<=279,'normal Japanese body fits its 12px minimum within 279px');
ctx.qldRender(true,ordinary,0,0,335,1,18,.35,1,279);
assert.ok(ctx.panel.descriptionFontSize>=12&&ctx.panel.descriptionFontSize<18,'normal Japanese body adapts within 18px..12px');
assert.strictEqual(ctx.content.description.text,ordinary.effectsPlain,'normal body remains assigned verbatim');
assert.strictEqual(ctx.panel.descriptionOmitted,false,'normal Japanese body fits at adaptive size');
fitRows.push({id:'ja-192-normal-description-preferred-279px',preferred_panel_height_px:ordinaryPreferred,
 minimum_panel_height_px:ordinaryMinimum,font_px:ctx.panel.descriptionFontSize,allocated_panel_height_px:279,
 full_text_preserved:ctx.content.description.text===ordinary.effectsPlain,description_omitted:ctx.panel.descriptionOmitted,status:'PASS'});
ctx.qldRender(false);
ctx.qldRender(true,ordinary,0,0,335,1,18,.35,1,172);
assert.strictEqual(ctx.panel.descriptionFontSize,12,'172px hard cap stops at the 12px floor');
assert.strictEqual(ctx.panel.descriptionOmitted,true,'172px hard cap remains explicitly unresolved');
assert.strictEqual(ctx.content.description.text,ordinary.effectsPlain,'hard-cap overflow preserves full text');
fitRows.push({id:'ja-192-normal-description-hard-cap-172px',font_px:ctx.panel.descriptionFontSize,
 allocated_panel_height_px:172,full_text_preserved:ctx.content.description.text===ordinary.effectsPlain,
 description_omitted:ctx.panel.descriptionOmitted,status:'LIMITED_UNRESOLVED'});
ctx.qldRender(false);
assert.strictEqual(ctx.panel.requiredHeight,0,'close resets required panel size');
assert.strictEqual(ctx.panel.descriptionMeasuredHeight,0,'close resets measured body size');
assert.strictEqual(ctx.panel.descriptionFontSize,0,'close resets adaptive font');
const shortNormal={name:'Short blade',count:1,type:2,weight:4,value:30,damage:12,categoryText:'Weapon',
 showCategory:true,showIcons:false,enchantMarker:0,effectsPlain:'Short text',detailText:''};
ctx.qldRender(true,shortNormal,0,0,335,1,18,.35,1,ctx.qldPreferredHeight(shortNormal,335,18));
assert.strictEqual(ctx.panel.descriptionFontSize,14.4,'short selection restores approved small body font');
assert.ok(ctx.panel.requiredHeight<ordinaryMinimum,'short selection does not retain expanded long-card size');
ctx.qldRender(false);ctx.qldRender(true,shortNormal,0,0,335,1,18,.35,1,ctx.qldPreferredHeight(shortNormal,335,18));
assert.strictEqual(ctx.content.description.text,'Short text','reopen renders current selection');
fitRows.push({id:'short-after-long-close-reopen',font_px:ctx.panel.descriptionFontSize,full_text_preserved:ctx.content.description.text==='Short text',description_omitted:ctx.panel.descriptionOmitted,status:'PASS'});
const englishNormal={name:'Plain blade',count:1,type:2,weight:4,value:30,damage:12,categoryText:'Weapon',
 showCategory:true,showIcons:false,enchantMarker:0,effectsPlain:fixtureDoc.fixtures.find(x=>x.id==='en-192').phrase.repeat(4),detailText:''};
ctx.qldRender(true,englishNormal,0,0,335,1,18,.35,1,220);
assert.ok(ctx.panel.descriptionFontSize>=12&&ctx.panel.descriptionFontSize<18,'English normal body adapts above the floor');
assert.strictEqual(ctx.panel.descriptionOmitted,false,'English normal body fits');
assert.strictEqual(ctx.content.description.text,englishNormal.effectsPlain,'English normal body is preserved');
fitRows.push({id:'en-192-normal-description-220px',font_px:ctx.panel.descriptionFontSize,full_text_preserved:ctx.content.description.text===englishNormal.effectsPlain,description_omitted:ctx.panel.descriptionOmitted,status:'PASS'});
const crlfText=String.fromCharCode(0x706b,0x708e,13,10,0x51b7,0x6c17);
const crlfCard={name:'Plain blade',count:1,type:2,weight:4,value:30,damage:12,categoryText:'Weapon',
 showCategory:true,showIcons:false,enchantMarker:0,effectsPlain:crlfText,detailText:''};
const crlfHeader=ctx.qldHeader(crlfCard,335,18);
ctx.qldRender(true,crlfCard,0,0,335,1,18,.35,1,crlfHeader.descriptionTop+40);
assert.strictEqual(ctx.content.description.text,crlfText,'normal CRLF body preserves exact line endings');
assert.strictEqual(ctx.panel.descriptionFontSize,12,'normal CRLF body adapts to its floor');
assert.strictEqual(ctx.panel.descriptionOmitted,false,'normal CRLF body fits');
fitRows.push({id:'ja-normal-crlf-floor',font_px:ctx.panel.descriptionFontSize,full_text_preserved:ctx.content.description.text===crlfText,description_omitted:ctx.panel.descriptionOmitted,status:'PASS'});
// Explicit LF is preserved; two lines are a fixture, not a body line limit.
// Boundary offsets exercise the production 0.01px clipping tolerance.
const newlineText='\u706b\u708e\n\u51b7\u6c17',newlineWidth=335;
assert.strictEqual(newlineText.split('\n').length,2);
assert.strictEqual(metrics(newlineText,18,newlineWidth-36,true).height,40);
assert.strictEqual(metrics(newlineText,12,newlineWidth-36,true).height,28);
const newlineCases=[
 ['lf-upper-above',36.82,14.4,false],
 ['lf-upper-exact',36.8,14.4,false],
 ['lf-upper-tolerance',36.795,14.4,false],
 ['lf-upper-below',36.78,13.4,false],
 ['lf-floor-above',32.02,12,false],
 ['lf-floor-exact',32,12,false],
 ['lf-floor-tolerance',31.995,12,false],
 ['lf-floor-below',31.98,12,true]
];
for(const [id,available,font,clipped] of newlineCases){
 const card=makeEnchant(newlineText),header=ctx.qldHeader(card,newlineWidth,18);
 const allocated=header.descriptionTop+8+available;
 const rendered=ctx.qldRender(true,card,0,0,newlineWidth,1,18,.35,1,allocated);
 assert.strictEqual(rendered,true,id+' renders the core card');
 assert.ok(ctx.panel._visible&&ctx.content.title._visible&&ctx.content.stats._visible,id+' keeps core fields');
 assert.strictEqual(ctx.content.description.text,newlineText,id+' preserves the exact LF body');
 assert.strictEqual(ctx.panel.descriptionFontSize,font,id+' selects the boundary font');
 assert.ok(font>=12&&font<=18,id+' stays within the requested font and floor');
 assert.ok(Math.abs(ctx.panel.descriptionMeasuredHeight-(2*(font+2)+4))<1e-6,id+' measures exactly two lines');
 assert.ok(Math.abs(ctx.content.description._height-available)<1e-6,id+' uses the allocated body height');
 assert.strictEqual(ctx.panel.descriptionOmitted,clipped,id+' reports clipping');
 assert.strictEqual(ctx.panel.descriptionOmitted,ctx.panel.descriptionMeasuredHeight>available+0.01,id+' matches the clipping contract');
 fitRows.push({id,requested_font_px:18,font_px:ctx.panel.descriptionFontSize,
  available_body_height_px:available,description_measured_height_px:ctx.panel.descriptionMeasuredHeight,
  full_text_preserved:ctx.content.description.text===newlineText,description_omitted:ctx.panel.descriptionOmitted});
 ctx.qldRender(false);
}
if(process.argv[4]){
 const {spawnSync}=require('child_process');
 if(process.argv[5]==='--require-preferred'){assert.strictEqual(typeof ctx.qldPreferredHeight,'function');assert.strictEqual(typeof ctx.qldDescriptionFontFloor,'function');}
 function run(c,cap,H,Y=40,LH=20){
  const w=335,n=ctx.qldMeasure(c,w,18),old=ctx.qldLongCardPreferredHeight;
  if(old!==undefined)ctx.qldLongCardPreferredHeight=cap;
  const pref=typeof ctx.qldPreferredHeight==='function'?ctx.qldPreferredHeight(c,w,18):Math.min(n,cap);
  if(old!==undefined)ctx.qldLongCardPreferredHeight=old;
  const floor=typeof ctx.qldDescriptionFontFloor==='function'?ctx.qldDescriptionFontFloor(18):ctx.qldEnchantFontFloor(18),a=[];
  for(let f=18;;f=Math.max(floor,f-1)){a.push([f,ctx.qldMeasure(c,w,18,f)]);if(f<=floor+.01)break;}
  const args=['--fit-probe',String(pref),'1280',String(H),'100',String(Y),'335',String(LH),String(a.length),...a.flatMap(v=>v.map(String))];
  const r=spawnSync(process.argv[4],args,{encoding:'utf8'});assert.strictEqual(r.status,0,r.stderr);
  const p=JSON.parse(r.stdout),ok=ctx.qldRender(true,{...c,descriptionFontSize:p.selected_font},p.x,p.y,p.width,1,18,.35,1,p.height);
  const row={name:c.name,cap_px:cap,natural_px:n,preferred_px:pref,font_px:p.selected_font,required_px:p.required_height,planned_px:p.panel_height,allocated_px:p.height,expanded:p.expanded,full_text_preserved:ctx.content.description.text===c.effectsPlain,clipped:ctx.panel.descriptionOmitted,rendered:ok};
  fitRows.push(row);return {p,row};
 }
 // Independent synthetic geometry: header111.6; body width299 (295 interior).
 assert.ok(Math.abs(ctx.qldHeader(ordinary,335,18).descriptionTop-111.6)<1e-8);
 assert.strictEqual(ctx.qldMeasure(ordinary,335,18,14),288);
 assert.strictEqual(ctx.qldMeasure(ordinary,335,18,13),263);
 assert.strictEqual(ctx.qldMeasure(ordinary,335,18,12),244);
 const a=run(ordinary,279,1000);assert.strictEqual(a.p.panel_height,279);assert.strictEqual(a.p.selected_font,13);assert.strictEqual(a.p.expanded,false);assert.strictEqual(a.row.clipped,false);
 const b=run(ordinary,172,1000);assert.strictEqual(b.p.selected_font,12);assert.ok(b.p.expanded&&b.p.panel_height>172);assert.strictEqual(b.p.height,b.p.panel_height);assert.strictEqual(b.row.clipped,false);
 const c=run(ordinary,172,244);assert.strictEqual(c.p.height,172);assert.strictEqual(c.row.clipped,true);assert.strictEqual(c.row.full_text_preserved,true);
 const d=run(jpLong,279,1000);assert.strictEqual(d.p.panel_height,279);assert.strictEqual(d.row.clipped,false);
 const e=run(englishNormal,279,1000);assert.strictEqual(e.row.clipped,false);assert.strictEqual(e.row.full_text_preserved,true);
 const f=run(crlfCard,279,1000);assert.strictEqual(f.row.full_text_preserved,true);
 const shortCard={name:'Short after long',count:1,type:2,weight:4,value:30,damage:12,categoryText:'Weapon',showCategory:true,showIcons:false,enchantMarker:0,effectsPlain:'Short text',detailText:''};
 ctx.qldRender(false);const g=run(shortCard,279,1000);assert.strictEqual(g.p.selected_font,18);assert.strictEqual(g.p.panel_height,g.row.natural_px);assert.strictEqual(g.p.expanded,false);
 ctx.qldRender(false);const wide=run(ordinary,172,1000),tight=run(ordinary,172,244);assert.ok(wide.p.height>tight.p.height);
}
console.log('QLD_FIT_BOUNDARY_REPORT '+JSON.stringify({renderer:'compiled AVM1/AS2 plus synthetic metrics, not game Scaleform',rows:fitRows}));
