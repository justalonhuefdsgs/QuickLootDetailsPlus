// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <array>
#include <optional>
#include <span>
namespace qld {
std::optional<std::array<unsigned char,32>> sha256(std::span<const unsigned char> bytes) noexcept;
}
