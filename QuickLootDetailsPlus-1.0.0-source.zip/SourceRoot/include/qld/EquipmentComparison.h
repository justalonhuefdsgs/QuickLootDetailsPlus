#pragma once
#include <cmath>
#include <optional>
#include <format>
#include <string>
#include <string_view>
namespace qld {
inline constexpr std::string_view kWeaponDamageLabelJa="\u53f3\u624b\u88c5\u5099\u3068\u306e\u653b\u6483\u529b\u5dee:";
inline constexpr std::string_view kWeaponDamageLabelEn="Main-hand damage difference:";
inline constexpr std::string_view kArmorRatingLabelJa="\u88c5\u5099\u4e2d\u9632\u5177\u3068\u306e\u9632\u5fa1\u529b\u5dee:";
inline constexpr std::string_view kArmorRatingLabelEn="Armor difference from equipped:";
inline bool equipmentComparisonCompatible(bool hasEquipped,bool sameType,bool sameSlot) noexcept {
    return hasEquipped && sameType && sameSlot;
}
inline std::optional<double> equipmentMetricDifference(double selected,double equipped) noexcept {
    if(!std::isfinite(selected) || !std::isfinite(equipped))return {};
    const double difference=selected-equipped;
    if(!std::isfinite(difference))return {};
    return difference;
}
inline std::string formatEquipmentComparisonText(std::string_view label,double difference) {
    return std::format("{} {:+.2f}",label,difference);
}
}
