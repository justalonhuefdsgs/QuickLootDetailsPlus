# Changelog
## 028 / 2026-10-24
destructor beginを解放前にflushし、明示movie owner解放後にendを記録する診断順序修正。
source契約を強化し、早過ぎるendをnegative controlで拒否。027のLFテストは保持。
必須10文書をローカル新規作成し、正本未取得・実機NOT_RUNを明記。offline結果は028証拠参照。


## QLD044 - viewport visibility repair

QLD044: preserve actual visibility on viewport changes and invalidate redraw revision instead; add extracted Native transition regression. Main/category SWF inputs are unchanged042-R1 immutable copies; new DLL identity binds the final source manifest to those exact hashes.
