#include "qld/Card.h"
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <vector>
#define CHECK(x) do {if(!(x)){std::cerr<<__LINE__<<": "<<#x<<'\n';std::exit(1);}}while(false)
static std::string escaped(std::string_view in){
    std::string out="\"";for(unsigned char c:in){if(c=='"' || c=='\\'){out+='\\';out+=c;}else if(c=='\n')out+="\\n";else if(c=='\r')out+="\\r";else if(c=='\t')out+="\\t";else out+=c;}return out+'"';
}
int main(int argc,char** argv){
    using namespace qld;
    std::vector<std::pair<std::string,std::string>> fixtures{
        {"検証項目の割合が <font face='$EverywhereMediumFont' size='20' color='#FFFFFF'>2</font>%、 <font face='$EverywhereMediumFont' size='20' color='#FFFFFF'>2</font> 時間早くなる。 ","検証項目の割合が 2%、 2 時間早くなる。 "},
        {"<FONT color='#FF0000'><b>15</b></FONT> ポイント<br/>炎のダメージ。","15 ポイント\n炎のダメージ。"},
        {"<p>1行目</p><p><i>2行目</i></p>","1行目\n2行目\n"},
        {"A&amp;B &quot;名&quot; &apos;題&apos; &#50; &#x32; &nbsp; &#x1F600;","A&B \"名\" '題' 2 2 \xC2\xA0 😀"},
        {"<font face='A>B' size=20>2</font>","2"},
        {"<custom><u>2</u> 時間</custom>","2 時間"},
        {"&lt;font size='20'&gt;2&lt;/font&gt; 時間","2 時間"},
        {"&amp;lt;font size='20'&amp;gt;2&amp;lt;/font&amp;gt; 時間","2 時間"},
        {"10%\r\n2 時間", "10%\r\n2 時間"},
        {"体力 < 3、値は 0。", "体力 < 3、値は 0。"},
        {"<!-- formatting only --><textformat leading='2'>本文</textformat>","本文"},
        {"<br><br>本文\n末尾", "\n\n本文\n末尾"},
        {"", ""},
        {"効果なし", "効果なし"}
    };
    for(const auto& [raw,plain]:fixtures){auto x=normalizeNativeText(raw);CHECK(x.ok);CHECK(x.text==plain);CHECK(x.text.find("<font")==std::string::npos);}
    auto unknown=normalizeNativeText("<custom>2</custom> &unknown;");CHECK(unknown.ok && unknown.unsupportedTags==2 && unknown.unknownEntities==1);CHECK(unknown.text=="2 &unknown;");
    auto literalEntity=normalizeNativeText("A &amp;amp; B");CHECK(literalEntity.ok && literalEntity.text=="A &amp; B");
    for(const auto* broken:{"<mag>%", "<2> 時間", "<dur>", "<area>", "<font face='broken>2</font>", "<font color='#fff'", "<img src='x'>", "<script>2</script>", "&#0;", "&#xD800;", "&#x110000;", "<!--broken", "<font></font>"}){auto x=normalizeNativeText(broken);CHECK(!x.ok && !x.error.empty());}
    auto longText=normalizeNativeText(std::string(65536,'a'));CHECK(longText.ok && longText.text.size()==65536);
    CHECK(!normalizeNativeText(std::string(65537,'a')).ok);
    CardSnapshot food{{{"name",std::string("検証食品")},{"type",5.0},{"weight",.1},{"value",2.0},{"effects",fixtures[0].first}}};
    const auto raw=std::get<std::string>(food.fields.at("effects"));food.fields["effectsPlain"]=normalizeNativeText(raw).text;
    CHECK(validCard(food));CHECK(std::get<std::string>(food.fields.at("effects"))==raw);
    if(argc>1){
        auto path=std::filesystem::path(argv[1]);std::filesystem::create_directories(path.parent_path());std::ofstream out(path,std::ios::binary);
        out<<"[";bool first=true;for(const auto& [original,plain]:fixtures){auto normalized=normalizeNativeText(original);if(!first)out<<",";first=false;out<<"{\"effects\":"<<escaped(original)<<",\"effectsPlain\":"<<escaped(normalized.text)<<"}";}out<<"]";CHECK(out.good());
    }
    std::cout<<"Native text normalization PASS: 14 semantic fixtures; nested font/color, line breaks/entities, unknown wrappers, malformed/placeholder rejection, original retained.\n";
}
