if(NOT TARGET Microsoft::DirectXMath)
  message(FATAL_ERROR "The pinned local DirectXMath target must be built first")
endif()
set(directxmath_FOUND TRUE)
