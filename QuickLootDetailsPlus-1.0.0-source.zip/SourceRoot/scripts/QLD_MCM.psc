Scriptname QLD_MCM extends MCM_ConfigBase

Event OnConfigInit()
    ModName = "QuickLootDetails"
    ApplySettings()
EndEvent

Event OnGameReload()
    parent.OnGameReload()
    ApplySettings()
EndEvent

Event OnSettingChange(string a_ID)
    ApplySettings()
EndEvent

Event OnConfigClose()
    ApplySettings()
EndEvent

Event OnConfigOpen()
    EnsureWorldOffsets()
EndEvent

; New per-axis keys are initialized once from untouched legacy physical offsets.
; Each write is independent: interrupted conversion never applies an offset twice.
Function EnsureWorldOffsets()
    if GetModSettingFloat("fDeltaX:World") == -1000000.0
        SetModSettingFloat("fDeltaX:World", GetModSettingFloat("fOffsetX:World") + 220.0)
    endif
    if GetModSettingFloat("fDeltaY:World") == -1000000.0
        SetModSettingFloat("fDeltaY:World", GetModSettingFloat("fOffsetY:World") - 90.0)
    endif
EndFunction

Function ApplySettings()
    EnsureWorldOffsets()
    QLD_Native.Configure(GetModSettingBool("bEnabled:General"), GetModSettingInt("iSide:Layout"), GetModSettingFloat("fOffsetX:Layout"), GetModSettingFloat("fOffsetY:Layout"), GetModSettingFloat("fWidth:Layout"), GetModSettingFloat("fScale:Layout"), GetModSettingFloat("fFontSize:Style"), GetModSettingFloat("fBackgroundOpacity:Style"), GetModSettingFloat("fTextOpacity:Style"), GetModSettingInt("iCardScale:QuickLoot"))
    QLD_Native.ConfigureWorld(GetModSettingBool("bEnabled:World"), GetModSettingInt("iAnchor:World"), GetModSettingFloat("fDeltaX:World") - 220.0, GetModSettingFloat("fDeltaY:World") + 90.0, GetModSettingInt("iCardScale:World"))
    QLD_Native.ConfigureCardDisplay(GetModSettingBool("bShowExtraInfo:CardInfo"), GetModSettingBool("bShowCategory:CardInfo"), GetModSettingBool("bShowValueWeight:CardInfo"), GetModSettingBool("bShowOwnedCount:CardInfo"), GetModSettingBool("bShowBookRead:CardInfo"), GetModSettingBool("bShowSpellLearned:CardInfo"), GetModSettingBool("bShowPotionDetails:CardInfo"), GetModSettingBool("bShowIngredientEffects:CardInfo"), GetModSettingBool("bShowEquipmentDetails:CardInfo"), GetModSettingBool("bShowSoulGemDetails:CardInfo"), GetModSettingBool("bShowItemFlags:CardInfo"), GetModSettingBool("bShowPluginSource:CardInfo"), GetModSettingInt("iMaxRows:CardInfo"), GetModSettingFloat("fFontScale:CardInfo"), GetModSettingBool("bShowIcons:CardInfo"), GetModSettingBool("bShowReferenceDps:CardInfo"))
EndFunction

Function ResetDefaults()
    SetModSettingBool("bEnabled:General", true)
    SetModSettingInt("iSide:Layout", 2)
    SetModSettingFloat("fOffsetX:Layout", 0.0)
    SetModSettingFloat("fOffsetY:Layout", 0.0)
    SetModSettingFloat("fWidth:Layout", 300.0)
    SetModSettingFloat("fScale:Layout", 1.0)
    SetModSettingFloat("fFontSize:Style", 18.0)
    SetModSettingFloat("fBackgroundOpacity:Style", 0.70)
    SetModSettingFloat("fTextOpacity:Style", 1.0)
    SetModSettingInt("iCardScale:QuickLoot", 100)
    SetModSettingBool("bEnabled:World", false)
    SetModSettingInt("iAnchor:World", 0)
    SetModSettingFloat("fOffsetX:World", -220.0)
    SetModSettingFloat("fOffsetY:World", 90.0)
    SetModSettingFloat("fDeltaX:World", 0.0)
    SetModSettingFloat("fDeltaY:World", 0.0)
    SetModSettingInt("iCardScale:World", 100)
    SetModSettingBool("bShowExtraInfo:CardInfo", true)
    SetModSettingBool("bShowCategory:CardInfo", true)
    SetModSettingBool("bShowIcons:CardInfo", true)
    SetModSettingBool("bShowReferenceDps:CardInfo", false)
    SetModSettingBool("bShowValueWeight:CardInfo", true)
    SetModSettingBool("bShowOwnedCount:CardInfo", true)
    SetModSettingBool("bShowBookRead:CardInfo", true)
    SetModSettingBool("bShowSpellLearned:CardInfo", true)
    SetModSettingBool("bShowPotionDetails:CardInfo", true)
    SetModSettingBool("bShowIngredientEffects:CardInfo", true)
    SetModSettingBool("bShowEquipmentDetails:CardInfo", true)
    SetModSettingBool("bShowSoulGemDetails:CardInfo", true)
    SetModSettingBool("bShowItemFlags:CardInfo", true)
    SetModSettingBool("bShowPluginSource:CardInfo", false)
    SetModSettingInt("iMaxRows:CardInfo", 4)
    SetModSettingFloat("fFontScale:CardInfo", 0.9)
    ApplySettings()
    RefreshMenu()
EndFunction

Function ResetQuickLootPosition()
    SetModSettingFloat("fOffsetX:Layout", 0.0)
    SetModSettingFloat("fOffsetY:Layout", 0.0)
    ApplySettings()
    RefreshMenu()
EndFunction

Function ResetWorldPosition()
    SetModSettingFloat("fDeltaX:World", 0.0)
    SetModSettingFloat("fDeltaY:World", 0.0)
    SetModSettingInt("iCardScale:World", 100)
    ApplySettings()
    RefreshMenu()
EndFunction
