#pragma once
#include "qld/Providers.h"
#include <cstddef>
#include <cstdint>
#include <optional>
#include <span>
#include <vector>
namespace qld {
struct LegacyLayout {
    std::string_view hash;
    std::uint32_t runtime,menuVtable, advance, message, inventoryVtable, groundVtable;
    std::uint16_t sourceOffset, vectorOffset;
};
// Each profile is independently verified against its exact DLL. SE uses binary/source
// evidence; EE1170 and AE use matching PDB fields + RTTI + method/code signatures.
inline constexpr LegacyLayout legacyLayouts[]{
    {"71ffa806a06d21b58f2c1a804cbf80b4884af0c234bd627fd851a2452d5871e4",0x01050610,0xabcd0,0x32ac0,0x344c0,0xac5a8,0xac590,0x3c,0x138},
    {"9ff2fafc0379c7d43a91e1e99d28d1187fc672bcb7ae1f40062656beaba87ecc",0x01050610,0x84d50,0x362c0,0x36270,0x811a8,0x811c0,0x3c,0x138},
    {"ca746bbed4e752c3853c83eca1599ae965caaa1815969d68821ce74ec9a3bc61",0x1064920,0xc12e0,0x42670,0x43e60,0xc1e80,0xc1e68,0x4c,0x148},
    {"c99d38c58a3ed60159e7a9f4c10110a04751a8b433cad8fd982d6c3ba960037f",0x1070680,0xe15a0,0x3e510,0x3ef40,0xdf1e8,0xdf1d0,0x3c,0x138},
};
constexpr const LegacyLayout* legacyLayout(const ProviderEvidence& e,std::uint32_t runtime) noexcept {
    for(const auto& l:legacyLayouts)if(l.hash==e.hash && l.runtime==runtime)return &l;
    return nullptr;
}
struct MemoryReader {
    virtual ~MemoryReader()=default;
    virtual bool read(std::uint64_t address,std::span<std::byte> output) const=0;
};
struct LegacySelection {
    std::uint32_t container{};
    std::uint64_t vectorBegin{},vectorEnd{},itemAddress{};
    std::int32_t index{},count{};
    std::uint64_t entryAddress{}; // scoped borrowed address; never placed in State or a frame
    std::vector<std::uint32_t> groundHandles;
    bool operator==(const LegacySelection&) const=default;
};
std::optional<LegacySelection> readLegacySelection(const MemoryReader&,const LegacyLayout&,
    std::uint64_t moduleBase,std::uint64_t menu,double selectedIndex,std::uint32_t providerLength);
}
