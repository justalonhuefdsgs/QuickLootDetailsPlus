#include "qld/ComparisonDiagnostics.h"
#if QLD_COMPARISON_DIAGNOSTICS
#include <spdlog/spdlog.h>
#include <cmath>
#include <array>
#include <mutex>

namespace qld::cmpdiag {
namespace {
std::atomic<std::uint64_t> sequence{}; thread_local Sample* active{}; std::mutex outputMutex; std::array<unsigned,2> counts{}; std::array<std::optional<Sample>,2> last{};
const char* kindName(Kind k) noexcept { return k == Kind::armor ? "armor" : "weapon"; }
const char* reasonName(Reason r) noexcept {
    switch (r) {
    case Reason::dropped: return "dropped"; case Reason::noPlayer: return "no_player_or_view";
    case Reason::noEquipped: return "no_equipped"; case Reason::typeMismatch: return "type_mismatch"; case Reason::slotMismatch: return "slot_mismatch"; case Reason::typeAndSlotMismatch: return "type_and_slot_mismatch";
    case Reason::emptyMask: return "empty_mask"; case Reason::missingSlot: return "missing_slot";
    case Reason::multipleArmor: return "multiple_armor"; case Reason::noInventory: return "no_inventory";
    case Reason::unworn: return "unworn"; case Reason::extraInvalid: return "extra_invalid";
    case Reason::extraMultiple: return "extra_multiple"; case Reason::selectedMetric: return "selected_metric";
    case Reason::equippedMetric: return "equipped_metric"; case Reason::nonfiniteDifference: return "nonfinite_difference";
    case Reason::computed: return "computed";
    } return "unknown";
}
const char* iconName(IconState s) noexcept {
    switch(s) { case IconState::inactive:return "inactive"; case IconState::pending:return "pending";
    case IconState::visible:return "visible"; case IconState::failure:return "failure_or_unavailable"; } return "unknown";
}
}
Sample newSample() noexcept { Sample s;s.seq=sequence.fetch_add(1,std::memory_order_relaxed)+1;return s; }
Capture::Capture(Sample* s) noexcept : previous_(active) { active=s; }
Capture::~Capture() noexcept { active=previous_; }
void comparison(Kind k,Reason r,std::optional<double> selected,std::optional<double> equipped) noexcept {
    if(!active)return;
    active->kind=k;active->kindKnown=true;active->comparisonKnown=true;active->reason=r;
    active->selected=selected && std::isfinite(*selected)?selected:std::nullopt;
    active->equipped=equipped && std::isfinite(*equipped)?equipped:std::nullopt;
}
void row(Kind k,bool hasField,bool included,bool enabled,bool equipment,bool category,bool icons,bool iconKnown,int maxRows) noexcept {
    if(!active)return;
    active->kind=k;active->kindKnown=true;active->rowKnown=true;
    active->field=hasField;active->included=included;active->enabled=enabled;active->equipment=equipment;
    active->category=category;active->icons=icons;active->iconLabelKnown=iconKnown;active->maxRows=maxRows;
}
void icon(IconState s,std::uint32_t missing,std::uint32_t flags,std::optional<double> width) noexcept {
    if(!active)return;
    active->iconKnown=true;active->iconState=s;active->missing=missing;active->flags=flags;
    active->width=width && std::isfinite(*width)?width:std::nullopt;
}
void emit(const Sample& s) noexcept {
    if(!s.seq || !s.kindKnown)return;
    try {
        auto logger=spdlog::default_logger();if(!logger)return;
        unsigned slot;
        { std::lock_guard lock(outputMutex);
          const unsigned k=s.kind==Kind::armor?1:0;
          auto signature=s;signature.seq=0;
          if((last[k] && *last[k]==signature) || counts[k]>=8)return;
          slot=++counts[k];last[k]=signature;
        }
        const auto number=[](std::optional<double> n){return n && std::isfinite(*n)?std::to_string(*n):std::string("unknown");};
        const auto diff=s.selected && s.equipped?std::optional<double>(*s.selected-*s.equipped):std::nullopt;
        logger->info("QLD_DIAG_SAMPLE seq={} kind={} slot={} cap=8 compare_known={} reason={} selected={} equipped={} difference={} row_known={} field={} included={} enabled={} equipment={} category={} icons={} icon_known_label={} max_rows={} rendered={} icon_observed={} icon_state={} missing_mask={} flags={} logical_width={}",
            s.seq,kindName(s.kind),slot,s.comparisonKnown,s.comparisonKnown?reasonName(s.reason):"unknown",number(s.selected),number(s.equipped),number(diff),s.rowKnown,s.field,s.included,s.enabled,s.equipment,s.category,s.icons,s.iconLabelKnown,s.maxRows,s.rendered,s.iconKnown,s.iconKnown?iconName(s.iconState):"unknown",s.missing,s.flags,number(s.width));
    } catch (...) {}
}
}
#endif