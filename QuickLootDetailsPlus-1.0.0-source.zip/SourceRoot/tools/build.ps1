param([switch]$CoreOnly, [int]$Jobs=6, [switch]$Diagnostics, [switch]$ExitDiagnostics,
      [string]$VSPath, [string]$Toolset='14.43.34808', [string]$SDKVersion='10.0.26100.0',
      [string]$BuildRoot, [string]$UiSwf, [string]$IconSwf)
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
if(-not $BuildRoot){$BuildRoot=Join-Path $root 'build'}
$BuildRoot=[IO.Path]::GetFullPath($BuildRoot)
if(-not $UiSwf){$UiSwf=Join-Path $root 'build\assets\Interface\QuickLootDetails.swf'}
if(-not $IconSwf){$IconSwf=Join-Path $root 'build\assets\Interface\QuickLootDetails_CategoryIcons.swf'}
$UiSwf=[IO.Path]::GetFullPath($UiSwf);$IconSwf=[IO.Path]::GetFullPath($IconSwf)
if(-not (Test-Path -LiteralPath $UiSwf -PathType Leaf)){throw "The exact compiled candidate SWF must exist before configure: $UiSwf"}
if(-not (Test-Path -LiteralPath $IconSwf -PathType Leaf)){throw "The exact candidate category-icon SWF must exist before configure: $IconSwf"}
if(-not $VSPath){
    $vswhere=Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
    if(-not (Test-Path -LiteralPath $vswhere)){throw 'Use -VSPath for an existing Visual Studio C++ installation'}
    $VSPath=& $vswhere -latest -products '*' -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
}
$cmake=Join-Path $VSPath 'Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe'
$ninja=Join-Path $VSPath 'Common7\IDE\CommonExtensions\Microsoft\CMake\Ninja'
$msvc=Join-Path $VSPath ('VC\Tools\MSVC\'+$Toolset)
$sdk=Join-Path ${env:ProgramFiles(x86)} 'Windows Kits\10'
$sdkbin=Join-Path $sdk ('bin\'+$SDKVersion+'\x64')
$env:PATH=(Join-Path $msvc 'bin\Hostx64\x64')+';'+$sdkbin+';'+$ninja+';'+$env:PATH
$env:INCLUDE=(Join-Path $msvc 'include')+';'+((@('ucrt','shared','um','winrt','cppwinrt')|ForEach-Object{Join-Path $sdk ('Include\'+$SDKVersion+'\'+$_)})-join ';')
$env:LIB=(Join-Path $msvc 'lib\x64')+';'+(Join-Path $sdk ('Lib\'+$SDKVersion+'\ucrt\x64'))+';'+(Join-Path $sdk ('Lib\'+$SDKVersion+'\um\x64'))
$env:WindowsSdkDir=$sdk+'\';$env:WindowsSDKVersion=$SDKVersion+'\';$env:WindowsSdkVerBinPath=$sdkbin+'\'
$env:APPDATA=Join-Path $BuildRoot '.tool-home';$env:LOCALAPPDATA=$env:APPDATA
$env:TEMP=Join-Path $BuildRoot 'temp';$env:TMP=$env:TEMP;$env:VSLANG='1033'
New-Item -ItemType Directory -Path $env:TEMP,$env:APPDATA -Force|Out-Null
$buildDir=Join-Path $BuildRoot $(if($CoreOnly){'core'}else{'native'})
$plugin=if($CoreOnly){'OFF'}else{'ON'};$diagnostic=if($Diagnostics){'ON'}else{'OFF'}
$exitDiagnostic=if($ExitDiagnostics){'ON'}else{'OFF'}
& $cmake -S $root -B $buildDir -G Ninja -DCMAKE_BUILD_TYPE=RelWithDebInfo ('-DQLD_UI_SWF='+$UiSwf.Replace('\','/')) ('-DQLD_CATEGORY_ICON_SWF='+$IconSwf.Replace('\','/')) ('-DQLD_BUILD_PLUGIN='+$plugin) ('-DQLD_DIAGNOSTIC_LOGGING='+$diagnostic) ('-DQLD_EXIT_DIAGNOSTICS='+$exitDiagnostic) ('-DCMAKE_CXX_COMPILER='+(Join-Path $msvc 'bin\Hostx64\x64\cl.exe').Replace('\','/')) ('-DCMAKE_RC_COMPILER='+(Join-Path $sdkbin 'rc.exe').Replace('\','/')) ('-DCMAKE_MT='+(Join-Path $sdkbin 'mt.exe').Replace('\','/'))
if($LASTEXITCODE -ne 0){throw 'CMake configure failed'}
& $cmake --build $buildDir --parallel $Jobs
if($LASTEXITCODE -ne 0){throw 'Native build failed'}
& (Join-Path (Split-Path $cmake) 'ctest.exe') --test-dir $buildDir --output-on-failure
if($LASTEXITCODE -ne 0){throw 'Tests failed'}
