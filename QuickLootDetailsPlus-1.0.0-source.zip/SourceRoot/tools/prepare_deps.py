"""Validate and extract local pinned public dependency archives; no network or install."""
import hashlib,json,pathlib,zipfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
def main():
    lock=json.loads((ROOT/'dependencies.json').read_text(encoding='utf-8'))
    for spec in lock['archives']:
        archive=ROOT/'deps'/spec['file']
        if hashlib.sha256(archive.read_bytes()).hexdigest()!=spec['sha256']:
            raise RuntimeError('Dependency archive hash mismatch: '+str(archive))
        target=ROOT/'deps'/spec['directory']
        if target.exists():
            print('Validated archive; existing source retained:',spec['directory']);continue
        base=(ROOT/'deps').resolve()
        with zipfile.ZipFile(archive) as z:
            for name in z.namelist():
                path=(base/name).resolve()
                if not path.is_relative_to(base) or (path!=base and not path.is_relative_to(target.resolve())):
                    raise RuntimeError('Archive path outside expected source root')
            z.extractall(base)
        print('Extracted:',spec['directory'])
if __name__=='__main__':main()
