#pragma once

#include "qld/ExitDiagnostics.h"

#include <memory>
#include <stdexcept>
#include <string_view>
#include <utility>

#include <spdlog/details/log_msg.h>
#include <spdlog/sinks/sink.h>

namespace qld::exitdiag {

class SpdlogEventSink final : public IEventSink {
public:
    explicit SpdlogEventSink(std::shared_ptr<spdlog::sinks::sink> sink) : sink_(std::move(sink)) {}

    void Write(std::string_view batch) override {
        if (!sink_) throw std::runtime_error("exit diagnostics sink unavailable");
        const spdlog::details::log_msg message{
            spdlog::log_clock::now(), spdlog::source_loc{}, "EXIT_DIAG", spdlog::level::info,
            spdlog::string_view_t(batch.data(), batch.size())};
        sink_->log(message);
    }

    bool Flush() override {
        if (!sink_) return false;
        sink_->flush();
        return true;
    }

private:
    std::shared_ptr<spdlog::sinks::sink> sink_;
};

}  // namespace qld::exitdiag
