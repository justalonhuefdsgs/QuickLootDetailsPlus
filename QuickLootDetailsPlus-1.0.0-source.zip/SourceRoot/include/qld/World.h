#pragma once
#include "qld/Core.h"

namespace qld {
// Pure world-state policy, owned exclusively by the menu's UI update context.
struct WorldTarget {
    std::uint32_t handle{},referenceId{},baseId{};
    std::int32_t count{};
    bool operator==(const WorldTarget&) const = default;
};
struct WorldTicket { std::uint64_t generation{}; WorldTarget target; };
struct WorldEnvironment {
    bool hudReady{},paused{},blockingMenu{},controlsReady{},quickLootOpen{};
    bool blocked() const noexcept { return !hudReady || paused || blockingMenu || !controlsReady || quickLootOpen; }
};
class WorldState {
public:
    void observe(std::optional<WorldTarget>,bool enabled,const WorldEnvironment&,double interval,std::uint64_t eventEpoch);
    std::optional<WorldTicket> requestRefresh();
    bool publish(const WorldTicket&,std::optional<CardSnapshot>);
    Frame frame(const Settings&,std::uint64_t settingsRevision) const;
    void clear();
private:
    std::optional<WorldTarget> target_;
    std::optional<Item> selected_;
    std::uint64_t generation_{},revision_{},eventEpoch_{};
    double refreshDelay_{};
};
}
