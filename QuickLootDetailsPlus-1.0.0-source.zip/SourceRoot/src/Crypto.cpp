// SPDX-License-Identifier: GPL-3.0-or-later
#include "qld/Crypto.h"
#include <Windows.h>
#include <bcrypt.h>
#include <limits>
namespace qld {
std::optional<std::array<unsigned char,32>> sha256(std::span<const unsigned char> bytes) noexcept {
    if(bytes.size()>(std::numeric_limits<ULONG>::max)())return {};
    BCRYPT_ALG_HANDLE algorithm{};BCRYPT_HASH_HANDLE hash{};
    if(BCryptOpenAlgorithmProvider(&algorithm,BCRYPT_SHA256_ALGORITHM,nullptr,0)<0)return {};
    if(BCryptCreateHash(algorithm,&hash,nullptr,0,nullptr,0,0)<0){BCryptCloseAlgorithmProvider(algorithm,0);return {};}
    std::array<unsigned char,32> digest{};
    const bool ok=(bytes.empty() || BCryptHashData(hash,const_cast<PUCHAR>(bytes.data()),static_cast<ULONG>(bytes.size()),0)>=0) &&
        BCryptFinishHash(hash,digest.data(),static_cast<ULONG>(digest.size()),0)>=0;
    BCryptDestroyHash(hash);BCryptCloseAlgorithmProvider(algorithm,0);
    if(!ok)return {};
    return digest;
}
}
