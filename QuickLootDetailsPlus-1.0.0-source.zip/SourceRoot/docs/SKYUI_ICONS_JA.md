# 0.1.20-r1 icon and status markers

分類名・標準tintは固定QuickLoot IE/SkyUI sourceのnative form/keyword/type分類を参照します。防具クラスはQuickLoot IEのArmorType light/heavyを最優先し、`ArmorType::kNone`だけ`VendorItemClothing`→`VendorItemJewelry`→slot fallbackを適用します。

QuickLoot IEの`iconEnchant`、`iconEnchantKnown`、`iconEnchantSpecial`、`iconRead` markerを元ベクターのまま別slotに使います。source SVG、shape ID、hash、credit範囲とライセンス文は[MARKER_ART_CREDIT_JA.md](MARKER_ART_CREDIT_JA.md)に記録しています。

Gold001はSkyrim.esm local FormID `0x00000F`だけです。重量とV/WはU+30FC `ー`、他の0重量itemは従来通りです。食料/飲料の効果は現行IsFood filterを保ちます。

インストール済みSkyUI SWFのframe/export tableは未確認です。source label 78件はpinned sourceの根拠であり、実際に導入されたSkyUIの78 framesが利用可能との証明ではありません。QuickLoot I4/reskinが差し替えるicon source/label/tintをこのnative分類が追跡する保証もありません。
