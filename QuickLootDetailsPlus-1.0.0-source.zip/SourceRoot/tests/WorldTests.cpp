#include "qld/World.h"
#include <cstdlib>
#include <iostream>
#include <limits>
using namespace qld;
static void expect(bool ok,const char* message){if(!ok){std::cerr<<"FAIL "<<message<<'\n';std::exit(1);}}
static CardSnapshot card(std::string description="体力を回復する。",double weight=0.3,double value=14){
    CardSnapshot c;c.fields={{"name",std::string("回復の薬（小）")},{"count",1.0},{"type",5.0},{"weight",weight},{"value",value},{"effects",std::move(description)}};
    expect(validCard(c),"native-like fixture contract");return c;
}
int main(){
    auto fresh=parseSettings(""); State boot; boot.configure(fresh);
    expect(boot.frame().settings.enabled && !boot.frame().settings.world.enabled && boot.frame().settings.world.anchor==WorldAnchor::right && boot.frame().settings.world.offsetX==-220 && boot.frame().settings.world.offsetY==90 && boot.frame().settings.world.cardScalePercent==100,"fresh defaults before MCM");
    auto disabled=parseSettings("[General]\nbEnabled=0\n[World]\niAnchor=1\nfOffsetX=41\nfOffsetY=-12\n"); boot.configure(disabled); auto kept=boot.frame().settings;
    expect(!kept.enabled && kept.world.anchor==WorldAnchor::right && kept.world.offsetX==41 && kept.world.offsetY==-12,"saved OFF and offsets preserved; legacy left ignored");
    kept.enabled=true; boot.configureLoot(kept); expect(boot.frame().settings.enabled,"explicit enable preserved");
    Settings settings;WorldEnvironment play{true,false,false,true,false};
    WorldTarget a{101,0x1001,0x2001,1},b{102,0x1002,0x2002,1};
    WorldState w;
    w.observe(a,settings.world.enabled,play,.016,1);
    expect(!w.requestRefresh() && !w.frame(settings,1).visible(),"new feature default OFF");
    settings.world.enabled=true;
    w.observe(a,true,play,.016,1);auto first=w.requestRefresh();expect(bool(first),"ON with already focused A");
    expect(w.publish(*first,card()),"A publish");expect(w.frame(settings,1).visible(),"A visible");
    const auto unchanged=w.frame(settings,1).revision;
    for(int i=0;i<20;++i){w.observe(a,true,play,.016,1);expect(!w.requestRefresh(),"no every-frame card generation");}
    w.observe(a,true,play,1,1);auto refresh=w.requestRefresh();expect(bool(refresh),"same target rechecked within one second");
    expect(w.publish(*refresh,card()),"same card accepted");expect(w.frame(settings,1).revision==unchanged,"unchanged card does not trigger redraw/height remeasure");
    w.observe(a,true,play,1,1);refresh=w.requestRefresh();expect(w.publish(*refresh,card("変更済み。",0,0)),"same target changed values");
    auto changed=w.frame(settings,1);expect(changed.revision>unchanged,"changed information invalidates render");
    expect(std::get<double>(changed.selected->card.fields.at("weight"))==0 && std::get<double>(changed.selected->card.fields.at("value"))==0,"zero values retained");
    w.observe(b,true,play,.016,2);expect(!w.frame(settings,1).visible(),"A cleared before B is resolved");
    auto second=w.requestRefresh();expect(bool(second) && !w.publish(*first,card()),"A stale ticket rejected");
    auto book=card();book.fields["type"]=4.0;book.fields["description"]=std::string("本の短い説明。");
    expect(w.publish(*second,book) && w.frame(settings,1).selected->card.fields==book.fields,"B BOOK CNAM native fields retained");
    w.observe(std::nullopt,true,play,.016,3);expect(!w.frame(settings,1).visible() && !w.publish(*second,card()),"aim away/lifetime deletion/pickup clears and rejects B");
    w.observe(a,true,play,.016,4);auto beforeABA=w.requestRefresh();
    w.observe(b,true,play,.016,5);w.observe(a,true,play,.016,6);
    expect(!w.publish(*beforeABA,card()),"A-B-A reference epoch protection");
    auto afterABA=w.requestRefresh();expect(w.publish(*afterABA,card()),"fresh A after ABA");
    a.count=2;w.observe(a,true,play,.016,6);expect(!w.frame(settings,1).visible(),"same reference changed stack count clears stale count");
    auto countRefresh=w.requestRefresh();auto stacked=card();stacked.fields["count"]=2.0;expect(w.publish(*countRefresh,std::move(stacked)),"individual extra-count refresh");
    for(int condition=0;condition<5;++condition){
        auto env=play;
        if(condition==0)env.quickLootOpen=true;
        if(condition==1)env.paused=true;
        if(condition==2)env.blockingMenu=true;
        if(condition==3)env.hudReady=false;
        if(condition==4)env.controlsReady=false;
        w.observe(a,true,env,.016,6);expect(!w.frame(settings,1).visible() && !w.requestRefresh(),"QuickLoot/menu/pause/HUD/controls suppression");
        w.observe(a,true,play,.016,6);auto resume=w.requestRefresh();expect(bool(resume) && w.publish(*resume,card()),"fresh refresh on suppression return");
    }
    w.observe(a,false,play,.016,6);expect(!w.frame(settings,1).visible(),"world OFF immediate hide");
    w.observe(a,true,play,.016,6);auto retry=w.requestRefresh();expect(w.publish(*retry,std::nullopt) && !w.frame(settings,1).visible(),"native resolver failure hides");
    w.observe(a,true,play,.2,6);expect(!w.requestRefresh(),"failure retries are bounded");
    w.observe(a,true,play,1,6);retry=w.requestRefresh();expect(bool(retry) && w.publish(*retry,card()),"native retry recovers");
    settings.enabled=false;expect(w.frame(settings,1).visible(),"QuickLoot switch OFF does not disable world");
    w.observe(a,true,play,1,6);auto ownedRefresh=w.requestRefresh();auto stolen=card();stolen.fields["stolen"]=true;
    expect(w.publish(*ownedRefresh,stolen) && w.frame(settings,1).visible(),"theft ownership does not exclude card");
    expect(std::get<bool>(w.frame(settings,1).selected->card.fields.at("stolen")),"native ownership field retained");
    for(int mask=0;mask<16;++mask){
        w.observe(a,true,play,1,6);auto ingredientRefresh=w.requestRefresh();auto ingredient=card();
        ingredient.fields["type"]=8.0;ingredient.fields["numItemEffects"]=4.0;
        for(int slot=0;slot<4;++slot)ingredient.fields["itemEffect"+std::to_string(slot)]=(mask & (1<<slot))?std::string("既知の効果。"):std::string{};
        expect(w.publish(*ingredientRefresh,ingredient) && w.frame(settings,1).selected->card.fields==ingredient.fields,"all ingredient knowledge masks kept for shared2x2 UI");
    }
    for(auto legacy:{Side::left,Side::right,Side::below}) {
        Settings input;input.side=legacy;input.offsetX=42;input.offsetY=-9;input.world.anchor=WorldAnchor::left;
        State fixed;fixed.configure(input);auto initial=fixed.frame().settings;
        expect(initial.side==Side::below && initial.offsetX==42 && initial.offsetY==-9 && initial.world.anchor==WorldAnchor::right,"legacy saved anchor selects fixed QuickLoot baseline without changing offsets or World");
        input.offsetX=-37;input.offsetY=11;fixed.configureLoot(input);auto updated=fixed.frame().settings;
        expect(updated.side==Side::below && updated.offsetX==-37 && updated.offsetY==11 && updated.world.anchor==WorldAnchor::right,"MCM configuration retains independent offsets and ignores legacy anchor");
    }
    State state;settings.world.enabled=true;settings.world.offsetX=123;state.configure(settings);
    Settings newLoot;newLoot.side=Side::right;newLoot.offsetX=-321;state.configureLoot(newLoot);
    expect(state.frame().settings.world.offsetX==123 && state.frame().settings.world.enabled,"QuickLoot configure preserves world keys");
    state.configureWorld({false,WorldAnchor::left,55,-20});auto saved=state.frame().settings;
    expect(saved.enabled && saved.side==Side::below && saved.offsetX==-321 && !saved.world.enabled,"world configure preserves QuickLoot keys");
    auto parsed=parseSettings("[General]\nbEnabled=0\n[Layout]\niSide=0\nfOffsetX=77\n[World]\nbEnabled=1\niAnchor=1\nfOffsetX=-13\nfOffsetY=27\n");
    expect(!parsed.enabled && parsed.side==Side::left && parsed.offsetX==77 && parsed.world.enabled && parsed.world.anchor==WorldAnchor::left && parsed.world.offsetX==-13 && parsed.world.offsetY==27,"independent saved INI roundtrip parse");
    auto old=parseSettings("[Layout]\nfWidth=335\nfOffsetY=19\n");expect(!old.world.enabled && old.width==335 && old.offsetY==19,"old saved config gains safe OFF defaults without reset");
    Settings pos;pos.width=335;
    auto shortBounds=placeWorldPanel(pos,1280,720,146),longBounds=placeWorldPanel(pos,1280,720,400);
    expect(shortBounds.x==693 && shortBounds.y==270 && shortBounds.height==146,"default right position avoids activation text center");
    expect(longBounds.x==shortBounds.x && longBounds.y==shortBounds.y && longBounds.height==400,"world long text grows down fixed origin");
    auto shortAgain=placeWorldPanel(pos,1280,720,146);expect(shortAgain.height==shortBounds.height,"long-short shrink stable");
    pos.side=Side::left;pos.offsetX=555;pos.offsetY=-400;
    auto unaffected=placeWorldPanel(pos,1280,720,146);expect(unaffected.x==shortBounds.x && unaffected.y==shortBounds.y,"QuickLoot position does not move world");
    auto lootBefore=placePanel({700,200,350,200},pos,1280,720,146);
    pos.world={true,WorldAnchor::left,31,22};auto moved=placeWorldPanel(pos,1280,720,146);auto lootAfter=placePanel({700,200,350,200},pos,1280,720,146);
    expect(moved.x==63 && moved.y==202,"world independent anchor offsets");
    expect(lootBefore.x==lootAfter.x && lootBefore.y==lootAfter.y,"world position does not move QuickLoot");
    auto capped=placeWorldPanel(pos,1280,720,3000);expect(capped.y+capped.height<=720,"physical screen bounded");
    expect(placeWorldPanel(pos,0,720,146).width==0 && placeWorldPanel(pos,1280,720,std::numeric_limits<double>::quiet_NaN()).height==0,"invalid viewport/metrics rejected");
    std::cout<<"World PASS: independent switches/config/placement, target A-B-none/ABA/count/lifetime invalidation, stale native rejection, bounded refresh/cache, QuickLoot and menu suppression, native-text/zero-value retention. Engine reference lifetime and actual GFx remain runtime pending.\n";
}
