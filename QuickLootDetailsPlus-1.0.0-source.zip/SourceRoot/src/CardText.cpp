#include "qld/Card.h"
#include <algorithm>
#include <charconv>
#include <cctype>
#include <map>
#include <vector>

namespace qld {
namespace {
std::string lower(std::string_view text) {
    std::string out(text);for(auto& c:out)c=static_cast<char>(std::tolower(static_cast<unsigned char>(c)));return out;
}
bool space(char c){return c==' ' || c=='\t' || c=='\r' || c=='\n';}
bool encode(std::uint32_t cp,std::string& out){
    if(cp==0 || cp>0x10ffff || (cp>=0xd800 && cp<=0xdfff))return false;
    if(cp<0x80)out+=static_cast<char>(cp);
    else if(cp<0x800){out+=static_cast<char>(0xc0|(cp>>6));out+=static_cast<char>(0x80|(cp&63));}
    else if(cp<0x10000){out+=static_cast<char>(0xe0|(cp>>12));out+=static_cast<char>(0x80|((cp>>6)&63));out+=static_cast<char>(0x80|(cp&63));}
    else{out+=static_cast<char>(0xf0|(cp>>18));out+=static_cast<char>(0x80|((cp>>12)&63));out+=static_cast<char>(0x80|((cp>>6)&63));out+=static_cast<char>(0x80|(cp&63));}return true;
}
bool entities(std::string_view in,std::string& out,TextNormalization& result){
    static const std::map<std::string,std::uint32_t> named{{"amp",38},{"lt",60},{"gt",62},{"quot",34},{"apos",39},{"nbsp",160},{"ensp",0x2002},{"emsp",0x2003},{"ndash",0x2013},{"mdash",0x2014},{"hellip",0x2026},{"bull",0x2022},{"copy",169},{"reg",174},{"trade",0x2122},{"deg",176},{"plusmn",177},{"times",215},{"divide",247}};
    for(std::size_t i=0;i<in.size();){
        if(in[i]!='&'){out+=in[i++];continue;}
        auto end=in.find(';',i+1);
        if(end==std::string_view::npos || end-i>24){out+=in[i++];continue;}
        auto key=in.substr(i+1,end-i-1);std::uint32_t cp{};bool found{};
        if(!key.empty() && key.front()=='#'){
            key.remove_prefix(1);int base=10;if(!key.empty() && (key.front()=='x' || key.front()=='X')){base=16;key.remove_prefix(1);}
            const auto parsed=std::from_chars(key.data(),key.data()+key.size(),cp,base);
            if(key.empty() || parsed.ec!=std::errc{} || parsed.ptr!=key.data()+key.size() || !encode(cp,out)){
                result.ok=false;result.error="invalid-character-reference";return false;
            }
            found=true;
        }else if(auto it=named.find(std::string(key));it!=named.end()){encode(it->second,out);found=true;}
        if(!found){out.append(in.substr(i,end-i+1));++result.unknownEntities;}
        i=end+1;
    }
    return true;
}
void line(std::string& out){if(!out.empty() && out.back()!='\n')out+='\n';}
bool markup(std::string_view in,std::string& out,TextNormalization& result){
    for(std::size_t i=0;i<in.size();){
        if(in[i]!='<'){out+=in[i++];continue;}
        if(in.substr(i,4)=="<!--"){
            auto end=in.find("-->",i+4);if(end==std::string_view::npos){result.error="unclosed-comment";return false;}
            i=end+3;++result.formattingTags;continue;
        }
        auto start=i+1;bool closing{};if(start<in.size() && in[start]=='/'){closing=true;++start;}
        if(start>=in.size() || !std::isalnum(static_cast<unsigned char>(in[start]))){out+=in[i++];continue;}
        auto nameEnd=start;while(nameEnd<in.size() && (std::isalnum(static_cast<unsigned char>(in[nameEnd])) || in[nameEnd]=='_' || in[nameEnd]=='-'))++nameEnd;
        const auto tag=lower(in.substr(start,nameEnd-start));
        if(nameEnd<in.size() && !space(in[nameEnd]) && in[nameEnd]!='>' && in[nameEnd]!='/'){out+=in[i++];continue;}
        auto end=nameEnd;char quote{};
        for(;end<in.size();++end){const auto c=in[end];if(quote){if(c==quote)quote=0;}else if(c=='\'' || c=='"')quote=c;else if(c=='>')break;else if(c=='<'){result.error="nested-tag-opener";return false;}}
        if(end==in.size()){result.error="unclosed-markup";return false;}
        const bool numeric=std::all_of(tag.begin(),tag.end(),[](char c){return c>='0' && c<='9';});
        if(numeric || tag=="mag" || tag=="dur" || tag=="area" || tag=="magnitude" || tag=="duration"){
            result.error="unexpanded-native-placeholder";return false;
        }
        if(tag=="script" || tag=="style" || tag=="img" || tag=="object" || tag=="embed"){
            result.error="unsupported-nontext-markup";return false;
        }
        if(tag=="br")out+='\n';
        else if(tag=="p" || tag=="div" || tag=="li")line(out);
        else if(tag!="font" && tag!="b" && tag!="i" && tag!="u" && tag!="s" && tag!="span" && tag!="a" && tag!="textformat")++result.unsupportedTags;
        ++result.formattingTags;i=end+1;
        (void)closing; // Formatting is deliberately flattened; words and numbers are never removed.
    }
    return true;
}
}
TextNormalization normalizeNativeText(std::string_view text){
    TextNormalization result;
    if(text.size()>65536){result.ok=false;result.error="text-limit";return result;}
    std::string decoded;
    if(!entities(text,decoded,result))return result;
    if(!markup(decoded,result.text,result)){result.ok=false;return result;}
    // An encoded wrapper can become visible only after decoding. Accept at most two additional
    // layers, preserving literal comparison operators such as "体力 < 3".
    for(int pass=0;pass<2;++pass){
        auto folded=lower(result.text);
        bool encodedMarkup{};
        for(const auto* tag:{"font","/font","br","p","/p","b","/b","i","/i","u","/u","span","/span","textformat","/textformat","mag","dur","area","0","1","2","3","4","5","6","7","8","9"})
            if(folded.find(std::string("&lt;")+tag)!=std::string::npos || folded.find(std::string("&amp;lt;")+tag)!=std::string::npos)encodedMarkup=true;
        if(!encodedMarkup)break;
        std::string next;if(!entities(result.text,next,result))return result;
        if(next==result.text)break;
        std::string plain;if(!markup(next,plain,result)){result.ok=false;return result;}result.text=std::move(plain);
    }
    auto folded=lower(result.text);
    for(const auto* token:{"<font","</font","&lt;font","&lt;/font","face=","size=","color=","<mag>","<dur>","<area>"})
        if(folded.find(token)!=std::string::npos){result.ok=false;result.error="remaining-markup-or-placeholder";return result;}
    if(!text.empty() && result.text.empty() && result.formattingTags){result.ok=false;result.error="markup-without-text";}
    return result;
}
}
