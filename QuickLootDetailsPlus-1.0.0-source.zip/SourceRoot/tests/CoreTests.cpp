#include "qld/Core.h"
#include "qld/EquipmentComparison.h"
#include <atomic>
#include <cstdlib>
#include <iostream>
#include <limits>
#include <thread>
#include <vector>
#define CHECK(x) do { if (!(x)) {std::cerr << __LINE__ << ": " << #x << '\n'; std::exit(1);} } while(false)
int main(int argc, char** argv) {
    // Equivalent physical placement must hold for old, new and partially migrated settings.
    for(double xx:{-8192.,-220.,0.,777.,8192.})for(double yy:{-4320.,0.,90.,500.,4320.})for(int sc:{50,100,150}){
        const auto oldIni=std::format("[General]\nbEnabled=0\n[World]\nbEnabled=1\nfOffsetX={}\nfOffsetY={}\niCardScale={}\n",xx,yy,sc);
        auto legacy=qld::parseSettings(oldIni);
        const auto newIni=oldIni+std::format("fDeltaX={}\nfDeltaY={}\n",xx+220,yy-90);
        auto migrated=qld::parseSettings(newIni);
        CHECK(!migrated.enabled && migrated.world.enabled);
        CHECK(migrated.world.offsetX==xx && migrated.world.offsetY==yy && migrated.world.cardScalePercent==sc);
        auto partial=qld::parseSettings(oldIni+std::format("fDeltaX={}\nfDeltaY=-1000000\n",xx+220));
        CHECK(partial.world.offsetX==xx && partial.world.offsetY==yy);
        CHECK(qld::parseSettings(newIni).world.offsetX==xx);
        for(double height:{140.,600.,1200.}){
            auto a=qld::placeWorldPanel(legacy,1920,1080,height,0),b=qld::placeWorldPanel(migrated,1920,1080,height,0);
            CHECK(a.x==b.x && a.y==b.y && a.width==b.width && a.height==b.height);
        }
    }
    auto delta=qld::parseSettings("[World]\nfDeltaX=0\nfDeltaY=0\n");
    CHECK(delta.world.offsetX==-220 && delta.world.offsetY==90);
    delta=qld::parseSettings("[World]\nfOffsetX=44\nfOffsetY=-55\nfDeltaX=nan\nfDeltaY=999999\n");
    CHECK(delta.world.offsetX==44 && delta.world.offsetY==-55);
    const auto fresh=qld::parseSettingsLayers("", "");
    CHECK(fresh.enabled && !fresh.world.enabled && fresh.world.offsetX==-220 && fresh.world.offsetY==90);
    const std::string defaults="[General]\nbEnabled=1\n[Style]\nfBackgroundOpacity=0.35\n[World]\nbEnabled=0\nfOffsetX=-220\nfOffsetY=90\n";
    auto startup=qld::parseSettingsLayers(defaults,"[Layout]\nfOffsetX=12\n");
    CHECK(startup.enabled && !startup.world.enabled && startup.backgroundOpacity==.35 && startup.offsetX==12);
    startup=qld::parseSettingsLayers(defaults,"[General]\nbEnabled=0\n");
    CHECK(!startup.enabled && !startup.world.enabled && startup.backgroundOpacity==.35);
    startup=qld::parseSettingsLayers(defaults,"bEnabled:General=1\n");
    CHECK(startup.enabled && startup.world.offsetX==-220 && startup.world.offsetY==90);
    qld::State boot;boot.configure(startup);CHECK(boot.frame().settings.enabled);
    startup.enabled=false;boot.configureLoot(startup);CHECK(!boot.frame().settings.enabled);
    auto persisted=qld::parseSettingsLayers(defaults,"[General]\nbEnabled=0\n");boot.configure(persisted);CHECK(!boot.frame().settings.enabled);
    if (argc == 10 && std::string_view(argv[1]) == "--placement-probe") {
        const auto value=[](const char* text) { return std::strtod(text,nullptr); };
        qld::Settings probeSettings{};
        const auto bounds=qld::placePanel({value(argv[6]),value(argv[7]),value(argv[8]),value(argv[9])},probeSettings,value(argv[4]),value(argv[5]),value(argv[2]),value(argv[3]));
        std::cout << "{\"x\":" << bounds.x << ",\"y\":" << bounds.y << ",\"width\":" << bounds.width << ",\"height\":" << bounds.height << "}\n";
        return 0;
    }

    if(argc==4 && std::string_view(argv[1])=="--equipment-comparison-format"){
        const std::string_view key=argv[3];
        std::string_view label;
        if(key=="weapon-ja")label=qld::kWeaponDamageLabelJa;
        else if(key=="weapon-en")label=qld::kWeaponDamageLabelEn;
        else if(key=="armor-ja")label=qld::kArmorRatingLabelJa;
        else if(key=="armor-en")label=qld::kArmorRatingLabelEn;
        else return 64;
        std::cout << qld::formatEquipmentComparisonText(label,std::strtod(argv[2],nullptr)) << '\n';
        return 0;
    }
    if(argc>=10 && (std::string_view(argv[1])=="--fit-probe" || std::string_view(argv[1])=="--world-fit-probe")){
        const auto value=[](const char* text){return std::strtod(text,nullptr);};
        const auto count=static_cast<int>(value(argv[9]));
        if(count<1 || argc!=10+2*count)return 64;
        std::vector<qld::DescriptionFitCandidate> candidates;
        for(int i=0;i<count;++i)candidates.push_back({value(argv[10+2*i]),value(argv[11+2*i])});
        qld::Settings settings{};settings.width=value(argv[7]);
        const qld::Bounds loot{value(argv[5]),value(argv[6]),value(argv[7]),value(argv[8])};
        const bool world=std::string_view(argv[1])=="--world-fit-probe";
        const auto available=world?qld::availableWorldPanelHeight(settings,value(argv[3]),value(argv[4])):qld::availablePanelHeight(loot,settings,value(argv[3]),value(argv[4]));
        const auto fit=qld::planDescriptionFit(value(argv[2]),candidates,available);
        if(!fit.valid)return 65;
        const auto bounds=world?qld::placeWorldPanel(settings,value(argv[3]),value(argv[4]),fit.panelHeight,0):qld::placePanel(loot,settings,value(argv[3]),value(argv[4]),fit.panelHeight,0);
        std::cout << "{\"base_font\":" << settings.fontSize << ",\"valid\":" << (fit.valid?"true":"false") << ",\"preferred_height\":" << fit.preferredHeight << ",\"panel_height\":" << fit.panelHeight << ",\"selected_font\":" << fit.fontSize << ",\"required_height\":" << fit.requiredHeight << ",\"expanded\":" << (fit.expanded?"true":"false") << ",\"x\":" << bounds.x << ",\"y\":" << bounds.y << ",\"width\":" << bounds.width << ",\"height\":" << bounds.height << "}\n";
        return 0;
    }
    using namespace qld;
    CHECK(equipmentComparisonCompatible(true,true,true));
    CHECK(!equipmentComparisonCompatible(false,true,true)); // no equipped item
    CHECK(!equipmentComparisonCompatible(true,false,true)); // type mismatch
    CHECK(!equipmentComparisonCompatible(true,true,false)); // equip-slot mismatch
    const auto damageDelta=equipmentMetricDifference(34.0,32.0);
    CHECK(damageDelta && *damageDelta==2.0);
    CHECK(!equipmentMetricDifference(std::numeric_limits<double>::quiet_NaN(),32.0));
    CHECK(!equipmentMetricDifference(34.0,std::numeric_limits<double>::infinity()));
    CHECK(!equipmentMetricDifference(std::numeric_limits<double>::max(),-std::numeric_limits<double>::max()));
    CHECK(formatEquipmentComparisonText("Weapon:",.004)=="Weapon: +0.00");
    CHECK(formatEquipmentComparisonText("Weapon:",-.004)=="Weapon: -0.00");
    CHECK(formatEquipmentComparisonText("Weapon:",.006)=="Weapon: +0.01");
    CHECK(formatEquipmentComparisonText("Armor:",-.006)=="Armor: -0.01");
    CHECK(formatEquipmentComparisonText("Weapon:",1.234)=="Weapon: +1.23");
    CHECK(formatEquipmentComparisonText("Armor:",-1.234)=="Armor: -1.23");
    CHECK(formatEquipmentComparisonText("Weapon:",5.0)=="Weapon: +5.00");
    CHECK(formatEquipmentComparisonText("Armor:",-3.0)=="Armor: -3.00");
    CHECK(formatEquipmentComparisonText("Weapon:",0.0)=="Weapon: +0.00");
    CHECK(formatEquipmentComparisonText("Armor:",-0.0)=="Armor: -0.00");
    const std::vector<DescriptionFitCandidate> measuredSizes{{18,343},{17,329},{16,297},{15,284},{14,255},{13,228},{12,207}};
    const auto preferredFit=planDescriptionFit(279,measuredSizes,1000);
    CHECK(preferredFit.valid && preferredFit.fontSize==14 && preferredFit.panelHeight==279 && !preferredFit.expanded);
    const auto expandedFit=planDescriptionFit(172,measuredSizes,1000);
    CHECK(expandedFit.valid && expandedFit.fontSize==12 && expandedFit.requiredHeight==207 && expandedFit.panelHeight==207 && expandedFit.expanded);
    const std::vector<DescriptionFitCandidate> invalidSizes{{18,std::numeric_limits<double>::quiet_NaN()},{0,100}};
    CHECK(!planDescriptionFit(172,invalidSizes,1000).valid);
    const auto cappedFit=planDescriptionFit(279,measuredSizes,172);
    CHECK(cappedFit.fontSize==12 && cappedFit.preferredHeight==172 && cappedFit.panelHeight==172 && cappedFit.requiredHeight==207);
    Settings capacitySettings{};
    CHECK(availablePanelHeight({100,40,335,20},capacitySettings,1280,244)==172);
    capacitySettings.scale=1.5;
    const auto capacity=availablePanelHeight({100,40,335,20},capacitySettings,1280,400);
    CHECK(capacity>0 && capacity<=400/quickLootRenderScale(capacitySettings));
    CHECK(availableWorldPanelHeight(capacitySettings,1280,400)<=400/worldRenderScale(capacitySettings));
    MovieLoadGate gate;
    CHECK(!gate.shouldAttempt(false,1) && gate.attempts()==0);
    CHECK(gate.shouldAttempt(true,0) && gate.attempts()==1);
    CHECK(!gate.shouldAttempt(true,.1));CHECK(!gate.shouldAttempt(false,99));
    CHECK(gate.shouldAttempt(true,1) && gate.attempts()==2);
    CHECK(!gate.shouldAttempt(true,std::numeric_limits<double>::quiet_NaN()));
    CHECK(gate.shouldAttempt(true,1) && gate.attempts()==3);
    CHECK(!gate.shouldAttempt(true,99) && !gate.shouldAttempt(false,99));
    Settings s;
    CHECK(s.side==Side::below);
    auto migrated=parseSettings("[Layout]\niSide=1\nfOffsetX=37\nfOffsetY=-9\n[Style]\nfBackgroundOpacity=0.2\nfFontSize=24");
    CHECK(migrated.side==Side::right && migrated.offsetX==37 && migrated.offsetY==-9 && migrated.backgroundOpacity==.2 && migrated.fontSize==24);
    CHECK(parseSettings("[Layout]\niSide=2").side==Side::below);
    CHECK(s.backgroundOpacity == 0.70 && s.textOpacity == 1);
    auto infoSettings=parseSettings("[CardInfo]\nbShowExtraInfo=1\nbShowCategory=1\nbShowValueWeight=0\nbShowOwnedCount=1\nbShowBookRead=1\nbShowSpellLearned=1\niMaxRows=9\nfFontScale=1.4");
    CHECK(infoSettings.cardDisplay.enabled && infoSettings.cardDisplay.category && !infoSettings.cardDisplay.valueWeight);
    CHECK(infoSettings.cardDisplay.ownedCount && infoSettings.cardDisplay.bookRead && infoSettings.cardDisplay.spellLearned);
    CHECK(infoSettings.cardDisplay.maxRows==6 && infoSettings.cardDisplay.fontScale==1.25);
    CardSnapshot infoCard{{{"categoryJa",std::string("本")},{"categoryEn",std::string("Book")},{"ownedCount",3.0},
        {"bookRead",false},{"spellLearned",true},{"stolen",true},{"pluginSource",std::string("Example.esp")}}};
    auto jaRows=buildCardInfoRows(infoCard,infoSettings.cardDisplay,false);
    auto enRows=buildCardInfoRows(infoCard,infoSettings.cardDisplay,true);
    CHECK(jaRows.size()==4 && enRows.size()==4);
    CHECK(enRows[0]=="Owned: 3" && enRows[1]=="Unread" && enRows[2]=="Spell: Learned" && enRows[3]=="Flags: Stolen");
    CHECK(jaRows[1]=="未読");
    auto readInfoCard=infoCard;readInfoCard.fields["bookRead"]=true;
    CHECK(buildCardInfoRows(readInfoCard,infoSettings.cardDisplay,false)[1]=="既読済み");
    CHECK(buildCardInfoRows(readInfoCard,infoSettings.cardDisplay,true)[1]=="Read");
    CHECK(displayAlchemyCategory(true,false,false)=="食品" && displayAlchemyCategory(true,false,true)=="Food");
    CHECK(displayAlchemyCategory(false,false,false)=="薬" && displayAlchemyCategory(false,false,true)=="Potion");
    CHECK(displayAlchemyCategory(false,true,false)=="毒" && displayAlchemyCategory(false,true,true)=="Poison");
    CardSnapshot enriched{{{"categoryJa",std::string("Armor")},{"categoryPathJa",std::string("Armor > Heavy > Cuirass")},
        {"ingredientKnownEffects",2.0},{"ingredientTotalEffects",4.0},{"soulCapacity",5.0},{"soulCurrent",0.0},
        {"potionBaseEffectsJa",std::string("base effects")}}};
    CardDisplaySettings allDetails;allDetails.maxRows=6;
    auto enrichedRows=buildCardInfoRows(enriched,allDetails,false);
    CHECK(enrichedRows.size()==2);
    CardSnapshot foodBaseRow{{{"isFoodOrDrink",true},{"potionBaseEffectsEn",std::string("not displayed")},{"effects",std::string("Native food description")}}};
    CHECK(buildCardInfoRows(foodBaseRow,allDetails,true).empty());
    CHECK(std::get<std::string>(foodBaseRow.fields["effects"])=="Native food description");
    // Skyrim's food-item flag also covers consumable beverages such as the referenced Alto Wine.
    CardSnapshot drinkBaseRow{{{"isFoodOrDrink",true},{"potionBaseEffectsJa",std::string("非表示")},{"effects",std::string("Native drink description")}}};
    CHECK(buildCardInfoRows(drinkBaseRow,allDetails,false).empty());
    CHECK(std::get<std::string>(drinkBaseRow.fields["effects"])=="Native drink description");
    CardSnapshot potionBaseRow{{{"isFoodOrDrink",false},{"potionBaseEffectsEn",std::string("displayed")}}};
    auto potionRows=buildCardInfoRows(potionBaseRow,allDetails,true);
    CHECK(potionRows.empty());
    CardSnapshot meleeDpsCard{{{"damage",34.0},{"weaponSpeed",1.2},{"isMeleeWeapon",true}}};
    CardDisplaySettings dpsOnly;dpsOnly.ownedCount=false;dpsOnly.equipmentDetails=false;
    CHECK(!dpsOnly.referenceDps && buildCardInfoRows(meleeDpsCard,dpsOnly,true).empty());
    dpsOnly.referenceDps=true;
    const auto dpsRows=buildCardInfoRows(meleeDpsCard,dpsOnly,true);
    CHECK(dpsRows.size()==1 && dpsRows[0]=="Reference DPS (estimate): 40.8");
    CHECK(referenceMeleeDps(12.0,1.0)==12.0 && !referenceMeleeDps(0.0,1.0) && !referenceMeleeDps(12.0,0.0) && !referenceMeleeDps(std::numeric_limits<double>::infinity(),1.0));
    auto bowCard=meleeDpsCard;bowCard.fields["isMeleeWeapon"]=false;
    CHECK(buildCardInfoRows(bowCard,dpsOnly,true).empty());
    CHECK(countKnownIngredientEffects(0xFFFF,0)==0 && countKnownIngredientEffects(0b1010,4)==2 && countKnownIngredientEffects(0b1111,3)==3 && countKnownIngredientEffects(0xFFFF,99)==4);
    CardSnapshot equipmentCard{{{"weaponTypeEn",std::string("Sword")},{"equipmentCompareEn",std::string("Main-hand damage difference: +2.00")},{"weaponSpeed",1.2},{"weaponReach",1.0}}};
    infoSettings.cardDisplay.maxRows=6;auto equipmentRows=buildCardInfoRows(equipmentCard,infoSettings.cardDisplay,true);
    CHECK(equipmentRows.size()==3 && equipmentRows[0]=="Weapon: Sword" && equipmentRows[1]=="Main-hand damage difference: +2.00" && equipmentRows[2]=="Speed: 1.20 | Reach: 1.00");
    CardSnapshot pairedWeapon{{{"weaponTypeJa",std::string("短剣")},{"weaponTypeEn",std::string("Dagger")},{"ownedCount",2.0},{"weaponSpeed",1.4},{"weaponReach",1.0}}};
    const auto pairedJa=buildCardInfoRows(pairedWeapon,allDetails,false),pairedEn=buildCardInfoRows(pairedWeapon,allDetails,true);
    CHECK(pairedJa.size()==2 && pairedJa[0]=="武器種: 短剣・所持数: 2" && pairedJa[1]=="速度: 1.40 / 射程: 1.00");
    CHECK(pairedEn.size()==2 && pairedEn[0]=="Weapon: Dagger | Owned: 2" && pairedEn[1]=="Speed: 1.40 | Reach: 1.00");
    CardSnapshot pairedArmor{{{"armorClassJa",std::string("\u8efd\u88c5")},{"armorClassEn",std::string("Light")},{"ownedCount",0.0},{"equipmentCompareJa",std::string("\u9632\u5fa1\u529b: +3.00")},{"equipmentCompareEn",std::string("Armor: +3.00")},{"effects",std::string("enchantment")}}};
    const auto armorJa=buildCardInfoRows(pairedArmor,allDetails,false),armorEn=buildCardInfoRows(pairedArmor,allDetails,true);
    CHECK(armorJa.size()==2 && armorJa[0]=="\u9632\u5177: \u8efd\u88c5\u30fb\u6240\u6301\u6570: 0" && armorJa[1]=="\u9632\u5fa1\u529b: +3.00");
    CHECK(armorEn.size()==2 && armorEn[0]=="Armor: Light | Owned: 0" && armorEn[1]=="Armor: +3.00");
    pairedArmor.fields.erase("equipmentCompareEn");
    CHECK(buildCardInfoRows(pairedArmor,allDetails,true).size()==1);
    CHECK(std::get<std::string>(pairedArmor.fields["effects"])=="enchantment");
    auto noEquipmentDetails=infoSettings.cardDisplay;noEquipmentDetails.equipmentDetails=false;
    CHECK(buildCardInfoRows(equipmentCard,noEquipmentDetails,true).empty());
    infoSettings.cardDisplay.maxRows=2;auto cappedRows=buildCardInfoRows(infoCard,infoSettings.cardDisplay,true);CHECK(cappedRows.size()==2);
    infoSettings.cardDisplay.enabled=false;CHECK(buildCardInfoRows(infoCard,infoSettings.cardDisplay,true).empty());
    s.width = -10; s.fontSize = std::numeric_limits<double>::quiet_NaN(); s.backgroundOpacity = 3;
    s.normalize(); CHECK(s.width == 180 && s.fontSize == 18 && s.backgroundOpacity == 1 && s.textOpacity == 1);
    s = parseSettings("[Layout]\r\nfWidth:Layout=480\r\nfFontSize:Style=22\nbEnabled:General=0\nfScale:Layout=oops\nfBackgroundOpacity:Style=nan\nfOffsetX:Layout=42garbage");
    CHECK(s.width == 480 && s.fontSize == 22 && !s.enabled && s.scale == 1 && s.offsetX == 0 && s.backgroundOpacity == .70);
    CHECK(!parseSettings("[CardInfo]\nbShowReferenceDps=0").cardDisplay.referenceDps && parseSettings("[CardInfo]\nbShowReferenceDps=1").cardDisplay.referenceDps);
    CHECK(cleanText("日本語", 7) == "日本");
    CHECK(cleanText("a\nb\tc") == "a b c");
    CHECK(cleanText(std::string("\xED\xA0\x80") + "valid") == "valid");
    CHECK(cleanText("<b>name</b>") == "<b>name</b>");
    State state; Item first{1, 42, 100, "Sword (Fine)", "武器", 1, 50, 3.5};
    state.select(42, first); CHECK(!state.frame().visible());
    state.open(42); state.select(42, first); CHECK(state.frame().visible());
    auto second = first; second.stackIdentity = 101; second.name = "Sword (Legendary)"; second.value = 300;
    state.select(42, second); CHECK(state.frame().selected->stackIdentity == 101 && state.frame().selected->value == 300);
    state.select(9, first); CHECK(state.frame().selected->stackIdentity == 101);
    state.invalidate(42); CHECK(!state.frame().visible());
    state.select(42, std::nullopt); CHECK(!state.frame().visible());
    state.select(42, first); state.close(); state.select(42, first); CHECK(!state.frame().visible());
    state.open(43); state.select(42, first); CHECK(!state.frame().visible());
    state.open(42); state.select(42, first); auto settings=Settings{}; settings.enabled=false; state.configure(settings); CHECK(!state.frame().visible());
    state.configure(Settings{}); CHECK(state.frame().visible());
    // Bad callback payloads never leave the previous selection visible.
    auto bad=first; bad.formId=0; state.select(42,bad); CHECK(!state.frame().visible());
    bad=first; bad.container=9; state.select(42,bad); CHECK(!state.frame().visible());
    bad=first; bad.count=0; state.select(42,bad); CHECK(!state.frame().visible());
    bad=first; bad.weight=std::numeric_limits<double>::infinity(); bad.value=-5;
    state.select(42,bad); CHECK(state.frame().selected->weight==0 && state.frame().selected->value==0);
    state.select(42,first); auto snapshot=state.frame(); first.name="Changed outside state";
    CHECK(snapshot.selected->name=="Sword (Fine)" && state.frame().selected->name=="Sword (Fine)");
    state.close(); CHECK(!state.frame().visible()); // missing menu / pre-load
    state.open(42); CHECK(!state.frame().visible()); // no stale selection on resume
    state.select(42,second); CHECK(state.frame().selected->stackIdentity==101);
    state.open(0); CHECK(!state.frame().open && !state.frame().visible());
    state.open(42); state.select(42,first); settings=Settings{}; settings.backgroundOpacity=0; settings.textOpacity=.8;
    state.configure(settings); CHECK(state.frame().settings.backgroundOpacity==0 && state.frame().settings.textOpacity==.8);
    state.configure(Settings{}); CHECK(state.frame().settings.backgroundOpacity==.70 && state.frame().settings.textOpacity==1);
    CardDisplaySettings cardDisplay;cardDisplay.pluginSource=true;cardDisplay.maxRows=99;state.configureCardDisplay(cardDisplay);
    CHECK(state.frame().settings.cardDisplay.pluginSource && state.frame().settings.cardDisplay.maxRows==6);
    state.configureLoot(Settings{});CHECK(state.frame().settings.cardDisplay.pluginSource && state.frame().settings.cardDisplay.maxRows==6);
    for (int i=0;i<10000;++i) { state.select(42, i%2 ? first : second); state.invalidate(42); CHECK(!state.frame().visible()); }
    std::thread writer([&]{for(int i=0;i<10000;++i)state.select(42, first);});
    for(int i=0;i<10000;++i) {auto f=state.frame(); CHECK(f.open && (!f.selected || f.selected->container==42));} writer.join();
    CHECK(providerAllowed(ie412Hash, se1597)); CHECK(!providerAllowed("unverified", se1597)); CHECK(providerAllowed(ie412Hash, 0x01064920));
    CHECK(!providerAllowed(ie412Hash,se1597,true)); CHECK(!providerAllowed("",se1597));
    settings=Settings{};settings.side=Side::left;
    auto b=placePanel({1200,300,300,300}, settings, 1920,1080); CHECK(b.x==888 && b.y==300 && b.width==300);
    settings=Settings{}; settings.side=Side::right; b=placePanel({1800,1050,200,300},settings,1920,1080); CHECK(b.x==1620 && b.y==924);
    settings.fontSize=36; b=placePanel({1800,1050,200,300},settings,1920,1080); CHECK(b.height==264 && b.y==816);
    settings=Settings{};
    b=placePanel({750,190,360,240},settings,1280,720,180);
    CHECK(b.x==750 && b.y==442 && b.height==180 && !b.aboveFallback);
    b=placePanel({1200,190,360,240},settings,1280,720,800);
    CHECK(b.x==980 && b.y==442 && b.height==278 && !b.aboveFallback);
    b=placePanel({750,450,360,230},settings,1280,720,300);
    CHECK(b.width==0 && b.height==0 && !b.aboveFallback);
    b=placePanel({750,20,360,670},settings,1280,720,300);CHECK(b.width==0 && b.height==0);
    settings.offsetX=35;settings.offsetY=10;b=placePanel({750,190,360,240},settings,1280,720,180);
    CHECK(b.x==785 && b.y==452);
    CHECK(placePanel({1,1,200,200},Settings{},std::numeric_limits<double>::quiet_NaN(),720,150).width==0);
    // The requested anchor stays below, and the panel uses the remaining viewport height.
    settings=Settings{};b=placePanel({722,190,335,238.67},settings,1280,720,200);
    CHECK(b.x==722 && std::abs(b.y-440.67)<.001 && b.height==200);
    auto small=placePanel({722,190,335,238.67},settings,1280,720,146);
    auto large=placePanel({722,190,335,238.67},settings,1280,720,250);
    CHECK(small.y==large.y && large.height==250 && small.height==146);
    CHECK(placePanel({722,190,335,238.67},settings,1280,720,146).height==small.height);
    const auto minBound=placePanel({300,200,360,200},settings,1280,720,500,210);
    CHECK(minBound.x==300 && minBound.y==412 && minBound.height==308 && !minBound.aboveFallback);
    // If the complete-body minimum (310px) exceeds the 308px remaining below,
    // retain a below-anchored basic card instead of clearing it wholesale.
    const auto bodyDoesNotFit=placePanel({300,200,360,200},settings,1280,720,500,310);
    CHECK(bodyDoesNotFit.x==300 && bodyDoesNotFit.y==412 && bodyDoesNotFit.height==308 && !bodyDoesNotFit.aboveFallback);
    // A preferred card may be shorter than the full body at the 12px floor.
    const auto expanded=placePanel({100,40,335,20},settings,1280,1000,180,260);
    CHECK(expanded.x==100 && expanded.y==72 && expanded.height==260);
    // The 178px viewport remainder is the hard cap: keep the core card in-bounds,
    // while AS2 reports the still-clipped full body.
    const auto capped=placePanel({100,40,335,20},settings,1280,250,180,260);
    CHECK(capped.x==100 && capped.y==72 && capped.height==178 && capped.y+capped.height==250);
    settings.side=Side::left;
    const auto sideExpanded=placePanel({700,40,335,20},settings,1280,1000,180,260);
    CHECK(sideExpanded.height==260 && sideExpanded.y==40);
    const auto sideCapped=placePanel({700,40,335,20},settings,1280,220,180,260);
    CHECK(sideCapped.height==220 && sideCapped.y==0 && sideCapped.y+sideCapped.height==220);
    settings=Settings{};
    const auto worldExpanded=placeWorldPanel(settings,1280,900,180,260);
    CHECK(worldExpanded.height==260 && worldExpanded.y==315);
    const auto worldCapped=placeWorldPanel(settings,1280,220,180,260);
    CHECK(worldCapped.height==220 && worldCapped.y==0 && worldCapped.y+worldCapped.height==220);    const auto p720x16x9=placePanel({300,120,360,240},settings,1280,720,250,150);
    const auto p1080x16x9=placePanel({600,200,360,360},settings,1920,1080,350,180);
    const auto p720x16x10=placePanel({700,180,260,210},settings,1152,720,260,150);
    const auto p1080x16x10=placePanel({1300,300,300,300},settings,1728,1080,330,180);
    CHECK(p720x16x9.y==372 && p720x16x9.height==250 && !p720x16x9.aboveFallback);
    CHECK(p1080x16x9.y==572 && p1080x16x9.height==350 && !p1080x16x9.aboveFallback);
    CHECK(p720x16x10.y==402 && p720x16x10.height==260 && !p720x16x10.aboveFallback);
    CHECK(p1080x16x10.y==612 && p1080x16x10.height==330 && !p1080x16x10.aboveFallback);
    b=placePanel({100,10,335,10},settings,1280,720,680);CHECK(b.y==32 && b.height==680);
    b=placePanel({100,10,335,10},settings,1280,720,900);CHECK(b.y==32 && b.height==688);
    settings.side=Side::left;b=placePanel({700,10,335,300},settings,1280,720,680);CHECK(b.height==680 && b.y==10);
    b=placePanel({700,10,335,300},settings,1280,720,900);CHECK(b.height==720 && b.y==0);
    settings=Settings{};settings.scale=2;b=placePanel({100,10,335,10},settings,1280,720,300);CHECK(b.height==600 && b.y==44 && b.width==600);
    first.details="体力を6.5回復";second.details="体力を17.25回復";
    state.open(42);state.select(42,first);state.select(42,second);CHECK(state.frame().selected->details==second.details);
    state.select(42,std::nullopt);CHECK(!state.frame().visible());
    std::cout << "Core PASS: configuration, UTF-8, stack identity, invalidation, switching, concurrency, provider rejection, placement\n";
}
