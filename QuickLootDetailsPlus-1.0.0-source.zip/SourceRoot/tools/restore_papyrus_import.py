"""Restore one missing compiler import from the user's own read-only game BSA.
The local PEX/PSC outputs are never part of the public source/runtime allowlists.
"""
import argparse,os,pathlib,re,struct,subprocess
ROOT=pathlib.Path(__file__).resolve().parents[1]
def restore(name):
    if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]*',name):raise RuntimeError('Invalid import type name')
    bsa=os.environ.get('QLD_GAME_BSA');tool=os.environ.get('QLD_CHAMPOLLION')
    if not bsa or not tool:raise RuntimeError('Supply QLD_GAME_BSA and QLD_CHAMPOLLION for local-only compiler import restoration')
    out=ROOT/'build/imports';stage=ROOT/'build/import-pex'
    out.mkdir(parents=True,exist_ok=True);stage.mkdir(parents=True,exist_ok=True)
    with pathlib.Path(bsa).open('rb') as stream:
        header=struct.unpack('<4s8I',stream.read(36))
        if header[0]!=b'BSA\0' or header[1]!=105 or header[4]>1000 or header[5]>50000:raise RuntimeError('Unsupported BSA105 header')
        folders=[struct.unpack('<QIIQ',stream.read(24)) for _ in range(header[4])];records=[]
        for _,count,_,_ in folders:
            length=stream.read(1)[0];folder=stream.read(length).rstrip(b'\0').lower()
            for _ in range(count):records.append((folder,struct.unpack('<QII',stream.read(16))))
        names=stream.read(header[7]).split(b'\0')
        for filename,(folder,(_,size,offset)) in zip(names,records):
            if folder!=b'scripts' or filename.lower()!=(name+'.pex').encode().lower():continue
            if bool(size&0x40000000)^bool(header[3]&4) or size&0x3fffffff>4*1024*1024:raise RuntimeError('Unsupported compressed/oversized compiler import')
            stream.seek(offset);data=stream.read(size&0x3fffffff)
            if data[:4]!=b'\xfa\x57\xc0\xde':raise RuntimeError('Invalid Skyrim PEX')
            pex=stage/(name+'.pex');pex.write_bytes(data)
            env=os.environ.copy();env['APPDATA']=env['LOCALAPPDATA']=str(ROOT/'.tool-home')
            subprocess.run([tool,str(pex),'-p',str(out)],check=True,cwd=ROOT,env=env)
            return out
    raise RuntimeError('Game archive lacks required compiler import '+name)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('type_name');restore(p.parse_args().type_name)
