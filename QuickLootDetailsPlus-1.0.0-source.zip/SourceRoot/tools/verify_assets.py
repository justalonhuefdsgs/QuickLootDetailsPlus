"""Read-only checks of compiled assets. This does not claim runtime validation."""
import os, configparser, hashlib, json, pathlib, re, struct, subprocess, zlib
ROOT=pathlib.Path(__file__).resolve().parents[1]
ASSETS=ROOT/'build/assets'
RESULTS=[]
BASELINE_RESULTS=[]
PAPYRUS_NOT_RUN=[]
def check(name, condition):
    if not condition: raise AssertionError(name)
    RESULTS.append(name)

def subrecords(data):
    pos=0; out=[]
    while pos<len(data):
        tag=data[pos:pos+4].decode('ascii'); size=struct.unpack_from('<H',data,pos+4)[0]
        pos+=6; out.append((tag,data[pos:pos+size])); pos+=size
    check('ESP subrecord boundaries',pos==len(data)); return out

class Cursor:
    def __init__(self,b):self.b=b;self.p=0
    def read(self,fmt):
        value=struct.unpack_from(fmt,self.b,self.p); self.p+=struct.calcsize(fmt); return value
    def string(self):
        n,=self.read('<H'); value=self.b[self.p:self.p+n].decode('utf-8');self.p+=n;return value
    def script(self):
        name=self.string(); status,count=self.read('<BH')
        check('VMAD script has no unbound properties',status==0 and count==0);return name

def esp():
    data=(ASSETS/'QuickLootDetails.esp').read_bytes()
    check('ESP TES4 and record version 44',data[:4]==b'TES4' and struct.unpack_from('<H',data,20)[0]==44)
    size,flags=struct.unpack_from('<II',data,4)
    check('ESP no light/localized/compressed flag',flags==0)
    head=dict(subrecords(data[24:24+size])); version,count,nextid=struct.unpack('<fII',head['HEDR'])
    check('ESP one new record, old-runtime header',abs(version-1.7)<.001 and count==1 and nextid==0x801)
    check('ESP only Skyrim.esm master',head['MAST']==b'Skyrim.esm\0' and sum(t==b'MAST' for t in re.findall(b'MAST',data))==1)
    group=24+size; check('ESP QUST group',data[group:group+4]==b'GRUP' and data[group+8:group+12]==b'QUST')
    pos=group+24; length,flags,form=struct.unpack_from('<III',data,pos+4)
    check('ESP new MCM-only QUST, no overrides',data[pos:pos+4]==b'QUST' and form==0x01000800 and flags==0 and pos+24+length==len(data))
    quest=dict(subrecords(data[pos+24:])); check('ESP start-game flag',struct.unpack_from('<H',quest['DNAM'])[0]&1==1)
    check('ESP Player alias',quest['ALID']==b'PlayerAlias\0' and struct.unpack('<I',quest['ALFR'])[0]==0x14)
    vm=Cursor(quest['VMAD']); check('VMAD v5 object-format2 one script',vm.read('<HHH')==(5,2,1))
    check('VMAD QLD_MCM attached',vm.script()=='QLD_MCM')
    check('VMAD no quest fragments',vm.read('<BH')==(2,0) and vm.string()=='')
    check('VMAD one alias',vm.read('<H')==(1,))
    check('VMAD alias belongs to new quest',vm.read('<HHIHHH')==(0,0,form,5,2,1))
    check('VMAD SkyUI reload alias attached',vm.script()=='SKI_PlayerLoadGameAlias' and vm.p==len(vm.b))
    check('SEQ exact new quest FixedFormID',(ASSETS/'SEQ/QuickLootDetails.seq').read_bytes()==struct.pack('<I',form))

def swf():
    data=(ASSETS/'Interface/QuickLootDetails.swf').read_bytes()
    check('SWF version8',data[:3] in (b'FWS',b'CWS') and data[3]==8)
    body=zlib.decompress(data[8:]) if data[:3]==b'CWS' else data[8:]
    check('SWF declared length',len(body)+8==struct.unpack_from('<I',data,4)[0])
    bits=body[0]>>3; pos=(5+4*bits+7)//8+4; tags=[];shape_bytes={};marker_instances={}
    while pos<len(body):
        header=struct.unpack_from('<H',body,pos)[0];pos+=2;tag=header>>6;n=header&63
        if n==63:n=struct.unpack_from('<I',body,pos)[0];pos+=4
        payload=body[pos:pos+n];pos+=n;tags.append(tag)
        if tag==69:check('SWF AVM1 only',struct.unpack('<I',payload)[0]&8==0)
        if tag in (2,22,32,83):shape_bytes[struct.unpack_from('<H',payload)[0]]=len(payload)
        if tag==26:
            flags=payload[0];depth=struct.unpack_from('<H',payload,1)[0];offset=3;character=None
            if flags&2:character=struct.unpack_from('<H',payload,offset)[0];offset+=2
            if flags&4:offset+=1
            if flags&8:offset+=4
            if flags&16:offset+=2
            if flags&32:
                marker_name=payload[offset:].split(b'\0',1)[0].decode('ascii')
                marker_instances[marker_name]=(character,depth)
    check('SWF boundaries and AS2 actions',pos==len(body) and 12 in tags and not any(t in tags for t in (72,82)))
    check('Compiled SWF has no image-marker shapes or stage instances',not shape_bytes and not marker_instances)
    marker_provenance=json.loads((ROOT/'assets/marker-art/provenance.json').read_text(encoding='utf-8'))
    check('QuickLoot IE GPL and exception notices byte-match the pinned source license hashes',
        hashlib.sha256((ROOT/'licenses/QuickLootIE-GPL-3.0.txt').read_bytes()).hexdigest()==marker_provenance['upstream_license_sha256'] and
        hashlib.sha256((ROOT/'licenses/QuickLootIE-EXCEPTIONS.md').read_bytes()).hexdigest()==marker_provenance['upstream_exceptions_sha256'])
    decoded='\n'.join(p.read_text(encoding='utf-8') for p in (ASSETS/'decoded-ui').rglob('*.as'))
    check('SWF render function with 10 arguments',bool(re.search(r'function qldRender\([^)]*\)',decoded)) and len(re.search(r'function qldRender\(([^)]*)\)',decoded)[1].split(','))==10)
    check('SWF copied text, separate alpha, adaptive height','setNewTextFormat' in decoded and 'textOpacity' in decoded and 'backgroundOpacity' in decoded and 'qldMeasure' in decoded and 'qldFitText' in decoded)
    check('SWF passive input',not any(t in decoded for t in ('onKeyDown','onPress','Key.addListener','Mouse.addListener','fscommand')))
    check('SWF native-card fields and normalized plain text',all(t in decoded for t in ('card.description','card.effectsPlain','card.weight','card.value','card.damage','card.armor','qldCardTitle','qldCardStats','qldCardDescription')) and 'htmlText' not in decoded)
    check('SWF no technical diagnostics or invented effect sentences',not any(t in decoded for t in ('定義値','プレイヤー計算','展開不可','取得不可','体力を15','invented-effect-placeholder')))
    check('SWF independent centered card','align = "center"' in decoded and 'function qldFrame(' in decoded and 'content.description' in decoded)
    source=(ROOT/'ui/panel.as').read_text(encoding='utf-8')
    check('Ingredient slots are a dedicated row-major four-cell layout','qldIngredientCell(card, index)' in source and 'index % 2' in source and 'index < 2' in source and 'card.type == 8' in source and 'qldGridMetrics' in decoded)
    frameStart=source.index('function qldFrame(')
    frame=source[frameStart:source.index('function qldIsKnownItemIconLabel',frameStart)]
    check('Outer frame is one black rectangle with no corners','border.lineStyle(1, 0x000000, 100)' in frame and frame.count('border.lineTo(')==4 and 'while' not in frame and '0xD8D8D8' not in frame)
    check('White single separator follows dynamic title height','divider.lineStyle(0.7, 0xFFFFFF, 100)' in source and 'divider.moveTo(16, header.dividerY)' in source and 'divider.lineTo(width - 16, header.dividerY)' in source and 'qldHeader' in decoded)
    check('Plain effects route has no hidden HTML parsing dependency','field.html = false' in source and 'htmlText' not in source and 'effectsPlain' in decoded)
    check('SWF game hooks, icon fallback and exact version',all(t in decoded for t in ('function InitExtensions(','function SetPlatform(','function qldProbe(','QLD_UI_0.1.20-065','MovieClipLoader','skyui/icons_item_psychosteve.swf','categoryText','showCategory','function onLoadInit(')))
    check('Existing category icon is grouped immediately before centered title; lower row is text-only',all(t in source for t in ('function qldPositionTitle(iconVisible)','categoryIcon._x = textLeft - 28','var categoryX = 16;','qldPositionTitle(true)','qldPositionTitle(false)')) and all(t in decoded for t in ('function qldPositionTitle(iconVisible)','qldPositionTitle(true)','qldPositionTitle(false)')) and bool(re.search(r'categoryIcon\._x = [^;]+ - 28;',decoded)) and 'categoryIcon._y = header.categoryTop' not in source and 'width - header.categoryX - 16' not in source)
    check('SWF no third-party asset import',not any(t in tags for t in (57,71)))


def mcm():
    config=json.loads((ASSETS/'MCM/Config/QuickLootDetails/config.json').read_text(encoding='utf-8'))
    check('MCM correct plugin identity and QuickLoot+SkyUI requirements',config['modName']=='QuickLootDetails' and set(config['pluginRequirements'])=={'QuickLootDetails.esp','SkyUI_SE.esp'})
    controls={c['id']:c for c in config['content'] if 'id' in c}
    ini=configparser.ConfigParser();ini.optionxform=str;ini.read(ASSETS/'MCM/Config/QuickLootDetails/settings.ini',encoding='utf-8')
    defaults={f'{key}:{section}':float(val) for section in ini.sections() for key,val in ini[section].items()}
    expected={'bEnabled:General':1,'iSide:Layout':2,'fOffsetX:Layout':0,'fOffsetY:Layout':0,'fWidth:Layout':300,'fScale:Layout':1,'iCardScale:QuickLoot':100,'fFontSize:Style':18,'fBackgroundOpacity:Style':.35,'fTextOpacity:Style':1,'bEnabled:World':0,'iAnchor:World':0,'fOffsetX:World':0,'fOffsetY:World':0,'iCardScale:World':100,'bShowExtraInfo:CardInfo':1,'bShowCategory:CardInfo':1,'bShowIcons:CardInfo':1,'bShowValueWeight:CardInfo':1,'bShowOwnedCount:CardInfo':1,'bShowBookRead:CardInfo':1,'bShowSpellLearned:CardInfo':1,'bShowPotionDetails:CardInfo':1,'bShowIngredientEffects:CardInfo':1,'bShowEquipmentDetails:CardInfo':1,'bShowReferenceDps:CardInfo':0,'bShowSoulGemDetails:CardInfo':1,'bShowItemFlags:CardInfo':1,'bShowPluginSource:CardInfo':0,'iMaxRows:CardInfo':4,'fFontScale:CardInfo':.9}
    check('MCM thirty-one controls including OFF-by-default reference DPS',set(controls)==set(expected) and len(controls)==31 and defaults==expected and config['displayName']=='$QLD_TITLE')
    for key in ('iCardScale:QuickLoot','iCardScale:World'):
        v=controls[key]['valueOptions']
        check(f'MCM {key} independent 50-150 percent range and five-percent step',v['sourceType']=='ModSettingInt' and v['min']==50 and v['max']==150 and v['step']==5 and controls[key]['text']==('$QLD_QUICKLOOT_SCALE' if key.endswith(':QuickLoot') else '$QLD_WORLD_SCALE'))
    for section in ('Layout','World'):
        for axis,limit in (('X',8192),('Y',4320)):
            c=controls[f'fOffset{axis}:{section}'];v=c['valueOptions']
            expected_key='$QLD_QUICKLOOT_'+axis if section=='Layout' else '$QLD_WORLD_'+axis
            expected_help=('$QLD_HELP_'+axis) if section=='Layout' else ('$QLD_HELP_WORLD_'+axis)
            check(f'MCM {section} {axis} signed fine range and locale keys',v['min']==-limit and v['max']==limit and v['step']==1 and c['text']==expected_key and c['help']==expected_help)
    check('Exactly four offset controls retained without duplicate keys',len([c for c in config['content'] if c.get('id','').startswith('fOffset')])==4)
    source=(ROOT/'scripts/QLD_MCM.psc').read_text(encoding='utf-8')
    setters={key:val.strip().lower() for _,key,val in re.findall(r'SetModSetting(Bool|Int|Float)\("([^"]+)",\s*([^)]*)\)',source)}
    reset={k:1.0 if v=='true' else 0.0 if v=='false' else float(v) for k,v in setters.items()}
    check('MCM reset matches defaults',reset==expected)
    check('MCM reset wired',any(c.get('action',{}).get('function')=='ResetDefaults' for c in config['content']))

def papyrus():
    current_hashes={};source_hashes={}
    for name in ('QLD_Native','QLD_MCM'):
        path=ASSETS/'Scripts'/f'{name}.pex'
        payload=path.read_bytes()
        check(f'{name} Skyrim PEX header',payload[:6]==b'\xfa\x57\xc0\xde\x03\x02')
        current_hashes[name]=hashlib.sha256(payload).hexdigest()
        source_hashes[name]=hashlib.sha256((ROOT/'scripts'/f'{name}.psc').read_bytes()).hexdigest()
    champollion=os.environ.get('QLD_CHAMPOLLION')
    if not champollion or not pathlib.Path(champollion).is_file():
        PAPYRUS_NOT_RUN.append({'status':'NOT_RUN/BLOCKED','reason':'An existing pinned Champollion executable was not configured; no Papyrus decompilation was run.'})
        return

    baseline_report_path=ROOT/'build/baselines/0.1.19-verification.json'
    evidence_path=ROOT/'build/baselines/inherited-papyrus-evidence.json'
    if not baseline_report_path.is_file() or not evidence_path.is_file():
        PAPYRUS_NOT_RUN.append({'status':'NOT_RUN/BLOCKED','reason':'Exact 0.1.19 source-build and 0.1.19-r1 runtime evidence bundle is absent.'})
        return
    baseline_report=json.loads(baseline_report_path.read_text(encoding='utf-8'))
    evidence=json.loads(evidence_path.read_text(encoding='utf-8'))
    baseline_static=baseline_report.get('STATIC',{})
    build_record=baseline_static.get('papyrus_build',{})
    prior_artifacts=baseline_static.get('artifacts',{})
    if baseline_report.get('build_id')!='QLD-0.1.19-812922367e8d0412' or baseline_static.get('status')!='STATIC_PASS' or baseline_static.get('current_checks')!=122 or baseline_static.get('papyrus_current_run',{}).get('status')!='PASS':
        PAPYRUS_NOT_RUN.append({'status':'NOT_RUN/BLOCKED','reason':'Inherited source record is not the exact passing 0.1.19 static/Papyrus verification.'})
        return
    evidence_ok=(evidence.get('status')=='INHERITED_EXACT_HASH'
        and evidence.get('source_archive',{}).get('sha256')=='ebc11e2bdf73a49c96dca8f12f9137b119da69524b7206f18ca095c8e453b52d'
        and evidence.get('revision_source_archive',{}).get('sha256')=='9d4194f816d08caee6fd297f3687b786ba4c5ff5b4b99813fdc2636137dd0f4d'
        and evidence.get('runtime_archive',{}).get('sha256')=='88a339ee54506d3d63fda9bd9c0aa66f7badb17450f5c2c801a181e504a74c7b'
        and evidence.get('prior_build_id')==baseline_report.get('build_id')
        and evidence.get('prior_static_checks')==122)
    source_match=build_record.get('source_sha256')==source_hashes
    pex_match=build_record.get('pex_sha256')==current_hashes
    artifact_match=all(prior_artifacts.get(f'build/assets/Scripts/{name}.pex')==current_hashes[name] for name in current_hashes)
    evidence_artifact_match=all(evidence.get('restored_artifacts_sha256',{}).get(f'Scripts/{name}.pex')==current_hashes[name] for name in current_hashes)
    check('Papyrus inherited source/runtime archive hashes and 0.1.19 build proof',evidence_ok)
    check('Papyrus unchanged source SHA-256 matches the proven 0.1.19 inputs',source_match)
    check('Papyrus current PEX SHA-256 matches the proven 0.1.19 compiled outputs',pex_match and artifact_match and evidence_artifact_match)
    current_record_path=ASSETS/'papyrus-build-record.json'
    current_record=json.loads(current_record_path.read_text(encoding='utf-8')) if current_record_path.is_file() else {}
    check('Papyrus inherited compiler record is byte-for-byte represented in the build output',current_record==build_record)

    champollion_path=pathlib.Path(champollion)
    champollion_hash=hashlib.sha256(champollion_path.read_bytes()).hexdigest()
    expected_champollion_hash=evidence.get('pinned_champollion_executable_sha256')
    check('Champollion executable matches the pinned 1.3.2 binary hash',bool(expected_champollion_hash) and champollion_hash==expected_champollion_hash)

    out=ROOT/'build/decoded-pex-current';out.mkdir(exist_ok=True)
    for name in ('QLD_Native','QLD_MCM'):
        stale=out/f'{name}.psc'
        if stale.exists():stale.unlink()
        path=ASSETS/'Scripts'/f'{name}.pex'
        subprocess.run([champollion,str(path),'-p',str(out)],check=True,capture_output=True)
    for name in ('QLD_Native','QLD_MCM'):
        if not (out/f'{name}.psc').is_file():
            raise AssertionError(f'Champollion did not produce {name}.psc')
    native=(out/'QLD_Native.psc').read_text(encoding='utf-8')
    mcm=(out/'QLD_MCM.psc').read_text(encoding='utf-8')
    portable_tools=json.loads((ROOT/'dependencies.json').read_text(encoding='utf-8')).get('portableTools',[])
    caprica_spec=next((x for x in portable_tools if pathlib.Path(x['file']).name.casefold()=='caprica.zip'),{})
    compiler=build_record.get('compiler',{})
    check('Papyrus compiler record pins Caprica 0.3.0a archive and executable',compiler.get('name')=='Caprica' and compiler.get('version')=='0.3.0a' and compiler.get('archive_sha256')==caprica_spec.get('sha256') and compiler.get('executable_sha256')==caprica_spec.get('executableSha256'))
    check('Papyrus compiler record matches current sources, PEX payloads and all required imports',build_record.get('source_sha256')==source_hashes and build_record.get('pex_sha256')==current_hashes and build_record.get('external_imports')=={'required':63,'matched':63,'missing':[]})
    signature=re.search(r'function Configure\(([^)]*)\)\s+global native',native,re.I)
    check('PEX Configure native/global ten parameters',signature is not None and len(signature[1].split(','))==10)
    signatureWorld=re.search(r'function ConfigureWorld\(([^)]*)\)\s+global native',native,re.I)
    check('PEX ConfigureWorld native/global five parameters',signatureWorld is not None and len(signatureWorld[1].split(','))==5)
    signatureCard=re.search(r'function ConfigureCardDisplay\(([^)]*)\)\s+global native',native,re.I)
    check('PEX ConfigureCardDisplay native/global sixteen parameters',signatureCard is not None and len(signatureCard[1].split(','))==16)
    check('PEX compiled MCM applies icon toggle, independent scales, and World keys',all(t.lower() in mcm.lower() for t in ('QLD_Native.Configure','iCardScale:QuickLoot','QLD_Native.ConfigureWorld','bEnabled:World','iAnchor:World','fOffsetX:World','fOffsetY:World','iCardScale:World','QLD_Native.ConfigureCardDisplay','bShowExtraInfo:CardInfo','bShowCategory:CardInfo','bShowIcons:CardInfo','bShowOwnedCount:CardInfo','bShowPluginSource:CardInfo','bShowReferenceDps:CardInfo','iMaxRows:CardInfo','fFontScale:CardInfo')))
    for function,section in (('ResetQuickLootPosition','Layout'),('ResetWorldPosition','World')):
        body=re.search(r'function '+function+r'\([^)]*\)(.*?)endfunction',mcm,re.I|re.S)
        check('PEX '+function+' exists',body is not None)
        setters=re.findall(r'SetModSetting(?:Bool|Int|Float)\("([^"]+)"\s*,\s*([^)]*)\)',body[1],re.I)
        check('PEX '+function+' only resets its two saved axes',len(setters)==2 and {key for key,value in setters}=={f'fOffsetX:{section}',f'fOffsetY:{section}'} and all(float(value)==0 for key,value in setters) and 'ApplySettings()' in body[1] and 'RefreshMenu()' in body[1])
        config=json.loads((ASSETS/'MCM/Config/QuickLootDetails/config.json').read_text(encoding='utf-8'))
        check('MCM '+function+' wired to compiled function',any(c.get('action',{}).get('function')==function for c in config['content']))
    check('PEX MCM parent and lifecycle' ,'extends mcm_configbase' in mcm.lower() and all(t.lower() in mcm.lower() for t in ('OnConfigInit','OnGameReload','OnSettingChange','OnConfigClose','ResetDefaults','ApplySettings','RefreshMenu')))

    decompiled_hashes={name:hashlib.sha256((out/f'{name}.psc').read_bytes()).hexdigest() for name in ('QLD_Native','QLD_MCM')}
    BASELINE_RESULTS.append({
        'papyrus_validation':'INHERITED_EXACT_BUILD_AND_FRESH_DECOMPILE_PASS',
        'prior_candidate':'0.1.19-candidate',
        'prior_build_id':baseline_report['build_id'],
        'prior_static_checks':baseline_static['current_checks'],
        'source_hashes_match_current':source_match,
        'pex_hashes_match_current':pex_match and artifact_match and evidence_artifact_match,
        'prior_compiler_record_matches_current':current_record==build_record,
        'current_decompiler_sha256':champollion_hash,
        'current_decompiler_pinned_sha256':expected_champollion_hash,
        'decompiled_source_sha256':decompiled_hashes,
        'source_archive_sha256':evidence['source_archive']['sha256'],
        'revision_source_archive_sha256':evidence['revision_source_archive']['sha256'],
        'runtime_archive_sha256':evidence['runtime_archive']['sha256'],
    })
    evidence.update({
        'fresh_decompilation_this_candidate':True,
        'decompiler_executable_sha256':champollion_hash,
        'decompiled_source_sha256':decompiled_hashes,
        'decompilation_result':'PASS',
    })
    evidence_path.write_text(json.dumps(evidence,ensure_ascii=False,indent=2),encoding='utf-8')

def dll():
    data=(ROOT/'build/native/plugin/QuickLootDetails.dll').read_bytes();pe=struct.unpack_from('<I',data,0x3c)[0]
    check('DLL x64 PE',data[pe:pe+4]==b'PE\0\0' and struct.unpack_from('<H',data,pe+4)[0]==0x8664)
    count=struct.unpack_from('<H',data,pe+6)[0];opt=pe+24;size=struct.unpack_from('<H',data,pe+20)[0]
    check('DLL PE32+',struct.unpack_from('<H',data,opt)[0]==0x20b)
    sections=[struct.unpack_from('<IIII',data,opt+size+i*40+8) for i in range(count)]
    def offset(rva):
        for virtualsize,virtual,rawsize,raw in sections:
            if virtual<=rva<virtual+max(virtualsize,rawsize):return raw+rva-virtual
        raise AssertionError('RVA outside PE sections')
    def cstring(rva):
        p=offset(rva);return data[p:data.index(0,p)].decode('ascii')
    rva=struct.unpack_from('<I',data,opt+112)[0];export=offset(rva)
    n=struct.unpack_from('<I',data,export+24)[0];table=offset(struct.unpack_from('<I',data,export+32)[0])
    names=[cstring(struct.unpack_from('<I',data,table+4*i)[0]) for i in range(n)]
    check('DLL all SKSE exports',set(('SKSEPlugin_Query','SKSEPlugin_Load','SKSEPlugin_Version')).issubset(names))
    ordinalTable=offset(struct.unpack_from('<I',data,export+36)[0]);functionTable=offset(struct.unpack_from('<I',data,export+28)[0])
    ordinal=struct.unpack_from('<H',data,ordinalTable+2*names.index('SKSEPlugin_Version'))[0]
    declaration=offset(struct.unpack_from('<I',data,functionTable+4*ordinal)[0])
    generated=(ROOT/'build/native/__QuickLootDetailsPlugin.cpp').read_text(encoding='utf-8')
    cmake=(ROOT/'CMakeLists.txt').read_text(encoding='utf-8')
    generated_version=re.search(r'\.Version\s*=\s*REL::Version\{\s*(\d+),\s*(\d+),\s*(\d+),\s*(\d+)\s*\}',generated)
    project_version=re.search(r'^project\(QuickLootDetails VERSION (\d+)\.(\d+)\.(\d+)',cmake,re.M)
    same_version=generated_version is not None and project_version is not None and tuple(map(int,generated_version.groups()[:3]))==tuple(map(int,project_version.groups()))
    if generated_version:
        major,minor,patch,build=map(int,generated_version.groups())
        packed_version=(major<<24)|(minor<<16)|(patch<<4)|build
    else: packed_version=-1
    check('Actual DLL exported version matches CMake and generated plugin declaration',same_version and struct.unpack_from('<II',data,declaration)==(1,packed_version) and data[declaration+8:declaration+25]==b'QuickLootDetails\0')
    versions=struct.unpack_from('<16I',data,declaration+0x30c)
    # Pinned CommonLib's VersionNumber default constructor fills remaining slots with 1.0.0.
    # Runtime acceptance is separately restricted by SKSEPlugin_Load and providerAllowed.
    check('Actual DLL primary runtime and minimum SKSE',versions[:3]==(0x01050610,0x01064920,0x01070680) and all(v in (0,0x01000000) for v in versions[3:]) and struct.unpack_from('<I',data,declaration+0x34c)[0]==0x02000140)
    generated=(ROOT/'build/native/__QuickLootDetailsPlugin.cpp').read_text(encoding='utf-8')
    check('DLL declares exactly SE1597/AE1170/AE1704 minimum global SKSE2.0.20','.RuntimeCompatibility = { REL::Version{ 1, 5, 97, 0 }, REL::Version{ 1, 6, 1170, 0 }, REL::Version{ 1, 7, 104, 0 } }' in generated and '.MinimumSKSEVersion = REL::Version{ 2, 0, 20, 0 }' in generated)
    rva=struct.unpack_from('<I',data,opt+120)[0];p=offset(rva);imports=[]
    while any(data[p:p+20]):
        imports.append(cstring(struct.unpack_from('<I',data,p+12)[0]));p+=20
    print('DLL imports:',', '.join(imports))
    system={'kernel32.dll','user32.dll','advapi32.dll','ole32.dll','shell32.dll','bcrypt.dll','d3d11.dll','d3dcompiler_47.dll','dbghelp.dll','dxgi.dll','version.dll'}
    check('DLL only Windows and MSVC runtime imports',all(x.lower() in system or x.lower().startswith(('api-ms-win-crt-','vcruntime140','msvcp140')) for x in imports))
    return imports

def sources():
    manifest=json.loads((ASSETS/'source-manifest.json').read_text(encoding='utf-8'))
    check('Assets match current generating sources',all(hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest for name,digest in manifest.items()))
    plugin=(ROOT/'src/Plugin.cpp').read_text(encoding='utf-8')
    check('Passive menu explicitly passes input through',bool(re.search(r'ProcessMessage\(RE::UIMessage&\) override\s*\{\s*//[^\n]*\n\s*return RE::UI_MESSAGE_RESULTS::kPassOn;\s*\}',plugin)))
    check('No input mutation, action interception or executable branch hook',not any(t in plugin for t in ('RegisterInputActionHandler','RegisterTakingItemHandler','RegisterOpeningLootMenuHandler','PerformInputAction','write_branch','write_call','AllocTrampoline','kPausesGame','kUsesCursor','kModal')))
    check('Provider checked before API handshake',plugin.index('qld::providerAllowed')<plugin.index('QuickLootAPI::Init') and 'conflictingProvider(' in plugin and 'EnumProcessModules' in plugin)
    constructor=plugin[plugin.index('DetailsMenu()'):plugin.index('static RE::IMenu* create()')]
    check('No early constructor movie load','LoadMovie' not in constructor and 'UI_PENDING' in constructor)
    check('Deferred bounded direct load after active loot movie','loadGate_.shouldAttempt(lootVisible,interval)' in plugin and 'loadMovie(loot->uiMovie.get())' in plugin)
    dataLoaded=plugin[plugin.index('if(m->type!=SKSE::MessagingInterface::kDataLoaded)'):plugin.index('extern "C"')]
    check('No detail menu queued during DataLoaded','queue->AddMessage' not in dataLoaded)
    check('Failures separated through definition/instance/viewport/script/render/display',all(t in plugin for t in ('UI_RESOURCE_DIAGNOSTIC','stage=movie-definition','stage=movie-instance','stage=viewport','script-initialization-or-version','UI_POSITION_PENDING','UI_RENDER_FAILED','UI_DISPLAY_ENTER','UI_DISPLAY_RETURN','PANEL_RENDER_APPLIED')))
    loading=plugin[plugin.index('bool loadMovie(RE::GFxMovieView*'):plugin.index('bool pendingPosition(')]
    check('Direct loader avoids the high-level filename precheck','FileExists' not in loading and 'manager->LoadMovie' not in loading and 'loader->CreateMovie' in loading)
    check('Definition and instance ownership balanced',all(t in loading for t in ('movieDefinition_.reset(definition);definition->Release()','uiMovie->Release()','uiMovie.reset();movieDefinition_.reset()')))
    check('Movie initialized before protocol validation',loading.index('SetViewport')<loading.index('Advance(0.0F)')<loading.index('const bool extensions')<loading.index('const bool probeCall'))
    check('Resource header read diagnostic is correctly boolean','const bool headerRead=' in loading and 'headerBytes' not in loading)
    check('Independent resource stream diagnostic uses Skyrim virtual filesystem','BSResourceNiBinaryStream resource("Interface\\\\QuickLootDetails.swf")' in loading and 'resource.read' in loading)
    native=(ROOT/'src/NativeCard.cpp').read_text(encoding='utf-8')
    check('Standard native ItemCard route, pinned typed ABI','native.SetItem(selected,false)' in native and 'RE::ItemCard native(view)' in native)
    check('Food and drink native food-item flag omits only duplicate base-effect row and preserves native text',all(t in native for t in ('const bool foodOrDrink=alchemy->IsFood()','isFoodOrDrink', 'if(!foodOrDrink)','alchemyBaseEffectSummary','potionBaseEffectsJa','potionBaseEffectsEn','native.SetItem(selected,false)')) and all(t in (ROOT/'src/Core.cpp').read_text(encoding='utf-8') for t in ('isFoodOrDrink','potionBaseEffectsEn')) and 'Native drink description' in (ROOT/'tests/CoreTests.cpp').read_text(encoding='utf-8') and '飲料の自然言語効果説明' in (ROOT/'tests/CardTests.cpp').read_text(encoding='utf-8') and not any(t in native for t in ('magicItemDescription','attackDamage','armorRating')))
    dpscore=(ROOT/'src/Core.cpp').read_text(encoding='utf-8');dpssetting=(ROOT/'include/qld/Core.h').read_text(encoding='utf-8')
    check('Reference DPS is opt-in, uses native ItemCard damage × record speed, and rejects unsupported weapon classes',all(t in dpscore for t in ('referenceMeleeDps(double damage,double weaponSpeed)','damage*weaponSpeed','Reference DPS (estimate): {:.1f}','参考DPS（概算）: {:.1f}','isMeleeWeapon')) and 'referenceDps{false}' in dpssetting and all(t in native for t in ('kOneHandSword','kOneHandDagger','kOneHandAxe','kOneHandMace','kTwoHandSword','kTwoHandAxe','isMeleeWeapon')) and all(t in (ROOT/'tests/CoreTests.cpp').read_text(encoding='utf-8') for t in ('Reference DPS (estimate): 40.8','referenceMeleeDps(12.0,1.0)','isMeleeWeapon')))
    check('Category hierarchy comes only from known Form/slot/book data',all(t in native for t in ('GetSlotMask','School unknown','GetAssociatedSkill','categoryPathJa','categoryPathEn','Other/unknown')))
    check('Ingredient known count is capped at actual native slots',all(t in native for t in ('gamedata.knownEffectFlags','ingredient->effects.size()','countKnownIngredientEffects')) and 'const auto count=std::min(effectCount,4u)' in (ROOT/'src/Core.cpp').read_text(encoding='utf-8') and 'std::popcount(flags&mask)' in (ROOT/'src/Core.cpp').read_text(encoding='utf-8'))
    check('Soul gem capacity and mixed selected stack do not guess a soul',all(t in native for t in ('GetMaximumCapacity','uniformSoulLevel','soulMixed','extra->GetSoulLevel()')))
    card=(ROOT/'src/Card.cpp').read_text(encoding='utf-8');contract=card[card.index('bool validCard('):card.index('return true; // zero weight/value')]
    check('New metadata remains optional and legacy zero weight/empty description remain valid',all(t in contract for t in ('number("type")','number("weight")','number("value")','text("name")','itemEffect3')) and not any(t in contract for t in ('categoryPath','ingredientKnownEffects','soulCapacity','potionBaseEffects')))
    ui_source=(ROOT/'ui/panel.as').read_text(encoding='utf-8')
    stats=ui_source[ui_source.index('function qldCardStats('):ui_source.index('function qldCardDescription',ui_source.index('function qldCardStats('))]
    check('V/W UI ratio is gated and excludes invalid or nonpositive weight',all(t in stats for t in ('card.showValueWeight != false','card.value / card.weight','isFinite(card.weight)','card.weight > 0','isFinite(card.value)','card.value >= 0','V/W')) and not any(t in native for t in ('value / weight','value/weight','valueWeightRatio')))
    check('Owned menu context and fresh scoped selection; no fixed worker ID',all(t in native for t in ('consistentStack','droppedEntry.AddExtraList','unexpected-field-type','native-field-contract','ambiguous-individual','GetInventory','selection-changed')) and 'uiThreadId' not in plugin and 'AddUITask' not in plugin and 'resolveNativeCard(*frame.selected,uiMovie.get())' in plugin)
    check('BOOK CNAM distinguished from body DESC',"itemCardDescription.GetDescription(description,book,'MANC')" in native and 'book-cnam-not-in-native-card' in native)
    check('Native card copied primitive fields, no retained GFx objects','std::map<std::string,CardValue>' in (ROOT/'include/qld/Card.h').read_text() and 'std::variant<double,bool,std::string>' in (ROOT/'include/qld/Card.h').read_text())
    check('Selection callback copies values; card is published with stale-selection protection','item.selectedTraits=qld::copyStackTraits(entry)' in plugin and 'state.publishCard(frame.generation,token' in plugin and 'state.select(e->container.native_handle(),std::move(item))' in plugin)
    callback=plugin[plugin.index('std::optional<qld::Item> copyItem'):plugin.index('void onOpen(')]
    check('Callback has no movie or native card operation',not any(t in callback for t in ('uiMovie','GetMenu','copyNativeCard','SetItem','resolveNativeCard')))
    check('Native resolver has exactly one owning-menu call',plugin.count('qld::resolveNativeCard(')==1 and 'GetInventory(' in native and '},true)' in native)
    core=(ROOT/'src/Core.cpp').read_text(encoding='utf-8')
    legacy=(ROOT/'src/LegacyBridge.cpp').read_text(encoding='utf-8')
    decoder=(ROOT/'src/LegacySelection.cpp').read_text(encoding='utf-8')
    check('Legacy reads exact native selected EntryData, never BaseForm/name lookup',all(t in decoder for t in ('out.entryAddress','observer!=out.entryAddress','container!=out.container','which!=0','which!=1','vectorRange(v,8,16384)')) and 'LookupByID' not in decoder)
    check('Legacy copies all ground handles and rejects divergent native cards','out.groundHandles.resize' in decoder and 'result->fields!=card->fields' in legacy and 'total!=selected.count' in legacy)
    check('Legacy owns provider Advance context and verifies before/after selection','originalAdvance(menu,interval,time);' in legacy and '*after!=*selection' in legacy and 'inspect(*after)!=key' in legacy and 'state->selectCurrent(generation' in legacy)
    check('Legacy exact vtable/code proof, compare-exchange and rollback',all(t in legacy for t in ('legacyBinaryEvidence','legacyVtableMatches(proof,base,table)','legacyCodeMatches(proof,n,code)','InterlockedCompareExchangePointer','replace(slots+4,reinterpret_cast<void*>(messageHook)')))
    proof=(ROOT/'include/qld/LegacyBinaryEvidence.h').read_text(encoding='utf-8')
    profiles=(ROOT/'include/qld/LegacySelection.h').read_text(encoding='utf-8')
    check('Legacy method/table guard rejects all foreign changes before mutation','table[n]!=base+proof.functions[n]' in proof and 'sha256(code)' in proof and 'slot!=4 && slot!=5' in proof and 'proof.messageSha256:proof.advanceSha256' in proof)
    check('EE1170 and AE use independently proven exact runtime profiles','l.runtime==runtime' in profiles and ',0x4c,0x148}' in profiles and 'ca746bbed4e752c3853c83eca1599ae965caaa1815969d68821ce74ec9a3bc61' in profiles and 'c99d38c58a3ed60159e7a9f4c10110a04751a8b433cad8fd982d6c3ba960037f' in profiles)
    check('Load gate rejects unsupported runtime/SKSE before initialization',plugin.index('runtimeLoadAllowed(')<plugin.index('SKSE::Init(skse)') and 'skse->SKSEVersion()' in plugin)
    layouts=json.loads((ROOT/'docs/provider-abi-facts.json').read_text())
    check('New providers retain matching-PDB ABI facts without copied code',len(layouts)==2 and all(x['matching_pdb'] and len(x['verified_fields'])==17 and 'message_signature' not in x for x in layouts))
    check('Legacy clones selected ExtraData pointer-list only within native scope','RE::InventoryEntryData owned(*borrowed)' in native and 'owned.countDelta=count' in native and 'copyNativeCard(&owned,drop,view)' in native)
    check('Legacy never persists borrowed entry in State','selectCurrent(std::uint64_t generation' in core and 'frame_.generation!=generation' in core and 'LegacySelection' not in (ROOT/'include/qld/Core.h').read_text())
    check('Legacy stale render and invalid native fallback suppressed','frame.revision!=lastRevision_' in plugin and '&& !legacyProvider)' in plugin)
    check('Card publication rejects stale close/reopen and selection','frame_.generation!=generation' in core and 'frame_.selected->stackIdentity!=selection' in core and '!frame_.open' in core)
    check('Native original effects retained alongside diagnosed normalized text','normalizeNativeText(std::get<std::string>(it->second))' in native and 'effectsPlain' in native and 'CARD_TEXT_FAILED' in native and 'CARD_TEXT_WARNING' in native and native.index('normalizeNativeText')<native.index('SKSE::log::debug("CARD_COPY_OK'))
    source=(ROOT/'ui/panel.as').read_text(encoding='utf-8')
    check('World source uses event handles only and validated game target',all(t in plugin for t in ('GetCrosshairRefEventSource','worldEventTarget.exchange(handle)','GetActiveTarget()','worldState_.observe','worldEventEpoch.load()!=eventEpoch','worldState_.clear()')))
    sink=plugin[plugin.index('class CrosshairSink'):plugin.index('qld::WorldEnvironment worldEnvironment')]
    check('Crosshair callback retains no pointer or performs movie/native work',not any(t in sink for t in ('SetItem','uiMovie','AddExtraList','resolveWorldCard','worldState_')))
    worldNative=native[native.index('std::optional<WorldTarget> inspectWorldTarget'):native.index('bool makeCardObject(')]
    check('World reference validates live lifetime, base, count, type and individual ExtraData',all(t in worldNative for t in ('IsDeleted()','IsDisabled()','IsActivationBlocked()','GetParentCell()','Get3D()','IsInventoryObject()','CanBeCarried()','ref->extraList.GetCount()','target.referenceId','copyNativeCard(&entry,handle,view)')))
    check('World native whitelist excludes non-pickup activators/containers/actors',all('RE::FormType::'+t in worldNative for t in ('AlchemyItem','Weapon','Armor','Book','Ingredient','Misc')) and not any('case RE::FormType::'+t in worldNative for t in ('Container','NPC','ActorCharacter','Door','Furniture','Activator','Flora','Tree')))
    check('World preserves HUD theft display and performs no acquisition',not any(t in plugin+worldNative for t in ('ActivateRef(','ActivatePickRef(','RemoveItem(','PickUpObject(','SetCrosshairTarget','HUD_MESSAGE_TYPE','ActivationPrompt','IsOwnedBy(')))
    check('World active reference checked before and after native generation',worldNative.count('pick->GetActiveTarget().native_handle()!=target.handle')==2 and 'inspectWorldTarget(handle)!=std::optional<WorldTarget>(target)' in worldNative)
    check('World independent settings native registration and initial OFF',all(t in plugin for t in ('RegisterFunction("ConfigureWorld"','state.configureWorld','state.configureLoot')) and 'bool enabled{false}' in (ROOT/'include/qld/Core.h').read_text(encoding='utf-8'))
    check('World suppresses QuickLoot, menus, pause and unavailable HUD',all(t in plugin for t in ('worldEnvironment(ui,lootVisible || settingFrame.open)','GameIsPaused()','numItemMenus','Dialogue Menu','InventoryMenu','IsShowingMenus()','IsActivateControlsEnabled()')))
    check('World skips draw immediately for stale target or suppression','qld::inspectWorldTarget(currentWorldHandle())!=worldRenderedTarget_' in plugin and 'if(worldMode_ && wasVisible_)' in plugin)
    check('World uses same render/measurement contract and bounded refresh',plugin.count('std::array<RE::GFxValue,10> args')==1 and 'qld::placeWorldPanel' in plugin and 'refreshDelay_=1.0;' in (ROOT/'src/World.cpp').read_text(encoding='utf-8'))
    check('QuickLoot/World effective render scales remain independent',all(t in plugin for t in ('qld::quickLootRenderScale(settings)','qld::worldRenderScale(settings)','qld::quickLootRenderScale(frame.settings)','qld::worldRenderScale(frame.settings)')) and 's.scale*static_cast<double>(s.quickLootScalePercent)/100.0' in core and 's.scale*static_cast<double>(s.world.cardScalePercent)/100.0' in core)
    check('Individual card scales leave anchor gaps and position offsets in screen units',all(t in core for t in ('12*s.scale','32*s.scale','panel.x+s.offsetX','panel.y+s.offsetY')))
    check('Description/grid use actual field autosize and never the ellipsis fitter','field.autoSize = "left"' in source and 'qldSetFullText(content.description' in source and 'qldSetFullText(field, cell.text' in source and 'qldSetText(content.description' not in source)

def main():
    sources();esp();swf();mcm();papyrus();imports=dll()
    artifacts=[p for p in ASSETS.rglob('*') if p.suffix in ('.esp','.pex','.seq','.swf') and p.name!='seed.swf']
    artifacts.append(ROOT/'build/native/plugin/QuickLootDetails.dll')
    static_status='STATIC_PARTIAL' if PAPYRUS_NOT_RUN else 'STATIC_PASS'
    report={'status':static_status,'runtime':'NOT_TESTED','check_count':len(RESULTS),'checks':RESULTS,'dll_imports':imports,'workspace_baselines':BASELINE_RESULTS,'papyrus_current_run':PAPYRUS_NOT_RUN[0] if PAPYRUS_NOT_RUN else {'status':'PASS','method':'Fresh Champollion 1.3.2 decompilation of byte-identical 0.1.19 PEX outputs; current Papyrus sources and inherited Caprica build record match exact SHA-256'},'papyrus_build':json.loads((ASSETS/'papyrus-build-record.json').read_text(encoding='utf-8')) if (ASSETS/'papyrus-build-record.json').is_file() else None,
        'artifacts':{str(p.relative_to(ROOT)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in artifacts}}
    (ROOT/'build/verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(f'{static_status}: {len(RESULTS)} current checks; Papyrus decompilation '+('NOT_RUN/BLOCKED; prior evidence is separately recorded.' if PAPYRUS_NOT_RUN else 'PASS.')+' RUNTIME NOT TESTED.')
if __name__=='__main__':main()
