"""Audit actual 065 source/runtime ZIP bytes, identities, allowlists and re-extraction."""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import tempfile
import zipfile
from pathlib import Path, PurePosixPath

from build_identity import read_identity, verify_binary
from marker_contract import verify_dll_binding
from package_private_065 import (
    LICENSES, PARENT_RUNTIME_SHA256, PARENT_SOURCE_SHA256, ROOT_DOCS, RUNTIME_CANDIDATE,
    RUNTIME_DLL, RUNTIME_ICON_SWF, RUNTIME_MANIFEST, RUNTIME_MARKER_HISTORY,
    RUNTIME_UI_SWF, RUNTIME_VERIFICATION, STALE_RUNTIME_DOCS, safe_name,
)
from source_manifest import collect_source_files, verify_manifest

SOURCE_MANIFEST = "QuickLootDetails/source-manifest.json"
FORBIDDEN_SOURCE_SUFFIXES = {".dll", ".exe", ".lib", ".pdb", ".swf", ".pex", ".esp", ".esl", ".esm", ".bsa", ".ba2"}
OLD_MARKER_HASHES = {
    "20.svg": "de4250106336c6811d2a9d5880d8c0cb4f79ca987208fa22e900dfa4b40a95e9",
    "22.svg": "fe2234b7e2455751490dd5b485baf627f063cd5b9ee621b14aa22ee63e753cd0",
    "24.svg": "1e32f52970c3d1d335529cbde5f9e1e0bea33e7c04087b434ec16ab93316106b",
    "26.svg": "79bdda172c7e1702f5e2925841a1d6c654fc76b79516f9d70b0bd7b4513f0cda",
}
BASELINE_DOC_REMOVALS = {
    "QuickLootDetails_Docs/docs/candidate-057.json",
    "QuickLootDetails_Docs/docs/verification.json",
    "QuickLootDetails_Docs/docs/MARKER_ART_CREDIT_JA.md",
}
NEW_RUNTIME_DOCS = {RUNTIME_CANDIDATE, RUNTIME_VERIFICATION, RUNTIME_MARKER_HISTORY}
REPLACED_RUNTIME_PATHS = {
    RUNTIME_UI_SWF, RUNTIME_DLL, RUNTIME_ICON_SWF,
    *("QuickLootDetails_Docs/" + name for name in ROOT_DOCS),
    RUNTIME_MARKER_HISTORY,
}


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def read_zip(path: Path) -> tuple[list[str], dict[str, bytes]]:
    with zipfile.ZipFile(path) as archive:
        bad = archive.testzip()
        if bad:
            raise AssertionError(f"ZIP CRC failure: {bad}")
        names = archive.namelist()
        if len(names) != len(set(names)):
            raise AssertionError("duplicate ZIP member names")
        for name in names:
            safe_name(name)
        return names, {name: archive.read(name) for name in names}


def verify_archive_manifest(manifest_bytes: bytes, payload: dict[str, bytes], label: str) -> dict[str, str]:
    manifest = json.loads(manifest_bytes.decode("utf-8-sig"))
    if not isinstance(manifest, dict) or set(manifest) != set(payload):
        raise AssertionError(f"{label} member set differs from its manifest")
    for name, digest in manifest.items():
        if sha(payload[name]) != digest:
            raise AssertionError(f"{label} member hash mismatch: {name}")
    return manifest


def read_referenced_parent_runtime(path: Path) -> dict[str, bytes]:
    if sha(path.read_bytes()) != PARENT_RUNTIME_SHA256:
        raise AssertionError("057 parent runtime ZIP hash differs from the lineage record")
    _, all_files = read_zip(path)
    if RUNTIME_MANIFEST not in all_files:
        raise AssertionError("057 parent runtime manifest is missing")
    payload = {name: data for name, data in all_files.items() if name != RUNTIME_MANIFEST}
    verify_archive_manifest(all_files[RUNTIME_MANIFEST], payload, "057 parent runtime manifest")
    return payload


def read_parent_source_dependencies(path: Path) -> dict[str, bytes]:
    if sha(path.read_bytes()) != PARENT_SOURCE_SHA256:
        raise AssertionError("057 parent source ZIP hash differs from the lineage record")
    required = {"QuickLootDetails/deps/commonlib.zip", "QuickLootDetails/deps/spdlog.zip",
                "QuickLootDetails/deps/directxtk.zip", "QuickLootDetails/deps/directxmath.zip"}
    with zipfile.ZipFile(path) as archive:
        names = set(archive.namelist())
        if not required.issubset(names):
            raise AssertionError("057 source ZIP is missing one or more pinned dependency archives")
        # Verify only the four pinned archive payloads; dependency trees are not expanded or recursively hashed.
        return {name: archive.read(name) for name in required}


def reextract_check(payloads: dict[str, dict[str, bytes]], build_root: Path) -> None:
    with tempfile.TemporaryDirectory(prefix="qld065-zip-audit-", dir=build_root) as temp:
        base = Path(temp).resolve()
        for label, files in payloads.items():
            area = (base / label).resolve()
            area.mkdir()
            for name, data in files.items():
                safe_name(name)
                target = (area / Path(*PurePosixPath(name).parts)).resolve()
                if not target.is_relative_to(area):
                    raise AssertionError(f"re-extraction path escaped: {name}")
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(data)
            for name, data in files.items():
                target = area / Path(*PurePosixPath(name).parts)
                if target.read_bytes() != data:
                    raise AssertionError(f"re-extraction byte mismatch: {label}/{name}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--build-root", type=Path, required=True)
    parser.add_argument("--baseline-source", type=Path, required=True)
    parser.add_argument("--baseline-runtime", type=Path, required=True)
    parser.add_argument("--source-zip", type=Path, required=True)
    parser.add_argument("--runtime-zip", type=Path, required=True)
    parser.add_argument("--verification-result", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    try:
        root = args.root.resolve()
        build_root = args.build_root.resolve()
        manifest_sha, manifest_count = verify_manifest(root)
        swf_path = build_root / "assets" / "Interface" / "QuickLootDetails.swf"
        icon_swf_path = build_root / "assets" / "Interface" / "QuickLootDetails_CategoryIcons.swf"
        dll_path = build_root / "native" / "plugin" / "QuickLootDetails.dll"
        swf, icon_swf, dll = swf_path.read_bytes(), icon_swf_path.read_bytes(), dll_path.read_bytes()
        identity = read_identity(root, swf_path, icon_swf_path)
        verify_binary(dll, identity)
        pair = verify_dll_binding(root, swf, icon_swf, dll)
        cache = (build_root / "native" / "CMakeCache.txt").read_text(encoding="utf-8-sig")
        if "QLD_EXIT_DIAGNOSTICS:BOOL=ON" not in cache or "QLD_DIAGNOSTIC_LOGGING:BOOL=OFF" not in cache:
            raise AssertionError("private testpack build options differ from the approved bounded diagnostics configuration")

        source_names, source_all = read_zip(args.source_zip)
        if SOURCE_MANIFEST not in source_all:
            raise AssertionError("065 source ZIP lacks source-manifest.json")
        source_payload = {name: data for name, data in source_all.items() if name != SOURCE_MANIFEST}
        source_manifest = verify_archive_manifest(source_all[SOURCE_MANIFEST], source_payload, SOURCE_MANIFEST)
        current_source = {"QuickLootDetails/" + rel: path.read_bytes() for rel, path in collect_source_files(root).items()}
        if source_payload != current_source:
            raise AssertionError("source ZIP bytes differ from the current 065 source allowlist")
        source_disk_manifest = json.loads((root / "source-manifest.json").read_text(encoding="utf-8-sig"))
        if source_manifest != source_disk_manifest or sha((root / "source-manifest.json").read_bytes()) != manifest_sha:
            raise AssertionError("source ZIP manifest differs from the recorded source manifest")
        if len(source_manifest) != manifest_count:
            raise AssertionError("source ZIP entry count differs from candidate source manifest")
        for name in source_payload:
            if PurePosixPath(name).suffix.lower() in FORBIDDEN_SOURCE_SUFFIXES:
                raise AssertionError(f"compiled runtime artifact found in source ZIP: {name}")

        parent_deps = read_parent_source_dependencies(args.baseline_source)
        for name, data in parent_deps.items():
            if source_payload.get(name) != data:
                raise AssertionError(f"pinned dependency archive changed from the 057 source: {name}")

        for filename, digest in OLD_MARKER_HASHES.items():
            path = "QuickLootDetails/assets/marker-art/" + filename
            data = source_payload.get(path)
            if data is None or sha(data) == digest:
                raise AssertionError(f"the 057 external marker SVG was not replaced: {filename}")
            if any(sha(other) == digest for other in source_payload.values()):
                raise AssertionError(f"the 057 marker SVG bytes remain elsewhere in the 065 source ZIP: {filename}")
        replacement_map = json.loads(source_payload["QuickLootDetails/assets/marker-art/provenance.json"])
        if replacement_map.get("source_set") != "061-iconset" or replacement_map.get("candidate") != identity["candidate_name"]:
            raise AssertionError("marker provenance does not distinguish 057 historical art from 061 replacement art")
        for slot, symbol in (("20", "enchanted_mark"), ("22", "known_enchant_mark"),
                             ("24", "special_enchant_mark"), ("26", "read_mark")):
            record = replacement_map["marker_slots"][slot]
            source_name = "QuickLootDetails/" + record["source_svg"]
            slot_name = f"QuickLootDetails/assets/marker-art/{slot}.svg"
            expected_hash = record["source_svg_sha256"]
            if record.get("symbol_id") != symbol or sha(source_payload[source_name]) != expected_hash:
                raise AssertionError(f"marker provenance source/hash mismatch for slot {slot}")
            if sha(source_payload[slot_name]) != expected_hash:
                raise AssertionError(f"marker slot SVG does not match its 061 overlay source for slot {slot}")

        parent_runtime = read_referenced_parent_runtime(args.baseline_runtime)
        runtime_names, runtime_all = read_zip(args.runtime_zip)
        if RUNTIME_MANIFEST not in runtime_all:
            raise AssertionError("065 runtime ZIP lacks its manifest")
        runtime_payload = {name: data for name, data in runtime_all.items() if name != RUNTIME_MANIFEST}
        runtime_manifest = verify_archive_manifest(runtime_all[RUNTIME_MANIFEST], runtime_payload, RUNTIME_MANIFEST)
        expected_names = (set(parent_runtime) - BASELINE_DOC_REMOVALS) | NEW_RUNTIME_DOCS | {RUNTIME_ICON_SWF}
        if set(runtime_payload) != expected_names:
            missing, extra = sorted(expected_names - set(runtime_payload)), sorted(set(runtime_payload) - expected_names)
            raise AssertionError(f"065 runtime allowlist mismatch; missing={missing}, extra={extra}")
        if runtime_payload[RUNTIME_UI_SWF] != swf or runtime_payload[RUNTIME_ICON_SWF] != icon_swf or runtime_payload[RUNTIME_DLL] != dll:
            raise AssertionError("runtime ZIP compiled UI/sidecar/DLL bytes differ from the exact candidate build")
        if any(name.lower().endswith(".pdb") for name in runtime_payload):
            raise AssertionError("private PDB must not be included in the runtime testpack")
        if {name for name in runtime_payload if name.lower().endswith(".dll")} != {RUNTIME_DLL}:
            raise AssertionError("runtime ZIP DLL allowlist differs")
        for name in STALE_RUNTIME_DOCS:
            if name in runtime_payload:
                raise AssertionError(f"stale 057 runtime document remains: {name}")
        runtime_root_docs = {"QuickLootDetails_Docs/" + name for name in ROOT_DOCS}
        for name, data in parent_runtime.items():
            if name not in BASELINE_DOC_REMOVALS | {RUNTIME_UI_SWF, RUNTIME_DLL, RUNTIME_ICON_SWF, RUNTIME_MANIFEST} and name not in runtime_root_docs:
                if runtime_payload.get(name) != data:
                    raise AssertionError(f"unrequested inherited runtime payload changed: {name}")

        inherited_license_paths = {name for name in parent_runtime if name.startswith("QuickLootDetails_Docs/licenses/")}
        if {name.rsplit("/", 1)[-1] for name in inherited_license_paths} != LICENSES:
            raise AssertionError("parent runtime's complete license/notice set differs from the expected inherited set")
        for name in inherited_license_paths:
            if runtime_payload.get(name) != parent_runtime[name]:
                raise AssertionError(f"an inherited license notice was removed or changed: {name}")
        for name in ROOT_DOCS:
            if runtime_payload["QuickLootDetails_Docs/" + name] != (root / name).read_bytes():
                raise AssertionError(f"runtime root notice differs from 065 source: {name}")

        candidate_doc = json.loads(runtime_payload[RUNTIME_CANDIDATE].decode("utf-8-sig"))
        verification_doc = json.loads(runtime_payload[RUNTIME_VERIFICATION].decode("utf-8-sig"))
        verification_result = json.loads(args.verification_result.read_text(encoding="utf-8-sig"))
        if candidate_doc.get("candidate_id") != identity["candidate_id"] or candidate_doc.get("category_icon_swf_sha256") != sha(icon_swf):
            raise AssertionError("runtime candidate document does not bind the exact dual-SWF identity")
        if verification_doc.get("candidate_id") != identity["candidate_id"]:
            raise AssertionError("runtime verification document candidate identity differs")
        if verification_doc.get("tests") != verification_result.get("tests"):
            raise AssertionError("runtime verification document tests differ from final 065 evidence")
        if any(value != "PASS" for value in verification_doc.get("tests", {}).values()):
            raise AssertionError("runtime verification document has a required test not marked PASS")
        if candidate_doc.get("pdb", {}).get("matches_dll_codeview") is not True:
            raise AssertionError("runtime candidate evidence does not confirm the private PDB identity")
        if candidate_doc.get("scope", {}).get("license_or_external_publication_permission") != "NOT_CLAIMED":
            raise AssertionError("candidate document makes an unsupported distribution/license permission claim")
        if candidate_doc.get("icon_library", {}).get("artwork_review_status") != "PROVISIONAL_PENDING_USER_REVIEW":
            raise AssertionError("runtime package fails to identify the current individual artwork as provisional")
        if candidate_doc.get("icon_library", {}).get("individual_svg_final_approval") is not False:
            raise AssertionError("runtime package claims final approval of the current individual SVGs")
        if candidate_doc.get("scope", {}).get("artwork") != "current individual SVG set remains provisional until the user resumes and completes icon review":
            raise AssertionError("runtime candidate scope omits the user's later icon review")

        source_base_dir = root.parent.parent / "evidence" / "inputs" / "057" / "source"
        old_credit = source_base_dir / "docs" / "MARKER_ART_CREDIT_JA.md"
        new_credit = root / "docs" / "MARKER_ART_CREDIT_057_HISTORY.md"
        if not old_credit.is_file() or not new_credit.is_file():
            raise AssertionError("marker-art credit history source evidence is incomplete")
        old_credit_hash = sha(old_credit.read_bytes())
        if old_credit_hash == sha(new_credit.read_bytes()):
            raise AssertionError("057 marker credit was copied as a current 065 artwork claim")
        if runtime_payload[RUNTIME_MARKER_HISTORY] != new_credit.read_bytes():
            raise AssertionError("runtime marker-art history differs from the candidate's historical-only notice")

        reextract_check({"source": source_payload, "runtime": runtime_payload}, build_root)
        result = {
            "status": "PASS", "candidate_name": identity["candidate_name"], "candidate_id": identity["candidate_id"],
            "lineage_build_id": identity["lineage_build_id"], "plugin_version": identity["plugin_version"],
            "category_route": identity["category_route"], "ui_probe_marker": identity["ui_probe_marker"],
            "artwork_review_status": candidate_doc["icon_library"]["artwork_review_status"],
            "verification_state": "TECHNICAL_TESTS_PASS_ART_REVIEW_PENDING",
            "source_manifest_sha256": manifest_sha, "source_manifest_entries": manifest_count,
            "marker_contract": pair["marker_contract"],
            "source_zip": {"name": args.source_zip.name, "bytes": args.source_zip.stat().st_size,
                           "sha256": sha(args.source_zip.read_bytes()), "entries_including_manifest": len(source_names)},
            "runtime_zip": {"name": args.runtime_zip.name, "bytes": args.runtime_zip.stat().st_size,
                            "sha256": sha(args.runtime_zip.read_bytes()), "entries_including_manifest": len(runtime_names)},
            "source_manifest_file_count": len(source_manifest), "runtime_manifest_file_count": len(runtime_manifest),
            "dependency_archive_policy": "four pinned source ZIPs compared byte-for-byte; no nested dependency-tree traversal",
            "old_057_marker_art_remaining": False,
            "marker_art_vs_api_license_scope": {
                "057_marker_vector_bytes_in_source_runtime": False,
                "QuickLootIE_API_header_and_MIT_exception_retained": True,
                "QuickLootIE_GPL_notices_retained": True,
                "publication_or_license_permission_claimed": False,
            },
            "crc": "PASS", "file_hashes": "PASS", "zip_member_allowlists": "PASS",
            "reextraction_byte_check": "PASS", "dll_main_swf_icon_swf_pairing": "PASS",
            "pdb_in_runtime_zip": False, "game_load": "NOT_TESTED", "Scaleform_execution": "NOT_TESTED",
            "CTD_resolution": "UNVERIFIED", "deployment": "NOT_PERFORMED", "publication": "NOT_PERFORMED",
        }
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        print("PACKAGE_AUDIT_065_PASS " + json.dumps(result, ensure_ascii=False, separators=(",", ":")))
        return 0
    except (OSError, AssertionError, ValueError, KeyError, json.JSONDecodeError, zipfile.BadZipFile) as exc:
        print(f"PACKAGE_AUDIT_065_FAIL {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
