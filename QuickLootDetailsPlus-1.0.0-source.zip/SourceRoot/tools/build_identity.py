"""Fail-closed 065 build identity generator and verifier."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
import re
import sys
import tempfile
from pathlib import Path
from source_manifest import verify_manifest, write_manifest


class IdentityError(ValueError):
    pass


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def cpp_string(value: str) -> str:
    return json.dumps(value, ensure_ascii=True)


def read_identity(root: Path, swf_path: Path, icon_swf_path: Path) -> dict[str, object]:
    try:
        swf_data = swf_path.read_bytes()
        icon_swf_data = icon_swf_path.read_bytes()
    except OSError as exc:
        raise IdentityError(f'compiled candidate SWF cannot be read: {exc}') from exc
    return read_identity_data(root, swf_data, icon_swf_data)


def read_identity_data(root: Path, swf_data: bytes, icon_swf_data: bytes) -> dict[str, object]:
    root = root.resolve()
    if not icon_swf_data:
        raise IdentityError('category-icon SWF is empty')
    manifest_sha, manifest_count = verify_manifest(root)
    try:
        meta = json.loads((root / 'docs' / 'candidate-065.json').read_text(encoding='utf-8-sig'))
        proof = json.loads((root / 'docs' / 'verification-065.json').read_text(encoding='utf-8-sig'))
        cmake = (root / 'CMakeLists.txt').read_text(encoding='utf-8-sig')
    except (OSError, json.JSONDecodeError) as exc:
        raise IdentityError(f'candidate identity input cannot be read: {exc}') from exc

    version_match = re.search(r'(?m)^\s*project\s*\(\s*QuickLootDetails\s+VERSION\s+([0-9]+\.[0-9]+\.[0-9]+)', cmake)
    if not version_match:
        raise IdentityError('QuickLootDetails project version is missing')
    project_version = version_match.group(1)
    candidate_name = meta.get('candidate_name')
    plugin_version = meta.get('plugin_version')
    route_expected = meta.get('category_route')
    marker_expected = meta.get('ui_probe_marker')
    lineage_id = meta.get('lineage_build_id')
    if candidate_name != 'QLD-ORIGINAL-ICON-INTEGRATION-065':
        raise IdentityError(f'unexpected candidate name: {candidate_name!r}')
    if plugin_version != f'{project_version}.0':
        raise IdentityError('candidate plugin_version does not match the CMake project version')
    if proof.get('candidate_name') != candidate_name or proof.get('plugin_version') != plugin_version:
        raise IdentityError('verification.json candidate name/plugin version mismatch')
    if proof.get('category_route') != route_expected:
        raise IdentityError('verification.json route mismatch')
    if proof.get('lineage', {}).get('canonical_build_id') != lineage_id:
        raise IdentityError('verification.json canonical lineage BuildID mismatch')
    if not isinstance(lineage_id, str) or not re.fullmatch(r'QLD-[0-9]+\.[0-9]+\.[0-9]+-r[0-9]+-[0-9a-f]{16}', lineage_id):
        raise IdentityError('canonical lineage BuildID is malformed')
    if not isinstance(route_expected, str) or route_expected not in {'text', 'skyui', 'owned-svg'}:
        raise IdentityError('candidate category route is missing or unsupported')
    plugin_source = (root / 'src' / 'Plugin.cpp').read_text(encoding='utf-8-sig')
    identity_log = ('IDENTITY candidate_name={} candidate_id={} lineage_build_id={} plugin_version={} '
                    'category_route={} source_manifest_sha256={} source_manifest_entries={} '
                    'ui_probe_marker={} ui_swf_sha256={} category_icon_swf_sha256={}')
    required_symbols = (
        'qld::build_identity::kCandidateName', 'qld::build_identity::kCandidateId',
        'qld::build_identity::kLineageBuildId', 'qld::build_identity::kPluginVersion',
        'qld::build_identity::kCategoryRoute', 'qld::build_identity::kSourceManifestSha256',
        'qld::build_identity::kSourceManifestEntries', 'qld::build_identity::kUiProbeMarker',
        'qld::build_identity::kUiSwfSha256', 'qld::build_identity::kCategoryIconSwfSha256',
    )
    if identity_log not in plugin_source or not all(symbol in plugin_source for symbol in required_symbols):
        raise IdentityError('Plugin.cpp startup logger does not bind every 065 identity field')

    from marker_contract import verify_marker_contract
    try:
        markers = verify_marker_contract(root, swf_data)
    except (OSError, ValueError, AssertionError) as exc:
        raise IdentityError(f'native/AS2/compiled-SWF marker contract failed: {exc}') from exc
    marker = markers['marker']
    if marker != marker_expected:
        raise IdentityError(f'candidate metadata marker {marker_expected!r} differs from source/SWF marker {marker!r}')
    if markers['category_route'] != route_expected:
        raise IdentityError(f'candidate route {route_expected!r} differs from AS2 source route {markers["category_route"]!r}')

    ui_swf_sha = sha256(swf_data)
    category_icon_swf_sha = sha256(icon_swf_data)
    candidate_material = {
        'candidate_name': candidate_name,
        'lineage_build_id': lineage_id,
        'plugin_version': plugin_version,
        'category_route': route_expected,
        'ui_probe_marker': marker,
        'source_manifest_sha256': manifest_sha,
        'ui_swf_sha256': ui_swf_sha,
        'category_icon_swf_sha256': category_icon_swf_sha,
    }
    candidate_digest = sha256(json.dumps(candidate_material, sort_keys=True, separators=(',', ':')).encode('utf-8'))
    candidate_id = f'QLD-065-{candidate_digest[:16]}'
    return {
        'candidate_name': candidate_name,
        'candidate_id': candidate_id,
        'lineage_build_id': lineage_id,
        'plugin_version': plugin_version,
        'category_route': route_expected,
        'source_manifest_sha256': manifest_sha,
        'source_manifest_entries': manifest_count,
        'ui_probe_marker': marker,
        'ui_swf_sha256': ui_swf_sha,
        'category_icon_swf_sha256': category_icon_swf_sha,
    }


def render_header(identity: dict[str, object]) -> bytes:
    fields = {
        'kCandidateName': str(identity['candidate_name']),
        'kCandidateId': str(identity['candidate_id']),
        'kLineageBuildId': str(identity['lineage_build_id']),
        'kPluginVersion': str(identity['plugin_version']),
        'kCategoryRoute': str(identity['category_route']),
        'kSourceManifestSha256': str(identity['source_manifest_sha256']),
        'kUiProbeMarker': str(identity['ui_probe_marker']),
        'kUiSwfSha256': str(identity['ui_swf_sha256']),
        'kCategoryIconSwfSha256': str(identity['category_icon_swf_sha256']),
    }
    lines = ['#pragma once', '#include <string_view>', 'namespace qld::build_identity {']
    for key, value in fields.items():
        lines.append(f'inline constexpr std::string_view {key} = {cpp_string(value)};')
    lines.append(f'inline constexpr unsigned long long kSourceManifestEntries = {int(identity["source_manifest_entries"])}ULL;')
    lines.extend(['}', ''])
    return '\n'.join(lines).encode('utf-8')


def write_if_changed(path: Path, content: bytes) -> bool:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_file() and path.read_bytes() == content:
        return False
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_bytes(content)
    os.replace(temporary, path)
    return True


def verify_header(path: Path, identity: dict[str, object]) -> None:
    text = path.read_text(encoding='utf-8-sig')
    fields = {
        'kCandidateName': identity['candidate_name'],
        'kCandidateId': identity['candidate_id'],
        'kLineageBuildId': identity['lineage_build_id'],
        'kPluginVersion': identity['plugin_version'],
        'kCategoryRoute': identity['category_route'],
        'kSourceManifestSha256': identity['source_manifest_sha256'],
        'kUiProbeMarker': identity['ui_probe_marker'],
        'kUiSwfSha256': identity['ui_swf_sha256'],
        'kCategoryIconSwfSha256': identity['category_icon_swf_sha256'],
    }
    for name, expected in fields.items():
        match = re.search(rf'\b{name}\s*=\s*"([^"]+)"', text)
        if not match or match.group(1) != expected:
            raise IdentityError(f'generated header {name} is missing or stale')
    count = re.search(r'\bkSourceManifestEntries\s*=\s*([0-9]+)ULL', text)
    if not count or int(count.group(1)) != identity['source_manifest_entries']:
        raise IdentityError('generated header manifest entry count is missing or stale')


def verify_binary(data: bytes, identity: dict[str, object]) -> None:
    for key in (
        'candidate_name', 'candidate_id', 'lineage_build_id', 'plugin_version', 'category_route',
        'source_manifest_sha256', 'ui_probe_marker', 'ui_swf_sha256', 'category_icon_swf_sha256',
    ):
        value = str(identity[key]).encode('ascii')
        if value not in data:
            raise IdentityError(f'compiled DLL does not contain {key}={identity[key]}')


def _self_test_manifest_and_noop() -> None:
    from source_manifest import verify_manifest, write_manifest
    with tempfile.TemporaryDirectory(prefix='qld065-identity-fixture-') as temp:
        root = Path(temp)
        (root / 'src').mkdir()
        (root / 'src' / 'Plugin.cpp').write_text('marker=old\n', encoding='utf-8')
        first_digest, first_count, changed = write_manifest(root)
        if not changed or first_count != 1:
            raise IdentityError('manifest fixture did not create one listed source file')
        actual_digest, actual_count = verify_manifest(root)
        if actual_digest != first_digest or actual_count != 1:
            raise IdentityError('new fixture manifest did not verify')
        header = root / 'BuildIdentity.h'
        if not write_if_changed(header, b'header\n'):
            raise IdentityError('first header write was incorrectly treated as unchanged')
        before = header.stat().st_mtime_ns
        if write_if_changed(header, b'header\n'):
            raise IdentityError('same-content header write was not a no-op')
        if header.stat().st_mtime_ns != before:
            raise IdentityError('same-content header no-op changed mtime')
        (root / 'src' / 'Plugin.cpp').write_text('marker=new\n', encoding='utf-8')
        try:
            verify_manifest(root)
        except ValueError:
            pass
        else:
            raise IdentityError('stale source manifest did not fail closed')
        update_digest, update_count, changed = write_manifest(root)
        if not changed or update_count != 1 or update_digest == first_digest:
            raise IdentityError('manifest refresh did not record changed source')
        if verify_manifest(root) != (update_digest, 1):
            raise IdentityError('updated fixture manifest did not verify')


def self_test(identity: dict[str, object]) -> None:
    rendered = render_header(identity)
    if rendered != render_header(dict(identity)):
        raise IdentityError('same identity rendered a nondeterministic header')
    changed_source = dict(identity, source_manifest_sha256='0' * 64)
    changed_swf = dict(identity, ui_swf_sha256='1' * 64)
    changed_icon_swf = dict(identity, category_icon_swf_sha256='2' * 64)
    if identity['candidate_id'] == _candidate_id(changed_source) or identity['candidate_id'] == _candidate_id(changed_swf) or identity['candidate_id'] == _candidate_id(changed_icon_swf):
        raise IdentityError('candidate ID did not change with source-manifest or either SWF identity')
    _self_test_manifest_and_noop()


def _candidate_id(identity: dict[str, object]) -> str:
    keys = ('candidate_name', 'lineage_build_id', 'plugin_version', 'category_route', 'ui_probe_marker', 'source_manifest_sha256', 'ui_swf_sha256', 'category_icon_swf_sha256')
    material = {key: identity[key] for key in keys}
    digest = sha256(json.dumps(material, sort_keys=True, separators=(',', ':')).encode('utf-8'))
    return f'QLD-065-{digest[:16]}'


def identity_line(identity: dict[str, object]) -> str:
    return (
        f"IDENTITY_PASS candidate_name={identity['candidate_name']} candidate_id={identity['candidate_id']} "
        f"lineage_build_id={identity['lineage_build_id']} plugin_version={identity['plugin_version']} "
        f"category_route={identity['category_route']} source_manifest_sha256={identity['source_manifest_sha256']} "
        f"source_manifest_entries={identity['source_manifest_entries']} ui_probe_marker={identity['ui_probe_marker']} "
        f"ui_swf_sha256={identity['ui_swf_sha256']} category_icon_swf_sha256={identity['category_icon_swf_sha256']}"
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument('--swf', type=Path, required=False)
    parser.add_argument('--icon-swf', type=Path, required=False)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--verify-header', type=Path)
    parser.add_argument('--verify-binary', type=Path)
    parser.add_argument('--self-test', action='store_true')
    parser.add_argument('--write-manifest', action='store_true')
    args = parser.parse_args()
    try:
        if args.write_manifest:
            digest, count, changed = write_manifest(args.root)
            print(f"{'MANIFEST_UPDATED' if changed else 'MANIFEST_UNCHANGED'} source_manifest_sha256={digest} source_manifest_entries={count}")
        if args.swf is None or args.icon_swf is None:
            if args.write_manifest and not (args.output or args.verify_header or args.verify_binary or args.self_test):
                return 0
            raise IdentityError('--swf and --icon-swf are required for build identity generation/verification')
        swf_path = args.swf.resolve()
        icon_swf_path = args.icon_swf.resolve()
        identity = read_identity(args.root, swf_path, icon_swf_path)
        if args.output:
            changed = write_if_changed(args.output, render_header(identity))
            print('HEADER_UPDATED' if changed else 'HEADER_UNCHANGED')
        if args.verify_header:
            verify_header(args.verify_header, identity)
        if args.verify_binary:
            verify_binary(args.verify_binary.read_bytes(), identity)
        if args.self_test:
            self_test(identity)
        print(identity_line(identity))
        return 0
    except (OSError, ValueError, IdentityError, AssertionError) as exc:
        print(f'IDENTITY_FAIL {exc}', file=sys.stderr)
        return 1

if __name__ == '__main__':
    raise SystemExit(main())
