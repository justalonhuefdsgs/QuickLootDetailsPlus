#pragma once
#include <atomic>
#include <cstdint>
#include <optional>
#include <utility>

namespace qld::cmpdiag {
enum class Kind : std::uint8_t { weapon, armor };
enum class Reason : std::uint8_t { dropped, noPlayer, noEquipped, typeMismatch, slotMismatch, typeAndSlotMismatch, emptyMask, missingSlot, multipleArmor, noInventory, unworn, extraInvalid, extraMultiple, selectedMetric, equippedMetric, nonfiniteDifference, computed };
enum class IconState : std::uint8_t { inactive, pending, visible, failure };
constexpr unsigned bucket(Reason r) noexcept {
    switch (r) {
    case Reason::dropped: case Reason::noPlayer: case Reason::noEquipped: case Reason::missingSlot: case Reason::noInventory: case Reason::unworn: return 0;
    case Reason::typeMismatch: case Reason::slotMismatch: case Reason::typeAndSlotMismatch: case Reason::emptyMask: case Reason::multipleArmor: case Reason::extraInvalid: case Reason::extraMultiple: return 1;
    case Reason::selectedMetric: case Reason::equippedMetric: case Reason::nonfiniteDifference: return 2;
    case Reason::computed: return 3;
    }
    return 2;
}
class Budget {
    std::atomic<std::uint32_t> used_{0};
public:
    bool claim(unsigned slot) noexcept {
        if (slot >= 16) return false;
        const auto bit = std::uint32_t{1} << slot;
        return (used_.fetch_or(bit, std::memory_order_relaxed) & bit) == 0;
    }
    template<class F> bool emit(unsigned slot, F&& sink) noexcept {
        if (!claim(slot)) return false;
        try { std::forward<F>(sink)(); } catch (...) {}
        return true;
    }
    std::uint32_t mask() const noexcept { return used_.load(std::memory_order_relaxed); }
};
constexpr unsigned comparisonSlot(Kind k, Reason r) noexcept { return (k == Kind::armor ? 4U : 0U) + bucket(r); }
constexpr unsigned rowSlot(Kind k, bool hasField) noexcept { return 8U + (k == Kind::armor ? 2U : 0U) + (hasField ? 1U : 0U); }
constexpr unsigned iconSlot(IconState s) noexcept { return 12U + static_cast<unsigned>(s); }

struct Sample {
    std::uint64_t seq{};
    Kind kind{Kind::weapon};
    bool kindKnown{}, comparisonKnown{}, rowKnown{}, rendered{}, iconKnown{};
    Reason reason{Reason::selectedMetric};
    std::optional<double> selected, equipped, width;
    bool field{}, included{}, enabled{}, equipment{}, category{}, icons{}, iconLabelKnown{};
    int maxRows{};
    IconState iconState{IconState::failure};
    std::uint32_t missing{}, flags{};
    bool operator==(const Sample&) const = default;
};
#if QLD_COMPARISON_DIAGNOSTICS
inline bool matches(std::uint64_t generation,std::uint64_t selection,std::uint64_t currentGeneration,std::uint64_t currentSelection,bool open) noexcept { return open && selection!=0 && generation==currentGeneration && selection==currentSelection; }
Sample newSample() noexcept;
class Capture {
    Sample* previous_;
public:
    explicit Capture(Sample*) noexcept;
    ~Capture() noexcept;
    Capture(const Capture&) = delete;
    Capture& operator=(const Capture&) = delete;
};
void emit(const Sample&) noexcept;
void comparison(Kind, Reason, std::optional<double> selected={}, std::optional<double> equipped={}) noexcept;
void row(Kind, bool hasField, bool rowIncluded, bool enabled, bool equipment, bool category, bool icons, bool iconKnown, int maxRows) noexcept;
void icon(IconState, std::uint32_t missingMask, std::uint32_t flags, std::optional<double> width) noexcept;
#endif
}