#include "qld/World.h"
#include <cmath>
#include <cstdlib>
#include <iostream>
#include <limits>
#include <sstream>
using namespace qld;
static void expect(bool b,const char* why){if(!b){std::cerr<<why<<'\n';std::exit(1);}}
static bool equal(double a,double b){return std::abs(a-b)<.001;}
static void inside(Bounds b,double w,double h){expect(b.width>0 && b.height>0 && b.x>=0 && b.y>=0 && b.x+b.width<=w+.001 && b.y+b.height<=h+.001,"card remains visible and inside viewport");}
static std::string savedIni(const Settings& s){
    std::ostringstream o;
    o<<"[General]\nbEnabled="<<s.enabled<<"\n[Layout]\niSide="<<int(s.side)<<"\nfOffsetX="<<s.offsetX<<"\nfOffsetY="<<s.offsetY<<"\nfWidth="<<s.width<<"\nfScale="<<s.scale<<"\n[QuickLoot]\niCardScale="<<s.quickLootScalePercent<<"\n[Style]\nfFontSize="<<s.fontSize<<"\nfBackgroundOpacity="<<s.backgroundOpacity<<"\nfTextOpacity="<<s.textOpacity<<"\n[World]\nbEnabled="<<s.world.enabled<<"\niAnchor="<<int(s.world.anchor)<<"\nfOffsetX="<<s.world.offsetX<<"\nfOffsetY="<<s.world.offsetY<<"\niCardScale="<<s.world.cardScalePercent<<"\n";
    return o.str(); // Same persisted keys consumed by MCM Helper; no new serializer in product.
}
int main(){
    Settings s;s.side=Side::left;
    const Bounds loot{850,200,300,200};
    auto zero=placePanel(loot,s,1920,1080,300);
    expect(zero.x==538 && zero.y==200 && zero.height==300,"accepted side anchor at zero");
    for(double d:{-1.,1.,-120.,120.}){
        s.offsetX=d;auto x=placePanel(loot,s,1920,1080,300);
        expect(equal(x.x,zero.x+d) && x.y==zero.y,"QuickLoot signed X movement");
        s.offsetX=0;s.offsetY=d;auto y=placePanel(loot,s,1920,1080,300);
        expect(y.x==zero.x && equal(y.y,zero.y+d),"QuickLoot signed Y movement");s.offsetY=0;
    }
    s.side=Side::below;auto base=placePanel(loot,s,1920,1080,300);s.offsetY=1000;
    auto lower=placePanel(loot,s,1920,1080,300);
    expect(!lower.aboveFallback && lower.y==780 && lower.height==300,"positive Y clamps below without old upper fallback or shrinking");
    s.offsetY=-1000;expect(placePanel(loot,s,1920,1080,300).y==0,"negative Y reaches top");
    s.offsetY=-100;auto recovered=placePanel({850,20,300,1040},s,1920,1080,300);
    expect(recovered.width==0 && recovered.height==0 && !recovered.aboveFallback,"crowded below placement does not trigger automatic upper fallback");
    s={};s.world.anchor=WorldAnchor::left;s.world.offsetX=0;s.world.offsetY=0;
    const auto wz=placeWorldPanel(s,1920,1080,300);
    for(double d:{-1.,1.,-30.,30.}){
        s.world.offsetX=d;auto x=placeWorldPanel(s,1920,1080,300);
        expect(equal(x.x,wz.x+d) && x.y==wz.y,"World signed X movement");
        s.world.offsetX=0;s.world.offsetY=d;auto y=placeWorldPanel(s,1920,1080,300);
        expect(y.x==wz.x && equal(y.y,wz.y+d),"World signed Y movement");s.world.offsetY=0;
    }
    s.world.offsetY=4320;auto down=placeWorldPanel(s,1920,1080,600);
    expect(down.height==600 && down.y==480,"World downward move keeps full long-card height");
    auto shortCard=placeWorldPanel(s,1920,1080,146);expect(shortCard.height==146 && shortCard.y==934,"short card shrinks and stays inside");
    s.world.offsetY=-4320;expect(placeWorldPanel(s,1920,1080,600).y==0,"World top edge");
    for(auto resolution:{Bounds{0,0,1280,720},Bounds{0,0,1920,1080},Bounds{0,0,3840,2160},Bounds{0,0,7680,4320}})
      for(double scale:{.5,1.,2.})for(auto side:{Side::left,Side::right,Side::below})
        for(double height:{300.,800.,6000.})for(double x:{-8192.,0.,8192.})for(double y:{-4320.,0.,4320.}){
            s={};s.scale=scale;s.side=side;s.offsetX=x;s.offsetY=y;s.world.offsetX=x;s.world.offsetY=y;
            auto w=resolution.width,h=resolution.height;
            auto q=placePanel({w*.5,h*.1,w*.2,h*.1},s,w,h,height);auto world=placeWorldPanel(s,w,h,height);
            if(q.width>0)inside(q,w,h);else expect(side==Side::below && q.height==0 && !q.aboveFallback,"below anchor never falls back when viewport cannot fit");inside(world,w,h);
            auto qAgain=placePanel({w*.5,h*.1,w*.2,h*.1},s,w,h,height);
            expect(q.x==qAgain.x && q.y==qAgain.y,"next redraw does not ignore saved offsets");
        }
    auto migrated=parseSettings("[General]\nbEnabled=0\n[Layout]\niSide=1\nfOffsetX=777\nfOffsetY=-611\nfWidth=335\nfScale=1.25\n[Style]\nfFontSize=22\nfBackgroundOpacity=0.15\nfTextOpacity=0.8\n[World]\nbEnabled=1\niAnchor=1\nfOffsetX=-912\nfOffsetY=431\n");
    expect(migrated.quickLootScalePercent==100 && migrated.world.cardScalePercent==100,"old INI settings gain neutral individual card scales");
    auto restored=parseSettings(savedIni(migrated));
    expect(restored.offsetX==777 && restored.offsetY==-611 && restored.world.offsetX==-912 && restored.world.offsetY==431,"old0.1.9 four positions survive save/restore/restart parse");
    expect(!restored.enabled && restored.world.enabled && restored.side==Side::right && restored.world.anchor==WorldAnchor::left && restored.width==335 && restored.scale==1.25 && restored.fontSize==22 && restored.backgroundOpacity==.15 && restored.textOpacity==.8,"migration preserves all existing non-position settings");
    auto scaleValues=parseSettings("[QuickLoot]\niCardScale=53\n[World]\niCardScale=148\n");
    expect(scaleValues.quickLootScalePercent==55 && scaleValues.world.cardScalePercent==150,"scale settings clamp and snap to the MCM five-percent step");
    scaleValues=parseSettings("[QuickLoot]\niCardScale=49\n[World]\niCardScale=52\n");
    expect(scaleValues.quickLootScalePercent==50 && scaleValues.world.cardScalePercent==50,"scale settings lower bounds and nearest step");
    scaleValues.quickLootScalePercent=151;scaleValues.world.cardScalePercent=49;scaleValues.normalize();
    expect(scaleValues.quickLootScalePercent==150 && scaleValues.world.cardScalePercent==50,"runtime scale configuration remains bounded");
    Settings fitWidth;fitWidth.side=Side::below;fitWidth.width=300;
    expect(equal(quickLootPanelWidth(fitWidth,335,1280),335),"details width may grow naturally to the visible QuickLoot list width");
    expect(equal(quickLootPanelWidth(fitWidth,245,1280),300),"details width preserves a configured width wider than the list");
    expect(equal(quickLootPanelWidth(fitWidth,335,320),320),"details width remains inside a narrower viewport");
    const auto shortBelow=placePanel({400,300,335,236},fitWidth,1280,720,300,220);
    expect(shortBelow.x==400 && shortBelow.y==548 && shortBelow.width==300 && shortBelow.height==172 && !shortBelow.aboveFallback,
           "172px below-space retains the basic card without moving the lower anchor when full body is too tall");
    const auto short16x10=placePanel({600,700,335,100},fitWidth,1920,1200,600,220);
    expect(short16x10.y==812 && short16x10.height==388 && short16x10.width==300,
           "16:10 below placement uses the available space and keeps the same anchor");
    expect(equal(quickLootPanelWidth(fitWidth,335,1920),335),"16:10 viewport uses actual list width as the panel upper bound");
    State state;state.configure(restored);auto qOriginal=placePanel(loot,state.frame().settings,1920,1080,300);
    auto worldSettings=restored.world;worldSettings.enabled=true;worldSettings.anchor=WorldAnchor::right;worldSettings.offsetX=5;worldSettings.offsetY=-22;worldSettings.cardScalePercent=75;state.configureWorld(worldSettings);auto mixed=state.frame().settings;
    auto qUnchanged=placePanel(loot,mixed,1920,1080,300);expect(qOriginal.x==qUnchanged.x && qOriginal.y==qUnchanged.y,"World update leaves QuickLoot position");
    auto worldOriginal=placeWorldPanel(mixed,1920,1080,300);
    mixed.offsetX=-222;mixed.offsetY=80;mixed.quickLootScalePercent=125;state.configureLoot(mixed);mixed=state.frame().settings;
    auto worldUnchanged=placeWorldPanel(mixed,1920,1080,300);expect(worldOriginal.x==worldUnchanged.x && worldOriginal.y==worldUnchanged.y,"QuickLoot update leaves World position");
    // Position reset uses the same four setters as the separately audited compiled Papyrus.
    mixed.offsetX=mixed.offsetY=0;state.configureLoot(mixed);auto reset=state.frame().settings;
    expect(reset.offsetX==0 && reset.offsetY==0 && reset.world.offsetX==5 && reset.world.offsetY==-22 && reset.width==335 && reset.scale==1.25 && !reset.enabled && reset.world.cardScalePercent==75,"QuickLoot position-only reset preserves World/style/switch");
    worldSettings=reset.world;worldSettings.offsetX=-220;worldSettings.offsetY=90;worldSettings.cardScalePercent=100;state.configureWorld(worldSettings);reset=state.frame().settings;
    expect(reset.world.offsetX==-220 && reset.world.offsetY==90 && reset.world.enabled && reset.world.anchor==WorldAnchor::right && reset.world.cardScalePercent==100 && reset.quickLootScalePercent==125 && reset.width==335,"World position-only reset preserves shared and QuickLoot settings");
    reset.world.enabled=false;state.configureWorld(reset.world);reset.world.enabled=true;state.configureWorld(reset.world);
    expect(state.frame().settings.world.offsetX==-220 && state.frame().settings.offsetX==0,"OFF/ON retains independent position settings");
    auto bounds=parseSettings("[Layout]\nfOffsetX=999999\nfOffsetY=-999999\n[World]\nfOffsetX=-999999\nfOffsetY=999999");
    expect(bounds.offsetX==8192 && bounds.offsetY==-4320 && bounds.world.offsetX==-8192 && bounds.world.offsetY==4320,"native signed range agrees with MCM");
    expect(placePanel(loot,s,0,720,300).width==0 && placeWorldPanel(s,1920,1080,std::numeric_limits<double>::quiet_NaN()).height==0,"invalid metrics remain rejected");
    Settings scaleBase;scaleBase.side=Side::below;scaleBase.scale=1.2;scaleBase.world.anchor=WorldAnchor::right;
    const auto qBase=placePanel({400,100,300,150},scaleBase,1920,1080,300);
    const auto wBase=placeWorldPanel(scaleBase,1920,1080,300);
    for(int pct:{50,100,150}){
        auto q=scaleBase;q.quickLootScalePercent=pct;
        auto qb=placePanel({400,100,300,150},q,1920,1080,300);
        expect(equal(qb.width,360.0*pct/100.0) && equal(qb.height,360.0*pct/100.0),"QuickLoot multiplier resizes the complete card");
        expect(equal(qb.y,qBase.y),"QuickLoot multiplier keeps the existing screen-space gap");
        expect(equal(quickLootRenderScale(q),1.2*pct/100.0),"QuickLoot renderer receives common times individual scale");
        expect(equal(placeWorldPanel(q,1920,1080,300).width,wBase.width) && equal(placeWorldPanel(q,1920,1080,300).height,wBase.height),"QuickLoot multiplier leaves World card unchanged");
        auto w=scaleBase;w.world.cardScalePercent=pct;
        auto wb=placeWorldPanel(w,1920,1080,300);
        expect(equal(wb.width,360.0*pct/100.0) && equal(wb.height,360.0*pct/100.0),"World multiplier resizes the complete card");
        expect(equal(wb.x+wb.width,wBase.x+wBase.width) && equal(wb.y, wBase.y),"World multiplier keeps its screen-space anchor and margin");
        expect(equal(worldRenderScale(w),1.2*pct/100.0),"World renderer receives common times individual scale");
        expect(equal(placePanel({400,100,300,150},w,1920,1080,300).width,qBase.width) && equal(placePanel({400,100,300,150},w,1920,1080,300).height,qBase.height),"World multiplier leaves QuickLoot card unchanged");
    }
    auto qOffset=scaleBase;qOffset.quickLootScalePercent=150;auto qShift=qOffset;qShift.offsetX=25;qShift.offsetY=18;
    const auto qa=placePanel({400,100,300,150},qOffset,1920,1080,300),qb=placePanel({400,100,300,150},qShift,1920,1080,300);
    expect(equal(qb.x-qa.x,25) && equal(qb.y-qa.y,18),"QuickLoot X/Y offsets remain screen-space pixels at independent scale");
    auto wOffset=scaleBase;wOffset.world.cardScalePercent=150;auto wShift=wOffset;wShift.world.offsetX-=25;wShift.world.offsetY+=18;
    const auto wa=placeWorldPanel(wOffset,1920,1080,300),wb=placeWorldPanel(wShift,1920,1080,300);
    expect(equal(wb.x-wa.x,-25) && equal(wb.y-wa.y,18),"World X/Y offsets remain screen-space pixels at independent scale");
    std::cout<<"Position PASS: signed axes, both edges, full height, old INI migration, independent card multipliers and pixel offsets, source switching independence, reset scope, 972 viewport/scale/text/axis combinations. Runtime MCM persistence remains human-test pending.\n";
}
