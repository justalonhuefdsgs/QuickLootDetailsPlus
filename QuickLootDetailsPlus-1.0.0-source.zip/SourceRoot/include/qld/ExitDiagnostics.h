#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <mutex>
#include <span>
#include <string_view>

namespace qld::exitdiag {

enum class Event : std::uint8_t {
    menuCreate = 1,
    menuDestroy,
    advanceMovie,
    providerOpen,
    providerClose,
    showEnqueue,
    showDispatch,
    closeDispatch
};

enum class Phase : std::uint8_t { begin = 1, end };

enum StateFlag : std::uint32_t {
    paused = 1U << 0,
    lootMenuOpen = 1U << 1,
    providerOpen = 1U << 2,
    onMenuStack = 1U << 3,
    queueAvailable = 1U << 4
};

struct EventRecord {
    std::uint64_t sequence{};
    std::uint64_t menuGeneration{};
    std::uintptr_t menuAddress{};
    std::uintptr_t uiMovieAddress{};
    std::uintptr_t movieDefinitionAddress{};
    std::uint32_t threadId{};
    std::uint32_t stateFlags{};
    std::uint8_t originCode{};
    Event event{};
    Phase phase{};
};

class IEventSink {
public:
    virtual ~IEventSink() = default;
    virtual void Write(std::string_view batch) = 0;
    virtual bool Flush() = 0;
};

class EventRecorder final {
public:
    static constexpr std::size_t capacity = 256;
    static constexpr std::size_t reservedTerminalRecords = 16;
    static constexpr std::size_t normalRecordLimit = capacity - reservedTerminalRecords;

    struct Stats {
        std::uint64_t lastSequence{};
        std::uint64_t dropped{};
        std::size_t stored{};
        std::size_t normalStored{};
        std::size_t terminalStored{};
        std::size_t flushed{};
    };

    std::uint64_t NewMenuGeneration();
    bool Record(EventRecord record, bool terminal = false);
    Stats GetStats() const;
    std::size_t CopyRecords(std::span<EventRecord> destination) const;

    // The by-value shared pointer pins the sink until its single batch write returns.
    // A null sink or failed write/flush leaves records pending for a later safe boundary.
    bool Flush(std::shared_ptr<IEventSink> sink) noexcept;

private:
    mutable std::mutex mutex_;
    std::mutex flushMutex_;
    std::array<EventRecord, capacity> records_{};
    std::uint64_t nextSequence_{};
    std::uint64_t nextMenuGeneration_{};
    std::uint64_t dropped_{};
    std::uint64_t reportedDropped_{};
    std::size_t stored_{};
    std::size_t normalStored_{};
    std::size_t terminalStored_{};
    std::size_t flushed_{};
};

}  // namespace qld::exitdiag
