#include <RE/Skyrim.h>
#include <SKSE/SKSE.h>
#include <spdlog/sinks/basic_file_sink.h>
#include <Windows.h>
#include <bcrypt.h>
#include <psapi.h>
#include <cwctype>
#include <fstream>
#include <mutex>
#include <vector>
#include "qld/Core.h"
#include "qld/ComparisonDiagnostics.h"
#include "qld/MovieOwnerLifetime.h"
#include "qld/ExitDiagnostics.h"
#include "qld/ExitDiagnosticsSpdlog.h"
#include "qld/Providers.h"
#include "qld/RuntimeContracts.h"
#include "qld/LegacyBridge.h"
#include "qld/LegacySelection.h"
#include "qld/NativeCard.h"
#include "qld/BuildIdentity.h"
#include "QuickLootAPI.h"

#ifndef QLD_EXIT_DIAGNOSTICS
#define QLD_EXIT_DIAGNOSTICS 0
#endif

namespace {
qld::State state;
constexpr std::string_view menuName = "QuickLootDetailsMenu";
std::atomic<std::uint64_t> stackSequence{};
std::atomic<bool> providerReady{};
std::atomic<bool> legacyProvider{};
std::atomic<std::uint32_t> worldEventTarget{};
std::atomic<std::uint64_t> worldEventEpoch{};
std::atomic<bool> worldEventSeen{},worldEventAvailable{};
#if QLD_EXIT_DIAGNOSTICS
struct ExitDiagnosticRuntime {
    std::atomic<std::shared_ptr<qld::exitdiag::IEventSink>> sink;
    std::mutex activeMenuMutex;
    std::uint64_t activeMenuGeneration{};
    std::uintptr_t activeMenuAddress{};
    qld::exitdiag::EventRecorder recorder;
};

ExitDiagnosticRuntime& exitDiagnosticRuntime() {
    // Keep the small bounded state and logger lease alive through late engine teardown.
    // The operating system reclaims it at process termination; DLL static destruction
    // cannot invalidate the sink or mutex before a menu destructor uses them.
    static auto* runtime = new ExitDiagnosticRuntime();
    return *runtime;
}

qld::exitdiag::EventRecorder& exitDiagnosticRecorder() {
    return exitDiagnosticRuntime().recorder;
}

struct ActiveMenuContext { std::uint64_t generation{}; std::uintptr_t address{}; };
ActiveMenuContext activeMenuSnapshot() noexcept {
    auto& runtime = exitDiagnosticRuntime();
    std::lock_guard lock(runtime.activeMenuMutex);
    return {runtime.activeMenuGeneration, runtime.activeMenuAddress};
}
void setActiveMenu(std::uint64_t generation, std::uintptr_t address) noexcept {
    auto& runtime = exitDiagnosticRuntime();
    std::lock_guard lock(runtime.activeMenuMutex);
    runtime.activeMenuGeneration = generation;
    runtime.activeMenuAddress = address;
}
void clearActiveMenu(std::uint64_t generation) noexcept {
    auto& runtime = exitDiagnosticRuntime();
    std::lock_guard lock(runtime.activeMenuMutex);
    if (runtime.activeMenuGeneration == generation) {
        runtime.activeMenuGeneration = 0;
        runtime.activeMenuAddress = 0;
    }
}

void recordGlobalDiagnostic(qld::exitdiag::Event event, qld::exitdiag::Phase phase,
                            std::uint8_t origin = 0, std::uint32_t flags = 0,
                            bool terminal = false) noexcept {
    try {
        const auto context = activeMenuSnapshot();
        qld::exitdiag::EventRecord record{};
        record.menuGeneration = context.generation;
        record.menuAddress = context.address;
        record.threadId = GetCurrentThreadId();
        record.stateFlags = flags;
        record.originCode = origin;
        record.event = event;
        record.phase = phase;
        exitDiagnosticRecorder().Record(record, terminal);
    } catch (...) {}
}

void flushGlobalDiagnostics() noexcept {
    try {
        auto sink = exitDiagnosticRuntime().sink.load(std::memory_order_acquire);
        if (sink) exitDiagnosticRecorder().Flush(std::move(sink));
    } catch (...) {}
}

void enqueueShow(std::uint8_t origin, bool flushAfter = true) {
    auto* queue = RE::UIMessageQueue::GetSingleton();
    const auto flags = queue ? qld::exitdiag::queueAvailable : 0U;
    recordGlobalDiagnostic(qld::exitdiag::Event::showEnqueue, qld::exitdiag::Phase::begin, origin, flags);
    if (queue) queue->AddMessage(menuName, RE::UI_MESSAGE_TYPE::kShow, nullptr);
    recordGlobalDiagnostic(qld::exitdiag::Event::showEnqueue, qld::exitdiag::Phase::end, origin, flags);
    if (flushAfter) flushGlobalDiagnostics();
}
#endif

template <class Function>
class ScopeExit final {
public:
    explicit ScopeExit(Function function) : function_(std::move(function)) {}
    ScopeExit(const ScopeExit&) = delete;
    ScopeExit& operator=(const ScopeExit&) = delete;
    ~ScopeExit() noexcept { try { function_(); } catch (...) {} }
private:
    Function function_;
};

class CrosshairSink final : public RE::BSTEventSink<SKSE::CrosshairRefEvent> {
public:
    RE::BSEventNotifyControl ProcessEvent(const SKSE::CrosshairRefEvent* event,RE::BSTEventSource<SKSE::CrosshairRefEvent>*) override {
        const auto handle=event && event->crosshairRef?event->crosshairRef->GetHandle().native_handle():0;
        if(worldEventTarget.exchange(handle)!=handle)++worldEventEpoch;
        worldEventSeen=true;
        // No reference/ExtraData/GFx pointer or native card work crosses the callback.
        return RE::BSEventNotifyControl::kContinue;
    }
} crosshairSink;
qld::WorldEnvironment worldEnvironment(RE::UI* ui,bool quickLootOpen) {
    qld::WorldEnvironment env;env.quickLootOpen=quickLootOpen;
    if(!ui){env.blockingMenu=true;return env;}
    auto hud=ui->GetMenu<RE::HUDMenu>();
    env.hudReady=ui->IsShowingMenus() && hud && hud->uiMovie && hud->uiMovie->GetVisible() && ui->IsMenuOpen(RE::HUDMenu::MENU_NAME);
    env.paused=ui->GameIsPaused();env.blockingMenu=ui->numItemMenus!=0 || ui->modal;
    for(const char* name:{"InventoryMenu","MagicMenu","FavoritesMenu","ContainerMenu","BarterMenu","GiftMenu","Dialogue Menu","Console","Journal Menu","MapMenu","Crafting Menu","TweenMenu","MessageBoxMenu","Loading Menu","Main Menu","RaceSex Menu","Training Menu","Lockpicking Menu","Sleep/Wait Menu"})
        if(ui->IsMenuOpen(name)){env.blockingMenu=true;break;}
    auto* controls=RE::ControlMap::GetSingleton();
    env.controlsReady=RE::PlayerCharacter::GetSingleton() && controls && controls->IsActivateControlsEnabled();
    return env;
}
RE::ObjectRefHandle currentWorldHandle() {
    auto* pick=RE::CrosshairPickData::GetSingleton();const auto handle=pick?pick->GetActiveTarget():RE::ObjectRefHandle{};
    if(worldEventAvailable && worldEventSeen && handle.native_handle()!=worldEventTarget.load())return {};
    return handle;
}

bool conflictingProvider(std::wstring_view selected=L"quicklootie.dll") {
    std::array<HMODULE,512> modules{}; DWORD needed{};
    if(!EnumProcessModules(GetCurrentProcess(),modules.data(),sizeof(modules),&needed) || needed>sizeof(modules))return true;
    for(std::size_t i=0;i<needed/sizeof(HMODULE);++i){
        std::array<wchar_t,32768> path{};
        auto length=GetModuleFileNameW(modules[i],path.data(),static_cast<DWORD>(path.size()));
        if(!length || length>=path.size())return true;
        auto name=std::filesystem::path(path.data()).filename().wstring();
        std::transform(name.begin(),name.end(),name.begin(),[](wchar_t c){return static_cast<wchar_t>(std::towlower(c));});
        if(name.starts_with(L"quickloot") && name!=selected && name!=L"quicklootdetails.dll")return true;
    }
    return false;
}

std::string moduleHash(HMODULE module) {
    std::array<wchar_t, 32768> path{};
    auto length = GetModuleFileNameW(module, path.data(), static_cast<DWORD>(path.size()));
    if (!length || length >= path.size()) return {};
    std::ifstream file(std::filesystem::path(path.data()), std::ios::binary);
    if (!file) return {};
    BCRYPT_ALG_HANDLE algorithm{}; BCRYPT_HASH_HANDLE hash{};
    if (BCryptOpenAlgorithmProvider(&algorithm, BCRYPT_SHA256_ALGORITHM, nullptr, 0) < 0) return {};
    if (BCryptCreateHash(algorithm, &hash, nullptr, 0, nullptr, 0, 0) < 0) { BCryptCloseAlgorithmProvider(algorithm, 0); return {}; }
    std::array<unsigned char, 16384> buffer{};
    std::size_t total{};
    bool success = true;
    while (file) {
        file.read(reinterpret_cast<char*>(buffer.data()), buffer.size());
        auto count = file.gcount(); total += static_cast<std::size_t>(count);
        if (total > 64*1024*1024 || (count && BCryptHashData(hash, buffer.data(), static_cast<ULONG>(count), 0) < 0)) {success=false; break;}
    }
    std::array<unsigned char, 32> digest{};
    if (file.bad() || BCryptFinishHash(hash, digest.data(), static_cast<ULONG>(digest.size()), 0) < 0) success=false;
    BCryptDestroyHash(hash); BCryptCloseAlgorithmProvider(algorithm, 0);
    if (!success) return {};
    std::string result;
    for (auto byte : digest) result += std::format("{:02x}", byte);
    return result;
}
const char* category(RE::FormType type) {
    switch(type) {
    case RE::FormType::Weapon: return "武器";
    case RE::FormType::Armor: return "防具";
    case RE::FormType::AlchemyItem: return "薬・食べ物";
    case RE::FormType::Ingredient: return "素材";
    case RE::FormType::Book: return "書籍";
    case RE::FormType::Ammo: return "矢・ボルト";
    case RE::FormType::SoulGem: return "魂石";
    case RE::FormType::KeyMaster: return "鍵";
    default: return "アイテム";
    }
}
std::optional<qld::Item> copyItem(RE::ObjectRefHandle container, const QuickLoot::API::ItemStack* stack) {
    if (!stack || !stack->entry || !stack->entry->object) return std::nullopt;
    auto* entry = stack->entry;
    if(entry->countDelta <= 0) return std::nullopt;
    qld::Item item;
    item.formId=entry->object->GetFormID(); item.container=container.native_handle();
    item.stackIdentity=++stackSequence;
    const auto* name=entry->GetDisplayName(); item.name=name ? name : "名称不明";
    item.category=category(entry->object->GetFormType()); item.count=entry->countDelta;
    item.value=entry->GetValue(); item.weight=entry->GetWeight();
    item.dropHandle=stack->dropRef.native_handle();item.selectedName=name?name:"";
    item.selectedTraits=qld::copyStackTraits(entry);
    if(item.dropHandle){
        auto reference=stack->dropRef.get();
        if(!reference || reference->IsDeleted() || reference->IsDisabled() || reference->GetObjectReference()!=entry->object)return {};
        RE::InventoryEntryData dropped(entry->object,item.count);dropped.AddExtraList(&reference->extraList);
        item.dropTraits=qld::copyStackTraits(&dropped);
    }
    SKSE::log::debug("SELECTION_COPIED form={:08x} selection={} count={} drop={:08x} thread={}",item.formId,item.stackIdentity,item.count,item.dropHandle,GetCurrentThreadId());
    return item;
}
void onOpen(QuickLoot::API::OpenLootMenuEvent* e) {
    if(!e)return;
#if QLD_EXIT_DIAGNOSTICS
    recordGlobalDiagnostic(qld::exitdiag::Event::providerOpen, qld::exitdiag::Phase::begin);
#endif
    state.open(e->container.native_handle());
    if(providerReady){
#if QLD_EXIT_DIAGNOSTICS
        enqueueShow(1, false);
#else
        if(auto* queue=RE::UIMessageQueue::GetSingleton())queue->AddMessage(menuName,RE::UI_MESSAGE_TYPE::kShow,nullptr);
#endif
    }
    SKSE::log::debug("OPEN container={:08x}",e->container.native_handle());
#if QLD_EXIT_DIAGNOSTICS
    recordGlobalDiagnostic(qld::exitdiag::Event::providerOpen, qld::exitdiag::Phase::end);
    flushGlobalDiagnostics();
#endif
}
void onClose(QuickLoot::API::CloseLootMenuEvent* e) {
    if(!e)return;
#if QLD_EXIT_DIAGNOSTICS
    recordGlobalDiagnostic(qld::exitdiag::Event::providerClose, qld::exitdiag::Phase::begin);
#endif
    state.close(); SKSE::log::debug("CLOSE");
#if QLD_EXIT_DIAGNOSTICS
    recordGlobalDiagnostic(qld::exitdiag::Event::providerClose, qld::exitdiag::Phase::end);
    flushGlobalDiagnostics();
#endif
}
void onSelect(QuickLoot::API::SelectItemEvent* e) {
    if(!e)return; auto item=copyItem(e->container,e->stack);
    if(item)SKSE::log::debug("SELECT form={:08x} event={} count={}",item->formId,item->stackIdentity,item->count);
    state.select(e->container.native_handle(),std::move(item));
}
void onInfo(QuickLoot::API::PopulateInfoBarEvent* e) {
    if(e)state.select(e->container.native_handle(),copyItem(e->container,e->stack));
}
void onInvalidate(QuickLoot::API::InvalidateLootMenuEvent* e) {
    if(e)state.invalidate(e->container.native_handle());
}
void onTake(QuickLoot::API::TakeItemEvent* e) {
    if(e)state.invalidate(e->container.native_handle());
}

bool numberMember(const RE::GFxValue& object, const char* member, double& result) {
    RE::GFxValue value;
    if(!object.GetMember(member,&value) || !value.IsNumber())return false;
    result=value.GetNumber(); return std::isfinite(result);
}

bool qldBackgroundHorizontalBounds(RE::GFxValue& object, RE::GFxValue& root, double& left, double& right) {
    RE::GFxValue background, bounds;
    RE::GFxValue::DisplayInfo display;
    if(!object.GetMember("background",&background) || !background.IsDisplayObject() ||
       !background.GetDisplayInfo(&display) || !display.GetVisible() ||
       !background.Invoke("getBounds",&bounds,&root,1)) return false;
    double l{}, r{};
    if(!numberMember(bounds,"xMin",l) || !numberMember(bounds,"xMax",r) || r<=l) return false;
    left=l; right=r; return true;
}

class DetailsMenu final : public RE::IMenu {
public:
    DetailsMenu() {
#if QLD_EXIT_DIAGNOSTICS
        diagnosticSink_ = exitDiagnosticRuntime().sink.load(std::memory_order_acquire);
        diagnosticGeneration_ = exitDiagnosticRecorder().NewMenuGeneration();
        setActiveMenu(diagnosticGeneration_, reinterpret_cast<std::uintptr_t>(this));
        recordDiagnostic(qld::exitdiag::Event::menuCreate, qld::exitdiag::Phase::begin);
#endif
        menuFlags.set(RE::UI_MENU_FLAGS::kAlwaysOpen,RE::UI_MENU_FLAGS::kRequiresUpdate,RE::UI_MENU_FLAGS::kAllowSaving);
        depthPriority=4;
        SKSE::log::info("UI_PENDING: movie loads only after active QuickLoot movie is ready");
#if QLD_EXIT_DIAGNOSTICS
        recordDiagnostic(qld::exitdiag::Event::menuCreate, qld::exitdiag::Phase::end);
        flushDiagnostics();
#endif
    }
    ~DetailsMenu() override {
#if QLD_EXIT_DIAGNOSTICS
        // Capture raw owner addresses only. Do not call GFx, menu virtuals, or SKSE::log here.
        recordDiagnostic(qld::exitdiag::Event::menuDestroy, qld::exitdiag::Phase::begin, 0, true);
        // Persist the begin record before owner release can enter GFx teardown.
        flushDiagnostics();
#endif
        // Release the base-owned view before C++ destroys the derived definition owner.
        qld::resetMovieOwnersInDependencyOrder(uiMovie, movieDefinition_);
#if QLD_EXIT_DIAGNOSTICS
        // This marker is reached only after both explicit owner resets returned.
        // Base-class/member destruction still follows the derived destructor body.
        recordDiagnostic(qld::exitdiag::Event::menuDestroy, qld::exitdiag::Phase::end, 0, true);
        clearActiveMenu(diagnosticGeneration_);
        flushDiagnostics();
#endif
    }
    static RE::IMenu* create(){return new DetailsMenu();}
    RE::UI_MESSAGE_RESULTS ProcessMessage(RE::UIMessage& message) override {
        // IMenu's default consumes Scaleform input. This passive menu must pass it on.
#if QLD_EXIT_DIAGNOSTICS
        const bool show = message.type == RE::UI_MESSAGE_TYPE::kShow;
        const bool close = message.type == RE::UI_MESSAGE_TYPE::kHide || message.type == RE::UI_MESSAGE_TYPE::kForceHide;
        if (show || close) recordDiagnostic(show ? qld::exitdiag::Event::showDispatch : qld::exitdiag::Event::closeDispatch,
                                            qld::exitdiag::Phase::begin);
#endif
        const auto result = RE::UI_MESSAGE_RESULTS::kPassOn;
#if QLD_EXIT_DIAGNOSTICS
        if (show || close) {
            recordDiagnostic(show ? qld::exitdiag::Event::showDispatch : qld::exitdiag::Event::closeDispatch,
                             qld::exitdiag::Phase::end);
            flushDiagnostics();
        }
#endif
        return result;
    }
    void PostDisplay() override {
        if(legacyProvider && !worldMode_ && wasVisible_){const auto frame=state.frame();if(!frame.open || !frame.selected || !qld::validCard(frame.selected->card) || frame.revision!=lastRevision_)return;}
        if(worldMode_ && wasVisible_){
            const auto current=state.frame();auto* ui=RE::UI::GetSingleton();
            if(!current.settings.world.enabled || worldEnvironment(ui,current.open || (ui && ui->IsMenuOpen("LootMenu"))).blocked() ||
               worldEventEpoch.load()!=worldRenderedEpoch_ ||
               qld::inspectWorldTarget(currentWorldHandle())!=worldRenderedTarget_)return;
        }
        const bool trace=uiMovie && wasVisible_ && !displayLogged_;
        if(trace)SKSE::log::info("UI_DISPLAY_ENTER menuOnStack={} movieVisible={}",OnStack(),uiMovie->GetVisible());
        RE::IMenu::PostDisplay();
        if(trace){SKSE::log::info("UI_DISPLAY_RETURN: Display returned; screen pixels still require human observation");displayLogged_=true;}
    }
    void AdvanceMovie(float interval, std::uint32_t time) override {
        auto* ui=RE::UI::GetSingleton();
        auto loot=ui ? ui->GetMenu("LootMenu") : nullptr;
        bool lootVisible=loot && loot->uiMovie && ui->IsMenuOpen("LootMenu");
        const auto settingFrame=state.frame();
        const auto environment=worldEnvironment(ui,lootVisible || settingFrame.open);
#if QLD_EXIT_DIAGNOSTICS
        const auto diagnosticFlags = (environment.paused ? qld::exitdiag::paused : 0U) |
                                     (lootVisible ? qld::exitdiag::lootMenuOpen : 0U) |
                                     (settingFrame.open ? qld::exitdiag::providerOpen : 0U) |
                                     (OnStack() ? qld::exitdiag::onMenuStack : 0U);
        const auto diagnosticUiMovie = reinterpret_cast<std::uintptr_t>(uiMovie.get());
        const auto diagnosticDefinition = reinterpret_cast<std::uintptr_t>(movieDefinition_.get());
        const bool diagnosticTransition = !advanceDiagnosticObserved_ || diagnosticFlags != lastAdvanceDiagnosticFlags_ ||
            diagnosticUiMovie != lastAdvanceUiMovie_ || diagnosticDefinition != lastAdvanceDefinition_;
        if (diagnosticTransition) recordDiagnostic(qld::exitdiag::Event::advanceMovie, qld::exitdiag::Phase::begin, diagnosticFlags);
        lastAdvanceDiagnosticFlags_ = diagnosticFlags;
        lastAdvanceUiMovie_ = diagnosticUiMovie;
        lastAdvanceDefinition_ = diagnosticDefinition;
        advanceDiagnosticObserved_ = true;
        ScopeExit advanceEnd([this, diagnosticTransition, diagnosticFlags]() noexcept {
            if (diagnosticTransition) {
                recordDiagnostic(qld::exitdiag::Event::advanceMovie, qld::exitdiag::Phase::end, diagnosticFlags);
                flushDiagnostics();
            }
        });
#endif
        const auto eventEpoch=worldEventEpoch.load();
        const auto worldTarget=settingFrame.settings.world.enabled && !environment.blocked()?qld::inspectWorldTarget(currentWorldHandle()):std::nullopt;
        worldState_.observe(worldTarget,settingFrame.settings.world.enabled,environment,interval,eventEpoch);
        if(!uiMovie){
            if(lootVisible){if(!loadGate_.shouldAttempt(lootVisible,interval) || !loadMovie(loot->uiMovie.get()))return;}
            else {
                auto hud=ui?ui->GetMenu<RE::HUDMenu>():nullptr;
                if(!worldTarget || !hud || !hud->uiMovie || !worldLoadGate_.shouldAttempt(true,interval))return;
                SKSE::log::info("WORLD_UI_LOAD source=HUDMenu same-loader=true");
                if(!loadMovie(hud->uiMovie.get()))return;
            }
        }
        RE::IMenu::AdvanceMovie(interval,time);
        auto frame=state.frame();
#if QLD_COMPARISON_DIAGNOSTICS
        if(diagPending_ && (!frame.selected || !qld::cmpdiag::matches(diagGeneration_,diagSelection_,frame.generation,frame.selected->stackIdentity,frame.open))){
            qld::cmpdiag::emit(*diagPending_);diagPending_.reset();
        }
        { qld::cmpdiag::Capture capture(diagPending_?&*diagPending_:nullptr);
          if(diagPending_ && diagPending_->rendered && wasVisible_ && frame.revision==lastRevision_)traceCategoryIcon(interval,frame.revision);
        }
#endif
        if(!frame.open)observedLoot_=false;
        if(lootVisible)observedLoot_=true;
        if(frame.open && observedLoot_ && !lootVisible){state.close();observedLoot_=false;}
        bool visible=providerReady && frame.visible() && loot && loot->uiMovie && ui->IsMenuOpen("LootMenu");
        if(visible && !qld::validCard(frame.selected->card) && !legacyProvider){
            // Work only in this menu's update context; no borrowed callback entry survives a frame.
            const auto token=frame.selected->stackIdentity;
            if(token!=attemptedSelection_ || frame.generation!=attemptedGeneration_){
                attemptedSelection_=token;attemptedGeneration_=frame.generation;
                #if QLD_COMPARISON_DIAGNOSTICS
                auto diagnosticCandidate=qld::cmpdiag::newSample();
                auto card=[&]{qld::cmpdiag::Capture capture(&diagnosticCandidate);return qld::resolveNativeCard(*frame.selected,uiMovie.get());}();
#else
                auto card=qld::resolveNativeCard(*frame.selected,uiMovie.get());
#endif
                if(card){
                    const bool adopted=state.publishCard(frame.generation,token,std::move(*card));
                    if(!adopted)SKSE::log::debug("CARD_DISCARDED stale-selection={}",token);
#if QLD_COMPARISON_DIAGNOSTICS
                    if(adopted){diagPending_=diagnosticCandidate;diagGeneration_=frame.generation;diagSelection_=token;}
#endif
                    frame=state.frame();
                }
            }
            visible=frame.visible() && frame.selected && qld::validCard(frame.selected->card);
        }
        bool useWorld=false;
        if(!visible && !lootVisible && !frame.open){
            if(auto ticket=worldState_.requestRefresh()){
                auto card=qld::resolveWorldCard(ticket->target,uiMovie.get());
                if(worldEventEpoch.load()!=eventEpoch || qld::inspectWorldTarget(currentWorldHandle())!=std::optional<qld::WorldTarget>(ticket->target)){
                    worldState_.clear();SKSE::log::debug("WORLD_CARD_DISCARDED stale-target=true");
                }else worldState_.publish(*ticket,std::move(card));
            }
            frame=worldState_.frame(settingFrame.settings,settingFrame.revision);
            visible=providerReady && frame.visible() && frame.selected && qld::validCard(frame.selected->card);
            useWorld=visible;
        }
        if(worldMode_!=useWorld){
            SKSE::log::debug("CARD_SOURCE_SWITCH world={} quickLootVisible={}",useWorld,lootVisible);
            worldMode_=useWorld;measureRevision_=UINT64_MAX;lastRevision_=UINT64_MAX;
        }
        if(visible && useWorld){
            auto hud=ui->GetMenu<RE::HUDMenu>();
            visible=hud && hud->uiMovie && syncViewport(hud->uiMovie.get());
        }else if(visible)visible=syncViewport(loot->uiMovie.get());
        #if QLD_COMPARISON_DIAGNOSTICS
        const bool diagnosticMatches=!useWorld && !legacyProvider && diagPending_ && frame.selected && qld::cmpdiag::matches(diagGeneration_,diagSelection_,frame.generation,frame.selected->stackIdentity,frame.open);
        qld::cmpdiag::Capture rowCapture(diagnosticMatches?&*diagPending_:nullptr);
#endif
        qld::Bounds panel{};
        if(visible)visible=useWorld?positionWorld(frame.settings,panel,frame.selected->card,frame.revision):position(loot->uiMovie.get(),frame.settings,panel,frame.selected->card,frame.revision);
        if(!visible){if(wasVisible_){RE::GFxValue arg(false); uiMovie->Invoke("_root.qldRender",nullptr,&arg,1);} wasVisible_=false;measureRevision_=UINT64_MAX; return;}
        if(wasVisible_ && frame.revision==lastRevision_ && panel.x==lastBounds_.x && panel.y==lastBounds_.y && panel.width==lastBounds_.width && panel.height==lastBounds_.height)return;
        auto& item=*frame.selected;RE::GFxValue card;
        if(!qld::makeCardObject(uiMovie.get(),item.card,frame.settings.cardDisplay,card) || !card.SetMember("descriptionFontSize",RE::GFxValue(measureSelectedFont_))){
            RE::GFxValue hidden(false);uiMovie->Invoke("_root.qldRender",nullptr,&hidden,1);wasVisible_=false;
            SKSE::log::warn("CARD_HIDDEN stage=render-card-object selection={}",item.stackIdentity);
            if(useWorld)worldState_.clear();else state.invalidate(item.container);return;
        }
        const auto renderScale=useWorld?qld::worldRenderScale(frame.settings):qld::quickLootRenderScale(frame.settings);
        std::array<RE::GFxValue,10> args{
            RE::GFxValue(true),card,RE::GFxValue(panel.x),RE::GFxValue(panel.y),
            RE::GFxValue(panel.width/renderScale),RE::GFxValue(renderScale),RE::GFxValue(frame.settings.fontSize),
            RE::GFxValue(frame.settings.backgroundOpacity),RE::GFxValue(frame.settings.textOpacity),RE::GFxValue(panel.height/renderScale)};
        RE::GFxValue rendered;
        if(!uiMovie->Invoke("_root.qldRender",&rendered,args.data(),static_cast<std::uint32_t>(args.size())) || !rendered.IsBool() || !rendered.GetBool()){
            RE::GFxValue hidden(false);uiMovie->Invoke("_root.qldRender",nullptr,&hidden,1);wasVisible_=false;
            if(!renderFailure_)SKSE::log::error("UI_RENDER_FAILED"); renderFailure_=true; return;
        }
        RE::GFxValue fullHeight,bodyHeight;
        if(uiMovie->GetVariable(&fullHeight,"_root.details.requiredHeight") && fullHeight.IsNumber() &&
           uiMovie->GetVariable(&bodyHeight,"_root.details.descriptionMeasuredHeight") && bodyHeight.IsNumber()){
            SKSE::log::debug("CARD_HEIGHT_APPLIED selection={} font={} renderScale={} logicalWidth={} measuredPanel={} renderRequired={} bodyField={} allocated={} x={} y={} spaceLimited={}",item.stackIdentity,frame.settings.fontSize,renderScale,panel.width/renderScale,measurePreferredHeight_,fullHeight.GetNumber(),bodyHeight.GetNumber(),panel.height/renderScale,panel.x,panel.y,spaceLimited_);
            if(fullHeight.GetNumber()>panel.height/renderScale+0.01)
                SKSE::log::warn("CARD_FULL_TEXT_LIMITED selection={} reason={} required={} allocated={} native-text-retained=true",item.stackIdentity,spaceLimited_?"screen-space":"measurement-disagreement",fullHeight.GetNumber(),panel.height/renderScale);
        }
        for(const char* field:{"titleOmitted","descriptionOmitted"}){
            RE::GFxValue omitted;const auto path=std::string("_root.details.")+field;
            if(uiMovie->GetVariable(&omitted,path.c_str()) && omitted.IsBool() && omitted.GetBool())
                SKSE::log::warn("UI_TEXT_LIMITED selection={} field={} width={} height={} font={}",item.stackIdentity,field,panel.width,panel.height,measureSelectedFont_);
        }
        if(!wasVisible_){
            RE::GFxValue child,root;RE::GFxValue::DisplayInfo display;
            const bool childFound=uiMovie->GetVariable(&child,"_root.details") && child.IsDisplayObject();
            const bool childDisplay=childFound && child.GetDisplayInfo(&display);
            const bool rootFound=uiMovie->GetVariable(&root,"_root") && root.IsDisplayObject();
            RE::GFxValue::DisplayInfo rootDisplay;
            const bool rootInfo=rootFound && root.GetDisplayInfo(&rootDisplay);
            SKSE::log::debug("PANEL_RENDER_APPLIED revision={} generation={} x={} y={} width={} height={} child={} childVisible={} childAlpha={} rootVisible={} rootAlpha={} movieVisible={} menuOpen={} menuOnStack={}",frame.revision,frame.generation,panel.x,panel.y,panel.width,panel.height,childFound,childDisplay && display.GetVisible(),childDisplay?display.GetAlpha():-1.0,rootInfo && rootDisplay.GetVisible(),rootInfo?rootDisplay.GetAlpha():-1.0,uiMovie->GetVisible(),ui->IsMenuOpen(menuName),OnStack());
        }
        if(useWorld){worldRenderedTarget_=worldTarget;worldRenderedEpoch_=eventEpoch;}
        wasVisible_=true; lastRevision_=frame.revision; lastBounds_=panel;
#if QLD_COMPARISON_DIAGNOSTICS
        if(diagnosticMatches){diagPending_->rendered=true;traceCategoryIcon(interval,frame.revision);}
#endif
    }
private:
#if QLD_COMPARISON_DIAGNOSTICS
    void traceCategoryIcon(float interval,std::uint64_t revision) noexcept {
        if(!uiMovie || !std::isfinite(interval) || interval<=0)return;
        if(revision!=diagIconRevision_){diagIconRevision_=revision;diagIconPolls_=0;diagIconElapsed_=0.25f;}
        else diagIconElapsed_+=std::min(interval,0.25f);
        if(diagIconPolls_>=20 || diagIconElapsed_<0.25f)return;
        ++diagIconPolls_;diagIconElapsed_=0;
        try {
            constexpr const char* paths[]={"_root.iconRequestedVisible","_root.iconLoadStarted","_root.iconLoaded","_root.iconLoadFailed","_root.details.content.categoryIcon._visible"};
            std::uint32_t flags=0,missing=0;
            for(std::uint32_t i=0;i<5;++i){
                RE::GFxValue value;
                if(!uiMovie->GetVariable(&value,paths[i]) || !value.IsBool())missing|=std::uint32_t{1}<<i;
                else if(value.GetBool())flags|=std::uint32_t{1}<<i;
            }
            RE::GFxValue widthValue;std::optional<double> width;
            if(uiMovie->GetVariable(&widthValue,"_root.currentTitleWidth") && widthValue.IsNumber() && std::isfinite(widthValue.GetNumber()))width=widthValue.GetNumber();
            const bool requested=(flags&1)!=0,loaded=(flags&4)!=0,failed=(flags&8)!=0,visible=(flags&16)!=0;
            const auto iconState=missing||failed||(requested&&loaded&&!visible)?qld::cmpdiag::IconState::failure:
                visible?qld::cmpdiag::IconState::visible:requested&&!loaded?qld::cmpdiag::IconState::pending:qld::cmpdiag::IconState::inactive;
            qld::cmpdiag::icon(iconState,missing,flags,width);
            if(diagPending_)qld::cmpdiag::emit(*diagPending_);
        } catch (...) {}
    }
#endif
    bool OnStack() const {return menuFlags.all(RE::UI_MENU_FLAGS::kOnStack);}
    bool loadMovie(RE::GFxMovieView* lootMovie) {
        auto* manager=RE::BSScaleformManager::GetSingleton();
        SKSE::log::info("UI_LOAD_ATTEMPT attempt={} manager={} loader={}",loadGate_.attempts(),manager!=nullptr,manager && manager->loader);
        if(!manager || !manager->loader){SKSE::log::error("UI_LOAD_FAILED stage=manager-or-loader");return false;}
        RE::BSResourceNiBinaryStream resource("Interface\\QuickLootDetails.swf");
        std::array<char,8> header{};
        const bool headerRead=resource.good() && resource.read(header.data(),static_cast<std::uint32_t>(header.size()));
        SKSE::log::info("UI_RESOURCE_DIAGNOSTIC streamOpen={} headerRead={} requestedBytes={} swfVersion={}",resource.good(),headerRead,header.size(),static_cast<unsigned char>(header[3]));
        auto* control=lootMovie->GetMovieDef();
        if(control)SKSE::log::info("UI_ACTIVE_QUICKLOOT version={} width={} height={} frames={} visible={}",control->GetVersion(),control->GetWidth(),control->GetHeight(),control->GetFrameCount(),lootMovie->GetVisible());
        // Standard CommonLib LoadMovie_Impl stages, bypassing only its filename precheck.
        // Both paths belong to this mod. The game's existing loader resolves MO2 resources.
        const auto flags=static_cast<RE::GFxLoader::LoadConstants>(RE::GFxLoader::kLoadKeepBindData|RE::GFxLoader::kLoadWaitFrame1);
        for(const char* path:{"Interface/QuickLootDetails.swf","Interface\\QuickLootDetails.swf"}){
            auto* definition=manager->loader->CreateMovie(path,flags);
            SKSE::log::info("UI_MOVIE_DEFINITION path={} created={}",path,definition!=nullptr);
            if(definition){movieDefinition_.reset(definition);definition->Release();break;}
        }
        if(!movieDefinition_){SKSE::log::error("UI_LOAD_FAILED stage=movie-definition attempt={}",loadGate_.attempts());return false;}
        SKSE::log::info("UI_DEFINITION_READY version={} width={} height={} frames={}",movieDefinition_->GetVersion(),movieDefinition_->GetWidth(),movieDefinition_->GetHeight(),movieDefinition_->GetFrameCount());
        uiMovie.reset(movieDefinition_->CreateInstance());
        if(!uiMovie){movieDefinition_.reset();SKSE::log::error("UI_LOAD_FAILED stage=movie-instance");return false;}
        uiMovie->Release(); // GPtr::reset adds one reference to the returned initial reference.
        SKSE::log::info("UI_INSTANCE_READY");
        RE::GViewport viewport;lootMovie->GetViewport(&viewport);
        if(viewport.bufferWidth<=0 || viewport.bufferHeight<=0 || viewport.width<=0 || viewport.height<=0){
            uiMovie.reset();movieDefinition_.reset();SKSE::log::error("UI_LOAD_FAILED stage=viewport");return false;
        }
        uiMovie->SetViewScaleMode(RE::GFxMovieView::ScaleModeType::kShowAll);
        uiMovie->SetBackgroundAlpha(0.0F);
        uiMovie->SetViewport(viewport);
        uiMovie->SetSafeRect(uiMovie->GetVisibleFrameRect());
        uiMovie->SetVisible(true);
        uiMovie->SetMouseCursorCount(0);
        uiMovie->SetVariable("_global.gfxExtensions",true);
        SKSE::log::info("UI_VIEWPORT_READY buffer={}x{} viewport={}x{} origin={},{}",viewport.bufferWidth,viewport.bufferHeight,viewport.width,viewport.height,viewport.left,viewport.top);
        uiMovie->Advance(0.0F);
        const bool extensions=uiMovie->IsAvailable("_root.InitExtensions") && uiMovie->Invoke("_root.InitExtensions",nullptr,nullptr,0);
        RefreshPlatform();
        constexpr auto expectedProbe="QLD_UI_0.1.20-065";
        bool render=false,probeCall=false;
        std::string probeText="<missing>";
        {
            // The returned GFxValue is Movie-managed; destroy it before releasing either Movie owner below.
            RE::GFxValue probe;
            render=uiMovie->IsAvailable("_root.qldRender");
            probeCall=uiMovie->Invoke("_root.qldProbe",&probe,nullptr,0);
            if(probeCall && probe.IsString())probeText=probe.GetString();
        }  // probe is released while uiMovie and movieDefinition_ are still alive.
        SKSE::log::info("UI_SCRIPT_STATUS expectedProbe={} extensions={} renderFunction={} probeCalled={} probe={}",expectedProbe,extensions,render,probeCall,probeText);
        if(!extensions || !render || !probeCall || probeText!=expectedProbe){
            uiMovie.reset();movieDefinition_.reset();SKSE::log::error("UI_LOAD_FAILED stage=script-initialization-or-version");return false;
        }
        SKSE::log::info("UI_LOADED candidate_id={} version={} passive=true paused=false input=false",qld::build_identity::kCandidateId,qld::build_identity::kPluginVersion);return true;
    }
    bool pendingPosition(const char* reason) {
        if(positionFailure_!=reason){SKSE::log::warn("UI_POSITION_PENDING stage={}",reason);positionFailure_=reason;}
        return false;
    }
    bool syncViewport(RE::GFxMovieView* source) {
        RE::GViewport from,to;
        source->GetViewport(&from);uiMovie->GetViewport(&to);
        if(from.bufferWidth<=0 || from.bufferHeight<=0 || from.width<=0 || from.height<=0)return pendingPosition("viewport-sync");
        if(from.bufferWidth!=to.bufferWidth || from.bufferHeight!=to.bufferHeight || from.width!=to.width || from.height!=to.height || from.left!=to.left || from.top!=to.top || from.scissorLeft!=to.scissorLeft || from.scissorTop!=to.scissorTop || from.scissorWidth!=to.scissorWidth || from.scissorHeight!=to.scissorHeight || from.scale!=to.scale || from.aspectRatio!=to.aspectRatio || from.flags.underlying()!=to.flags.underlying()){
            uiMovie->SetViewport(from);
            uiMovie->SetSafeRect(uiMovie->GetVisibleFrameRect());
            measureRevision_=UINT64_MAX;lastRevision_=UINT64_MAX;
        }
        return true;
    }
    bool measureDescriptionPlan(const RE::GFxValue& cardObject,double width,double requestedFont,double availableHeight,double& naturalHeight,qld::DescriptionFitPlan& plan) {
        std::array<RE::GFxValue,3> preferredArgs{cardObject,RE::GFxValue(width),RE::GFxValue(requestedFont)};
        RE::GFxValue preferred,floorValue;
        if(!uiMovie->Invoke("_root.qldPreferredHeight",&preferred,preferredArgs.data(),3) || !preferred.IsNumber() || !std::isfinite(preferred.GetNumber()) || preferred.GetNumber()<=0)return false;
        RE::GFxValue floorArg(requestedFont);
        if(!uiMovie->Invoke("_root.qldDescriptionFontFloor",&floorValue,&floorArg,1) || !floorValue.IsNumber() || !std::isfinite(floorValue.GetNumber()) || floorValue.GetNumber()<=0 || floorValue.GetNumber()>requestedFont)return false;
        std::vector<qld::DescriptionFitCandidate> candidates;
        for(double font=requestedFont;;font=std::max(floorValue.GetNumber(),font-1.0)){
            std::array<RE::GFxValue,4> measureArgs{cardObject,RE::GFxValue(width),RE::GFxValue(requestedFont),RE::GFxValue(font)};
            RE::GFxValue measured;
            if(!uiMovie->Invoke("_root.qldMeasure",&measured,measureArgs.data(),4) || !measured.IsNumber() || !std::isfinite(measured.GetNumber()) || measured.GetNumber()<=0)return false;
            candidates.push_back({font,measured.GetNumber()});
            if(font<=floorValue.GetNumber()+0.01)break;
        }
        naturalHeight=candidates.front().requiredHeight;
        plan=qld::planDescriptionFit(preferred.GetNumber(),candidates,availableHeight);
        return plan.valid;
    }
    bool position(RE::GFxMovieView* lootMovie,const qld::Settings& settings,qld::Bounds& panel,const qld::CardSnapshot& card,std::uint64_t revision) {
        RE::GFxValue object,root,bounds;
        if(!lootMovie->GetVariable(&object,legacyProvider?"_root.rootObj":"_root.lootMenu") || !object.IsDisplayObject() || !lootMovie->GetVariable(&root,"_root"))return pendingPosition("quickloot-root");
        RE::GFxValue::DisplayInfo display;
        if(!object.GetDisplayInfo(&display) || !display.GetVisible())return pendingPosition("quickloot-display");
        if(!object.Invoke("getBounds",&bounds,&root,1))return pendingPosition("quickloot-bounds");
        double left,top,right,bottom;
        if(!numberMember(bounds,"xMin",left) || !numberMember(bounds,"yMin",top) || !numberMember(bounds,"xMax",right) || !numberMember(bounds,"yMax",bottom))return pendingPosition("bounds-numbers");
        auto source=lootMovie->GetVisibleFrameRect(),target=uiMovie->GetVisibleFrameRect();
        double sw=source.right-source.left,sh=source.bottom-source.top,tw=target.right-target.left,th=target.bottom-target.top;
        if(!std::isfinite(sw) || !std::isfinite(sh) || !std::isfinite(tw) || !std::isfinite(th) || sw<=0 || sh<=0 || tw<=0 || th<=0 || right<=left || bottom<=top)return pendingPosition("viewport-dimensions");
        double horizontalLeft=left, horizontalRight=right;
        if(!legacyProvider) (void)qldBackgroundHorizontalBounds(object,root,horizontalLeft,horizontalRight);
        qld::Bounds normalized{(horizontalLeft-source.left)*tw/sw,(top-source.top)*th/sh,(horizontalRight-horizontalLeft)*tw/sw,(bottom-top)*th/sh};
        const double renderScale=qld::quickLootRenderScale(settings);
        const double logicalWidth=qld::quickLootPanelWidth(settings,normalized.width,tw);
        if(!std::isfinite(logicalWidth) || logicalWidth<=0)return pendingPosition("detail-width");
        const auto availableHeight=qld::availablePanelHeight(normalized,settings,tw,th);
        if(availableHeight<=0)return pendingPosition("no-readable-capacity");
        if(revision!=measureRevision_ || logicalWidth!=measureWidth_ || settings.fontSize!=measureFont_ || availableHeight!=measureAvailableHeight_){
            RE::GFxValue cardObject;if(!qld::makeCardObject(uiMovie.get(),card,settings.cardDisplay,cardObject))return pendingPosition("card-object");
            qld::DescriptionFitPlan fit;double natural{};
            if(!measureDescriptionPlan(cardObject,logicalWidth,settings.fontSize,availableHeight,natural,fit))return pendingPosition("detail-fit-measure");
            measureHeight_=natural;measurePreferredHeight_=fit.preferredHeight;measurePanelHeight_=fit.panelHeight;
            measureSelectedFont_=fit.fontSize;measureRequiredHeight_=fit.requiredHeight;measureRevision_=revision;measureWidth_=logicalWidth;measureFont_=settings.fontSize;measureAvailableHeight_=availableHeight;
            SKSE::log::debug("CARD_FIT_PLAN revision={} width={} requestedFont={} natural={} preferred={} selectedFont={} required={} plannedPanel={} expanded={}",revision,logicalWidth,settings.fontSize,natural,fit.preferredHeight,fit.fontSize,fit.requiredHeight,fit.panelHeight,fit.expanded);
        }
        auto placementSettings=settings;placementSettings.width=logicalWidth;
        panel=qld::placePanel(normalized,placementSettings,tw,th,measurePanelHeight_,0);
        if(panel.width<=0 || panel.height<=0)return pendingPosition("no-readable-space");
        spaceLimited_=panel.height+0.01<measureRequiredHeight_*renderScale;
        if(panel.aboveFallback && !aboveFallbackLogged_){SKSE::log::info("UI_PLACEMENT_ABOVE: insufficient room below; height={} gap={}",panel.height,12*settings.scale);aboveFallbackLogged_=true;}
        panel.x+=target.left; panel.y+=target.top;
        positionFailure_.clear();return true;
    }
    bool positionWorld(const qld::Settings& settings,qld::Bounds& panel,const qld::CardSnapshot& card,std::uint64_t revision) {
        const auto rect=uiMovie->GetVisibleFrameRect();const auto width=rect.right-rect.left,height=rect.bottom-rect.top;
        if(!std::isfinite(width) || !std::isfinite(height) || width<=0 || height<=0)return pendingPosition("world-viewport");
        const auto renderScale=qld::worldRenderScale(settings);
        const auto logicalWidth=std::min(settings.width,width/renderScale);
        const auto availableHeight=qld::availableWorldPanelHeight(settings,width,height);
        if(availableHeight<=0)return pendingPosition("no-readable-capacity");
        if(revision!=measureRevision_ || logicalWidth!=measureWidth_ || settings.fontSize!=measureFont_ || availableHeight!=measureAvailableHeight_){
            RE::GFxValue object;if(!qld::makeCardObject(uiMovie.get(),card,settings.cardDisplay,object))return pendingPosition("world-card-object");
            qld::DescriptionFitPlan fit;double natural{};
            if(!measureDescriptionPlan(object,logicalWidth,settings.fontSize,availableHeight,natural,fit))return pendingPosition("world-detail-fit-measure");
            measureHeight_=natural;measurePreferredHeight_=fit.preferredHeight;measurePanelHeight_=fit.panelHeight;
            measureSelectedFont_=fit.fontSize;measureRequiredHeight_=fit.requiredHeight;measureRevision_=revision;measureWidth_=logicalWidth;measureFont_=settings.fontSize;measureAvailableHeight_=availableHeight;
            SKSE::log::debug("WORLD_CARD_FIT_PLAN revision={} width={} requestedFont={} natural={} preferred={} selectedFont={} required={} plannedPanel={} expanded={}",revision,logicalWidth,settings.fontSize,natural,fit.preferredHeight,fit.fontSize,fit.requiredHeight,fit.panelHeight,fit.expanded);
        }
        panel=qld::placeWorldPanel(settings,width,height,measurePanelHeight_,0);
        if(panel.width<=0 || panel.height<=0)return pendingPosition("world-no-readable-space");
        spaceLimited_=panel.height+0.01<measureRequiredHeight_*renderScale;
        panel.x+=rect.left;panel.y+=rect.top;positionFailure_.clear();return true;
    }
    void recordDiagnostic(qld::exitdiag::Event event, qld::exitdiag::Phase phase,
                          std::uint32_t flags = 0, bool terminal = false) noexcept {
#if QLD_EXIT_DIAGNOSTICS
        try {
            qld::exitdiag::EventRecord record{};
            record.menuGeneration = diagnosticGeneration_;
            record.menuAddress = reinterpret_cast<std::uintptr_t>(this);
            record.uiMovieAddress = reinterpret_cast<std::uintptr_t>(uiMovie.get());
            record.movieDefinitionAddress = reinterpret_cast<std::uintptr_t>(movieDefinition_.get());
            record.threadId = GetCurrentThreadId();
            record.stateFlags = flags;
            record.event = event;
            record.phase = phase;
            exitDiagnosticRecorder().Record(record, terminal);
        } catch (...) {}
#else
        (void)event; (void)phase; (void)flags; (void)terminal;
#endif
    }
    void flushDiagnostics() noexcept {
#if QLD_EXIT_DIAGNOSTICS
        try { if (diagnosticSink_) exitDiagnosticRecorder().Flush(diagnosticSink_); } catch (...) {}
#endif
    }
#if QLD_COMPARISON_DIAGNOSTICS
    std::optional<qld::cmpdiag::Sample> diagPending_;
    std::uint64_t diagGeneration_{},diagSelection_{};
    std::uint64_t diagIconRevision_{UINT64_MAX};
    unsigned diagIconPolls_{};
    float diagIconElapsed_{};
#endif
    qld::WorldState worldState_;
    qld::MovieLoadGate worldLoadGate_;
    bool worldMode_{};
    std::optional<qld::WorldTarget> worldRenderedTarget_;
    std::uint64_t worldRenderedEpoch_{};
    RE::GPtr<RE::GFxMovieDef> movieDefinition_;
    bool wasVisible_{},renderFailure_{},observedLoot_{},displayLogged_{},aboveFallbackLogged_{},spaceLimited_{};
    qld::MovieLoadGate loadGate_;
    std::string positionFailure_;
    std::uint64_t lastRevision_{},attemptedSelection_{},attemptedGeneration_{};
    qld::Bounds lastBounds_{};
    std::uint64_t measureRevision_{};
    double measureWidth_{},measureFont_{},measureHeight_{},measurePreferredHeight_{},measurePanelHeight_{},measureSelectedFont_{},measureRequiredHeight_{},measureAvailableHeight_{};
#if QLD_EXIT_DIAGNOSTICS
    std::shared_ptr<qld::exitdiag::IEventSink> diagnosticSink_;
    std::uint64_t diagnosticGeneration_{};
    std::uint64_t lastAdvanceDiagnosticFlags_{};
    std::uintptr_t lastAdvanceUiMovie_{},lastAdvanceDefinition_{};
    bool advanceDiagnosticObserved_{};
#endif
};
void configure(RE::StaticFunctionTag*,bool enabled,std::int32_t side,float x,float y,float width,float scale,float font,float background,float text,std::int32_t cardScalePercent) {
    qld::Settings settings{enabled,side==0?qld::Side::left:side==1?qld::Side::right:qld::Side::below,x,y,width,scale,font,background,text};
    settings.quickLootScalePercent=cardScalePercent;
    state.configureLoot(settings); SKSE::log::info("SETTINGS_APPLIED enabled={} side={} background={} text={} cardScalePercent={}",enabled,side,background,text,cardScalePercent);
}
void configureWorld(RE::StaticFunctionTag*,bool enabled,std::int32_t anchor,float x,float y,std::int32_t cardScalePercent) {
    state.configureWorld({enabled,anchor==1?qld::WorldAnchor::left:qld::WorldAnchor::right,x,y,cardScalePercent});
    SKSE::log::info("WORLD_SETTINGS_APPLIED enabled={} anchor={} x={} y={} cardScalePercent={} independent=true",enabled,anchor,x,y,cardScalePercent);
}
void configureCardDisplay(RE::StaticFunctionTag*,bool enabled,bool category,bool valueWeight,bool ownedCount,bool bookRead,bool spellLearned,bool potionDetails,bool ingredientEffects,bool equipmentDetails,bool soulGemDetails,bool itemFlags,bool pluginSource,std::int32_t maxRows,float fontScale,bool showIcons,bool referenceDps) {
    qld::CardDisplaySettings display{enabled,category,valueWeight,ownedCount,bookRead,spellLearned,potionDetails,ingredientEffects,equipmentDetails,soulGemDetails,itemFlags,pluginSource,maxRows,fontScale,showIcons,referenceDps};
    state.configureCardDisplay(display);
}
bool registerPapyrus(RE::BSScript::IVirtualMachine* vm) {
    vm->RegisterFunction("Configure","QLD_Native",configure);
    vm->RegisterFunction("ConfigureWorld","QLD_Native",configureWorld);
    vm->RegisterFunction("ConfigureCardDisplay","QLD_Native",configureCardDisplay);
    SKSE::log::info("PAPYRUS_REGISTERED"); return true;
}
void loadSettings() {
    const auto read=[](const char* path) {
        std::ifstream file(path);
        if(!file)return std::string{};
        std::string text(65537,'\0'); file.read(text.data(),text.size()); text.resize(static_cast<std::size_t>(file.gcount()));
        if(text.size()>65536){SKSE::log::warn("SETTINGS_IGNORED: file exceeds 64 KiB");return std::string{};}
        return text;
    };
    const auto defaults=read("Data/MCM/Config/QuickLootDetails/settings.ini");
    const auto user=read("Data/MCM/Settings/QuickLootDetails.ini");
    const auto settings=qld::parseSettingsLayers(defaults,user);
    state.configure(settings);
    SKSE::log::info("QLD_STARTUP_SETTINGS defaultsPresent={} userPresent={} mainEnabled={} worldEnabled={}",!defaults.empty(),!user.empty(),settings.enabled,settings.world.enabled);
}
void message(SKSE::MessagingInterface::Message* m) {
    if(!m)return;
    if(m->type==SKSE::MessagingInterface::kPreLoadGame || m->type==SKSE::MessagingInterface::kNewGame){state.close();worldEventTarget=0;worldEventSeen=false;++worldEventEpoch;}
    if(m->type==SKSE::MessagingInterface::kPostLoadGame){
        state.close(); loadSettings();
        // Only copied settings cross Papyrus threads; movie calls remain in AdvanceMovie.
        if(providerReady){
#if QLD_EXIT_DIAGNOSTICS
            enqueueShow(2);
#else
            if(auto* queue=RE::UIMessageQueue::GetSingleton())queue->AddMessage(menuName,RE::UI_MESSAGE_TYPE::kShow,nullptr);
#endif
        }
    }
    if(m->type==SKSE::MessagingInterface::kNewGame && providerReady){
#if QLD_EXIT_DIAGNOSTICS
        enqueueShow(3);
#else
        if(auto* queue=RE::UIMessageQueue::GetSingleton())queue->AddMessage(menuName,RE::UI_MESSAGE_TYPE::kShow,nullptr);
#endif
    }
    if(m->type!=SKSE::MessagingInterface::kDataLoaded)return;
    HMODULE module{};const qld::ProviderEvidence* evidence{};std::string hash;
    for(const auto& [wide,narrow]:std::array<std::pair<const wchar_t*,const char*>,3>{{{L"QuickLootIE.dll","QuickLootIE.dll"},{L"QuickLootEE.dll","QuickLootEE.dll"},{L"QuickLootRE.dll","QuickLootRE.dll"}}}){
        if(auto found=GetModuleHandleW(wide)){
            if(module){SKSE::log::warn("PROVIDER_DISABLED: multiple providers loaded");return;}
            module=found;hash=moduleHash(found);evidence=qld::identifyProvider(narrow,hash);
        }
    }
    if(!module || !evidence || !qld::providerAllowed(hash,REL::Module::get().version().pack(),
        conflictingProvider(evidence->kind==qld::ProviderKind::ie?L"quicklootie.dll":evidence->kind==qld::ProviderKind::ee?L"quicklootee.dll":L"quicklootre.dll"))){
        SKSE::log::warn("PROVIDER_DISABLED: unverified/conflicting/unimplemented provider sha256={}",hash);return;
    }
    auto* ui=RE::UI::GetSingleton(); auto* queue=RE::UIMessageQueue::GetSingleton();
    if(!ui || !queue){SKSE::log::error("PROVIDER_DISABLED: UI unavailable");return;}
    if(evidence->kind==qld::ProviderKind::ie){
        if(!GetProcAddress(module,"GetQuickLootInterfaceV20") || !QuickLoot::API::QuickLootAPI::Init("QuickLootDetails",QuickLoot::API::ApiVersion::kV20)){
            SKSE::log::error("PROVIDER_DISABLED: V20 API unavailable");return;
        }
        QuickLoot::API::QuickLootAPI::RegisterOpenLootMenuHandler(onOpen);
        QuickLoot::API::QuickLootAPI::RegisterCloseLootMenuHandler(onClose);
        QuickLoot::API::QuickLootAPI::RegisterSelectItemHandler(onSelect);
        QuickLoot::API::QuickLootAPI::RegisterPopulateInfoBarHandler(onInfo);
        QuickLoot::API::QuickLootAPI::RegisterInvalidateLootMenuHandler(onInvalidate);
        QuickLoot::API::QuickLootAPI::RegisterTakeItemHandler(onTake);
    }else{
        if(!qld::installLegacyBridge(*evidence,module,state,[]{if(providerReady){
#if QLD_EXIT_DIAGNOSTICS
            enqueueShow(4);
#else
            if(auto* q=RE::UIMessageQueue::GetSingleton())q->AddMessage(menuName,RE::UI_MESSAGE_TYPE::kShow,nullptr);
#endif
        }})){SKSE::log::error("PROVIDER_DISABLED: legacy vtable/code proof mismatch or bridge install failed");return;}
        legacyProvider=true;
    }
    ui->Register(menuName,DetailsMenu::create); providerReady=true;
    if(auto* source=SKSE::GetCrosshairRefEventSource()){source->AddEventSink(&crosshairSink);worldEventAvailable=true;SKSE::log::info("WORLD_CROSSHAIR_READY event=true live-handle-validation=true");}
    else SKSE::log::warn("WORLD_CROSSHAIR_READY event=false live-handle-validation=true");
    loadSettings();
    SKSE::log::info("PROVIDER_READY {} route={} sha256={}",evidence->name,legacyProvider?"verified-provider-advance":"IE-V20",hash);
}
}

extern "C" __declspec(dllexport) bool SKSEPlugin_Load(const SKSE::LoadInterface* skse) {
    auto log=SKSE::log::log_directory(); if(!log)return false;
    auto sink=std::make_shared<spdlog::sinks::basic_file_sink_mt>((*log/"QuickLootDetails.log").string(),true);
    auto logger=std::make_shared<spdlog::logger>("QuickLootDetails",sink);
    spdlog::set_default_logger(logger); spdlog::set_level(QLD_DIAGNOSTIC_LOGGING?spdlog::level::debug:spdlog::level::info); spdlog::flush_on(spdlog::level::info);
#if QLD_EXIT_DIAGNOSTICS
    exitDiagnosticRuntime().sink.store(std::make_shared<qld::exitdiag::SpdlogEventSink>(sink), std::memory_order_release);
#endif
    SKSE::log::info("IDENTITY candidate_name={} candidate_id={} lineage_build_id={} plugin_version={} category_route={} source_manifest_sha256={} source_manifest_entries={} ui_probe_marker={} ui_swf_sha256={} category_icon_swf_sha256={}",qld::build_identity::kCandidateName,qld::build_identity::kCandidateId,qld::build_identity::kLineageBuildId,qld::build_identity::kPluginVersion,qld::build_identity::kCategoryRoute,qld::build_identity::kSourceManifestSha256,qld::build_identity::kSourceManifestEntries,qld::build_identity::kUiProbeMarker,qld::build_identity::kUiSwfSha256,qld::build_identity::kCategoryIconSwfSha256);
    SKSE::log::info("START candidate_id={} version={} runtime={}",qld::build_identity::kCandidateId,qld::build_identity::kPluginVersion,skse->RuntimeVersion().string());
    if(!qld::runtimeLoadAllowed(skse->RuntimeVersion().pack(),skse->SKSEVersion(),skse->IsEditor())){SKSE::log::warn("RUNTIME_DISABLED: exact Steam runtime/SKSE contract mismatch skse={:08x}",skse->SKSEVersion());return false;}
    SKSE::Init(skse);
    const auto* messaging=SKSE::GetMessagingInterface(); const auto* papyrus=SKSE::GetPapyrusInterface();
    if(!messaging || !papyrus || !messaging->RegisterListener(message) || !papyrus->Register(registerPapyrus))return false;
    SKSE::log::info("PLUGIN_LOADED"); return true;
}
