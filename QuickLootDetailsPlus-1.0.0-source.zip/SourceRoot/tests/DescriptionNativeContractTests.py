from pathlib import Path
r=Path(__file__).resolve().parents[1]
p=(r/'src/Plugin.cpp').read_text(encoding='utf-8')
a=(r/'ui/panel.as').read_text(encoding='utf-8')
c=(r/'src/Core.cpp').read_text(encoding='utf-8')
assert 'RE::GFxValue(requestedFont),RE::GFxValue(font)' in p
assert 'measureArgs.data(),4)' in p
assert 'planDescriptionFit(preferred.GetNumber(),candidates,availableHeight)' in p
assert p.count('availableHeight!=measureAvailableHeight_')==2
assert 'qld::availablePanelHeight(normalized,settings,tw,th)' in p
assert 'qld::availableWorldPanelHeight(settings,width,height)' in p
assert 'card.SetMember("descriptionFontSize",RE::GFxValue(measureSelectedFont_))' in p
assert 'RE::GFxValue(renderScale),RE::GFxValue(frame.settings.fontSize)' in p
assert 'RE::GFxValue(renderScale),RE::GFxValue(measureSelectedFont_)' not in p
assert p.index('visible=syncViewport(loot->uiMovie.get())')<p.index('if(visible)visible=useWorld?positionWorld')
assert 'measureRevision_=UINT64_MAX;lastRevision_=UINT64_MAX;' in p
assert 'wasVisible_=false;measureRevision_=UINT64_MAX; return;' in p
for field in ['scissorLeft','scissorTop','scissorWidth','scissorHeight','scale','aspectRatio']:
 assert 'from.'+field+'!=to.'+field in p
assert 'from.flags.underlying()!=to.flags.underlying()' in p
assert 'preferred=std::min(preferred,available)' in c
assert 'placePanel(loot,settings,width,height,height/scale,0)' in c
assert 'placeWorldPanel(settings,width,height,height/scale,0)' in c
assert 'var header = qldHeader(card, width, fontSize);' in a
assert 'qldSetAdaptiveDescriptionText(content.description, descriptionText, bodySize' in a
assert 'qldLongCardPreferredHeight = 279;' in a
print('NATIVE_DESCRIPTION_CONTRACT_PASS static GFx wiring; no runtime execution')
sync=p[p.index('bool syncViewport('):p.index('bool measureDescriptionPlan(')]
assert 'wasVisible_=false' not in sync
