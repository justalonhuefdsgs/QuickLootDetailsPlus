#include "qld/Core.h"
#include <cstdint>
#include <iostream>
#include <memory>
#include <string_view>
namespace RE {
struct GFxValue { explicit GFxValue(bool v):value(v){} bool value; };
struct GViewport {
 int bufferWidth=1280,bufferHeight=720,width=1280,height=720;
 int left=0,top=0,scissorLeft=0,scissorTop=0,scissorWidth=1280,scissorHeight=720;
 float scale=1,aspectRatio=1;
 struct Flags { int value=0;int underlying()const{return value;} } flags;
};
struct GFxMovieView {
 GViewport viewport; bool shown=false;int hides=0;
 void GetViewport(GViewport* out){*out=viewport;}
 void SetViewport(GViewport v){viewport=v;}
 int GetVisibleFrameRect(){return 0;}
 void SetSafeRect(int){}
 bool Invoke(const char*,void*,GFxValue* arg,int){
  if(!arg->value){++hides;shown=false;}return true;
 }
};
struct HUDMenu {std::shared_ptr<GFxMovieView> uiMovie=std::make_shared<GFxMovieView>();};
}
struct UI {
 std::shared_ptr<RE::HUDMenu> hud=std::make_shared<RE::HUDMenu>();
 template<class T>std::shared_ptr<T> GetMenu(){return hud;}
};
struct Fixture {
 struct Selected {int card=0;};
 struct Frame {qld::Settings settings;std::shared_ptr<Selected> selected=std::make_shared<Selected>();std::uint64_t revision=1;} frame;
 std::shared_ptr<RE::GFxMovieView> uiMovie=std::make_shared<RE::GFxMovieView>();
 std::shared_ptr<RE::HUDMenu> loot=std::make_shared<RE::HUDMenu>();
 std::shared_ptr<UI> ui=std::make_shared<UI>();
 bool wasVisible_=false,forceFailure=false;
 std::uint64_t measureRevision_=0,lastRevision_=UINT64_MAX;
 qld::Bounds lastBounds_{};int draws=0;
 bool pendingPosition(const char*){return false;}
 bool position(RE::GFxMovieView* source,const qld::Settings&,qld::Bounds& panel,int,std::uint64_t){
  // Placement is a boundary double: tests exercise actual transition code, not GFx/placement.
  if(forceFailure || source->viewport.height<136)return false;
  panel={10,10,300,136};return true;
 }
 bool positionWorld(const qld::Settings& settings,qld::Bounds& panel,int card,std::uint64_t revision){
  return position(ui->hud->uiMovie.get(),settings,panel,card,revision);
 }
#include "ViewportTransitions.inc"
};
int failures=0,assertions=0;
void check(bool value,std::string_view label){
 ++assertions;std::cout<<(value?"PASS ":"FAIL ")<<label<<'\n';
 if(!value)++failures;
}

int main(){
 for(bool world:{false,true}){
  std::cout<<"MODE "<<(world?"world":"loot")<<'\n';
  Fixture f;auto source=world?f.ui->hud->uiMovie:f.loot->uiMovie;
  f.advance(true,world);
  check(f.wasVisible_&&f.uiMovie->shown&&f.draws==1,"initial show");
  source->viewport.height=700; // Same placement/revision must still redraw.
  f.advance(true,world);
  check(f.draws==2&&f.wasVisible_,"viewport success invalidates redraw guard");
  source->viewport.height=100;
  f.advance(true,world);
  check(!f.wasVisible_&&!f.uiMovie->shown&&f.uiMovie->hides==1,"viewport placement failure hides old panel once");
  f.advance(true,world);
  check(!f.uiMovie->shown&&f.uiMovie->hides==1,"repeated failure stays hidden without duplicate clear");
  source->viewport.height=720;f.advance(true,world);
  check(f.wasVisible_&&f.uiMovie->shown&&f.draws==3,"hidden recovers");
  f.advance(false,world);
  check(!f.wasVisible_&&!f.uiMovie->shown&&f.uiMovie->hides==2,"close clears");
  f.advance(false,world);
  check(f.uiMovie->hides==2,"repeated close");
  f.advance(true,world);
  check(f.wasVisible_&&f.draws==4,"reopen redraws");
  ++f.frame.revision;f.advance(true,world);
  check(f.draws==5,"selection revision redraws");
  source->viewport.width=0;f.advance(true,world);
  check(!f.uiMovie->shown&&f.uiMovie->hides==3,"invalid viewport adjacent early return clears");
  source->viewport.width=1280;f.advance(true,world);
  check(f.wasVisible_&&f.draws==6,"invalid viewport recovery");
  source->viewport.scissorTop=1;f.forceFailure=true;f.advance(true,world);
  check(!f.uiMovie->shown&&f.uiMovie->hides==4,"measurement or bounds failure after viewport invalidation clears");
 }
 std::cout<<"ASSERTIONS "<<assertions<<" FAILURES "<<failures<<'\n';
 return failures?1:0;
}
