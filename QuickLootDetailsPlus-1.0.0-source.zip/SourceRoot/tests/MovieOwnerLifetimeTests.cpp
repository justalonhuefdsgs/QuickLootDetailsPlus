#include <array>
#include <cstddef>
#include <iostream>
#include <string>
#include <string_view>
#include <vector>

#include <RE/G/GPtr.h>

#include "qld/MovieOwnerLifetime.h"

namespace {

enum class Owner : std::size_t
{
    view = 0,
    definition = 1
};

constexpr std::string_view ownerName(Owner owner)
{
    return owner == Owner::view ? "view" : "definition";
}

struct Trace
{
    std::array<int, 2> liveReferences{ 1, 1 };
    std::array<int, 2> zeroTransitions{};
    std::vector<Owner> releaseOrder;
    std::vector<std::string> lifetimeEvents;
    bool viewObservedDefinitionAlive{};
};

struct RefCounted
{
    RefCounted(Trace& a_trace, Owner a_owner) : trace(a_trace), owner(a_owner) {}

    void AddRef()
    {
        ++references;
        trace.liveReferences[static_cast<std::size_t>(owner)] = references;
    }

    void Release()
    {
        --references;
        trace.liveReferences[static_cast<std::size_t>(owner)] = references;
        if (references == 0) {
            ++trace.zeroTransitions[static_cast<std::size_t>(owner)];
            trace.releaseOrder.push_back(owner);
            trace.lifetimeEvents.push_back(std::string("zero:") + std::string(ownerName(owner)));
            if (owner == Owner::view) {
                trace.viewObservedDefinitionAlive =
                    trace.liveReferences[static_cast<std::size_t>(Owner::definition)] > 0;
            }
        }
    }

    Trace& trace;
    Owner owner;
    int references{ 1 };
};

struct CheckResult
{
    int failures{};

    void check(bool condition, std::string_view name, std::string_view expected, std::string_view observed)
    {
        if (!condition) {
            ++failures;
            std::cerr << "FAIL " << name << ": expected " << expected << ", observed " << observed << '\n';
        }
    }
};

std::string formatOrder(const Trace& trace)
{
    std::string result = "[";
    for (std::size_t i = 0; i < trace.releaseOrder.size(); ++i) {
        if (i != 0) {
            result += ",";
        }
        result += ownerName(trace.releaseOrder[i]);
    }
    result += "]";
    return result;
}

std::vector<std::string> invariantFailures(const Trace& trace)
{
    std::vector<std::string> failures;
    if (trace.releaseOrder != std::vector<Owner>{ Owner::view, Owner::definition }) {
        failures.push_back("release order expected [view,definition], observed " + formatOrder(trace));
    }
    if (!trace.viewObservedDefinitionAlive) {
        failures.push_back("view release expected definition reference count > 0, observed 0");
    }
    if (trace.zeroTransitions[static_cast<std::size_t>(Owner::view)] != 1 ||
        trace.zeroTransitions[static_cast<std::size_t>(Owner::definition)] != 1) {
        failures.push_back("each owner expected one zero transition, observed view=" +
                           std::to_string(trace.zeroTransitions[static_cast<std::size_t>(Owner::view)]) +
                           " definition=" +
                           std::to_string(trace.zeroTransitions[static_cast<std::size_t>(Owner::definition)]));
    }
    return failures;
}

void dropExternalReferences(RefCounted& view, RefCounted& definition)
{
    view.Release();
    definition.Release();
}

struct BaseMenuOwnerModel
{
    explicit BaseMenuOwnerModel(Trace& a_trace) : trace(a_trace) {}
    virtual ~BaseMenuOwnerModel() { trace.lifetimeEvents.emplace_back("base-body"); }

    void attachView(RefCounted& a_view) { uiMovie.reset(&a_view); }

    Trace& trace;
    RE::GPtr<RefCounted> uiMovie;
};

struct DerivedMenuOwnerModel final : BaseMenuOwnerModel
{
    explicit DerivedMenuOwnerModel(Trace& a_trace) : BaseMenuOwnerModel(a_trace), derivedTrace(a_trace) {}
    ~DerivedMenuOwnerModel() override { derivedTrace.lifetimeEvents.emplace_back("derived-body"); }

    void attachDefinition(RefCounted& a_definition) { movieDefinition.reset(&a_definition); }

    Trace& derivedTrace;
    RE::GPtr<RefCounted> movieDefinition;
};

std::vector<std::string> structuralOrderFailures(const std::vector<std::string>& events)
{
    const std::vector<std::string> expected{
        "derived-body", "zero:definition", "base-body", "zero:view"
    };
    if (events == expected) {
        return {};
    }
    std::string observed = "[";
    for (std::size_t i = 0; i < events.size(); ++i) {
        if (i != 0) {
            observed += ",";
        }
        observed += events[i];
    }
    observed += "]";
    return { "base/derived owner destruction expected [derived-body,zero:definition,base-body,zero:view], observed " + observed };
}

int runNegativeControl()
{
    Trace trace;
    RefCounted definition{ trace, Owner::definition };
    RefCounted view{ trace, Owner::view };
    RE::GPtr<RefCounted> definitionOwner{ &definition };
    RE::GPtr<RefCounted> viewOwner{ &view };
    dropExternalReferences(view, definition);

    definitionOwner.reset();
    viewOwner.reset();

    const auto failures = invariantFailures(trace);
    for (const auto& failure : failures) {
        std::cerr << "NEGATIVE_CONTROL_DETECTED: " << failure << '\n';
    }
    const std::vector<std::string> wrongStructuralOrder{
        "derived-body", "base-body", "zero:view", "zero:definition"
    };
    const auto structuralFailures = structuralOrderFailures(wrongStructuralOrder);
    for (const auto& failure : structuralFailures) {
        std::cerr << "NEGATIVE_CONTROL_DETECTED: " << failure << '\n';
    }
    if (failures.empty()) {
        std::cerr << "NEGATIVE_CONTROL_MISSED: reverse release order was accepted\n";
        return 0;
    }
    if (structuralFailures.empty()) {
        std::cerr << "NEGATIVE_CONTROL_MISSED: incorrect base/derived order was accepted\n";
        return 0;
    }
    return 1;
}

int runChecks()
{
    CheckResult result;
    {
        Trace trace;
        RefCounted definition{ trace, Owner::definition };
        RefCounted view{ trace, Owner::view };
        RE::GPtr<RefCounted> definitionOwner{ &definition };
        RE::GPtr<RefCounted> viewOwner{ &view };
        dropExternalReferences(view, definition);
        qld::resetMovieOwnersInDependencyOrder(viewOwner, definitionOwner);
        const auto failures = invariantFailures(trace);
        result.check(failures.empty(), "helper dependency order", "no invariant violations",
                     failures.empty() ? "none" : failures.front());
        result.check(!viewOwner && !definitionOwner, "helper clears both owners", "both null",
                     std::string("view=") + (viewOwner ? "non-null" : "null") +
                         " definition=" + (definitionOwner ? "non-null" : "null"));
    }

    {
        Trace trace;
        RE::GPtr<RefCounted> viewOwner;
        RE::GPtr<RefCounted> definitionOwner;
        qld::resetMovieOwnersInDependencyOrder(viewOwner, definitionOwner);
        result.check(trace.releaseOrder.empty(), "both null", "no release", formatOrder(trace));
        result.check(!viewOwner && !definitionOwner, "both null remain null", "both null", "both null");
    }

    {
        Trace trace;
        RefCounted view{ trace, Owner::view };
        RE::GPtr<RefCounted> viewOwner{ &view };
        view.Release();
        RE::GPtr<RefCounted> definitionOwner;
        qld::resetMovieOwnersInDependencyOrder(viewOwner, definitionOwner);
        result.check(trace.zeroTransitions[static_cast<std::size_t>(Owner::view)] == 1,
                     "definition null", "view released once", std::to_string(trace.zeroTransitions[0]));
        result.check(!viewOwner && !definitionOwner, "definition null owners", "both null", "both null");
    }

    {
        Trace trace;
        RefCounted definition{ trace, Owner::definition };
        RE::GPtr<RefCounted> viewOwner;
        RE::GPtr<RefCounted> definitionOwner{ &definition };
        definition.Release();
        qld::resetMovieOwnersInDependencyOrder(viewOwner, definitionOwner);
        result.check(trace.zeroTransitions[static_cast<std::size_t>(Owner::definition)] == 1,
                     "view null", "definition released once", std::to_string(trace.zeroTransitions[1]));
        result.check(!viewOwner && !definitionOwner, "view null owners", "both null", "both null");
    }

    {
        Trace trace;
        RefCounted definition{ trace, Owner::definition };
        RefCounted view{ trace, Owner::view };
        RE::GPtr<RefCounted> definitionOwner{ &definition };
        RE::GPtr<RefCounted> viewOwner{ &view };
        dropExternalReferences(view, definition);
        qld::resetMovieOwnersInDependencyOrder(viewOwner, definitionOwner);
        qld::resetMovieOwnersInDependencyOrder(viewOwner, definitionOwner);
        result.check(trace.zeroTransitions[0] == 1 && trace.zeroTransitions[1] == 1,
                     "repeated reset", "one zero transition per owner",
                     std::to_string(trace.zeroTransitions[0]) + "," + std::to_string(trace.zeroTransitions[1]));
    }

    {
        Trace trace;
        RefCounted definition{ trace, Owner::definition };
        RefCounted view{ trace, Owner::view };
        {
            RE::GPtr<RefCounted> definitionOwner{ &definition };
            RE::GPtr<RefCounted> viewOwner{ &view };
            dropExternalReferences(view, definition);
            qld::resetMovieOwnersInDependencyOrder(viewOwner, definitionOwner);
        }
        result.check(trace.zeroTransitions[0] == 1 && trace.zeroTransitions[1] == 1,
                     "explicit reset then auto destruction", "no extra release",
                     std::to_string(trace.zeroTransitions[0]) + "," + std::to_string(trace.zeroTransitions[1]));
    }

    {
        Trace trace;
        RefCounted definition{ trace, Owner::definition };
        RefCounted view{ trace, Owner::view };
        {
            RE::GPtr<RefCounted> definitionOwner{ &definition };
            RE::GPtr<RefCounted> viewOwner{ &view };
            dropExternalReferences(view, definition);
        }
        const auto failures = invariantFailures(trace);
        result.check(failures.empty(), "declaration-order auto destruction model",
                     "reverse declaration destroys view before definition",
                     failures.empty() ? formatOrder(trace) : failures.front());
    }

    {
        Trace trace;
        RefCounted definition{ trace, Owner::definition };
        RefCounted view{ trace, Owner::view };
        {
            DerivedMenuOwnerModel menu{ trace };
            // Model the two GPtr owner slots and C++ subobject order only. These
            // fake reference counts do not specify CreateMovie/CreateInstance
            // ownership or GFxMovieView/GFxMovieDef cross-ownership.
            menu.attachDefinition(definition);
            definition.Release();  // balance the synthetic creator reference only
            menu.attachView(view);
            view.Release();        // balance the synthetic creator reference only
        }
        const auto failures = structuralOrderFailures(trace.lifetimeEvents);
        result.check(failures.empty(), "base/derived member auto destruction",
                     "derived body, derived definition owner, base body, base view owner",
                     failures.empty() ? "expected C++ owner order observed" : failures.front());
        result.check(trace.releaseOrder == std::vector<Owner>{ Owner::definition, Owner::view },
                     "base/derived GPtr owner release order", "[definition,view]", formatOrder(trace));
        result.check(trace.zeroTransitions[static_cast<std::size_t>(Owner::definition)] == 1 &&
                         trace.zeroTransitions[static_cast<std::size_t>(Owner::view)] == 1,
                     "base/derived single owner releases", "one zero transition per fake owner",
                     std::to_string(trace.zeroTransitions[1]) + "," + std::to_string(trace.zeroTransitions[0]));
    }

    if (result.failures != 0) {
        std::cerr << "movie owner model checks failed: " << result.failures << '\n';
        return 1;
    }
    std::cout << "movie owner model checks PASS: helper, nulls, repeated reset, explicit/automatic destruction, base/derived GPtr member order; fake objects remain allocated for the entire test; GFx internal ownership is not modeled\n";
    return 0;
}

}  // namespace

int main(int argc, char** argv)
{
    if (argc == 2 && std::string_view{ argv[1] } == "--negative-control") {
        return runNegativeControl();
    }
    if (argc != 1) {
        std::cerr << "usage: qld_movie_owner_lifetime_tests [--negative-control]\n";
        return 2;
    }
    return runChecks();
}
