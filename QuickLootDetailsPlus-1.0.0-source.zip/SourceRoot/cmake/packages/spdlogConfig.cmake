if(NOT TARGET spdlog::spdlog)
  message(FATAL_ERROR "The pinned local spdlog target must be built first")
endif()
set(spdlog_FOUND TRUE)
