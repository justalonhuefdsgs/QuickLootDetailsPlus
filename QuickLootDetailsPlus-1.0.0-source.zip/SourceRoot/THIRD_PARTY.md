# Third-party scope

| Component / pin | Included use | Terms and notice location |
|---|---|---|
| CommonLibSSE-NG 23eded41e1a0ab65887f96e49025506731e8212f / 7.5.0 | Compiled from included source and statically linked | GPL-3.0-or-later with the unchanged upstream exception; `licenses/CommonLib-COPYING.txt`, `CommonLib-EXCEPTIONS.md`, `CommonLib-legacy-MIT.txt` |
| spdlog v1.16.0 | Compiled/static linked with `SPDLOG_USE_STD_FORMAT` | MIT; `licenses/spdlog-LICENSE.txt` |
| DirectXTK feb2024 | Compiled/static linked dependency | MIT; `licenses/DirectXTK-LICENSE.txt` |
| DirectXMath feb2024 | Included header dependency | MIT; `licenses/DirectXMath-LICENSE.txt` |
| QuickLoot IE API header / e4dc2812c5583dd714f6d7da89e514a232845653 | `vendor/QuickLootAPI.h` native API input; explicit header exception | MIT; `licenses/QuickLootIE-API-MIT.txt` |
| QuickLoot IE status-marker vectors used by 057 | Historical inherited 057 artwork only; the 065 marker and category-icon inputs are the 061 SVGs | Original GPL and exception texts are retained under `licenses/`; 057 source/build scope is recorded in the historical evidence and is not the 065 build input |
| EE / RE2.8.6 fork / AE reference profiles | ABI facts and hashes; no provider source tree/binary/UI/code prefixes | See `docs/license-provenance.json`; source/permission mapping remains unresolved |
| MCM Helper / eecef06507b506df0f73066be3a2ba7e45b0d8de | External compiler imports/runtime dependency, not redistributed or linked | MIT source evidence in `docs/license-provenance.json` |
| Skyrim/SKSE/SkyUI Papyrus compiler imports | External SDK/runtime dependencies, not redistributed | Follow their own terms; external import files remain outside this candidate |
| SkyUI item icon movie | No runtime reference in the `owned-svg` route; no movie or artwork copied | Existing SkyUI reference history remains in `docs/SKYUI_ICONS_JA.md` |
| Caprica 0.3.0a / Champollion 1.3.2 | External build/verification tools; no tool executable included | See `dependencies.json` and `licenses/` |
| JPEXS FFDec 23.0.1 / Java / MSVC / CMake / Ninja / Python / Node | External build/verification tools | No tool executable is redistributed |

The private source package includes the allowlisted code, source SVGs, dependency archives, and unchanged license texts. It contains no game files, SkyUI movie, embedded game font, PDB, private log, or user conversation. The runtime review testpack is not a publication.

Nexus posting rules, cooperative-mod permissions, artwork rights, and separately required provider assets remain separate questions. This inventory grants no permissions on behalf of any author.
