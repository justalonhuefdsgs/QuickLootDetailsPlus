// Execute the actual compiled SWF's decompiled AVM1/AS2; SYNTHETIC metrics, no game GFx.
const fs=require('fs'),vm=require('vm'),assert=require('assert');
let iconLoadCount=0;
const ctx={Math,isFinite,stop(){},_global:{},Color:function(target){this.target=target;this.setRGB=v=>{target.tint=v;};},MovieClipLoader:function(){this.addListener=function(listener){this.listener=listener;};this.loadClip=function(source,target){iconLoadCount++;this.source=source;this.target=target;return true;};}};
function metrics(text,font,width,wrap){let x=0,max=0,lines=text===''?0:1;for(const c of text){if(c==='\n'){max=Math.max(max,x);x=0;lines++;continue;}if(c==='\r')continue;const cp=c.codePointAt(0);if(/\p{Mark}/u.test(c)||cp===0x200d||cp===0xfe0f)continue;const w=font*(cp<128?.6:1);if(wrap&&x>0&&x+w>width){max=Math.max(max,x);x=0;lines++;}x+=w;}return {width:Math.max(max,x),height:lines*(font+2)};}
function clip(){return {_visible:true,_currentframe:1,_totalframes:100,labelFrames:{default_misc:73,default_food:31},ops:[],createEmptyMovieClip(name){return this[name]=clip();},gotoAndStop(label){this.frameLabel=label;this._currentframe=this.labelFrames[label]||1;},createTextField(name,depth,x,y,width,height){
 const field={testName:name,_x:x,_y:y,_width:width,_visible:true,text:'',html:false,setNewTextFormat(f){this.format=f;},setTextFormat(f){this.format=f;}};
 let boxHeight=height,auto='none';
 Object.defineProperty(field,'_height',{get(){return boxHeight;},set(v){boxHeight=v;}});
 Object.defineProperty(field,'autoSize',{get(){return auto;},set(v){auto=v;if(v!=='none'){
   const m=metrics(this.text,this.format.size,Math.max(1,this._width-4),this.wordWrap);
   if(!this.wordWrap)this._width=m.width+4;
   boxHeight=m.height+4;
 }}});
 Object.defineProperty(field,'htmlText',{get(){return this.originalHTML||'';},set(v){throw Error('Plain native text path cannot depend on htmlText');}});
 for(const property of ['textWidth','textHeight'])Object.defineProperty(field,property,{get(){
   const nativeExtent=property==='textWidth'&&ctx.reportNaturalWidth&&this.wordWrap;
   const m=metrics(this.text,this.format.size,Math.max(1,this._width-4),nativeExtent?false:this.wordWrap);
   return m[property==='textWidth'?'width':'height'];
 }});
 this[name]=field;
},clear(){this.ops=[];},lineStyle(...a){this.ops.push(['style',...a]);},beginFill(...a){this.ops.push(['fill',...a]);},moveTo(...a){this.ops.push(['move',...a]);},lineTo(...a){this.ops.push(['line',...a]);},endFill(){this.ops.push(['end']);}};}

ctx.createEmptyMovieClip=name=>clip();ctx.TextFormat=function(font,size,color){this.font=font;this.size=size;this.color=color;};
for(const n of ['qldMarkerEnchant','qldMarkerKnown','qldMarkerSpecial','qldMarkerRead'])ctx[n]=clip();
vm.createContext(ctx);vm.runInContext(fs.readFileSync(process.argv[2],'utf8'),ctx);assert.strictEqual(ctx.qldProbe(),'QLD_UI_0.1.20-065');ctx.InitExtensions();ctx.SetPlatform(1,false);

assert.strictEqual(ctx.QLD_CATEGORY_ICON_ROUTE,'text');
const card={name:'callback edge',count:1,type:4,weight:1,value:3,description:'',categoryText:'Book',showCategory:true,showIcons:true,iconLabel:'__unknown_icon__',enchantMarker:0,bookRead:false};
let h=ctx.qldMeasure(card,300,18);ctx.qldRender(true,card,0,0,300,1,18,.35,1,h);
assert.strictEqual(iconLoadCount,0,'text default must not start a SkyUI load');assert.strictEqual(ctx.categoryIcon._visible,false);assert.strictEqual(ctx.content.category.text,'Book');assert.strictEqual(ctx.content.title._x,16);
ctx.QLD_CATEGORY_ICON_ROUTE='unknown';h=ctx.qldMeasure(card,300,18);ctx.qldRender(true,card,0,0,300,1,18,.35,1,h);
assert.strictEqual(iconLoadCount,0,'unknown route must fail closed');assert.strictEqual(ctx.categoryIcon._visible,false);assert.strictEqual(ctx.content.category.text,'Book');
// The test mutates the AS2 var directly to create a pending request; this is not a runtime setting or UI.
ctx.QLD_CATEGORY_ICON_ROUTE='skyui';h=ctx.qldMeasure(card,300,18);ctx.qldRender(true,card,0,0,300,1,18,.35,1,h);
assert.strictEqual(iconLoadCount,1);assert.strictEqual(ctx.categoryIcon._visible,false);const startedGeneration=ctx.iconLoadGeneration;assert.strictEqual(startedGeneration,ctx.iconRequestGeneration);
ctx.QLD_CATEGORY_ICON_ROUTE='text';h=ctx.qldMeasure(card,300,18);ctx.qldRender(true,card,0,0,300,1,18,.35,1,h);
assert.ok(ctx.iconRequestGeneration>startedGeneration,'leaving the route invalidates its outstanding request');assert.strictEqual(iconLoadCount,1);assert.strictEqual(ctx.categoryIcon._visible,false);assert.strictEqual(ctx.content.category.text,'Book');assert.strictEqual(ctx.content.title._x,16);
ctx.onLoadError(ctx.categoryIcon);assert.strictEqual(ctx.iconLoadFailed,false,'a stale error must not poison route state');
ctx.onLoadInit(ctx.categoryIcon);assert.strictEqual(ctx.categoryIcon._visible,false,'a stale success callback must be discarded');assert.strictEqual(ctx.iconLoaded,false);assert.strictEqual(iconLoadCount,1);
ctx.qldApplyCategoryIcon();assert.strictEqual(ctx.categoryIcon._visible,false,'direct apply must also fail closed');
console.log('ROUTE GENERATION PASS: text default starts no load; unknown route fails closed; stale success/error callbacks cannot reveal icon or poison current state. Synthetic compiled AS2; no game GFx.');
