#pragma once
#include <RE/Skyrim.h>
#include <Windows.h>
#include "qld/Core.h"
#include "qld/Providers.h"
namespace qld {
bool installLegacyBridge(const ProviderEvidence&,HMODULE,State&,void(*showDetails)());
std::optional<CardSnapshot> copyLegacyNativeCard(RE::InventoryEntryData*,RE::ObjectRefHandle,
    std::int32_t,RE::GFxMovieView*);
}
