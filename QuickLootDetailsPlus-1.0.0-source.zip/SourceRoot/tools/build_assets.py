"""Build own UI/quest/Papyrus using explicitly supplied external tools/imports.
No installation, download, deployment or game configuration writes.
"""
import hashlib,json,os,pathlib,re,shutil,struct,subprocess
from icon_library import build_icon_movie
ROOT=pathlib.Path(__file__).resolve().parents[1]
OUT=ROOT/'build/assets'
TOOL_HOME=ROOT/'build/.tool-home'
APPROVED_FFDEC_JARS={
    '23.0.1':'84088e1c955ae649c22ca3e3d8ac8bfa59eeba6f10a18fa77eccd2f91d801a84',
    '26.3.0':'1587e60b2ec2c0e4f5721fd5f2aaaf2379f6d416569de99054b5c5d1e9ba841c',
}

def tool(key):
    value=os.environ.get(key)
    if not value or not pathlib.Path(value).is_file():raise RuntimeError('Set '+key+' to an existing external tool file')
    return value
def run(*args):
    env=os.environ.copy();env['APPDATA']=env['LOCALAPPDATA']=str(TOOL_HOME)
    env['TEMP']=env['TMP']=str(ROOT/'build/temp')
    subprocess.run([str(a) for a in args],check=True,cwd=ROOT,env=env)
def ffdec(*args):
    run(tool('QLD_JAVA'),'-Duser.home='+str(TOOL_HOME),'-Djava.awt.headless=true','-jar',tool('QLD_FFDEC'),*args)

def ffdec_identity():
    java_path=pathlib.Path(tool('QLD_JAVA'))
    jar_path=pathlib.Path(tool('QLD_FFDEC'))
    env=os.environ.copy()
    env['APPDATA']=env['LOCALAPPDATA']=str(TOOL_HOME)
    env['TEMP']=env['TMP']=str(ROOT/'build/temp')
    result=subprocess.run([str(java_path),'-Duser.home='+str(TOOL_HOME),'-Djava.awt.headless=true','-jar',str(jar_path),'-help'],
        check=False,cwd=ROOT,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace')
    output=result.stdout+'\n'+result.stderr
    match=re.search(r'JPEXS Free Flash Decompiler v\.([0-9]+(?:\.[0-9]+){1,2})',output)
    if result.returncode!=0 or not match:
        raise RuntimeError('Could not detect JPEXS FFDec version from the existing configured QLD_FFDEC JAR')
    version=match.group(1);jar_sha256=hashlib.sha256(jar_path.read_bytes()).hexdigest()
    if APPROVED_FFDEC_JARS.get(version)!=jar_sha256:
        raise RuntimeError('Configured FFDec version/hash is not one of the explicitly evidenced 049/057 local toolchains')
    return {'version':version,'jar_name':jar_path.name,'jar_sha256':jar_sha256}


def marker_swf_map(path):
    data=path.read_bytes()
    body=__import__('zlib').decompress(data[8:]) if data[:3]==b'CWS' else data[8:]
    pos=(5+4*(body[0]>>3)+7)//8+4;shapes={};placements={}
    while pos<len(body):
        header=struct.unpack_from('<H',body,pos)[0];pos+=2;length=header&63
        if length==63:length=struct.unpack_from('<I',body,pos)[0];pos+=4
        tag=header>>6;payload=body[pos:pos+length];pos+=length
        if tag in (2,22,32,83):shapes[struct.unpack_from('<H',payload)[0]]=len(payload)
        if tag==26:
            flags=payload[0];depth=struct.unpack_from('<H',payload,1)[0];offset=3;character=None
            if flags&2:character=struct.unpack_from('<H',payload,offset)[0];offset+=2
            if flags&4:offset+=1
            if flags&8:offset+=4
            if flags&16:offset+=2
            if flags&32:
                raw=payload[offset:]
                if b'\0' in raw:placements[raw.split(b'\0',1)[0].decode('ascii')]=(character,depth)
    if pos!=len(body):raise RuntimeError('Marker SWF tag boundary mismatch')
    return {'shape_payload_bytes':shapes,'named_instances':placements}

def make_ui():
    bits=format(16,'05b')+''.join(format(v&0xffff,'016b') for v in (0,25600,0,14400))
    bits+='0'*(-len(bits)%8);rect=int(bits,2).to_bytes(len(bits)//8,'big')
    tag=lambda n,v:struct.pack('<H',(n<<6)|len(v))+v
    OUT.mkdir(parents=True,exist_ok=True)
    tool_identity=ffdec_identity()
    category_icon_record=build_icon_movie(ROOT,ROOT/'build',lambda *args:ffdec('-importShapes',*args),tool_identity)
    body=rect+struct.pack('<HH',30*256,1)+tag(69,b'\0'*4)+tag(12,b'\x07\0')+tag(1,b'')+tag(0,b'')
    seed=OUT/'seed.swf';seed.write_bytes(b'FWS\x08'+struct.pack('<I',8+len(body))+body)
    shaped=seed
    target=OUT/'Interface/QuickLootDetails.swf';target.parent.mkdir(parents=True,exist_ok=True)
    seed_scripts=OUT/'seed-scripts';ffdec('-export','script',seed_scripts,shaped)
    exported=list(seed_scripts.rglob('*.as'));assert len(exported)==1
    exported[0].write_text((ROOT/'ui/layout.js').read_text(encoding='utf-8')+'\n'+(ROOT/'ui/panel.as').read_text(encoding='utf-8'),encoding='utf-8')
    ffdec('-onerror','abort','-importScript',shaped,target,seed_scripts)
    ffdec('-export','script',OUT/'decoded-ui',target)
    assert 'qldRender' in (OUT/'decoded-ui/scripts/frame_1/DoAction.as').read_text(encoding='utf-8')
    assert 'QuickLootDetails_CategoryIcons.swf' in (OUT/'decoded-ui/scripts/frame_1/DoAction.as').read_text(encoding='utf-8')

def anonymize_pex(path,name):
    data=path.read_bytes();assert data[:8]==b'\xfa\x57\xc0\xde\x03\x02\x00\x01'
    pos=16
    for _ in range(3):
        n=struct.unpack_from('>H',data,pos)[0];pos+=2+n
    # Only header metadata and timestamp change. Bytecode/debug/string tables remain byte-identical.
    fields=[name+'.psc','QuickLoot Details contributors','public-build']
    header=data[:8]+b'\0'*8+b''.join(struct.pack('>H',len(v.encode()))+v.encode() for v in fields)
    clean=header+data[pos:];path.write_bytes(clean)
    assert clean[len(header):]==data[pos:]
    return {'source_file':fields[0],'compiler_user':fields[1],'compiler_machine':fields[2],'timestamp':0,'payload_sha256':hashlib.sha256(data[pos:]).hexdigest()}

def make_papyrus():
    imports=[ROOT/'scripts']+[pathlib.Path(s) for s in os.environ.get('QLD_PAPYRUS_IMPORTS','').split(';') if s]
    if len(imports)<2 or any(not p.is_dir() for p in imports):raise RuntimeError('Set QLD_PAPYRUS_IMPORTS to existing Skyrim/SKSE + MCM Helper compiler import directories; see BUILD.md')
    compiler_path=pathlib.Path(tool('QLD_CAPRICA')).resolve()
    dependencies=json.loads((ROOT/'dependencies.json').read_text(encoding='utf-8'))
    caprica_spec=next((x for x in dependencies.get('portableTools',[]) if pathlib.Path(x['file']).name.casefold()=='caprica.zip'),None)
    if not caprica_spec:raise RuntimeError('Caprica release is not pinned in dependencies.json')
    caprica_archive=compiler_path.parent.parent/pathlib.Path(caprica_spec['file']).name
    archive_sha=hashlib.sha256(caprica_archive.read_bytes()).hexdigest() if caprica_archive.is_file() else ''
    executable_sha=hashlib.sha256(compiler_path.read_bytes()).hexdigest()
    if archive_sha!=caprica_spec['sha256']:raise RuntimeError('Caprica archive missing or does not match pinned release hash')
    if executable_sha!=caprica_spec.get('executableSha256'):raise RuntimeError('Caprica executable does not match the pinned extracted binary hash')
    required_imports=json.loads((ROOT/'docs/papyrus-imports-required.json').read_text(encoding='utf-8'))['files']
    available={}
    for directory in imports[1:]:
        for source in directory.glob('*.psc'):
            available.setdefault(source.name.casefold(),[]).append(hashlib.sha256(source.read_bytes()).hexdigest())
    missing=[name for name,digest in required_imports.items() if not any(v==digest for v in available.get(name.casefold(),[]))]
    if missing:raise RuntimeError('Required Papyrus compiler source imports are absent or mismatched: '+', '.join(sorted(missing)))
    local=ROOT/'build/imports';local.mkdir(parents=True,exist_ok=True);imports.append(local)
    pex=OUT/'Scripts';pex.mkdir(parents=True,exist_ok=True)
    report={}
    for name in ('QLD_Native','QLD_MCM'):
        command=[tool('QLD_CAPRICA'),'--game=skyrim','--ignorecwd','--anonymize','--flags='+str(ROOT/'scripts/Skyrim.flg'),
            '--import='+';'.join(str(p) for p in imports),'--output='+str(pex),str(ROOT/'scripts'/f'{name}.psc')]
        for _ in range(96):
            result=subprocess.run(command,cwd=ROOT,capture_output=True,text=True,encoding='utf-8',errors='replace')
            if result.returncode==0:break
            missing=re.search(r"Unable to resolve type '([A-Za-z][A-Za-z0-9_]*)'",result.stdout+result.stderr)
            if not missing or not os.environ.get('QLD_GAME_BSA'):raise RuntimeError(result.stdout+result.stderr)
            target=missing.group(1)
            if any(p.stem.casefold()==target.casefold() for p in local.glob('*.psc')):raise RuntimeError('Repeated unresolved compiler import '+target)
            from restore_papyrus_import import restore
            restore(target)
        else:raise RuntimeError('Compiler import closure exceeds 96 types')
        report[name]=anonymize_pex(pex/f'{name}.pex',name)
    (OUT/'pex-metadata.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    # Filename/hash provenance only. Never retain SDK source paths in public output.
    imported={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for d in imports for p in sorted(d.glob('*.psc'))}
    (OUT/'compiler-import-manifest.json').write_text(json.dumps(imported,indent=2),encoding='utf-8')
    caprica_url=caprica_spec['url']
    compiler_record={'compiler':{'name':'Caprica','version':caprica_url.rstrip('/').rsplit('/',2)[-2],'release_url':caprica_url,
        'archive_sha256':archive_sha,'executable_sha256':executable_sha},
        'external_imports':{'required':len(required_imports),'matched':len(required_imports),'missing':[]},
        'source_sha256':{name:hashlib.sha256((ROOT/'scripts'/f'{name}.psc').read_bytes()).hexdigest() for name in report},
        'pex_sha256':{name:hashlib.sha256((pex/f'{name}.pex').read_bytes()).hexdigest() for name in report},
        'payload_sha256':{name:value['payload_sha256'] for name,value in report.items()}}
    (OUT/'papyrus-build-record.json').write_text(json.dumps(compiler_record,indent=2),encoding='utf-8')

def sub(tag,value):
    assert len(value)<=65535
    return tag.encode('ascii')+struct.pack('<H',len(value))+value
def record(tag,form,data,flags=0):
    return tag.encode('ascii')+struct.pack('<IIIHHHH',len(data),flags,form,0,0,44,0)+data
def make_esp():
    strings=lambda s:struct.pack('<H',len(s.encode()))+s.encode()
    vmad=struct.pack('<HHH',5,2,1)+strings('QLD_MCM')+b'\0'+struct.pack('<H',0)
    vmad+=b'\x02'+struct.pack('<H',0)+strings('')+struct.pack('<H',1)
    vmad+=struct.pack('<HHIHHH',0,0,0x01000800,5,2,1)
    vmad+=strings('SKI_PlayerLoadGameAlias')+b'\0'+struct.pack('<H',0)
    quest=sub('EDID',b'QLD_MCMQuest\0')+sub('VMAD',vmad)
    quest+=sub('DNAM',struct.pack('<HBBIHH',0x11,0,0,0,0,0))+sub('NEXT',b'')
    quest+=sub('ANAM',struct.pack('<I',1))+sub('ALST',struct.pack('<I',0))
    quest+=sub('ALID',b'PlayerAlias\0')+sub('FNAM',struct.pack('<I',0))
    quest+=sub('ALFR',struct.pack('<I',0x14))+sub('VTCK',struct.pack('<I',0))+sub('ALED',b'')
    quest=record('QUST',0x01000800,quest)
    header=sub('HEDR',struct.pack('<fII',1.7,1,0x801))
    header+=sub('CNAM',b'QuickLoot Details contributors\0')+sub('SNAM',b'Passive QuickLoot detail panel configuration\0')
    header+=sub('MAST',b'Skyrim.esm\0')+sub('DATA',b'\0'*8)
    group=b'GRUP'+struct.pack('<I4sIHHHH',len(quest)+24,b'QUST',0,0,0,0,0)+quest
    (OUT/'QuickLootDetails.esp').write_bytes(record('TES4',0,header)+group)
    (OUT/'SEQ').mkdir(exist_ok=True);(OUT/'SEQ/QuickLootDetails.seq').write_bytes(struct.pack('<I',0x01000800))

def write_source_manifest():
    manifest={str(p.relative_to(ROOT)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest()
        for folder in ('ui','scripts','assets') for p in sorted((ROOT/folder).rglob('*')) if p.is_file()}
    manifest['tools/build_assets.py']=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()
    manifest['tools/icon_library.py']=hashlib.sha256((ROOT/'tools/icon_library.py').read_bytes()).hexdigest()
    (OUT/'source-manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')

def main():
    import argparse,shutil
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--papyrus-only',action='store_true',help='compile ESP/PEX/config assets but do not create or retain a SWF; never package this incomplete output')
    parser.add_argument('--ui-only',action='store_true',help='build the SWF/config/source manifest only; Papyrus artifacts must be supplied separately and identified as inherited')
    parser.add_argument('--manifest-only',action='store_true',help='refresh copied config assets and the source manifest without touching SWF/PEX/ESP/SEQ')
    args=parser.parse_args()
    if sum((args.papyrus_only,args.ui_only,args.manifest_only))>1:raise RuntimeError('Choose only one partial asset-build mode')
    for p in (OUT,ROOT/'build/temp',TOOL_HOME):p.mkdir(parents=True,exist_ok=True)
    if args.manifest_only:
        shutil.copytree(ROOT/'assets',OUT,dirs_exist_ok=True)
        write_source_manifest()
        print('Copied current config assets and refreshed source manifest; SWF/PEX/ESP/SEQ unchanged.')
        return
    swf=OUT/'Interface/QuickLootDetails.swf'
    if args.papyrus_only and swf.exists():
        raise RuntimeError('Refusing papyrus-only build while any pre-existing SWF is present; use a fresh candidate output directory')
    if args.ui_only and swf.exists():
        raise RuntimeError('Refusing UI-only build while a pre-existing SWF is present; use a fresh candidate output directory')
    shutil.copytree(ROOT/'assets',OUT,dirs_exist_ok=True)
    if args.ui_only:
        make_ui();write_source_manifest()
        print('Own SWF/config/source manifest built. Papyrus/ESP/SEQ were not built by this command.')
        return
    if not args.papyrus_only:make_ui()
    make_papyrus();make_esp()
    if args.papyrus_only:
        (OUT/'UI_NOT_BUILT.txt').write_text('Papyrus-only candidate output. No QuickLootDetails SWF was built. Not eligible for runtime packaging.\n',encoding='utf-8')
    write_source_manifest()
    print('Own assets compiled; PEX metadata independently sanitized and payload verified.')
if __name__=='__main__':main()
