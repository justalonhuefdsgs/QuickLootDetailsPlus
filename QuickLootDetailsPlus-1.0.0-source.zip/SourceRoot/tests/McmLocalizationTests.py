#!/usr/bin/env python3
"""Static checks for complete MCM Helper localization and stable saved setting IDs."""
import configparser
import json
import pathlib
import re
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
CONFIG = ROOT / "assets/MCM/Config/QuickLootDetails/config.json"
LANG_DIR = ROOT / "assets/Interface/Translations"
LANGS = ("ENGLISH", "JAPANESE")

def fail(message):
    raise AssertionError(message)

def read_catalog(language):
    path = LANG_DIR / f"QuickLootDetails_{language}.txt"
    raw = path.read_bytes()
    if not raw.startswith(b"\xff\xfe"):
        fail(f"{path.name}: missing UTF-16 LE BOM")
    try:
        text = raw[2:].decode("utf-16-le")
    except UnicodeDecodeError as exc:
        fail(f"{path.name}: invalid UTF-16 LE: {exc}")
    entries = {}
    for line_no, line in enumerate(text.splitlines(), 1):
        if not line or line.count("\t") != 1:
            fail(f"{path.name}:{line_no}: expected one tab-separated key/value")
        key, value = line.split("\t")
        if not key.startswith("$QLD_") or not value.strip():
            fail(f"{path.name}:{line_no}: invalid or empty translation")
        if key in entries:
            fail(f"{path.name}:{line_no}: duplicate key {key}")
        if "\r" in value or "\n" in value or "\t" in value:
            fail(f"{path.name}:{line_no}: embedded control character")
        entries[key] = value
    return entries

def config_keys(node, path="config"):
    found=[]
    if isinstance(node, dict):
        for key,value in node.items():
            current=f"{path}.{key}"
            if key in {"displayName","pageDisplayName","text","help"} and isinstance(value,str):
                found.append((current,value))
            if key in {"options"} and isinstance(value,list):
                found.extend((f"{current}[{i}]",v) for i,v in enumerate(value) if isinstance(v,str))
            if key=="value" and isinstance(value,str):
                found.append((current,value))
            found.extend(config_keys(value,current))
    elif isinstance(node,list):
        for i,value in enumerate(node):
            found.extend(config_keys(value,f"{path}[{i}]"))
    return found

def main():
    cfg=json.loads(CONFIG.read_text(encoding="utf-8"))
    en=read_catalog("ENGLISH"); ja=read_catalog("JAPANESE")
    if any(term not in en["$QLD_HELP_POTION"].lower() for term in ("potion", "poison", "food", "drink")) or any(term not in ja["$QLD_HELP_POTION"] for term in ("薬", "毒", "飲食物")):
        fail("alchemy description help must include food and drink")
    if set(en)!=set(ja): fail("English and Japanese key sets differ; no English fallback is assumed")
    refs=config_keys(cfg)
    for path,value in refs:
        if not value.startswith("$QLD_"):
            fail(f"user-facing MCM text is not localized: {path}={value!r}")
        if value not in en or value not in ja:
            fail(f"missing translation for {path}: {value}")
    legacy={"$QLD_QUICKLOOT_ANCHOR","$QLD_HELP_ANCHOR","$QLD_OPTION_BELOW","$QLD_ICONS","$QLD_HELP_ICONS","$QLD_RESET_POSITION","$QLD_HELP_RESET_POSITION","$QLD_WORLD_ANCHOR","$QLD_HELP_WORLD_ANCHOR","$QLD_OPTION_RIGHT","$QLD_OPTION_LEFT"}
    referenced=set(value for _,value in refs)
    if referenced & legacy or set(en)!=referenced | legacy:
        fail("translation catalogs have unexpected unused keys or missing preserved legacy strings")
    for key,value in en.items():
        if re.search(r"[ぁ-ヿ一-龯]",value): fail(f"Japanese characters in English value {key}")
    allowed_jp_words={"QuickLoot","SkyUI","DPS"}
    for key,value in ja.items():
        words=set(re.findall(r"[A-Za-z]{2,}",value))
        if key=="$QLD_TITLE": words-= {"Detail","Plus"}
        if words-allowed_jp_words: fail(f"unnecessary English in Japanese value {key}: {sorted(words-allowed_jp_words)}")
        if " / " in value or " /" in value or "/ " in value:
            fail(f"mixed bilingual value in Japanese catalog: {key}")
    required={"QuickLootDetails.esp","SkyUI_SE.esp"}
    estimate_en=en.get("$QLD_HELP_REFERENCE_DPS",""); estimate_ja=ja.get("$QLD_HELP_REFERENCE_DPS","")
    if any(term not in estimate_en for term in ("not measured DPS","attacks per second","Animation cycles","attack cadence","perks/effects","live combat conditions")):
        fail("English reference-DPS help omits estimate limits")
    if any(term not in estimate_ja for term in ("実測DPS","攻撃/秒","アニメーション周期","攻撃間隔","能力/効果","戦闘中の条件")):
        fail("Japanese reference-DPS help omits estimate limits")
    if "(estimate)" not in en.get("$QLD_REFERENCE_DPS","") or "（概算）" not in ja.get("$QLD_REFERENCE_DPS",""):
        fail("reference-DPS label does not identify an estimate")
    if not required.issubset(set(cfg.get("pluginRequirements",[]))):
        fail("QuickLootDetails.esp and SkyUI_SE.esp must be required")
    pages=cfg.get("pages",[])
    if len(pages)!=4 or len({p.get("pageDisplayName") for p in pages})!=4: fail("four unique selectable pages required")
    if [p.get("pageDisplayName") for p in pages]!=["$QLD_PAGE_MAIN","$QLD_PAGE_WORLD","$QLD_PAGE_DETAILS","$QLD_PAGE_RESET"]: fail("page order changed")
    items=[item for page in pages for item in page["content"]]
    ids=[item["id"] for item in items if item.get("id")]
    if len(ids)!=28 or len(set(ids))!=28: fail("28 unique saved setting controls required")
    if any(item.get("id") for item in pages[3]["content"]): fail("reset page must contain no setting controls")
    actions=[item.get("action",{}).get("function") for item in pages[3]["content"] if item.get("action")]
    if set(actions)!={"ResetQuickLootPosition","ResetWorldPosition","ResetDefaults"} or len(actions)!=3: fail("reset action routing changed")
    controls={item.get("id"):item for item in items if item.get("id")}
    if "bShowIcons:CardInfo" in controls or "iSide:Layout" in controls:
        fail("obsolete QuickLoot controls must not be visible")
    if "bShowReferenceDps:CardInfo" not in controls:
        fail("missing MCM reference-DPS setting")
    if controls["bShowReferenceDps:CardInfo"].get("valueOptions",{}).get("sourceType")!="ModSettingBool":
        fail("reference-DPS toggle is not a saved boolean setting")
    if "iAnchor:World" in controls:
        fail("World anchor must be hidden while its saved key remains compatible")
    ini=configparser.ConfigParser();ini.optionxform=str
    ini.read(ROOT/"assets/MCM/Config/QuickLootDetails/settings.ini",encoding="utf-8")
    if ini.getint("General","bEnabled")!=1 or ini.getint("World","bEnabled")!=0 or ini.getint("World","iAnchor")!=0 or ini.getfloat("World","fOffsetX")!=-220 or ini.getfloat("World","fOffsetY")!=90 or ini.getint("World","iCardScale")!=100:
        fail("fresh display and world defaults mismatch")
    if not {"fDeltaX:World","fDeltaY:World"}.issubset(controls) or {"fOffsetX:World","fOffsetY:World"} & controls.keys(): fail("delta UI / legacy-key split")
    if ini.getfloat("World","fDeltaX")!=-1000000 or ini.getfloat("World","fDeltaY")!=-1000000: fail("uninitialized per-axis compatibility sentinel")
    if sum(len(ini[sec]) for sec in ini.sections())!=33: fail("31 legacy plus 2 versioned delta keys required")
    if ini.getint("CardInfo","bShowIcons",fallback=0)!=1:
        fail("icon display must default to ON")
    if ini.getint("CardInfo","bShowReferenceDps",fallback=1)!=0:
        fail("reference-DPS display must default to OFF")
    script=(ROOT/"scripts/QLD_MCM.psc").read_text(encoding="utf-8")
    native=(ROOT/"scripts/QLD_Native.psc").read_text(encoding="utf-8")
    if 'bool showIcons, bool referenceDps) global native' not in native or 'GetModSettingBool("bShowReferenceDps:CardInfo")' not in script:
        fail("Papyrus source does not pass the saved reference-DPS setting to native code")
    if 'SetModSettingBool("bShowIcons:CardInfo", true)' not in script:
        fail("ResetDefaults must restore icons to ON")
    if 'SetModSettingBool("bShowReferenceDps:CardInfo", false)' not in script or 'GetModSettingBool("bShowReferenceDps:CardInfo")' not in script:
        fail("ResetDefaults and ApplySettings must wire reference-DPS OFF/setting")
    print(f"MCM localization PASS: {len(refs)} visible fields, {len(en)} exact keys in both UTF-16 LE BOM catalogs; settings IDs/default verified")

if __name__=="__main__": main()
