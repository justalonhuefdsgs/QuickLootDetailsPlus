#include "qld/LegacyBridge.h"
#include "qld/LegacySelection.h"
#include "qld/LegacyBinaryEvidence.h"
#include "qld/NativeCard.h"
#include <SKSE/SKSE.h>
#include <atomic>
#include <cstring>
#include <mutex>

namespace qld { namespace {
class LocalMemory final:public MemoryReader {
public:
    bool read(std::uint64_t a,std::span<std::byte> out) const override {
        SIZE_T copied{};
        return !out.empty() && ReadProcessMemory(GetCurrentProcess(),reinterpret_cast<const void*>(a),out.data(),out.size(),&copied) && copied==out.size();
    }
} memory;
const LegacyLayout* layout{};std::uint64_t moduleBase{};State* state{};void(*show)(){};
using Advance=void(*)(RE::IMenu*,float,std::uint32_t);
using Message=RE::UI_MESSAGE_RESULTS(*)(RE::IMenu*,RE::UIMessage&);
Advance originalAdvance{};Message originalMessage{};
std::recursive_mutex updateMutex;
std::uint64_t sequence{};double delay{};
struct Key {
    std::uint32_t container{},form{};std::int32_t index{},count{};
    std::uint64_t allocationToken{},vectorToken{};
    std::string name;std::vector<StackTraits> traits;
    std::vector<std::uint32_t> groundHandles;
    bool operator==(const Key&)const=default;
};
std::optional<Key> previous;
void clear() {
    previous.reset();delay=0;
    if(state && state->frame().open)state->close();
}
bool selectedUI(RE::IMenu* menu,double& index,std::uint32_t& length,std::string& name,double& count) {
    if(!menu || !menu->OnStack() || !menu->uiMovie || !menu->uiMovie->GetVisible())return false;
    RE::GFxValue root,list,selected,provider,value;RE::GFxValue::DisplayInfo display;
    auto* view=menu->uiMovie.get();
    if(!view->GetVariable(&root,"_root.rootObj") || !root.IsDisplayObject() || !root.GetDisplayInfo(&display) || !display.GetVisible() ||
       !view->GetVariable(&list,"_root.rootObj.itemList") || !list.IsObject() ||
       !list.GetMember("selectedIndex",&value) || !value.IsNumber())return false;
    index=value.GetNumber();
    if(!list.GetMember("dataProvider",&provider) || !provider.IsArray())return false;
    length=provider.GetArraySize();
    if(!std::isfinite(index) || index<0 || index>=length || std::floor(index)!=index || length>16384 ||
       !provider.GetElement(static_cast<std::uint32_t>(index),&selected) || !selected.IsObject() ||
       !selected.GetMember("displayName",&value) || !value.IsString())return false;
    name=value.GetString()?value.GetString():"";
    if(name.size()>65536 || !selected.GetMember("count",&value) || !value.IsNumber())return false;
    count=value.GetNumber();return std::isfinite(count);
}
std::optional<Key> inspect(const LegacySelection& selected) {
    auto container=RE::TESObjectREFR::LookupByHandle(selected.container);
    if(!container || container->IsDeleted() || container->IsDisabled() || container->IsActivationBlocked())return {};
    Key key;key.container=selected.container;key.index=selected.index;key.count=selected.count;
    key.allocationToken=selected.itemAddress;key.vectorToken=selected.vectorBegin;
    key.groundHandles=selected.groundHandles;
    if(selected.entryAddress){
        std::array<std::byte,sizeof(RE::InventoryEntryData)> header{};
        if(!memory.read(selected.entryAddress,header))return {};
        auto* entry=reinterpret_cast<RE::InventoryEntryData*>(selected.entryAddress);
        if(!entry->object || !entry->object->IsInventoryObject() ||
           RE::TESForm::LookupByID<RE::TESBoundObject>(entry->object->GetFormID())!=entry->object)return {};
        key.form=entry->object->GetFormID();const auto* name=entry->GetDisplayName();key.name=name?name:"";
        key.traits=copyStackTraits(entry);
    }else{
        std::int64_t total{};
        for(auto handle:selected.groundHandles){
            auto ref=RE::TESObjectREFR::LookupByHandle(handle);
            if(!ref || ref->IsDeleted() || ref->IsDisabled() || !ref->GetBaseObject() || !ref->GetBaseObject()->IsInventoryObject())return {};
            auto* object=ref->GetBaseObject();const auto n=ref->extraList.GetCount();if(n<=0)return {};
            if(key.form && key.form!=object->GetFormID())return {};
            key.form=object->GetFormID();total+=n;
            if(key.name.empty()){const auto* name=ref->GetDisplayFullName();key.name=name?name:"";}
            RE::InventoryEntryData entry(object,n);entry.AddExtraList(&ref->extraList);
            auto traits=copyStackTraits(&entry);key.traits.insert(key.traits.end(),traits.begin(),traits.end());
        }
        if(total!=selected.count)return {};
    }
    return key;
}
std::optional<CardSnapshot> generate(const LegacySelection& selected,const Key& key,RE::GFxMovieView* view) {
    if(selected.entryAddress)return copyLegacyNativeCard(reinterpret_cast<RE::InventoryEntryData*>(selected.entryAddress),{},selected.count,view);
    // A dropped group is displayable only when every real reference generates the
    // same native card (including charge, poison and individual enchantment fields).
    std::optional<CardSnapshot> result;
    for(auto raw:selected.groundHandles){
        auto ref=RE::TESObjectREFR::LookupByHandle(raw);
        if(!ref || ref->IsDeleted() || ref->IsDisabled() || !ref->GetBaseObject() || ref->GetBaseObject()->GetFormID()!=key.form)return {};
        RE::InventoryEntryData entry(ref->GetBaseObject(),selected.count);
        auto card=copyLegacyNativeCard(&entry,ref->GetHandle(),selected.count,view);
        if(!card || (result && result->fields!=card->fields))return {};
        result=std::move(card);
    }
    return result;
}
void observe(RE::IMenu* menu,float interval) {
    double index{},count{};std::uint32_t length{};std::string name;
    if(!selectedUI(menu,index,length,name,count)){clear();return;}
    const auto address=reinterpret_cast<std::uint64_t>(menu);
    auto selection=readLegacySelection(memory,*layout,moduleBase,address,index,length);
    if(!selection || selection->count!=count){clear();return;}
    auto key=inspect(*selection);
    if(!key || key->name!=name){clear();return;}
    auto frame=state->frame();
    if(!frame.open || !frame.selected || frame.selected->container!=key->container){
        state->open(key->container);previous.reset();delay=0;if(show)show();
    }
    delay=std::max(0.0,delay-(std::isfinite(interval)?std::clamp<double>(interval,0,1):0));
    const bool changed=!previous || *previous!=*key;
    if(!changed && delay>0)return;
    previous=*key;delay=0.25;
    // Retain primitive values only. Each borrowed entry dies before Advance returns.
    if(changed)state->invalidate(key->container);frame=state->frame();const auto generation=frame.generation;
    auto card=generate(*selection,*key,menu->uiMovie.get());
    double afterIndex{},afterCount{};std::uint32_t afterLength{};std::string afterName;
    if(!card || !selectedUI(menu,afterIndex,afterLength,afterName,afterCount)){clear();return;}
    auto after=readLegacySelection(memory,*layout,moduleBase,address,afterIndex,afterLength);
    if(!after || *after!=*selection || afterName!=name || afterCount!=count || inspect(*after)!=key){clear();return;}
    if(state->frame().generation!=generation || !state->frame().open)return;
    const auto current=state->frame();
    if(!changed && current.selected && current.selected->card.fields==card->fields)return;
    Item item;item.formId=key->form;item.container=key->container;item.count=key->count;
    item.stackIdentity=++sequence;item.name=key->name;item.selectedName=key->name;item.selectedTraits=key->traits;
    item.card=std::move(*card);
    if(!state->selectCurrent(generation,key->container,std::move(item)))return;
    SKSE::log::debug("LEGACY_CARD_COPIED provider={} index={} form={:08x} count={} changed={} owned-provider-advance=true",layout->hash.substr(0,8),index,key->form,key->count,changed);
}
void advanceHook(RE::IMenu* menu,float interval,std::uint32_t time) {
    std::lock_guard lock(updateMutex);
    originalAdvance(menu,interval,time);
    observe(menu,interval);
}
RE::UI_MESSAGE_RESULTS messageHook(RE::IMenu* menu,RE::UIMessage& message) {
    std::lock_guard lock(updateMutex);
    if(*message.type==RE::UI_MESSAGE_TYPE::kHide)clear();
    return originalMessage(menu,message);
}
bool replace(void** slot,void* expected,void* value) {
    DWORD old{};if(!VirtualProtect(slot,sizeof(void*),PAGE_READWRITE,&old))return false;
    const bool ok=InterlockedCompareExchangePointer(slot,value,expected)==expected;
    DWORD ignored{};VirtualProtect(slot,sizeof(void*),old,&ignored);return ok;
}
}
bool installLegacyBridge(const ProviderEvidence& provider,HMODULE module,State& target,void(*showDetails)()) {
    const auto* candidate=legacyLayout(provider,REL::Module::get().version().pack());
    if(!candidate || !module || layout)return false;
    const auto base=reinterpret_cast<std::uint64_t>(module);
    const auto i=static_cast<std::size_t>(candidate-legacyLayouts);const auto& proof=legacyBinaryEvidence[i];
    std::array<std::uint64_t,9> table{};std::array<unsigned char,32> code{};
    if(!memory.read(base+candidate->menuVtable,std::as_writable_bytes(std::span(table))))return false;
    if(!legacyVtableMatches(proof,base,table))return false;
    for(auto n:{4,5}){
        if(!memory.read(table[n],std::as_writable_bytes(std::span(code))) || !legacyCodeMatches(proof,n,code))return false;
    }
    auto** slots=reinterpret_cast<void**>(base+candidate->menuVtable);
    layout=candidate;moduleBase=base;state=&target;show=showDetails;
    originalMessage=reinterpret_cast<Message>(table[4]);originalAdvance=reinterpret_cast<Advance>(table[5]);
    if(!replace(slots+4,reinterpret_cast<void*>(table[4]),reinterpret_cast<void*>(messageHook))){layout=nullptr;return false;}
    if(!replace(slots+5,reinterpret_cast<void*>(table[5]),reinterpret_cast<void*>(advanceHook))){
        replace(slots+4,reinterpret_cast<void*>(messageHook),reinterpret_cast<void*>(table[4]));layout=nullptr;return false;
    }
    SKSE::log::info("LEGACY_BRIDGE_READY provider={} verified-vtable={:x} advance={:x} message={:x} no-input-hooks=true",provider.name,candidate->menuVtable,candidate->advance,candidate->message);
    return true;
}
}
