#include "qld/Card.h"
#include <cmath>

namespace qld {
bool consistentStack(std::span<const StackTraits> traits,std::int32_t totalCount,StackTraits base) noexcept {
    if(totalCount<=0)return false;
    auto valid=[](const StackTraits& x){return std::isfinite(x.health) && x.health>0 && x.health<=1e7 && x.count>0;};
    if(!valid(base))return false;
    if(traits.empty())return true;
    const auto& first=traits.front();if(!valid(first))return false;
    std::int64_t represented{};
    for(const auto& x:traits){if(!valid(x) || x.health!=first.health || x.enchantment!=first.enchantment)return false;represented+=x.count;}
    return represented<=totalCount && (represented==totalCount || (base.health==first.health && base.enchantment==first.enchantment));
}
bool validCard(const CardSnapshot& card) noexcept {
    auto number=[&](const char* name){auto it=card.fields.find(name);return it!=card.fields.end() && std::holds_alternative<double>(it->second) && std::isfinite(std::get<double>(it->second)) && std::get<double>(it->second)>=0 && std::get<double>(it->second)<=1e7;};
    auto text=[&](const char* name){auto it=card.fields.find(name);return it!=card.fields.end() && std::holds_alternative<std::string>(it->second) && std::get<std::string>(it->second).size()<=65536;};
    if(!number("type") || !number("weight") || !number("value") || !text("name") || std::get<std::string>(card.fields.at("name")).empty())return false;
    const auto type=std::get<double>(card.fields.at("type"));
    if(type!=std::floor(type) || type>16)return false;
    if(card.fields.contains("count") && (!number("count") || std::get<double>(card.fields.at("count"))<1 || std::get<double>(card.fields.at("count"))!=std::floor(std::get<double>(card.fields.at("count")))))return false;
    if(type==1 && (!number("armor") || !text("effects")))return false;
    if(type==2 && (!number("damage") || !text("effects")))return false;
    if((type==5 || type==6 || type==7) && !text("effects"))return false;
    if(type==4 && !text("description"))return false;
    if(type==8){
        if(!number("numItemEffects") || std::get<double>(card.fields.at("numItemEffects"))>4 || std::get<double>(card.fields.at("numItemEffects"))!=std::floor(std::get<double>(card.fields.at("numItemEffects"))))return false;
        for(const char* name:{"itemEffect0","itemEffect1","itemEffect2","itemEffect3"})if(!text(name))return false;
    }
    for(const auto& [key,value]:card.fields){
        if(auto s=std::get_if<std::string>(&value);s && s->size()>65536)return false;
        if(auto n=std::get_if<double>(&value);n && !std::isfinite(*n))return false;
    }
    return true; // zero weight/value and genuinely empty descriptions are valid.
}
}
