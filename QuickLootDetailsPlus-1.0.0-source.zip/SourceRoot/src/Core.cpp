#include "qld/Core.h"
#include "qld/Providers.h"

#include <charconv>
#include <cctype>
#include <bit>
#include <format>

namespace qld {
namespace {
double bounded(double value, double fallback, double low, double high) {
    return std::isfinite(value) ? std::clamp(value, low, high) : fallback;
}
std::string_view trim(std::string_view v) {
    while (!v.empty() && std::isspace(static_cast<unsigned char>(v.front()))) v.remove_prefix(1);
    while (!v.empty() && std::isspace(static_cast<unsigned char>(v.back()))) v.remove_suffix(1);
    return v;
}
}
void WorldSettings::normalize() noexcept {
    offsetX=bounded(offsetX,-220,-8192,8192);
    offsetY=bounded(offsetY,90,-4320,4320);
    cardScalePercent=std::clamp(((std::clamp(cardScalePercent,50,150)+2)/5)*5,50,150);
    if(anchor!=WorldAnchor::right && anchor!=WorldAnchor::left)anchor=WorldAnchor::right;
}
void CardDisplaySettings::normalize() noexcept {
    maxRows=std::clamp(maxRows,1,6);
    fontScale=bounded(fontScale,0.9,0.75,1.25);
}
void Settings::normalize() noexcept {
    offsetX = bounded(offsetX, 0, -8192, 8192);
    offsetY = bounded(offsetY, 0, -4320, 4320);
    width = bounded(width, 300, 180, 800);
    scale = bounded(scale, 1, 0.5, 2);
    fontSize = bounded(fontSize, 18, 10, 36);
    backgroundOpacity = bounded(backgroundOpacity, 0.70, 0, 1);
    textOpacity = bounded(textOpacity, 1, 0.1, 1);
    quickLootScalePercent=std::clamp(((std::clamp(quickLootScalePercent,50,150)+2)/5)*5,50,150);
    if (side != Side::left && side != Side::right && side != Side::below) side = Side::below;
    world.normalize();
    cardDisplay.normalize();
}
double quickLootRenderScale(const Settings& settings) noexcept {
    auto s=settings;s.normalize();
    return s.scale*static_cast<double>(s.quickLootScalePercent)/100.0;
}
double worldRenderScale(const Settings& settings) noexcept {
    auto s=settings;s.normalize();
    return s.scale*static_cast<double>(s.world.cardScalePercent)/100.0;
}
bool MovieLoadGate::shouldAttempt(bool lootVisible, double interval) noexcept {
    if(!lootVisible || attempts_>=3)return false;
    delay_=std::max(0.0,delay_-(std::isfinite(interval)?std::clamp(interval,0.0,1.0):0.0));
    if(delay_>0)return false;
    ++attempts_;delay_=1.0;return true;
}
Settings parseSettings(std::string_view ini) {
    Settings s;
    std::optional<double> worldDeltaX,worldDeltaY;
    std::string section;
    while (!ini.empty()) {
        auto e = ini.find('\n');
        auto line = trim(ini.substr(0, e));
        ini = e == ini.npos ? std::string_view{} : ini.substr(e + 1);
        if (line.empty() || line.front() == ';' || line.front() == '#') continue;
        if (line.front() == '[' && line.back() == ']') { section = std::string(trim(line.substr(1,line.size()-2))); continue; }
        auto equals = line.find('=');
        if (equals == line.npos) continue;
        auto rawKey = trim(line.substr(0, equals));
        auto key = std::string(rawKey);
        if (rawKey.find(':') == rawKey.npos && !section.empty()) key += ":" + section;
        auto val = trim(line.substr(equals + 1));
        double number{};
        auto result = std::from_chars(val.data(), val.data() + val.size(), number);
        if (result.ec != std::errc{} || result.ptr != val.data() + val.size()) continue;
        if (key == "bEnabled:General") s.enabled = number != 0;
        else if (key == "iSide:Layout") s.side = number == 0 ? Side::left : number == 1 ? Side::right : Side::below;
        else if (key == "fOffsetX:Layout") s.offsetX = number;
        else if (key == "fOffsetY:Layout") s.offsetY = number;
        else if (key == "fWidth:Layout") s.width = number;
        else if (key == "fScale:Layout") s.scale = number;
        else if (key == "fFontSize:Style") s.fontSize = number;
        else if (key == "fBackgroundOpacity:Style") s.backgroundOpacity = number;
        else if (key == "fTextOpacity:Style") s.textOpacity = number;
        else if (key == "iCardScale:QuickLoot") s.quickLootScalePercent = std::isfinite(number) ? static_cast<int>(std::lround(std::clamp(number,50.0,150.0))) : 100;
        else if (key == "bEnabled:World") s.world.enabled = number != 0;
        else if (key == "iAnchor:World") s.world.anchor = number == 1 ? WorldAnchor::left : WorldAnchor::right;
        else if (key == "fOffsetX:World") s.world.offsetX = number;
        else if (key == "fOffsetY:World") s.world.offsetY = number;
        else if (key == "fDeltaX:World" && std::isfinite(number) && number>=-7972 && number<=8412) worldDeltaX=number;
        else if (key == "fDeltaY:World" && std::isfinite(number) && number>=-4410 && number<=4230) worldDeltaY=number;
        else if (key == "iCardScale:World") s.world.cardScalePercent = std::isfinite(number) ? static_cast<int>(std::lround(std::clamp(number,50.0,150.0))) : 100;
        else if (key == "bShowExtraInfo:CardInfo") s.cardDisplay.enabled=number!=0;
        else if (key == "bShowCategory:CardInfo") s.cardDisplay.category=number!=0;
        else if (key == "bShowValueWeight:CardInfo") s.cardDisplay.valueWeight=number!=0;
        else if (key == "bShowOwnedCount:CardInfo") s.cardDisplay.ownedCount=number!=0;
        else if (key == "bShowBookRead:CardInfo") s.cardDisplay.bookRead=number!=0;
        else if (key == "bShowSpellLearned:CardInfo") s.cardDisplay.spellLearned=number!=0;
        else if (key == "bShowPotionDetails:CardInfo") s.cardDisplay.potionDetails=number!=0;
        else if (key == "bShowIngredientEffects:CardInfo") s.cardDisplay.ingredientEffects=number!=0;
        else if (key == "bShowEquipmentDetails:CardInfo") s.cardDisplay.equipmentDetails=number!=0;
        else if (key == "bShowSoulGemDetails:CardInfo") s.cardDisplay.soulGemDetails=number!=0;
        else if (key == "bShowItemFlags:CardInfo") s.cardDisplay.itemFlags=number!=0;
        else if (key == "bShowPluginSource:CardInfo") s.cardDisplay.pluginSource=number!=0;
        else if (key == "iMaxRows:CardInfo") s.cardDisplay.maxRows=std::isfinite(number)?static_cast<int>(std::lround(number)):4;
        else if (key == "fFontScale:CardInfo") s.cardDisplay.fontScale=number;
        else if (key == "bShowIcons:CardInfo") s.cardDisplay.showIcons=number!=0;
        else if (key == "bShowReferenceDps:CardInfo") s.cardDisplay.referenceDps=number!=0;
    }
    if(worldDeltaX)s.world.offsetX=-220+*worldDeltaX;
    if(worldDeltaY)s.world.offsetY=90+*worldDeltaY;
    s.normalize();
    return s;
}
Settings parseSettingsLayers(std::string_view defaults, std::string_view user) {
    std::string merged(defaults);
    merged += "\n[]\n"; // Reset section before the independent user INI.
    merged += user;
    return parseSettings(merged);
}
std::optional<double> referenceMeleeDps(double damage,double weaponSpeed) noexcept {
    if(!std::isfinite(damage)||!std::isfinite(weaponSpeed)||damage<=0||damage>100000||weaponSpeed<=0||weaponSpeed>5)return {};
    const double estimate=damage*weaponSpeed;
    if(!std::isfinite(estimate)||estimate<=0||estimate>1000000)return {};
    return estimate;
}
std::string_view displayAlchemyCategory(bool isFoodOrDrink,bool isPoison,bool english) noexcept {
    if(isFoodOrDrink)return english?"Food":"食品";
    if(isPoison)return english?"Poison":"毒";
    return english?"Potion":"薬";
}
std::vector<std::string> buildCardInfoRows(const CardSnapshot& card,const CardDisplaySettings& requested,bool english) {
    auto settings=requested;settings.normalize();
    std::vector<std::string> rows;
    if(!settings.enabled)return rows;
    const auto string=[&](const char* key)->const std::string* {
        const auto it=card.fields.find(key);
        return it==card.fields.end()?nullptr:std::get_if<std::string>(&it->second);
    };
    const auto number=[&](const char* key)->const double* {
        const auto it=card.fields.find(key);
        return it==card.fields.end()?nullptr:std::get_if<double>(&it->second);
    };
    const auto boolean=[&](const char* key)->const bool* {
        const auto it=card.fields.find(key);
        return it==card.fields.end()?nullptr:std::get_if<bool>(&it->second);
    };
    const auto add=[&](std::string row) {
        if(!row.empty() && rows.size()<static_cast<std::size_t>(settings.maxRows))rows.push_back(cleanText(row,512));
    };
    const auto* ownedCount=number("ownedCount");
    const bool validOwnedCount=ownedCount&&std::isfinite(*ownedCount)&&*ownedCount>=0&&*ownedCount<=1e7&&*ownedCount==std::floor(*ownedCount);
    const auto* weaponType=string(english?"weaponTypeEn":"weaponTypeJa");
    const bool pairWeaponAndCount=settings.ownedCount&&settings.equipmentDetails&&validOwnedCount&&weaponType&&!weaponType->empty();
    const auto* armorClass=string(english?"armorClassEn":"armorClassJa");
    const bool pairArmorAndCount=settings.ownedCount&&settings.equipmentDetails&&validOwnedCount&&armorClass&&!armorClass->empty()&&!pairWeaponAndCount;
    if(settings.ownedCount&&validOwnedCount){
        if(pairWeaponAndCount)add(english?std::format("Weapon: {} | Owned: {:.0f}",*weaponType,*ownedCount):std::format("武器種: {}・所持数: {:.0f}",*weaponType,*ownedCount));
        else if(pairArmorAndCount)add(english?std::format("Armor: {} | Owned: {:.0f}",*armorClass,*ownedCount):std::format("防具: {}・所持数: {:.0f}",*armorClass,*ownedCount));
        else add(english?std::format("Owned: {:.0f}",*ownedCount):std::format("所持数: {:.0f}",*ownedCount));
    }
    if(settings.bookRead)if(const auto* value=boolean("bookRead"))add(english?(*value?"Read":"Unread"):(*value?"既読済み":"未読"));
    if(settings.spellLearned)if(const auto* value=boolean("spellLearned"))add(english?std::format("Spell: {}",*value?"Learned":"Not learned"):std::format("呪文: {}",*value?"習得済み":"未習得"));
    if(settings.equipmentDetails){
        if(weaponType&&!weaponType->empty()&&!pairWeaponAndCount)add(english?std::format("Weapon: {}",*weaponType):std::format("武器種: {}",*weaponType));
        if(armorClass&&!armorClass->empty()&&!pairArmorAndCount)add(english?std::format("Armor: {}",*armorClass):std::format("防具: {}",*armorClass));
        if(const auto* value=string(english?"equipmentCompareEn":"equipmentCompareJa");value&&!value->empty())add(*value);
    }
    if(settings.referenceDps){
        const auto* melee=boolean("isMeleeWeapon");const auto* damage=number("damage");const auto* speed=number("weaponSpeed");
        if(melee&&*melee&&damage&&speed)if(const auto estimate=referenceMeleeDps(*damage,*speed))
            add(english?std::format("Reference DPS (estimate): {:.1f}",*estimate):std::format("参考DPS（概算）: {:.1f}",*estimate));
    }
    if(settings.equipmentDetails){
        const auto* speed=number("weaponSpeed");const auto* reach=number("weaponReach");
        const bool validSpeed=speed&&std::isfinite(*speed)&&*speed>=0&&*speed<=1e4;
        const bool validReach=reach&&std::isfinite(*reach)&&*reach>=0&&*reach<=1e4;
        if(validSpeed&&validReach)add(english?std::format("Speed: {:.2f} | Reach: {:.2f}",*speed,*reach):std::format("速度: {:.2f} / 射程: {:.2f}",*speed,*reach));
        else if(validSpeed)add(english?std::format("Speed: {:.2f}",*speed):std::format("速度: {:.2f}",*speed));
        else if(validReach)add(english?std::format("Reach: {:.2f}",*reach):std::format("射程: {:.2f}",*reach));
    }
    if(settings.ingredientEffects){
        const auto* known=number("ingredientKnownEffects");const auto* total=number("ingredientTotalEffects");
        if(known&&total&&std::isfinite(*known)&&std::isfinite(*total)&&*known>=0&&*known<=4&&*total>=1&&*total<=4&&*known<=*total&&*known==std::floor(*known)&&*total==std::floor(*total))
            add(english?std::format("Known effects: {:.0f}/{:.0f}",*known,*total):std::format("既知効果: {:.0f}/{:.0f}",*known,*total));
    }
    if(settings.soulGemDetails){
        const auto level=[&](double value)->std::string_view {
            constexpr std::string_view ja[]={"空","極小","小","普通","大","極大"};
            constexpr std::string_view en[]={"Empty","Petty","Lesser","Common","Greater","Grand"};
            if(!std::isfinite(value)||value<0||value>5||value!=std::floor(value))return {};
            return english?en[static_cast<std::size_t>(value)]:ja[static_cast<std::size_t>(value)];
        };
        if(const auto* capacity=number("soulCapacity");capacity&&*capacity>0){
            const auto capacityText=level(*capacity);
            std::string currentText;
            if(const auto* mixed=boolean("soulMixed");mixed&&*mixed)currentText=english?"Mixed/unknown":"混在/不明";
            else if(const auto* current=number("soulCurrent"))currentText=level(*current);
            if(!capacityText.empty()&&!currentText.empty())add(english?std::format("Soul: {} / Capacity: {}",currentText,capacityText):std::format("魂: {} / 容量: {}",currentText,capacityText));
        } else {
            std::string gem;
            if(const auto* textValue=string("soulLVL");textValue&&!textValue->empty())gem=*textValue;
            else if(const auto* numericValue=number("soulLVL");numericValue&&std::isfinite(*numericValue))gem=std::format("{:.0f}",*numericValue);
            if(!gem.empty())add(english?std::format("Soul: {}",gem):std::format("魂: {}",gem));
        }
    }
    if(settings.itemFlags){
        std::string flags;
        const auto append=[&](const char* key,const char* ja,const char* en){
            if(const auto* value=boolean(key);value&&*value){if(!flags.empty())flags+=english?", ":"・";flags+=english?en:ja;}
        };
        append("stolen","盗品","Stolen");append("poisoned","毒","Poisoned");append("questItem","クエスト","Quest");
        if(!flags.empty())add(english?std::format("Flags: {}",flags):std::format("状態: {}",flags));
    }
    if(settings.pluginSource)if(const auto* value=string("pluginSource");value&&!value->empty())add(english?std::format("Source: {}",*value):std::format("出典: {}",*value));
    return rows;
}
std::uint32_t countKnownIngredientEffects(std::uint32_t flags,std::uint32_t effectCount) noexcept {
    const auto count=std::min(effectCount,4u);
    const auto mask=count==4?0xFu:((1u<<count)-1u);
    return static_cast<std::uint32_t>(std::popcount(flags&mask));
}
std::string cleanText(std::string_view text, std::size_t maxBytes) {
    std::string out;
    for (std::size_t i = 0; i < text.size();) {
        auto c = static_cast<unsigned char>(text[i]);
        std::size_t n = c < 0x80 ? 1 : c >= 0xC2 && c <= 0xDF ? 2 : c >= 0xE0 && c <= 0xEF ? 3 : c >= 0xF0 && c <= 0xF4 ? 4 : 0;
        if (n == 0 || i + n > text.size()) { ++i; continue; }
        bool valid = true;
        for (std::size_t j = 1; j < n; ++j) if ((static_cast<unsigned char>(text[i+j]) & 0xC0) != 0x80) valid = false;
        if (n == 3 && ((c == 0xE0 && static_cast<unsigned char>(text[i+1]) < 0xA0) || (c == 0xED && static_cast<unsigned char>(text[i+1]) >= 0xA0))) valid = false;
        if (n == 4 && ((c == 0xF0 && static_cast<unsigned char>(text[i+1]) < 0x90) || (c == 0xF4 && static_cast<unsigned char>(text[i+1]) >= 0x90))) valid = false;
        if (!valid) { ++i; continue; }
        if (out.size() + n > maxBytes) break;
        if (n == 1 && (c < 0x20 || c == 0x7F)) out += ' ';
        else out.append(text.substr(i, n));
        i += n;
    }
    return out;
}
void State::open(std::uint32_t container) {
    std::lock_guard lock(mutex_);
    ++frame_.generation; ++frame_.revision;
    frame_.open = container != 0; frame_.selected.reset(); container_ = container;
}
void State::close() {
    std::lock_guard lock(mutex_);
    frame_.open = false; frame_.selected.reset(); container_ = 0;
    ++frame_.generation; ++frame_.revision;
}
void State::invalidate(std::uint32_t container) {
    std::lock_guard lock(mutex_);
    if (container != container_) return;
    frame_.selected.reset(); ++frame_.revision;
}
void State::select(std::uint32_t container, std::optional<Item> item) {
    std::lock_guard lock(mutex_);
    if (!frame_.open || container != container_) return;
    if (item && (item->formId == 0 || item->container != container || item->count <= 0)) item.reset();
    if (item) {
        item->name = cleanText(item->name);
        item->category = cleanText(item->category, 80);
        // CardSnapshot owns the exact native card fields; no text/value rewriting.
        item->weight = bounded(item->weight, 0, 0, 1e7);
        item->value = std::max(item->value, 0);
    }
    frame_.selected = std::move(item); ++frame_.revision;
}
bool State::publishCard(std::uint64_t generation,std::uint64_t selection,CardSnapshot card) {
    std::lock_guard lock(mutex_);
    if(!frame_.open || frame_.generation!=generation || !frame_.selected || frame_.selected->stackIdentity!=selection || !validCard(card))return false;
    frame_.selected->card=std::move(card);++frame_.revision;return true;
}
bool State::selectCurrent(std::uint64_t generation,std::uint32_t container,Item item) {
    std::lock_guard lock(mutex_);
    if(!frame_.open || frame_.generation!=generation || container_!=container || item.container!=container || !item.formId || item.count<=0 || !validCard(item.card))return false;
    item.name=cleanText(item.name);item.category=cleanText(item.category,80);
    frame_.selected=std::move(item);++frame_.revision;return true;
}
void State::configure(Settings settings) {
    settings.side=Side::below; // Keep saved legacy anchors without using them for the QuickLoot card.
    settings.world.anchor=WorldAnchor::right; // Preserve legacy key but use the fixed world baseline.
    settings.normalize(); std::lock_guard lock(mutex_);
    frame_.settings = settings; ++frame_.revision;
}
void State::configureLoot(Settings settings) {
    settings.side=Side::below; // MCM no longer exposes the legacy QuickLoot anchor.
    settings.normalize();std::lock_guard lock(mutex_);
    settings.world=frame_.settings.world;settings.cardDisplay=frame_.settings.cardDisplay;frame_.settings=settings;++frame_.revision;
}
void State::configureWorld(WorldSettings settings) {
    settings.anchor=WorldAnchor::right; // Legacy anchor is retained in storage, not used for placement.
    settings.normalize();std::lock_guard lock(mutex_);
    frame_.settings.world=settings;++frame_.revision;
}
void State::configureCardDisplay(CardDisplaySettings settings) {
    settings.normalize();std::lock_guard lock(mutex_);
    frame_.settings.cardDisplay=settings;++frame_.revision;
}
Frame State::frame() const { std::lock_guard lock(mutex_); return frame_; }
static Bounds placePanelAnchor(Bounds loot, const Settings& settings, double screenWidth, double screenHeight,double desiredLogicalHeight,double minimumLogicalHeight) {
    auto s = settings; s.normalize();
    if(!std::isfinite(screenWidth) || !std::isfinite(screenHeight) || screenWidth<=0 || screenHeight<=0 || !std::isfinite(desiredLogicalHeight) || desiredLogicalHeight<0 || !std::isfinite(minimumLogicalHeight) || minimumLogicalHeight<0 || !std::isfinite(loot.x) || !std::isfinite(loot.y) || !std::isfinite(loot.width) || !std::isfinite(loot.height) || loot.width<=0 || loot.height<=0)return {};
    const auto renderScale=s.scale*static_cast<double>(s.quickLootScalePercent)/100.0;
    auto width = std::min(s.width*renderScale, screenWidth);
    auto desired=desiredLogicalHeight>0?desiredLogicalHeight:std::max(156.0,6*(s.fontSize+2)+36);
    const auto basicMinimum=std::max(4*s.fontSize+64,1.0)*renderScale;
    auto minimum=std::max(4*s.fontSize+64,minimumLogicalHeight)*renderScale;
    auto height=std::min(std::max(desired*renderScale,minimum),screenHeight);
    if(s.side==Side::below){
        if(height<basicMinimum)return {};
        auto x=std::clamp(loot.x+s.offsetX,0.0,std::max(0.0,screenWidth-width));
        const auto requestedY=std::max(0.0,loot.y+loot.height+12*s.scale+s.offsetY);
        const auto minimumY=std::max(0.0,loot.y+loot.height+12*s.scale);
        const auto y=std::min(requestedY,std::max(minimumY,screenHeight-height));
        const auto available=screenHeight-y;
        if(available>=minimum)return {x,y,width,std::min(height,available),false};
        // Keep the title/stats card when the body cannot fit. The renderer keeps
        // the complete description in its field and marks a clipped body; it
        // must not hide the whole card merely because the full-text minimum is
        // taller than the remaining space.
        if(available>=basicMinimum)return {x,y,width,std::min(height,available),false};
        return {};
    }
    if(height<basicMinimum)return {};
    auto x = s.side == Side::left ? loot.x - width - 12*s.scale : loot.x + loot.width + 12*s.scale;
    return {std::clamp(x+s.offsetX, 0.0, std::max(0.0, screenWidth-width)),
            std::clamp(loot.y+s.offsetY, 0.0, std::max(0.0, screenHeight-height)), width, height};
}
double quickLootPanelWidth(const Settings& settings,double listWidth,double screenWidth) noexcept {
    auto s=settings;s.normalize();
    const auto scale=quickLootRenderScale(s);
    if(!std::isfinite(listWidth) || !std::isfinite(screenWidth) || listWidth<=0 || screenWidth<=0 || !std::isfinite(scale) || scale<=0)return 0;
    // Extend the details panel only as far as the actual QuickLoot list bounds,
    // while preserving an explicitly wider user setting and viewport clipping.
    return std::min(std::max(s.width,listWidth/scale),screenWidth/scale);
}
Bounds placePanel(Bounds loot, const Settings& settings, double screenWidth, double screenHeight,double desiredLogicalHeight,double minimumLogicalHeight) {
    return placePanelAnchor(loot,settings,screenWidth,screenHeight,desiredLogicalHeight,minimumLogicalHeight);
}
double availablePanelHeight(Bounds loot,const Settings& settings,double width,double height) {
    const auto scale=quickLootRenderScale(settings);
    if(!std::isfinite(height) || height<=0 || !std::isfinite(scale) || scale<=0)return 0;
    return placePanel(loot,settings,width,height,height/scale,0).height/scale;
}
double availableWorldPanelHeight(const Settings& settings,double width,double height) {
    const auto scale=worldRenderScale(settings);
    if(!std::isfinite(height) || height<=0 || !std::isfinite(scale) || scale<=0)return 0;
    return placeWorldPanel(settings,width,height,height/scale,0).height/scale;
}
DescriptionFitPlan planDescriptionFit(double preferred, std::span<const DescriptionFitCandidate> candidates,double available) noexcept {
    if(!std::isfinite(preferred) || preferred<=0 || !std::isfinite(available) || available<=0)return {};
    preferred=std::min(preferred,available);
    const DescriptionFitCandidate* best{};
    const DescriptionFitCandidate* floor{};
    for(const auto& candidate:candidates){
        if(!std::isfinite(candidate.fontSize) || candidate.fontSize<=0 || !std::isfinite(candidate.requiredHeight) || candidate.requiredHeight<=0)continue;
        if(!floor || candidate.fontSize<floor->fontSize)floor=&candidate;
        if(candidate.requiredHeight<=preferred+0.01 && (!best || candidate.fontSize>best->fontSize))best=&candidate;
    }
    if(best)return {preferred,preferred,best->fontSize,best->requiredHeight,false,true};
    if(!floor)return {};
    const auto panelHeight=std::min(available,std::max(preferred,floor->requiredHeight));
    return {preferred,panelHeight,floor->fontSize,floor->requiredHeight,panelHeight>preferred+0.01,true};
}
bool providerAllowed(std::string_view hash, std::uint32_t runtime, bool conflictingProvider) noexcept {
    const ProviderEvidence* provider{};
    for(const auto& e:providerEvidence)if(e.hash==hash){provider=&e;break;}
    return !conflictingProvider && provider && adapterImplemented(*provider,runtime);
}
Bounds placeWorldPanel(const Settings& settings,double screenWidth,double screenHeight,double desiredLogicalHeight,double minimumLogicalHeight) {
    auto s=settings;s.normalize();
    if(!std::isfinite(screenWidth) || !std::isfinite(screenHeight) || screenWidth<=0 || screenHeight<=0 || !std::isfinite(desiredLogicalHeight) || desiredLogicalHeight<=0 || !std::isfinite(minimumLogicalHeight) || minimumLogicalHeight<0)return {};
    const auto renderScale=s.scale*static_cast<double>(s.world.cardScalePercent)/100.0;
    const auto width=std::min(s.width*renderScale,screenWidth);
    const auto basicMinimum=std::max(4*s.fontSize+64,1.0)*renderScale;
    const auto minimum=std::max(4*s.fontSize+64,minimumLogicalHeight)*renderScale;
    const auto requested=std::max(desiredLogicalHeight*renderScale,minimum);
    const auto automaticY=std::clamp(screenHeight*0.25,0.0,std::max(0.0,screenHeight-minimum));
    // Prefer the full measured height, grow to the 12px body minimum when needed,
    // and clip only at the viewport's actual hard bound.
    const auto height=std::min(requested,s.world.offsetY==0?screenHeight-automaticY:screenHeight);
    const auto y=std::clamp(automaticY+s.world.offsetY,0.0,std::max(0.0,screenHeight-height));
    if(height<basicMinimum)return {};
    const auto margin=32*s.scale;
    const auto baseX=s.world.anchor==WorldAnchor::right?screenWidth-width-margin:margin;
    const auto x=std::clamp(baseX+s.world.offsetX,0.0,std::max(0.0,screenWidth-width));
    return {x,y,width,height};
}
}
