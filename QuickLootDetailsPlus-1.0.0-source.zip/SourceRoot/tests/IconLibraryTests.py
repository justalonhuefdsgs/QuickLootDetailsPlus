from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
from build_assets import marker_swf_map  # noqa: E402
from icon_library import IconLibraryError, inventory, validate_svg  # noqa: E402


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--main-swf", type=Path, required=True)
    parser.add_argument("--icon-swf", type=Path, required=True)
    parser.add_argument("--compiled-as2", type=Path, required=True)
    parser.add_argument("--artifact-root", type=Path, required=True)
    parser.add_argument("--build-record", type=Path, required=True)
    args = parser.parse_args()
    root = args.root.resolve()
    artifact_root = args.artifact_root.resolve()
    assets = root / "assets" / "category-icons"
    mapping = json.loads((assets / "manifest" / "icon_mapping.json").read_text(encoding="utf-8-sig"))
    overlays = json.loads((assets / "manifest" / "overlay_mapping.json").read_text(encoding="utf-8-sig"))
    audit = json.loads((assets / "manifest" / "vector_checks_061.json").read_text(encoding="utf-8-sig"))
    marker_source = json.loads((root / "assets" / "marker-art" / "provenance.json").read_text(encoding="utf-8-sig"))
    build_record = json.loads(args.build_record.read_text(encoding="utf-8-sig"))

    items = mapping["items"]
    source_labels = mapping["source_labels"]
    require(len(items) == 80 and len(overlays) == 4, "expected 80 base SVGs and four overlays")
    require(len(source_labels) == 78 and len(set(source_labels)) == 78, "expected 78 unique active source labels")
    require([item["label"] for item in items if item["source_label"]] == source_labels, "active mapping order changed")
    symbols = [item["symbol_id"] for item in items] + [item["symbol_id"] for item in overlays]
    require(len(symbols) == 84 and len(set(symbols)) == 84, "061 symbol IDs are missing or duplicated")
    require(audit["source_label_count"] == 78 and audit["mapped_source_label_count"] == 78, "061 audit label coverage differs")
    require(audit["duplicate_symbol_ids"] == 0 and audit["all_18_v3_symbols_preserved"], "061 audit symbol/carryover gate failed")
    require(not audit["individual_geometry_mismatches"] and not audit["overlay_geometry_mismatches"], "061 vector geometry audit failed")
    require(audit["external_references"] == [] and audit["all_svg_external_references"] == [], "061 vector audit reports external references")

    expected_svg: dict[str, str] = {}
    for entry in items + overlays:
        svg = assets / entry["asset_path"]
        validate_svg(svg)
        expected_svg[entry["symbol_id"]] = sha(svg)
    require(len(expected_svg) == 84, "not all 84 individual SVGs were checked")
    require("unknown_fallback" not in source_labels and "drink" not in source_labels, "a supplemental icon became active")
    require("food_wine" in source_labels, "existing food_wine route is missing")

    icon_data = args.icon_swf.read_bytes()
    info = inventory(icon_data)
    records = build_record["shape_records"]
    require(len(records) == 84, "build record does not contain all 84 symbols")
    require(len({record["shape_id"] for record in records}) == 84, "SWF shape IDs are not unique")
    require({record["symbol_id"]: record["source_svg_sha256"] for record in records} == expected_svg,
            "build input SVG hashes differ from the exact 061 individual assets")
    require(set(info["shape_payload_bytes"]) == {record["shape_id"] for record in records}, "compiled sidecar shape IDs differ from build map")
    require(all(info["shape_payload_bytes"][record["shape_id"]] > 8 for record in records), "an imported vector shape is empty")
    expected_labels = {label: i + 2 for i, label in enumerate(source_labels)}
    require(info["frame_labels"] == expected_labels, "SWF frame-label order or blank first frame differs")
    by_label = {record["label"]: record["shape_id"] for record in records if record["label"] is not None}
    expected_frame_shapes = {index + 2: by_label[label] for index, label in enumerate(source_labels)}
    require(info["label_shape_ids"] == expected_frame_shapes, "SWF label-to-vector drawing map differs")
    require(info["frame_count"] == 79, "sidecar should have one blank frame followed by 78 active label frames")
    require(info["forbidden_tag_count"] == 0, "sidecar contains text, font, bitmap, or media SWF tags")
    require(sha(args.icon_swf) == build_record["sidecar_sha256"], "compiled sidecar hash differs from its build record")
    inactive = [entry for entry in items if not entry["source_label"]]
    placed_ids = set(info["label_shape_ids"].values())
    require(len(inactive) == 2, "expected exactly two non-active supplemental item assets")
    require(all(by_label[item["label"]] not in placed_ids for item in inactive), "supplemental fallback/drink art was placed on an active frame")

    panel = (root / "ui" / "panel.as").read_text(encoding="utf-8-sig")
    compiled = args.compiled_as2.read_text(encoding="utf-8-sig")
    route = re.search(r'(?m)^\s*var\s+QLD_CATEGORY_ICON_ROUTE\s*=\s*"([^"]+)"\s*;', panel)
    require(route and route.group(1) == "text", "approved card category-icon-disabled route changed")
    label_function = re.search(r"function\s+qldIsKnownItemIconLabel\s*\(label\)\s*\{(.*?)\n\}", compiled, re.S)
    require(label_function is not None, "compiled AS2 known-label function is missing")
    labels_match = re.search(r"\bvar\s+[A-Za-z_$][\w$]*\s*=\s*\[(.*?)\];", label_function.group(1), re.S)
    require(labels_match is not None, "compiled AS2 known-label array is missing")
    compiled_labels = re.findall(r'"([^"]+)"', labels_match.group(1))
    require(compiled_labels == source_labels, "compiled AS2 label list/order differs from the 061 mapping")
    require("QuickLootDetails_CategoryIcons.swf" in compiled, "compiled AS2 does not load the candidate sidecar movie")
    require("default_misc" in compiled and "unknown_fallback" not in compiled_labels, "unknown label fallback was changed")
    require("drink" not in compiled_labels, "supplemental drink became an active AS2 label")
    # Category and title marker rendering was removed by approved107/113 changes.
    # Preserve all84 archived SVG/source/frame integrity checks above.
    marker_info = marker_swf_map(args.main_swf)
    require(not marker_info["shape_payload_bytes"] and not marker_info["named_instances"], "removed title marker art returned")
    require("var enchantMarkerIcon" not in compiled and "var readMarkerIcon" not in compiled, "removed marker bindings returned")
    require("categoryIcon._visible = false" in compiled, "disabled category icon is not hidden")

    pixel_report = artifact_root / "preview" / "pixel_checks_065.json"
    require(pixel_report.is_file(), "PC pixel-check report is missing")
    pixels = json.loads(pixel_report.read_text(encoding="utf-8-sig"))
    require(pixels.get("status") == "PASS" and pixels.get("standalone_asset_count") == 84, "PC local pixel check failed")
    for size in ("16", "20", "24"):
        result = pixels["native_size_sheets"][size]
        require(result["base_asset_count"] == 80 and result["combinations_rendered"] == 8, f"{size}px preview coverage is incomplete")
        require((artifact_root / "preview" / result["sheet"]).is_file(), f"{size}px preview sheet is missing")

    print("ICON_LIBRARY_PASS active_labels=78 base_assets=80 overlays=4 symbols=84 frames=78 swf_static_vector=PASS pc_pixels=16,20,24")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, KeyError, IconLibraryError, json.JSONDecodeError, AssertionError) as exc:
        print(f"ICON_LIBRARY_FAIL {exc}", file=sys.stderr)
        raise SystemExit(1)
