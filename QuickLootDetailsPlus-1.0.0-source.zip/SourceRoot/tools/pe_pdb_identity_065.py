"""Verify the candidate DLL CodeView RSDS record against its private PDB Info stream."""
from __future__ import annotations

import argparse
import hashlib
import json
import struct
import sys
import uuid
from pathlib import Path

MSF7 = b"Microsoft C/C++ MSF 7.00\r\n\x1aDS\x00\x00\x00"


class IdentityParseError(ValueError):
    pass


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_u16(data: bytes, offset: int) -> int:
    if offset < 0 or offset + 2 > len(data):
        raise IdentityParseError("truncated PE/PDB 16-bit field")
    return struct.unpack_from("<H", data, offset)[0]


def read_u32(data: bytes, offset: int) -> int:
    if offset < 0 or offset + 4 > len(data):
        raise IdentityParseError("truncated PE/PDB 32-bit field")
    return struct.unpack_from("<I", data, offset)[0]


def parse_pe_codeview(data: bytes) -> dict[str, object]:
    if data[:2] != b"MZ":
        raise IdentityParseError("DLL does not have a DOS MZ header")
    pe = read_u32(data, 0x3C)
    if data[pe:pe + 4] != b"PE\0\0":
        raise IdentityParseError("DLL PE signature is missing")
    coff = pe + 4
    section_count = read_u16(data, coff + 2)
    optional_size = read_u16(data, coff + 16)
    optional = coff + 20
    magic = read_u16(data, optional)
    if magic == 0x20B:
        directory_offset, count_offset = optional + 112, optional + 108
    elif magic == 0x10B:
        directory_offset, count_offset = optional + 96, optional + 92
    else:
        raise IdentityParseError(f"unsupported PE optional-header magic 0x{magic:04x}")
    directory_count = read_u32(data, count_offset)
    if directory_count <= 6:
        raise IdentityParseError("PE has no debug data directory")
    debug_rva = read_u32(data, directory_offset + 6 * 8)
    debug_size = read_u32(data, directory_offset + 6 * 8 + 4)
    if debug_rva == 0 or debug_size < 28:
        raise IdentityParseError("PE debug data directory is empty")
    size_of_headers = read_u32(data, optional + 60)
    section_table = optional + optional_size
    sections = []
    for index in range(section_count):
        offset = section_table + index * 40
        virtual_size, virtual_address, raw_size, raw_pointer = struct.unpack_from("<IIII", data, offset + 8)
        sections.append((virtual_address, max(virtual_size, raw_size), raw_size, raw_pointer))

    def rva_to_offset(rva: int) -> int:
        if rva < size_of_headers:
            return rva
        for virtual_address, extent, raw_size, raw_pointer in sections:
            if virtual_address <= rva < virtual_address + extent:
                delta = rva - virtual_address
                if delta >= raw_size:
                    break
                return raw_pointer + delta
        raise IdentityParseError(f"PE RVA 0x{rva:x} does not map to file data")

    debug_offset = rva_to_offset(debug_rva)
    for offset in range(debug_offset, debug_offset + debug_size - 27, 28):
        record_type = read_u32(data, offset + 12)
        size = read_u32(data, offset + 16)
        pointer = read_u32(data, offset + 24)
        if record_type != 2:
            continue
        if size < 25 or pointer + size > len(data):
            raise IdentityParseError("PE CodeView debug payload is truncated")
        record = data[pointer:pointer + size]
        if record[:4] != b"RSDS":
            continue
        guid = str(uuid.UUID(bytes_le=record[4:20])).upper()
        age = read_u32(record, 20)
        raw_path = record[24:].split(b"\0", 1)[0].decode("utf-8", errors="replace")
        return {"guid": guid, "age": age, "pdb_basename": Path(raw_path.replace("\\", "/")).name}
    raise IdentityParseError("PE contains no RSDS CodeView record")


def parse_pdb_info(data: bytes) -> dict[str, object]:
    if not data.startswith(MSF7):
        raise IdentityParseError("PDB is not an MSF 7.0 file")
    block_size, free_page_map, block_count, directory_bytes, _reserved, block_map_addr = struct.unpack_from("<6I", data, len(MSF7))
    if block_size < 512 or block_size > 65536 or block_count == 0 or block_count * block_size > len(data):
        raise IdentityParseError("invalid PDB MSF superblock dimensions")
    directory_blocks = (directory_bytes + block_size - 1) // block_size
    block_map_offset = block_map_addr * block_size
    if block_map_offset + directory_blocks * 4 > len(data):
        raise IdentityParseError("PDB directory block map is truncated")
    directory_page_ids = struct.unpack_from("<" + "I" * directory_blocks, data, block_map_offset)
    directory = bytearray()
    for page in directory_page_ids:
        if page >= block_count:
            raise IdentityParseError("PDB directory page is outside the MSF file")
        start = page * block_size
        directory.extend(data[start:start + block_size])
    directory = directory[:directory_bytes]
    if len(directory) < 4:
        raise IdentityParseError("PDB stream directory is empty")
    stream_count = read_u32(directory, 0)
    if stream_count < 2:
        raise IdentityParseError("PDB has no PDB Info stream")
    size_offset = 4
    if size_offset + stream_count * 4 > len(directory):
        raise IdentityParseError("PDB stream-size table is truncated")
    sizes = list(struct.unpack_from("<" + "I" * stream_count, directory, size_offset))
    pos = size_offset + stream_count * 4
    streams: list[bytes | None] = []
    for size in sizes:
        if size == 0xFFFFFFFF:
            streams.append(None)
            continue
        page_count = (size + block_size - 1) // block_size
        if pos + page_count * 4 > len(directory):
            raise IdentityParseError("PDB stream page list is truncated")
        pages = struct.unpack_from("<" + "I" * page_count, directory, pos) if page_count else ()
        pos += page_count * 4
        content = bytearray()
        for page in pages:
            if page >= block_count:
                raise IdentityParseError("PDB stream page is outside the MSF file")
            start = page * block_size
            content.extend(data[start:start + block_size])
        streams.append(bytes(content[:size]))
    info = streams[1]
    if info is None or len(info) < 28:
        raise IdentityParseError("PDB Info stream is missing or truncated")
    age = read_u32(info, 8)
    guid = str(uuid.UUID(bytes_le=info[12:28])).upper()
    return {"guid": guid, "age": age, "info_stream_bytes": len(info), "msf_block_size": block_size,
            "msf_block_count": block_count, "free_page_map_block": free_page_map}


def inspect(dll_path: Path, pdb_path: Path) -> dict[str, object]:
    dll_data = dll_path.read_bytes()
    pdb_data = pdb_path.read_bytes()
    codeview = parse_pe_codeview(dll_data)
    pdb = parse_pdb_info(pdb_data)
    matches = codeview["guid"] == pdb["guid"] and codeview["age"] == pdb["age"]
    return {
        "status": "PASS" if matches else "FAIL",
        "dll": {"path": str(dll_path), "bytes": len(dll_data), "sha256": sha256_file(dll_path), "codeview": codeview},
        "pdb": {"path": str(pdb_path), "bytes": len(pdb_data), "sha256": sha256_file(pdb_path),
                **pdb, "matches_dll_codeview": matches, "private_evidence_only": True},
        "method": "PE IMAGE_DEBUG_DIRECTORY CodeView RSDS vs PDB MSF 7.0 Info stream 1 GUID/age",
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dll", type=Path, required=True)
    parser.add_argument("--pdb", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    try:
        report = inspect(args.dll.resolve(), args.pdb.resolve())
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
        print("PE_PDB_IDENTITY_065_" + report["status"] + " guid=" + report["pdb"]["guid"] + " age=" + str(report["pdb"]["age"]))
        return 0 if report["status"] == "PASS" else 1
    except (OSError, ValueError, struct.error, json.JSONDecodeError) as exc:
        print(f"PE_PDB_IDENTITY_065_FAIL {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
