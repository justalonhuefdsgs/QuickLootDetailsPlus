#include "qld/LegacySelection.h"
#include "qld/Core.h"
#include "qld/LegacyBinaryEvidence.h"
#include <array>
#include <cstring>
#include <cstdlib>
#include <iostream>
#include <limits>
using namespace qld;
static unsigned checks{};
void expect(bool value,const char* message){++checks;if(!value){std::cerr<<message<<'\n';std::exit(1);}}
struct Arena final:MemoryReader {
    static constexpr std::uint64_t base=0x200000;
    std::array<std::byte,8192> bytes{};
    bool read(std::uint64_t a,std::span<std::byte> out)const override {
        if(a<base || a-base>bytes.size() || out.size()>bytes.size()-(a-base))return false;
        std::memcpy(out.data(),bytes.data()+a-base,out.size());return true;
    }
    template<class T>void put(std::uint64_t a,T value){std::memcpy(bytes.data()+a-base,&value,sizeof(value));}
};
int main(){
 constexpr std::uint64_t module=0x180000000,menu=Arena::base,list=menu+0x400,item=menu+0x800,entry=menu+0xa00,ground=menu+0xc00;
 for(auto& profile:legacyLayouts){
    const auto& proof=legacyBinaryEvidence[&profile-legacyLayouts];
    std::array<std::uint64_t,9> table{};
    for(std::size_t n=0;n<table.size();++n)table[n]=module+proof.functions[n];
    expect(legacyVtableMatches(proof,module,table),"exact relocated vtable accepted");
    for(std::size_t n=0;n<table.size();++n){++table[n];expect(!legacyVtableMatches(proof,module,table),"foreign hook in any slot rejected");--table[n];}
    auto syntheticProof=proof;
    syntheticProof.messageSha256=syntheticProof.advanceSha256={0x63,0x0d,0xcd,0x29,0x66,0xc4,0x33,0x66,0x91,0x12,0x54,0x48,0xbb,0xb2,0x5b,0x4f,0xf4,0x12,0xa4,0x9c,0x73,0x2d,0xb2,0xc8,0xab,0xc1,0xb8,0x58,0x1b,0xd7,0x10,0xdd};
    for(int slot:{4,5}){
        std::array<unsigned char,32> code{};for(std::size_t n=0;n<code.size();++n)code[n]=static_cast<unsigned char>(n);
        expect(legacyCodeMatches(syntheticProof,slot,code),"exact method signature accepted");
        for(auto& byte:code){byte^=1;expect(!legacyCodeMatches(syntheticProof,slot,code),"single modified byte rejected before hook installation");byte^=1;}
    }
    expect(!legacyCodeMatches(proof,3,std::array<unsigned char,32>{}),"unverified hook slot rejected");
    Arena a;a.put(menu,module+profile.menuVtable);a.put(menu+profile.sourceOffset,42u);
    a.put(menu+profile.vectorOffset,std::array<std::uint64_t,3>{list,list+8,list+16});a.put(list,item);
    a.put(item,module+profile.inventoryVtable);a.put(item+8,entry);a.put(item+0x18,std::uint8_t{0});a.put(item+0x20,std::int64_t{3});
    a.put(item+0x78,entry);a.put(item+0x80,42u);
    auto read=[&](double idx=0,std::uint32_t n=1){return readLegacySelection(a,profile,module,menu,idx,n);};
    auto selected=read();expect(selected && selected->entryAddress==entry && selected->count==3 && selected->container==42,"actual selected EntryData and combined count retained");
    for(double invalid:{-1.,1.,0.5,std::numeric_limits<double>::quiet_NaN(),std::numeric_limits<double>::infinity()})expect(!read(invalid),"invalid selection must fail closed");
    expect(!read(0,2),"GFx/native list mismatch rejected");
    a.put(menu+profile.vectorOffset,std::array<std::uint64_t,3>{list,list+24,list+8});expect(!read(),"corrupt vector rejected");
    a.put(menu+profile.vectorOffset,std::array<std::uint64_t,3>{list,list+8,list+16});
    a.put(item+8,entry+8);expect(!read(),"observer and owning entry must agree");a.put(item+8,entry);
    a.put(item+0x80,43u);expect(!read(),"selected container must agree");a.put(item+0x80,42u);
    a.put(item+0x18,std::uint8_t{1});expect(!read(),"inventory discriminator mismatch rejected");a.put(item+0x18,std::uint8_t{0});
    for(std::int64_t invalid:{0ll,-1ll,2147483648ll}){a.put(item+0x20,invalid);expect(!read(),"invalid/overflow count rejected");}a.put(item+0x20,std::int64_t{3});
    a.put(item,module+0x1234);expect(!read(),"unknown subclass rejected");
    a.put(item,module+profile.groundVtable);a.put(item+0x18,std::uint8_t{1});
    a.put(item+0x78,std::array<std::uint64_t,3>{ground,ground+8,ground+16});a.put(item+8,std::array<std::uint64_t,2>{ground,2});
    a.put(ground,std::array<std::uint32_t,2>{101,102});
    selected=read();expect(selected && !selected->entryAddress && selected->groundHandles==std::vector<std::uint32_t>{101,102},"all actual ground handles copied");
    a.put(item+8,std::array<std::uint64_t,2>{ground,1});expect(!read(),"borrowed span and owning ground vector must agree");
    a.put(item+8,std::array<std::uint64_t,2>{ground,2});a.put(ground,std::array<std::uint32_t,2>{101,0});expect(!read(),"null ground handle rejected");
    a.put(menu+profile.sourceOffset,0u);expect(!read(),"closed/invalidated container rejected");
    expect(!readLegacySelection(a,profile,module,menu+8192,0,1),"unreadable menu rejected without dereference");
 }
 for(const auto& e:providerEvidence){
    unsigned matches{};
    for(auto runtime:{se1597,0x01064920u,0x01070680u})if(auto* p=legacyLayout(e,runtime)){++matches;expect(p->runtime==runtime,"bridge cannot borrow another runtime profile");}
    expect(matches==((e.kind==ProviderKind::ie || e.selection==SelectionContract::legacySourcePending)?0u:1u),"each legacy binary has exactly one proven runtime profile");
    expect(!legacyLayout(e,0x01070630),"1.7.99 does not become allowed by minor-version similarity");
 }
 expect(legacyLayouts[2].sourceOffset==0x4c && legacyLayouts[2].vectorOffset==0x148,"EE1170 cross-build menu uses matching PDB layout, not SE offsets");
 State state;state.open(42);auto old=state.frame().generation;state.close();state.open(42);
 Item stale;stale.formId=1;stale.container=42;stale.count=3;
 stale.card.fields={{"name",std::string("Book")},{"type",4.0},{"count",3.0},{"weight",1.0},{"value",10.0},{"description",std::string("Native selected-instance text")}};
 expect(validCard(stale.card),"lifetime fixture is independently a valid native card");
 expect(!state.selectCurrent(old,42,stale),"close/reopen rejects native result from prior generation");
 expect(!state.frame().selected,"stale result must not erase or insert a selection");
 expect(state.selectCurrent(state.frame().generation,42,stale),"current generation accepts same otherwise valid result");
 stale.card.fields["description"]=std::string("borrowed source changed");
 expect(std::get<std::string>(state.frame().selected->card.fields.at("description"))=="Native selected-instance text","published card owns selected-instance values");
 state.close();expect(!state.selectCurrent(state.frame().generation,42,stale),"closed menu rejects even matching generation");
 std::cout<<"Legacy PASS: "<<checks<<" bounded binary-layout and stale-lifetime checks. Synthetic memory only; no runtime load.\n";
}
