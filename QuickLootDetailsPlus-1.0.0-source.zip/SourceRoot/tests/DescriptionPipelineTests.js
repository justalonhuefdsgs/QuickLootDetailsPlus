const fs=require('fs'),assert=require('assert'),cp=require('child_process');
const harness=fs.readFileSync(__dirname+'/LongEnchantFitTests.js','utf8').split('const fixtureDoc=')[0];
const extra=fs.readFileSync(__filename,'utf8').split('/*'+'CASES')[1].split('END_CASES*/')[0];
new Function('require','process',harness+extra)(require,process);
/*CASES
const cp=require('child_process');
const doc=JSON.parse(fs.readFileSync(process.argv[3],'utf8'));
const jp=doc.fixtures.find(x=>x.id==='ja-192');
const ordinary={name:'Plain blade',count:1,type:2,weight:4,value:30,damage:12,categoryText:'Weapon',showCategory:true,showIcons:false,enchantMarker:0,effectsPlain:jp.phrase.repeat(jp.repeat),detailText:''};
function run(card,H,world=false){
 assert.strictEqual(ctx.qldLongCardPreferredHeight,279,'product default preference unchanged');
 const a=[];for(let f=18;f>=12;f--)a.push([f,ctx.qldMeasure.length>=4?ctx.qldMeasure(card,335,18,f):ctx.qldMeasure(card,335,f)]);
 const args=[world?'--world-fit-probe':'--fit-probe',String(ctx.qldPreferredHeight(card,335,18)),'1280',String(H),'100','40','335','20',String(a.length),...a.flatMap(x=>x.map(String))];
 const p=JSON.parse(cp.execFileSync(process.argv[4],args,{encoding:'utf8'}));
 const renderCard={...card,descriptionFontSize:p.selected_font};
 ctx.qldRender(true,renderCard,p.x,p.y,335,1,p.base_font===undefined?p.selected_font:p.base_font,.35,1,p.height);
 console.log(JSON.stringify({H,world,plan:p,titleFont:ctx.content.title.format.size,bodyFont:ctx.panel.descriptionFontSize,bodyTop:ctx.content.description._y,clipped:ctx.panel.descriptionOmitted}));
 return p;
}
function stable(card){
 const h=ctx.qldHeader(card,335,18);
 assert.strictEqual(ctx.content.title.format.size,18,'title retains requested18 while body shrinks');
 assert.strictEqual(ctx.content.stats.format.size,16.2,'numeric font unchanged');
 assert.strictEqual(ctx.content.category.format.size,16.2,'category font unchanged');
 assert.strictEqual(ctx.content.description._y,h.descriptionTop,'header geometry unchanged');
 if(h.detailHeight>0)assert.strictEqual(ctx.content.detailInfo.format.size,h.detailFont,'detail font unchanged');
 assert.strictEqual(ctx.content.description.text,card.effectsPlain,'full body/newlines unchanged');
}
if(process.argv[5]==='font'){run(ordinary,1000);stable(ordinary);}
else if(process.argv[5]==='cap'){const p=run(ordinary,244);assert.ok(p.preferred_height<=172,'default279 must be clamped to actual172 before planning');}
else{
 let p=run(ordinary,1000);stable(ordinary);assert.strictEqual(p.selected_font,13);assert.strictEqual(p.expanded,false);assert.strictEqual(p.height,279);
 p=run(ordinary,244);stable(ordinary);assert.strictEqual(p.preferred_height,172);assert.strictEqual(p.selected_font,12);assert.strictEqual(p.required_height,244);assert.strictEqual(p.height,172);assert.strictEqual(ctx.panel.descriptionOmitted,true);
 const longer={...ordinary,effectsPlain:ordinary.effectsPlain.repeat(2)};
 p=run(longer,1000);stable(longer);assert.strictEqual(p.selected_font,12);assert.ok(p.expanded&&p.height>279);assert.strictEqual(ctx.panel.descriptionOmitted,false);
 const enchant={...ordinary,enchantMarker:1};run(enchant,1000);stable(enchant);
 const en={...ordinary,effectsPlain:'A readable English description. '.repeat(8)};run(en,1000);stable(en);
 const lf={...ordinary,effectsPlain:'Fire\nFrost'};run(lf,1000);stable(lf);
 const crlf={...ordinary,effectsPlain:'Fire\r\nFrost'};run(crlf,1000);stable(crlf);
 const detail={...ordinary,detailText:'Main-hand damage difference: +0.00',equipmentCompareEn:'Main-hand damage difference: +0.00'};
 run(detail,1000);stable(detail);
 ctx.qldRender(false);assert.strictEqual(ctx.panel.requiredHeight,0);
 const short={...ordinary,effectsPlain:'Short text'};p=run(short,1000);stable(short);assert.strictEqual(p.selected_font,18);assert.strictEqual(p.panel_height,ctx.qldMeasure(short,335,18));
 ctx.qldRender(false);p=run(short,1000);stable(short);
 p=run(ordinary,1000);assert.strictEqual(p.selected_font,13);
 p=run(ordinary,244);assert.strictEqual(p.selected_font,12);
 p=run(ordinary,1000);assert.strictEqual(p.selected_font,13);stable(ordinary);
 p=run(longer,1000,true);stable(longer);assert.strictEqual(p.selected_font,12);assert.ok(p.expanded);
 p=run(ordinary,200,true);stable(ordinary);assert.strictEqual(p.selected_font,12);assert.ok(p.height<=200);
 console.log('DESCRIPTION_PIPELINE_PASS header/body isolated; real capacity default279; LF/CRLF; overflow; world; resets. Synthetic metrics, not GFx.');
}
END_CASES*/
