# ルート選択と非同期アイコンcallback

`ui/panel.as` の `QLD_CATEGORY_ICON_ROUTE` は、ビルド前に選ぶソース側のroute selectorです。既定値は `"text"` で、カテゴリ名を文字表示し、SkyUIのアイコンSWFを要求しません。別候補を作るときだけソース値を `"skyui"` に変えてSWFを再ビルドします。MCM項目やプレイ中に切り替えるUIはありません。

ActionScript 2での宣言は `var` です。これは言語上のimmutable定数ではなく、実行時に別スクリプトから書き換えられる可能性があります。そのため「コンパイル済みSWFの絶対に変更できない定数」とは説明しません。運用上はビルド前に選ぶ値として扱い、実行時の変更をユーザー向け機能としてサポートしません。`"skyui"` 以外の値はicon要求を開始しないfail-closed経路です。

未完了要求にはgenerationを付けます。text/unknown routeへのrenderで現在のpending requestを無効化し、`onLoadInit` と `onLoadError` はcallback時点のrouteとgenerationを照合します。古い成功callbackは素材を表示せず、古い失敗callbackも現在routeの状態を変更しません。ロード完了後にパネルを閉じた場合は、完了素材を非表示のまま保持し、同じrouteで再表示できます。

`tests/UiRouteGenerationTests.js` はコンパイル済みAS2をsynthetic hostで実行します。text既定の無ロード、unknown route、遅延callbackの破棄を確認します。これはSkyrim GFxや画面・ゲームパッドの実機試験ではありません。

SkyUIのSWFは取得・同梱・改変していません。QuickLoot IE由来の4つのmarker形状は別の素材・ライセンス根拠です。
