"""Restore unchanged Papyrus/ESP/SEQ files with exact 0.1.19 evidence.

Only reads the named 0.1.19 source and 0.1.19-r1 runtime archives. The
archives' complete SHA-256 values and their member manifests are checked before
copying allowlisted build assets into this isolated candidate.
"""
import argparse
import hashlib
import json
import pathlib
import zipfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
RUNTIME_SHA256 = '88a339ee54506d3d63fda9bd9c0aa66f7badb17450f5c2c801a181e504a74c7b'
SOURCE_SHA256 = 'ebc11e2bdf73a49c96dca8f12f9137b119da69524b7206f18ca095c8e453b52d'
REVISION_SOURCE_SHA256 = '9d4194f816d08caee6fd297f3687b786ba4c5ff5b4b99813fdc2636137dd0f4d'
RUNTIME_ARTIFACTS = {
    'QuickLootDetails.esp': '6816d1bc4cf13052705a8be44fe56c6b863fcb2f5dd588e99a95e83b3c85d1f5',
    'SEQ/QuickLootDetails.seq': '004be5580012efcdec118fce2444cf2dab6a4709d71924066ed03b59a19969de',
    'Scripts/QLD_MCM.pex': '291c1486e78abc51addb345ce2813bfd9f2a154396a91fb08e8a00cc65774c6e',
    'Scripts/QLD_Native.pex': '5a7cf3227a8b39bef9fd623916c9c9d933f9dd877f20df3fc26ee0c96eb89041',
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_proof(source_archive):
    payload = source_archive.read_bytes()
    if sha(payload) != SOURCE_SHA256:
        raise RuntimeError('0.1.19 source archive SHA-256 mismatch')
    with zipfile.ZipFile(source_archive) as archive:
        if archive.testzip() is not None:
            raise RuntimeError('0.1.19 source archive CRC failure')
        name = 'QuickLootDetails/docs/verification.json'
        proof = json.loads(archive.read(name))
    if proof.get('build_id') != 'QLD-0.1.19-812922367e8d0412':
        raise RuntimeError('Unexpected 0.1.19 verification build ID')
    static = proof.get('STATIC', {})
    if static.get('status') != 'STATIC_PASS' or static.get('current_checks') != 122:
        raise RuntimeError('0.1.19 Papyrus/static evidence is not a current STATIC_PASS record')
    if static.get('papyrus_current_run', {}).get('status') != 'PASS':
        raise RuntimeError('0.1.19 does not contain a passing Papyrus compile/decompile record')
    return proof


def read_revision_proof(revision_source_archive, current_sources):
    payload = revision_source_archive.read_bytes()
    if sha(payload) != REVISION_SOURCE_SHA256:
        raise RuntimeError('0.1.19-r1 source archive SHA-256 mismatch')
    with zipfile.ZipFile(revision_source_archive) as archive:
        if archive.testzip() is not None:
            raise RuntimeError('0.1.19-r1 source archive CRC failure')
        proof = json.loads(archive.read('QuickLootDetails/docs/verification.json'))
        if proof.get('package_id') != '0.1.19-r1' or proof.get('BASE_STATIC', {}).get('status') != 'INHERITED_STATIC_PASS_NOT_RERUN':
            raise RuntimeError('Unexpected 0.1.19-r1 source evidence')
        source_entries = proof['PROVENANCE']['compiler_input_manifest']['project_psc_entries']
        champollion = proof['PROVENANCE']['tools']['Champollion']
        for name in ('QLD_Native', 'QLD_MCM'):
            member = f'QuickLootDetails/scripts/{name}.psc'
            archived_hash = sha(archive.read(member))
            if archived_hash != current_sources[name] or archived_hash != source_entries[f'{name}.psc']:
                raise RuntimeError(f'0.1.19-r1 project Papyrus source differs: {name}')
        if not champollion.get('available_executable_matches_pinned_archive') or champollion.get('pinned_archive_executable_sha256') != champollion.get('currently_available_executable_sha256'):
            raise RuntimeError('0.1.19-r1 Champollion provenance does not identify the pinned binary')
    return proof


def restore(runtime_archive, source_archive, revision_source_archive):
    runtime_bytes = runtime_archive.read_bytes()
    if sha(runtime_bytes) != RUNTIME_SHA256:
        raise RuntimeError('0.1.19-r1 runtime archive SHA-256 mismatch')
    proof = read_proof(source_archive)
    current_sources = {
        name: sha((ROOT / 'scripts' / f'{name}.psc').read_bytes())
        for name in ('QLD_Native', 'QLD_MCM')
    }
    revision_proof = read_revision_proof(revision_source_archive, current_sources)
    build_record = proof.get('STATIC', {}).get('papyrus_build', {})
    source_hashes = build_record.get('source_sha256', {})
    pex_hashes = build_record.get('pex_sha256', {})
    artifacts = proof.get('STATIC', {}).get('artifacts', {})
    for script in ('QLD_Native', 'QLD_MCM'):
        source_path = ROOT / 'scripts' / f'{script}.psc'
        if not source_path.is_file() or sha(source_path.read_bytes()) != source_hashes.get(script):
            raise RuntimeError(f'Current Papyrus source differs from the audited 0.1.19 source: {script}')
        expected = RUNTIME_ARTIFACTS[f'Scripts/{script}.pex']
        if pex_hashes.get(script) != expected or artifacts.get(f'build/assets/Scripts/{script}.pex') != expected:
            raise RuntimeError(f'0.1.19 compiled PEX evidence does not match the runtime archive: {script}')
    if artifacts.get('build/assets/QuickLootDetails.esp') != RUNTIME_ARTIFACTS['QuickLootDetails.esp']:
        raise RuntimeError('0.1.19 ESP evidence does not match the runtime archive')
    if artifacts.get('build/assets/SEQ/QuickLootDetails.seq') != RUNTIME_ARTIFACTS['SEQ/QuickLootDetails.seq']:
        raise RuntimeError('0.1.19 SEQ evidence does not match the runtime archive')

    with zipfile.ZipFile(runtime_archive) as archive:
        if archive.testzip() is not None:
            raise RuntimeError('0.1.19-r1 runtime archive CRC failure')
        manifest = json.loads(archive.read('QuickLootDetails_Docs/manifest.json'))
        for member, digest in RUNTIME_ARTIFACTS.items():
            data = archive.read(member)
            if sha(data) != digest or manifest.get(member) != digest:
                raise RuntimeError('0.1.19-r1 member/manifest hash mismatch: ' + member)
            if artifacts.get('build/assets/' + member) != digest:
                raise RuntimeError('0.1.19 and 0.1.19-r1 artifact evidence differs: ' + member)
            target = (ROOT / 'build/assets' / member).resolve()
            base = (ROOT / 'build/assets').resolve()
            if not target.is_relative_to(base):
                raise RuntimeError('Unsafe build output path')
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)

    proof_dir = ROOT / 'build/baselines'
    proof_dir.mkdir(parents=True, exist_ok=True)
    (proof_dir / '0.1.19-verification.json').write_text(
        json.dumps(proof, ensure_ascii=False, indent=2), encoding='utf-8')
    (ROOT / 'build/assets/papyrus-build-record.json').write_text(
        json.dumps(build_record, ensure_ascii=False, indent=2), encoding='utf-8')
    evidence = {
        'status': 'INHERITED_EXACT_HASH',
        'source_archive': {'name': source_archive.name, 'sha256': SOURCE_SHA256,
                           'member': 'QuickLootDetails/docs/verification.json'},
        'revision_source_archive': {'name': revision_source_archive.name,
                                    'sha256': REVISION_SOURCE_SHA256,
                                    'package_id': revision_proof['package_id']},
        'runtime_archive': {'name': runtime_archive.name, 'sha256': RUNTIME_SHA256,
                            'manifest': 'QuickLootDetails_Docs/manifest.json'},
        'prior_build_id': proof['build_id'],
        'prior_static_checks': static_count(proof),
        'prior_papyrus_build_record': build_record,
        'pinned_champollion_executable_sha256': revision_proof['PROVENANCE']['tools']['Champollion']['pinned_archive_executable_sha256'],
        'restored_artifacts_sha256': RUNTIME_ARTIFACTS,
        'current_source_sha256': current_sources,
        'fresh_decompilation_this_candidate': False,
        'compiler_import_sources_copied': False,
    }
    (proof_dir / 'inherited-papyrus-evidence.json').write_text(
        json.dumps(evidence, ensure_ascii=False, indent=2), encoding='utf-8')
    print('Restored exact 0.1.19-r1 Papyrus/ESP/SEQ hashes; 0.1.19 source and verification evidence recorded. Papyrus fresh decompilation remains a separate step.')


def static_count(proof):
    return proof.get('STATIC', {}).get('current_checks')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runtime-archive', required=True, type=pathlib.Path,
                        help='unchanged 0.1.19-r1 public candidate ZIP')
    parser.add_argument('--source-archive', required=True, type=pathlib.Path,
                        help='unchanged 0.1.19 source ZIP with the current Papyrus verification')
    parser.add_argument('--revision-source-archive', required=True, type=pathlib.Path,
                        help='unchanged 0.1.19-r1 source ZIP with pinned compiler/decompiler provenance')
    args = parser.parse_args()
    restore(args.runtime_archive, args.source_archive, args.revision_source_archive)


if __name__ == '__main__':
    main()
