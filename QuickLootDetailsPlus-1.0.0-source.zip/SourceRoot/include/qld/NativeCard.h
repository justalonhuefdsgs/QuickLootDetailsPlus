#pragma once
#include <RE/Skyrim.h>
#include "qld/Card.h"
#include <optional>
#include "qld/Core.h"
#include "qld/World.h"
namespace qld {
std::vector<StackTraits> copyStackTraits(RE::InventoryEntryData*);
// Called exclusively by DetailsMenu::AdvanceMovie with that menu's own movie.
std::optional<CardSnapshot> resolveNativeCard(const Item&,RE::GFxMovieView*);
std::optional<WorldTarget> inspectWorldTarget(RE::ObjectRefHandle);
std::optional<CardSnapshot> resolveWorldCard(const WorldTarget&,RE::GFxMovieView*);
bool makeCardObject(RE::GFxMovieView*,const CardSnapshot&,const CardDisplaySettings&,RE::GFxValue&);
}
