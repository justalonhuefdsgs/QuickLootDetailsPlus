#pragma once

namespace qld {

template <class ViewPtr, class DefinitionPtr>
void resetMovieOwnersInDependencyOrder(ViewPtr& view, DefinitionPtr& definition)
{
    view.reset();
    definition.reset();
}

}  // namespace qld
