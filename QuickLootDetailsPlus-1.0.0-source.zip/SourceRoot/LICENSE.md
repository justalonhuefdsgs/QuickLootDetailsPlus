# License and source scope

The third-party components in this source tree retain their own notices and license texts. See `THIRD_PARTY.md`, `NOTICE.md`, and `licenses/`. The QuickLoot IE API header keeps its separate explicit MIT exception in `licenses/QuickLootIE-API-MIT.txt`. CommonLib and the other inherited dependencies retain their existing source and notice files.

The 057 QuickLoot IE marker-vector history is preserved separately from the 065 art inputs. The 065 build imports the self-authored 061 overlay SVGs into the marker slots and the 061 individual item SVGs into the sidecar movie. This provenance distinction does not remove any inherited license notice or create a new license grant. No license, Nexus, DP, or public-release permission is asserted for the 065 art set or candidate.

This candidate remains private and unpublished.
