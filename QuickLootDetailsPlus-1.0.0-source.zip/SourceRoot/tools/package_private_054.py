"""Create private 054 source and runtime ZIPs only after candidate identity gates pass."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
import re
import sys
import zipfile
from pathlib import Path, PurePosixPath
from source_manifest import collect_source_files, verify_manifest
from build_identity import read_identity, verify_binary
from marker_contract import verify_dll_binding

SOURCE_ARCHIVE_SHA256 = '60c7371d3f64a4e19a3e832af719aaace21c70ed39b1b6ae83d784b23f291376'
BASE_RUNTIME_SHA256 = '85a091a8a6c705708a10e3d76c83531a6dd31d8c5afbaa7a439e15be41cabb6c'
RUNTIME_DLL = 'SKSE/Plugins/QuickLootDetails.dll'
RUNTIME_SWF = 'Interface/QuickLootDetails.swf'
RUNTIME_MANIFEST = 'QuickLootDetails_Docs/manifest.json'
RUNTIME_CANDIDATE_DOC = 'QuickLootDetails_Docs/docs/candidate-054.json'
RUNTIME_VERIFICATION_DOC = 'QuickLootDetails_Docs/docs/verification.json'
LICENSES = {
    'CommonLib-COPYING.txt', 'CommonLib-EXCEPTIONS.md', 'CommonLib-legacy-MIT.txt',
    'DirectXMath-LICENSE.txt', 'DirectXTK-LICENSE.txt', 'QuickLootIE-API-MIT.txt',
    'QuickLoot-reference-profiles-MIT.txt', 'QuickLootIE-GPL-3.0.txt',
    'QuickLootIE-EXCEPTIONS.md', 'spdlog-LICENSE.txt',
}


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def safe_name(name: str) -> None:
    path = PurePosixPath(name)
    if path.is_absolute() or not path.parts or '..' in path.parts or '\\' in name or name.endswith('/'):
        raise ValueError(f'unsafe ZIP member path: {name!r}')


def write_zip(path: Path, files: dict[str, bytes], manifest_name: str, manifest: dict[str, str]) -> None:
    if path.exists():
        raise FileExistsError(f'refusing to overwrite package: {path}')
    if set(files) != set(manifest):
        raise ValueError('package manifest keys do not exactly match package payload files')
    for name in files:
        safe_name(name)
    manifest_bytes = (json.dumps(dict(sorted(manifest.items())), indent=2, ensure_ascii=True) + '\n').encode('utf-8')
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.tmp')
    with zipfile.ZipFile(temporary, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(files.items()):
            info = zipfile.ZipInfo(name, (2026, 10, 7, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, data)
        info = zipfile.ZipInfo(manifest_name, (2026, 10, 7, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, manifest_bytes)
    os.replace(temporary, path)


def read_baseline_runtime(path: Path) -> dict[str, bytes]:
    if sha(path.read_bytes()) != BASE_RUNTIME_SHA256:
        raise ValueError('034 runtime testpack SHA-256 does not match authorized baseline')
    with zipfile.ZipFile(path) as archive:
        bad = archive.testzip()
        if bad:
            raise ValueError(f'034 runtime testpack CRC failure: {bad}')
        names = archive.namelist()
        if len(names) != len(set(names)) or RUNTIME_MANIFEST not in names:
            raise ValueError('034 runtime package has duplicate entries or no manifest')
        for name in names:
            safe_name(name)
        old_manifest = json.loads(archive.read(RUNTIME_MANIFEST).decode('utf-8-sig'))
        payload_names = set(names) - {RUNTIME_MANIFEST}
        if set(old_manifest) != payload_names:
            raise ValueError('034 runtime manifest does not match its ZIP member set')
        files = {name: archive.read(name) for name in payload_names}
    for name, expected in old_manifest.items():
        if sha(files[name]) != expected:
            raise ValueError(f'034 runtime manifest hash mismatch: {name}')
    return files


def runtime_candidate_doc(identity: dict[str, object], dll: bytes, swf: bytes, build: dict, pe: dict | None) -> dict:
    return {
        'candidate_name': identity['candidate_name'], 'candidate_id': identity['candidate_id'],
        'lineage_build_id': identity['lineage_build_id'], 'plugin_version': identity['plugin_version'],
        'category_route': identity['category_route'], 'ui_probe_marker': identity['ui_probe_marker'],
        'source_manifest_sha256': identity['source_manifest_sha256'],
        'source_manifest_entries': identity['source_manifest_entries'], 'ui_swf_sha256': sha(swf),
        'runtime_dll_sha256': sha(dll), 'runtime_dll_bytes': len(dll),
        'pdb': {'private_evidence_only': True, 'sha256': pe.get('pdb', {}).get('sha256') if pe else None,
                'matches_dll_codeview': pe.get('pdb', {}).get('matches_dll_codeview') if pe else None},
        'build_exit_code': build.get('build', {}).get('exit_code'),
        'ctest': build.get('ctest'),
        'status': {'package': 'PRIVATE_REVIEW_TESTPACK', 'game_load': 'NOT_TESTED',
                   'Scaleform_execution': 'NOT_TESTED', 'CTD_resolution': 'UNVERIFIED',
                   'deployment': 'NOT_PERFORMED', 'publication': 'NOT_PERFORMED'},
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--build-root', type=Path, required=True)
    parser.add_argument('--baseline-source', type=Path, required=True)
    parser.add_argument('--baseline-runtime', type=Path, required=True)
    parser.add_argument('--dist', type=Path, required=True)
    parser.add_argument('--build-result', type=Path, required=True)
    parser.add_argument('--pe-identity', type=Path, required=True)
    parser.add_argument('--audit-report', type=Path, required=True)
    args = parser.parse_args()
    try:
        root = args.root.resolve()
        build_root = args.build_root.resolve()
        if sha(args.baseline_source.read_bytes()) != SOURCE_ARCHIVE_SHA256:
            raise ValueError('034 source archive SHA-256 does not match authorized baseline')
        manifest_sha, manifest_count = verify_manifest(root)
        build_result = json.loads(args.build_result.read_text(encoding='utf-8-sig'))
        pe_identity = json.loads(args.pe_identity.read_text(encoding='utf-8-sig'))
        if build_result.get('build', {}).get('exit_code') != 0:
            raise ValueError('native build evidence is not successful')
        ctest = build_result.get('ctest', {})
        if ctest.get('exit_code') != 0 or ctest.get('failed') != 0 or ctest.get('passed', 0) < 1:
            raise ValueError('candidate CTest evidence is missing or failed')
        if pe_identity.get('status') != 'PASS' or not pe_identity.get('pdb', {}).get('matches_dll_codeview'):
            raise ValueError('DLL/PDB CodeView identity evidence is missing or mismatched')

        swf_path = build_root / 'assets' / 'Interface' / 'QuickLootDetails.swf'
        dll_path = build_root / 'native' / 'plugin' / 'QuickLootDetails.dll'
        swf = swf_path.read_bytes()
        dll = dll_path.read_bytes()
        identity = read_identity(root, swf_path)
        verify_binary(dll, identity)
        pair = verify_dll_binding(root, swf, dll)
        if identity['source_manifest_sha256'] != manifest_sha or identity['source_manifest_entries'] != manifest_count:
            raise ValueError('candidate header identity differs from exact source-manifest bytes/count')
        if build_result.get('identity', {}).get('candidate_id') != identity['candidate_id']:
            raise ValueError('build result candidate ID differs from current source/SWF identity')
        if pe_identity.get('dll', {}).get('sha256') != sha(dll):
            raise ValueError('PE/PDB evidence belongs to another DLL')

        source_payload: dict[str, bytes] = {}
        for rel, path in collect_source_files(root).items():
            source_payload['QuickLootDetails/' + rel] = path.read_bytes()
        source_manifest_bytes = (root / 'source-manifest.json').read_bytes()
        if json.loads(source_manifest_bytes.decode('utf-8-sig')) != {name: sha(data) for name, data in sorted(source_payload.items())}:
            raise ValueError('source manifest does not match the exact source ZIP payload')
        source_manifest = json.loads(source_manifest_bytes.decode('utf-8-sig'))

        runtime_payload = read_baseline_runtime(args.baseline_runtime)
        if RUNTIME_DLL not in runtime_payload or RUNTIME_SWF not in runtime_payload:
            raise ValueError('034 runtime baseline lacks the DLL/SWF payload pair')
        runtime_payload[RUNTIME_SWF] = swf
        if sha(runtime_payload[RUNTIME_DLL]) == sha(dll):
            raise ValueError('new native DLL unexpectedly equals the old 034 baseline DLL')
        runtime_payload[RUNTIME_DLL] = dll
        candidate_doc = runtime_candidate_doc(identity, dll, swf, build_result, pe_identity)
        candidate_bytes = (json.dumps(candidate_doc, indent=2, ensure_ascii=False) + '\n').encode('utf-8')
        runtime_payload[RUNTIME_CANDIDATE_DOC] = candidate_bytes
        runtime_payload[RUNTIME_VERIFICATION_DOC] = candidate_bytes
        for license_name in LICENSES:
            if 'QuickLootDetails_Docs/licenses/' + license_name not in runtime_payload:
                raise ValueError('required runtime license file is missing: ' + license_name)

        source_manifest_map = {name: sha(data) for name, data in sorted(source_payload.items()) if name != 'QuickLootDetails/source-manifest.json'}
        if source_manifest_map != source_manifest:
            raise ValueError('source ZIP manifest does not describe package payload (self file excluded)')
        runtime_manifest_map = {name: sha(data) for name, data in sorted(runtime_payload.items())}

        source_path = args.dist / 'QuickLootDetails-054-private-source.zip'
        runtime_path = args.dist / 'QuickLootDetails-054-private-runtime-testpack.zip'
        write_zip(source_path, source_payload, 'QuickLootDetails/source-manifest.json', source_manifest_map)
        write_zip(runtime_path, runtime_payload, RUNTIME_MANIFEST, runtime_manifest_map)

        args.audit_report.parent.mkdir(parents=True, exist_ok=True)
        audit_result_path = args.audit_report
        audit_report = audit_result_path.with_name('package-audit.json')
        audit_raw = audit_result_path.with_name('package-audit-raw.txt')
        import subprocess
        result = subprocess.run(
            [sys.executable, str(root / 'tools' / 'package_audit_054.py'), '--root', str(root),
             '--build-root', str(build_root), '--baseline-source', str(args.baseline_source.resolve()),
             '--baseline-runtime', str(args.baseline_runtime.resolve()),
             '--source-zip', str(source_path), '--runtime-zip', str(runtime_path),
             '--output', str(audit_report)],
            cwd=root, capture_output=True, text=True, encoding='utf-8', errors='replace')
        audit_raw.write_text(result.stdout + result.stderr, encoding='utf-8')
        if result.returncode != 0:
            raise ValueError(f'054 ZIP audit failed with exit {result.returncode}; see {audit_result_path}')
        package_meta = {
            'candidate_name': identity['candidate_name'], 'candidate_id': identity['candidate_id'],
            'lineage_build_id': identity['lineage_build_id'], 'plugin_version': identity['plugin_version'],
            'category_route': identity['category_route'], 'ui_probe_marker': identity['ui_probe_marker'],
            'source_manifest_sha256': manifest_sha, 'source_manifest_entries': manifest_count,
            'baseline_source_sha256': SOURCE_ARCHIVE_SHA256, 'baseline_runtime_sha256': BASE_RUNTIME_SHA256,
            'source_zip': {'path': source_path.name, 'bytes': source_path.stat().st_size, 'sha256': sha(source_path.read_bytes())},
            'runtime_zip': {'path': runtime_path.name, 'bytes': runtime_path.stat().st_size, 'sha256': sha(runtime_path.read_bytes())},
            'dll': {'bytes': len(dll), 'sha256': sha(dll)}, 'swf': {'bytes': len(swf), 'sha256': sha(swf)},
            'pdb_sha256_private_evidence': pe_identity['pdb']['sha256'], 'marker_gate': pair['status'],
            'zip_audit': 'PASS', 'game_load': 'NOT_TESTED', 'ctd_resolution': 'UNVERIFIED',
            'deployment': 'NOT_PERFORMED', 'publication': 'NOT_PERFORMED',
        }
        args.audit_report.write_text(json.dumps(package_meta, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
        print('PACKAGE_054_PASS ' + json.dumps(package_meta, ensure_ascii=False, separators=(',', ':')))
        return 0
    except (OSError, ValueError, KeyError, zipfile.BadZipFile) as exc:
        print(f'PACKAGE_054_FAIL {exc}', file=sys.stderr)
        return 1

if __name__ == '__main__':
    raise SystemExit(main())
