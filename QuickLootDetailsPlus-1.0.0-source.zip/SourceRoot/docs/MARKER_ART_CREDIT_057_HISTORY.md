> Historical 057 source record only. The 065 candidate replaces these four SVG inputs with the 061 overlays; this document does not describe the 065 marker artwork.

# QuickLoot IE マーカー素材の出典・ライセンス（0.1.20-r2）

## 変更通知（2026-10-06 UTC）

QuickLoot Details の4つの状態マーカーは、QuickLoot IE 4.1.2 の固定コミット `e4dc2812c5583dd714f6d7da89e514a232845653` に含まれるベクター素材を抽出し、本プロジェクトのパネルへ組み込んだものです。抽出・組み込みは2026-10-06 UTCに完了しました。今回のr2文書整備も2026-10-06 UTCです。

- 固定上流アーカイブ SHA-256: `6b64b8e82b508e43c57b12bf08e1c25b1842d34ea4fe5296920630fae8e4e4ae`
- 元SWF: `res/swf/Interface/LootMenuIE.swf`
- 元SWF SHA-256: `e2a5fdea66b0a167ca5c9349f37a7d7ab58e904d68700344aefaf6f80ec3b0e7`
- 固定版の上流 LICENSE: https://github.com/MissCorruption/QuickLootIE/blob/e4dc2812c5583dd714f6d7da89e514a232845653/LICENSE
- FFDec による直接ベクター書き出しです。ラスタライズや描き直しはしていません。

| Shape ID | QuickLoot IE symbol | 状態 | SVG |
|---:|---|---|---|
| 20 | `iconEnchant` | enchant / unknown | `assets/marker-art/20.svg` |
| 22 | `iconEnchantKnown` | known enchantment | `assets/marker-art/22.svg` |
| 24 | `iconEnchantSpecial` | special enchantment | `assets/marker-art/24.svg` |
| 26 | `iconRead` | read book | `assets/marker-art/26.svg` |

元SWFから各SVGへの個別ハッシュとshape対応は [`assets/marker-art/provenance.json`](../assets/marker-art/provenance.json) に保存されています。r2の隔離再生成記録は [`docs/verification.json`](verification.json) を参照してください。

## クレジット

QuickLoot IE の [Nexus Mods ページ](https://www.nexusmods.com/skyrimspecialedition/mods/120075) は、Excited Puppy Energy を新しいベクターアイコンのクレジット対象として記載しています。この謝辞はプロジェクト単位で適用し、shape 20/22/24/26 の個別作者を特定するものではありません。Komegaki は新しいサムネイルの作者として記載されています。Himika はDLLおよびSWFソースファイルのクレジット対象です。既存の「QuickLootの原案・実装」への謝辞も [NOTICE.md](../NOTICE.md) に保持しています。

## ライセンス範囲と対応ソース

本配布ではQuickLoot IE由来の4ベクター素材と、それを組み込んだQuickLoot Detailsパネル出力にGNU GPL version 3 or laterと同梱のModding Exception / GPL-3.0 Linking Exceptionを適用します。対応する編集・ビルド入力は `ui/panel.as`、`ui/layout.js`、4つのSVG、`assets/marker-art/provenance.json`、`tools/build_assets.py` です。完全な対応ソースは `QuickLootDetails-0.1.20-r2-text-032-private-source.zip` として同一リリースのランタイムZIPと同じ公開場所に置く計画です。公開は未実施です。

`vendor/QuickLootAPI.h` のMIT例外は別個に維持します。Nexus上のアップロード・DP条件はリポジトリのソフトウェアライセンスとは別に確認が必要です。本記載はプロジェクトの配布範囲の説明であり、法的判断や許諾保証ではありません。


## 032候補の保持状態

032の非公開testpackと対応source ZIPの組は未公開です。text routeはSkyUI icon SWFをロードせず、最終見た目採用は未決です。SkyUI作者への問い合わせはユーザー送信済みで返答待ちです。新しいSkyUI SWF/BSAは抽出・同梱・変更していません。
