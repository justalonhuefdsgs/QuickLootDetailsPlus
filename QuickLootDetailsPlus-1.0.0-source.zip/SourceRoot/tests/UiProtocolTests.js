// Execute the supplied production AS2 source or decoded compiled AVM1/AS2; SYNTHETIC metrics, no game GFx.
const fs=require('fs'),vm=require('vm'),assert=require('assert');
let iconLoadCount=0;
const ctx={Math,isFinite,stop(){},_global:{},Color:function(target){this.target=target;this.setRGB=v=>{target.tint=v;};},MovieClipLoader:function(){this.addListener=function(listener){this.listener=listener;};this.loadClip=function(source,target){iconLoadCount++;this.source=source;this.target=target;return true;};}};
function metrics(text,font,width,wrap){let x=0,max=0,lines=text===''?0:1;for(const c of text){if(c==='\n'){max=Math.max(max,x);x=0;lines++;continue;}if(c==='\r')continue;const cp=c.codePointAt(0);if(/\p{Mark}/u.test(c)||cp===0x200d||cp===0xfe0f)continue;const w=font*(cp<128?.6:1);if(wrap&&x>0&&x+w>width){max=Math.max(max,x);x=0;lines++;}x+=w;}return {width:Math.max(max,x),height:lines*(font+2)};}
function clip(){return {_visible:true,_currentframe:1,_totalframes:100,labelFrames:{default_misc:73,default_food:31,default_book:54,default_weapon:4,default_armor:5},ops:[],createEmptyMovieClip(name){return this[name]=clip();},gotoAndStop(label){this.frameLabel=label;this._currentframe=this.labelFrames[label]||1;},createTextField(name,depth,x,y,width,height){
 const field={testName:name,_x:x,_y:y,_width:width,_visible:true,text:'',html:false,formatRanges:[],setNewTextFormat(f){this.format=f;},setTextFormat(a,b,c){if(arguments.length===1&&a&&typeof a==="object"){this.format=a;this.formatRanges=[];}else if(arguments.length===3&&Number.isInteger(a)&&Number.isInteger(b)&&a>=0&&b>=a&&b<=this.text.length&&c&&typeof c==="object"){this.formatRanges.push({start:a,end:b,color:c.color});}else throw new TypeError("AS2 setTextFormat requires format or begin,end,format");}};
 let boxHeight=height,auto='none';
 Object.defineProperty(field,'_height',{get(){return boxHeight;},set(v){boxHeight=v;}});
 Object.defineProperty(field,'autoSize',{get(){return auto;},set(v){auto=v;if(v!=='none'){
   const m=metrics(this.text,this.format.size,Math.max(1,this._width-4),this.wordWrap);
   if(!this.wordWrap)this._width=m.width+4;
   boxHeight=m.height+4;
 }}});
 Object.defineProperty(field,'htmlText',{get(){return this.originalHTML||'';},set(v){throw Error('Plain native text path cannot depend on htmlText');}});
 for(const property of ['textWidth','textHeight'])Object.defineProperty(field,property,{get(){
   const nativeExtent=property==='textWidth'&&ctx.reportNaturalWidth&&this.wordWrap;
   const m=metrics(this.text,this.format.size,Math.max(1,this._width-4),nativeExtent?false:this.wordWrap);
   return m[property==='textWidth'?'width':'height'];
 }});
 this[name]=field;
},clear(){this.ops=[];},lineStyle(...a){this.ops.push(['style',...a]);},beginFill(...a){this.ops.push(['fill',...a]);},moveTo(...a){this.ops.push(['move',...a]);},lineTo(...a){this.ops.push(['line',...a]);},endFill(){this.ops.push(['end']);}};}

ctx.createEmptyMovieClip=name=>clip();ctx.TextFormat=function(font,size,color){this.font=font;this.size=size;this.color=color;};
function loadProductionAs2(context){vm.createContext(context);if(process.argv[4])vm.runInContext(fs.readFileSync(process.argv[4],'utf8'),context);vm.runInContext(fs.readFileSync(process.argv[2],'utf8'),context);}
loadProductionAs2(ctx);assert.strictEqual(ctx.qldProbe(),'QLD_UI_0.1.20-065');ctx.InitExtensions();ctx.SetPlatform(1,false);
const normalized=JSON.parse(fs.readFileSync(process.argv[3],'utf8'));
const book={name:'[Fixture]詳細パネルの検証用冊子',count:1,type:4,weight:0,value:0,description:'基本的なスカイシャードのオプション設定に使用される。'};
const vectorCard={...book,enchantMarker:2,bookRead:true,bookReadText:'Read'};const vectorHeight=ctx.qldMeasure(vectorCard,300,18);ctx.qldRender(true,vectorCard,40,30,300,2,18,.35,1,vectorHeight);assert.strictEqual(ctx.content.description.text,'Read\n'+book.description);assert.strictEqual(ctx.qldHeader(vectorCard,300,18).markerVisible,false);assert.strictEqual(ctx.qldHeader(vectorCard,300,18).readVisible,false);ctx.qldRender(false);
const food={name:'検証食品',count:1,type:5,weight:.1,value:2,...normalized[0]};
const weapon={name:'吸収付呪の剣',count:1,type:2,weight:27,value:825,damage:34,...normalized[1]};
const armor={name:'防具',count:1,type:1,weight:10,value:12,armor:47,effects:'',effectsPlain:''};
const gold={name:'ゴールド',count:4,type:3,weight:0,value:1,effects:'',effectsPlain:''};
const ingredient={name:'検証素材',count:1,type:8,weight:.4,value:23,numItemEffects:4,itemEffect0:'',itemEffect1:'',itemEffect2:'',itemEffect3:''};
assert.strictEqual(ctx.QLD_CATEGORY_ICON_ROUTE,'text');const noArtCard={...book,type:4,categoryText:'Book',showCategory:true,showIcons:true,iconLabel:'default_book',enchantMarker:2,bookReadText:'Read'};const noArtHeight=ctx.qldMeasure(noArtCard,300,18);ctx.qldRender(true,noArtCard,0,0,300,1,18,.35,1,noArtHeight);assert.strictEqual(iconLoadCount,0);assert.strictEqual(ctx.categoryIcon._visible,false);assert.strictEqual(ctx.content.title._width,268);assert.strictEqual(ctx.content.description.text,'Read\n'+book.description);ctx.qldRender(false);ctx.QLD_CATEGORY_ICON_ROUTE='skyui';const skyUiCard={...noArtCard,categoryText:'Food',iconLabel:'default_food'};const skyUiHeight=ctx.qldMeasure(skyUiCard,300,18);ctx.qldRender(true,skyUiCard,0,0,300,1,18,.35,1,skyUiHeight);assert.strictEqual(iconLoadCount,1);assert.strictEqual(ctx.iconLoader.source,'skyui/icons_item_psychosteve.swf');ctx.onLoadInit(ctx.categoryIcon);assert.strictEqual(ctx.categoryIcon._visible,true);ctx.qldRender(false);
assert.strictEqual(ctx.qldCardDescription({...book,bookReadText:'既読'}),'既読\n'+book.description);assert.strictEqual(ctx.qldCardDescription({...book,bookReadText:'未読'}),'未読\n'+book.description);assert.strictEqual(ctx.qldCardDescription({...book,bookReadText:'Unread',description:''}),'Unread');assert.strictEqual(ctx.qldCardDescription({...book,bookReadText:undefined}),book.description);assert.strictEqual(ctx.qldCardDescription({...book,type:2,bookReadText:'Read',effectsPlain:'enchantment'}),'enchantment');
const samples=[book,food,weapon,armor,gold,ingredient,{...food,effects:'長文',effectsPlain:'長い日本語の説明。'.repeat(300)},{...book,name:'長い名前'.repeat(80)}];
let scenarios=0,visible=0;
function checkFields(width,height,card,font){
 assert.ok(ctx.panel._visible);visible++;
 const fields=[ctx.content.title,ctx.content.stats,...(card.detailText?[ctx.content.detailInfo]:[]),...(card.type===8?[0,1,2,3].map(i=>ctx.content['effect'+i]):[ctx.content.description])];
 for(const field of fields){assert.ok(field._x>=0&&field._y>=0&&field._x+field._width<=width+.01&&field._y+field._height<=height+.01,JSON.stringify({name:field.testName,x:field._x,y:field._y,w:field._width,h:field._height,width,height,font}));if(!ctx.reportNaturalWidth)assert.ok(field.textWidth<=field._width+.01);if(!ctx.panel.descriptionOmitted||field.testName==='title'||field.testName==='stats')assert.ok(field.textHeight<=field._height+.01);assert.strictEqual(field.html,false);assert.ok(!/<\/?font|face=|size=|color=|<mag>|<dur>|<area>/i.test(field.text));}
 assert.strictEqual(ctx.content.title.format.size,font);assert.strictEqual(ctx.content.title.format.align,'center');assert.ok(!ctx.panel.statsOmitted);
 const outer=ctx.border.ops;assert.strictEqual(outer.filter(x=>x[0]==='style').length,1);assert.strictEqual(outer[0][2],0);assert.strictEqual(outer.filter(x=>x[0]==='line').length,4);assert.deepStrictEqual(Array.from(outer[1]),['move',0,0]);assert.deepStrictEqual(Array.from(outer.at(-1)),['line',0,0]);
 const inner=ctx.divider.ops;assert.strictEqual(inner.length,3);assert.strictEqual(inner[0][2],0xffffff);assert.strictEqual(inner[1][1],16);assert.strictEqual(inner[2][1],width-16);assert.ok(inner[1][2]>=ctx.content.title._y+ctx.content.title._height+3);assert.ok(inner[1][2]<ctx.content.stats._y);
 if(card.type===8){
  assert.strictEqual(ctx.content.description._visible,false);
  const f=[0,1,2,3].map(i=>ctx.content['effect'+i]);assert.strictEqual(f[0]._y,f[1]._y);assert.strictEqual(f[2]._y,f[3]._y);assert.strictEqual(f[0]._x,f[2]._x);assert.strictEqual(f[1]._x,f[3]._x);assert.ok(f[1]._x-f[0]._x-f[0]._width>=15);assert.ok(f[2]._y-f[0]._y-f[0]._height>=7);
 }else for(let i=0;i<4;i++)assert.strictEqual(ctx.content['effect'+i]._visible,false);
}
const wine={...book,name:'アルトワイン',type:3,weight:.5,value:12,categoryText:'薬',showCategory:true,showIcons:true,iconLabel:'default_food',effects:'native',effectsPlain:'通常の効果説明'};
assert.strictEqual(ctx.qldCardStats(wine,335),'\u91d1\u984d 12  \u91cd\u91cf 0.5  V/W 24');
assert.ok(ctx.qldCardStats({...book,weight:0,value:50},335).endsWith('V/W ー'));
for(const card of [{...book,weight:-1,value:50},{...book,weight:NaN,value:50},{...book,weight:1,value:NaN},{...book,weight:Infinity,value:50},{...book,weight:1,value:Infinity}])assert.ok(ctx.qldCardStats(card,335).endsWith('V/W —')); 
const wineHeight=ctx.qldMeasure(wine,335,18);ctx.qldRender(true,wine,0,0,335,1,18,.35,1,wineHeight);ctx.onLoadInit(ctx.categoryIcon);
assert.ok(ctx.categoryIcon._visible);assert.strictEqual(ctx.categoryIcon.frameLabel,'default_food');assert.strictEqual(ctx.content.category.text,'薬');assert.strictEqual(ctx.content.category._x,16);assert.ok(Math.abs(ctx.categoryIcon._x+28-(ctx.content.title._x+(ctx.content.title._width-ctx.content.title.textWidth)/2))<1.01);assert.ok(Math.abs((ctx.categoryIcon._x+(ctx.content.title._x+(ctx.content.title._width+ctx.content.title.textWidth)/2))/2-167.5)<1.01);assert.ok(ctx.categoryIcon._y<ctx.divider.ops[1][2]);assert.strictEqual(ctx.content.description.text,'通常の効果説明');
for(const width of [180,300,335,800])for(const name of ['アルトワイン','アルトワイン'.repeat(20)]){const item={...wine,name};const h=ctx.qldMeasure(item,width,18);ctx.qldRender(true,item,0,0,width,1,18,.35,1,h);if(ctx.panel._visible){assert.ok(ctx.categoryIcon._visible);assert.ok(ctx.categoryIcon._x>=0);assert.ok(ctx.categoryIcon._x+24<=width);const left=ctx.content.title._x+(ctx.content.title._width-ctx.content.title.textWidth)/2;assert.ok(Math.abs(ctx.categoryIcon._x+28-left)<1.01);}ctx.qldRender(false);}
for(const font of [10,18,36])for(const width of [180,300,335,800])for(const height of [146,180,400,576])for(const card of samples){
 ctx.qldRender(true,card,700,442,width,1,font,.35,.9,height);if(ctx.panel._visible)checkFields(width,height,card,font);ctx.qldRender(false);assert.strictEqual(ctx.panel._visible,false);for(let i=0;i<4;i++){assert.strictEqual(ctx.content['effect'+i].text,'');assert.strictEqual(ctx.content['effect'+i]._visible,false);}assert.strictEqual(ctx.content.description.text,'');scenarios++;
}
// All 16 known/unknown combinations, preserving native slot identity (not just known prefixes).
for(let mask=0;mask<16;mask++)for(const width of [180,300,335,800])for(const font of [10,18,36]){
 const card={...ingredient};for(let i=0;i<4;i++)card['itemEffect'+i]=mask&(1<<i)?'既知効果'+i:'';
 const height=Math.min(576,ctx.qldMeasure(card,width,font));ctx.qldRender(true,card,0,0,width,1,font,.35,1,height);scenarios++;
 if(!ctx.panel._visible){assert.ok(ctx.panel.statsOmitted);continue;}checkFields(width,height,card,font);
 for(let i=0;i<4;i++){const field=ctx.content['effect'+i];assert.strictEqual(field.text,card['itemEffect'+i]||'不明');assert.strictEqual(field.format.color,card['itemEffect'+i]?0xffffff:0x999999);}
}
for(const n of [0,1,2,3,4]){const card={...ingredient,numItemEffects:n};const h=ctx.qldMeasure(card,300,18);ctx.qldRender(true,card,0,0,300,1,18,.35,1,h);checkFields(300,h,card,18);for(let i=0;i<4;i++)assert.strictEqual(ctx.content['effect'+i].text,i<n?'不明':'');scenarios++;}
const longGrid={...ingredient,itemEffect0:'長い日本語の既知効果'.repeat(10),itemEffect1:'二番目の長い効果'.repeat(8),itemEffect2:'三番目の効果'.repeat(9),itemEffect3:'四番目の効果'.repeat(12)};
for(const font of [10,18,36])for(const width of [180,300,335,800]){const measured=ctx.qldMeasure(longGrid,width,font);const h=Math.min(576,measured);ctx.qldRender(true,longGrid,0,0,width,1,font,.35,1,h);if(ctx.panel._visible){checkFields(width,h,longGrid,font);if(measured<=576)assert.strictEqual(ctx.panel.descriptionOmitted,false);}scenarios++;}
for(const sample of normalized){const card={...food,...sample};const h=ctx.qldMeasure(card,335,18);ctx.qldRender(true,card,0,0,335,1,18,.35,1,h);checkFields(335,h,card,18);assert.strictEqual(ctx.content.description.text,sample.effectsPlain);assert.strictEqual(ctx.panel.descriptionOmitted,false);scenarios++;}
for(const card of [gold,armor,{...book,description:''}]){const h=ctx.qldMeasure(card,300,18);assert.ok(h>=136);ctx.qldRender(true,card,0,0,300,1,18,.35,1,h);checkFields(300,h,card,18);scenarios++;}
for(const scale of [.5,1,2]){const h=ctx.qldMeasure(ingredient,335,18);ctx.qldRender(true,ingredient,0,0,335,scale,18,.15,.7,h);checkFields(335,h,ingredient,18);assert.strictEqual(ctx.panel._xscale,scale*100);assert.strictEqual(ctx.content._alpha,70);assert.strictEqual(ctx.background.ops[0][2],15);scenarios++;}
const infoCard={...book,detailText:'Category: Book\nOwned: 2',detailFontScale:.8,showValueWeight:false,showEquipmentDetails:false};
const infoHeight=ctx.qldMeasure(infoCard,335,18);ctx.qldRender(true,infoCard,0,0,335,1,18,.35,1,infoHeight);
assert.ok(ctx.panel._visible);assert.strictEqual(ctx.content.detailInfo.text,infoCard.detailText);assert.ok(ctx.content.detailInfo._y>ctx.content.stats._y);assert.ok(ctx.content.description._y>=ctx.content.detailInfo._y+ctx.content.detailInfo._height);assert.strictEqual(ctx.content.stats.text,'');checkFields(335,infoHeight,infoCard,18);scenarios++;
const weaponCompareEn="Main-hand damage difference: +5.00";
const weaponCompareJa="\u53f3\u624b\u88c5\u5099\u3068\u306e\u653b\u6483\u529b\u5dee: +5.00";
const weaponCompareText="Weapon: Iron Sword\n"+weaponCompareEn;
const positiveRange=ctx.qldEquipmentComparisonRange(weaponCompareText,weaponCompareJa,weaponCompareEn);
assert.ok(positiveRange);assert.strictEqual(positiveRange.value,5);assert.strictEqual(positiveRange.color,0x66B2FF);
const armorCompareJa="\u88c5\u5099\u4e2d\u9632\u5177\u3068\u306e\u9632\u5fa1\u529b\u5dee: -3.00";
const armorCompareEn="Armor difference from equipped: -3.00";
const armorCompareText="\u88c5\u5099: Iron Helmet\n"+armorCompareJa;
const negativeRange=ctx.qldEquipmentComparisonRange(armorCompareText,armorCompareJa,armorCompareEn);
assert.ok(negativeRange);assert.strictEqual(negativeRange.value,-3);assert.strictEqual(negativeRange.color,0xFF6B6B);
assert.strictEqual(ctx.qldEquipmentComparisonRange("+0.00","Test: +0.00","Test: +0.00"),null);
assert.strictEqual(ctx.qldEquipmentComparisonRange("-0.00","Test: -0.00","Test: -0.00"),null);
assert.strictEqual(ctx.qldEquipmentComparisonRange("Test: +NaN","Test: +NaN",""),null);
assert.strictEqual(ctx.qldEquipmentComparisonRange(weaponCompareEn+"\n"+weaponCompareEn,"",weaponCompareEn),null);
function renderEquipmentCompare(card){const h=ctx.qldMeasure(card,335,18);ctx.qldRender(true,card,0,0,335,1,18,.35,1,h);return ctx.content.detailInfo.formatRanges;}
const weaponCompareCard={...weapon,detailText:weaponCompareText,equipmentCompareJa:weaponCompareJa,equipmentCompareEn:weaponCompareEn};
let comparisonRanges=renderEquipmentCompare(weaponCompareCard);
assert.strictEqual(ctx.content.detailInfo.text,weaponCompareText);assert.strictEqual(comparisonRanges.length,1);
assert.strictEqual(comparisonRanges[0].start,weaponCompareText.indexOf('+5.00'));assert.strictEqual(comparisonRanges[0].end,comparisonRanges[0].start+'+5.00'.length);assert.strictEqual(comparisonRanges[0].color,0x66B2FF);
const armorCompareCard={...armor,detailText:armorCompareText,equipmentCompareJa:armorCompareJa,equipmentCompareEn:armorCompareEn};
comparisonRanges=renderEquipmentCompare(armorCompareCard);
assert.strictEqual(ctx.content.detailInfo.text,ctx.qldEquipmentDisplay(armorCompareText,armorCompareJa).detail);assert.strictEqual(comparisonRanges.length,1);assert.strictEqual(comparisonRanges[0].color,0xFF6B6B);
const neutralArmorLine="Armor difference from equipped: -0.00";
comparisonRanges=renderEquipmentCompare({...armor,detailText:neutralArmorLine,equipmentCompareEn:neutralArmorLine});
assert.strictEqual(comparisonRanges.length,0);assert.strictEqual(ctx.content.detailInfo.format.color,0xFFFFFF);
for(const [base,label] of [[weapon,'Main-hand damage difference:'],[armor,'Armor difference from equipped:']]) {
 for(const value of ['+0.00','-0.00']) {
  const line=label+' '+value;
  const ranges=renderEquipmentCompare({...base,languageEnglish:true,detailText:line,equipmentCompareEn:line});
  assert.strictEqual(ctx.content.detailInfo.text,label+' ー');
  assert.strictEqual(ranges.length,0);assert.strictEqual(ctx.content.detailInfo.format.color,0xFFFFFF);
 }
}
for(const [base,label,value,color] of [[weapon,'Main-hand damage difference:','+2.00',0x66B2FF],[armor,'Armor difference from equipped:','-3.00',0xFF6B6B]]) {
 const line=label+' '+value, ranges=renderEquipmentCompare({...base,languageEnglish:true,detailText:line,equipmentCompareEn:line});
 assert.strictEqual(ranges.length,1);assert.strictEqual(ctx.content.detailInfo.text.slice(ranges[0].start,ranges[0].end),value);assert.strictEqual(ranges[0].color,color);
}
assert.strictEqual(ctx.qldCardStats({...weapon,languageEnglish:true},335),'Damage 34  Value 825  Weight 27  V/W 30.56');
assert.ok(ctx.qldCardStats({...armor,languageEnglish:true},180).startsWith('AR 47  Val 12  Wt 10'));
assert.strictEqual(ctx.qldIngredientCell({...ingredient,languageEnglish:true},0).text,'Unknown');
assert.strictEqual(ctx.qldIngredientCell({...ingredient,languageEnglish:true,numItemEffects:0},0).text,'');
comparisonRanges=renderEquipmentCompare(infoCard);assert.strictEqual(comparisonRanges.length,0);
ctx.qldRender(false);assert.strictEqual(ctx.content.detailInfo.text,"");assert.strictEqual(ctx.content.detailInfo.formatRanges.length,0);
comparisonRanges=renderEquipmentCompare(weaponCompareCard);assert.strictEqual(comparisonRanges.length,1);assert.strictEqual(comparisonRanges[0].color,0x66B2FF);
console.log("Equipment comparison color PASS: 10 positive/negative/zero/invalid/ambiguous/weapon/armor/language/switch/close-reopen scenarios.");scenarios+=10;
const jpExpected="\u653b\u6483\u529b: +5.00";
const jpFull="Owned: 99\n"+weaponCompareJa+"\nReach: 0.70";
const jpDisplay=ctx.qldEquipmentDisplay(jpFull,weaponCompareJa);
assert.strictEqual(jpDisplay.detail,"Owned: 99\n"+jpExpected+"\nReach: 0.70");
const jpRange=ctx.qldEquipmentComparisonRange(jpDisplay.detail,jpDisplay.comparison,"");
assert.strictEqual(jpDisplay.detail.slice(jpRange.start,jpRange.end),"+5.00");
assert.strictEqual(jpRange.start,jpDisplay.detail.indexOf("+5.00"));
const arDisplay=ctx.qldEquipmentDisplay(armorCompareText,armorCompareJa);
assert.strictEqual(arDisplay.detail,armorCompareText.replace(armorCompareJa,"\u9632\u5fa1\u529b: -3.00"));
const armorZeroLine=armorCompareJa.substring(0,armorCompareJa.lastIndexOf(' '))+' +0.00';
const armorZeroDisplay=ctx.qldEquipmentDisplay(armorZeroLine,armorZeroLine);
assert.strictEqual(armorZeroDisplay.detail,"\u9632\u5fa1\u529b\uff1a\u30fc");
assert.strictEqual(ctx.qldEquipmentComparisonRange(armorZeroDisplay.detail,armorZeroDisplay.comparison,''),null);
const arRange=ctx.qldEquipmentComparisonRange(arDisplay.detail,arDisplay.comparison,"");
assert.strictEqual(arDisplay.detail.slice(arRange.start,arRange.end),"-3.00");
assert.strictEqual(ctx.qldEquipmentDisplay(weaponCompareJa+"\n"+weaponCompareJa,weaponCompareJa).detail,weaponCompareJa+"\n"+weaponCompareJa);
console.log("Japanese label and value-only color span PASS: 6 assertions.");scenarios+=6;

// QLD111: zero is a known rounded comparison, not an absent comparison.
for(const [kind,label,outLabel,base] of [
 ['weapon',weaponCompareJa.substring(0,weaponCompareJa.lastIndexOf(' ')),'\u653b\u6483\u529b',weapon],
 ['armor',armorCompareJa.substring(0,armorCompareJa.lastIndexOf(' ')),'\u9632\u5fa1\u529b',armor]]) {
 for(const value of ['+0.00','-0.00']) {
  const line=label+' '+value, detail='Owned: 1\n'+line+'\nReach: 0.70';
  const disp=ctx.qldEquipmentDisplay(detail,line);
  assert.strictEqual(disp.comparison,outLabel+'\uff1a\u30fc');
  assert.strictEqual(disp.detail,'Owned: 1\n'+outLabel+'\uff1a\u30fc\nReach: 0.70');
  assert.strictEqual(ctx.qldEquipmentComparisonRange(disp.detail,disp.comparison,''),null);
  const ranges=renderEquipmentCompare({...base,detailText:detail,equipmentCompareJa:line,equipmentCompareEn:''});
  assert.strictEqual(ranges.length,0);assert.strictEqual(ctx.content.detailInfo.format.color,0xFFFFFF);
 }
}
const noCompare='Owned: 1\nReach: 0.70';
renderEquipmentCompare(weaponCompareCard);
assert.strictEqual(renderEquipmentCompare({...weapon,detailText:noCompare,equipmentCompareJa:'',equipmentCompareEn:''}).length,0);
assert.strictEqual(ctx.content.detailInfo.text,noCompare);
assert.strictEqual(ctx.content.detailInfo.format.color,0xFFFFFF);
console.log('QLD111 zero/display/switch PASS: 23 assertions.');
const nativeFormatter=process.argv[5];
if(nativeFormatter){
 const child=require('child_process');
 const nativeFormat=(raw,label)=>child.execFileSync(nativeFormatter,['--equipment-comparison-format',raw,label],{encoding:'utf8'}).trim();
 const weaponLabelJa=weaponCompareJa.substring(0,weaponCompareJa.lastIndexOf(' '));
 const armorLabelJa=armorCompareJa.substring(0,armorCompareJa.lastIndexOf(' '));
 const weaponLabelEn=weaponCompareEn.substring(0,weaponCompareEn.lastIndexOf(' '));
 const armorLabelEn=armorCompareEn.substring(0,armorCompareEn.lastIndexOf(' '));
 const cases=[
  {raw:'0.004',label:'weapon-en',lang:'en',kind:'weapon',text:weaponLabelEn+' +0.00',color:null},
  {raw:'-0.004',label:'armor-ja',lang:'ja',kind:'armor',text:armorLabelJa+' -0.00',color:null},
  {raw:'0.006',label:'weapon-ja',lang:'ja',kind:'weapon',text:weaponLabelJa+' +0.01',color:0x66B2FF,value:.01},
  {raw:'-0.006',label:'armor-en',lang:'en',kind:'armor',text:armorLabelEn+' -0.01',color:0xFF6B6B,value:-.01},
  {raw:'1.234',label:'weapon-en',lang:'en',kind:'weapon',text:weaponLabelEn+' +1.23',color:0x66B2FF,value:1.23},
  {raw:'-1.234',label:'armor-ja',lang:'ja',kind:'armor',text:armorLabelJa+' -1.23',color:0xFF6B6B,value:-1.23},
  {raw:'5',label:'weapon-ja',lang:'ja',kind:'weapon',text:weaponLabelJa+' +5.00',color:0x66B2FF,value:5},
  {raw:'-3',label:'armor-en',lang:'en',kind:'armor',text:armorLabelEn+' -3.00',color:0xFF6B6B,value:-3},
  {raw:'0',label:'weapon-en',lang:'en',kind:'weapon',text:weaponLabelEn+' +0.00',color:null},
  {raw:'-0',label:'armor-ja',lang:'ja',kind:'armor',text:armorLabelJa+' -0.00',color:null}
 ];
 for(const test of cases){
  const actual=nativeFormat(test.raw,test.label);assert.strictEqual(actual,test.text);
  const ja=test.lang==='ja'?actual:'',en=test.lang==='en'?actual:'';
  const range=ctx.qldEquipmentComparisonRange(actual,ja,en);
  if(test.color===null)assert.strictEqual(range,null);else{assert.ok(range);assert.strictEqual(range.value,test.value);assert.strictEqual(range.color,test.color);}
  const base=test.kind==='weapon'?weapon:armor;
  const ranges=renderEquipmentCompare({...base,detailText:actual,equipmentCompareJa:ja,equipmentCompareEn:en});
  assert.strictEqual(ctx.content.detailInfo.text,ctx.qldEquipmentDisplay(actual,ja).detail);
  if(test.color===null){assert.strictEqual(ranges.length,0);assert.strictEqual(ctx.content.detailInfo.format.color,0xFFFFFF);}
  else{assert.strictEqual(ranges.length,1);assert.strictEqual(ranges[0].color,test.color);}
  console.log('Native comparison '+test.raw+' -> '+actual+' color='+(test.color===null?'neutral':test.color.toString(16)));
 }
 console.log('Production C++ formatter -> compiled AS2 comparison rounding/color PASS: '+cases.length+' cases.');scenarios+=cases.length;
}

const noPotion={...food,displayKind:'alchemy',showPotionDetails:false};ctx.qldRender(true,noPotion,0,0,335,1,18,.35,1,ctx.qldMeasure(noPotion,335,18));assert.strictEqual(ctx.content.description.text,'');scenarios++;
const noIngredient={...ingredient,showIngredientEffects:false};ctx.qldRender(true,noIngredient,0,0,335,1,18,.35,1,ctx.qldMeasure(noIngredient,335,18));assert.ok(ctx.panel._visible);assert.strictEqual(ctx.content.effect0._visible,false);scenarios++;
ctx.qldRender(true,book,0,0,335,1,18,.35,1,ctx.qldMeasure(book,335,18));assert.strictEqual(ctx.content.description.text,book.description);assert.strictEqual(ctx.content.stats.text,'\u91d1\u984d 0  \u91cd\u91cf 0  V/W \u30fc');
ctx.qldRender(true,food,0,0,335,1,18,.35,1,ctx.qldMeasure(food,335,18));assert.strictEqual(ctx.content.description.text,normalized[0].effectsPlain);
ctx.qldRender(true,{...food,effectsPlain:undefined},0,0,335,1,18,.35,1,240);assert.strictEqual(ctx.panel._visible,false);
ctx.qldRender(true,{},0,0,300,1,18,.35,1,200);assert.strictEqual(ctx.panel._visible,false);
assert.deepStrictEqual(Array.from(ctx.qldTextBoundaries('か\u3099👩‍👩‍👧A')),[0,2,10,11]);
// Lower-card height regression: actual field autosize is authoritative, not ink-width fitting.
const paragraphs={...food,effectsPlain:food.effectsPlain+'\n第二の効果が 7%、3 時間続く。\n\n第三の効果もそのまま残る。'};
const tall={...food,effectsPlain:'長い説明を全文表示する。'.repeat(12)};
for(const naturalExtent of [false,true]){
 ctx.reportNaturalWidth=naturalExtent;
 for(const width of [180,300,335,800])for(const font of [10,18,24,36])for(const card of [food,paragraphs,tall,{...book,description:''},ingredient,longGrid]){
   const full=ctx.qldMeasure(card,width,font);
   const allocated=Math.min(full,720);ctx.qldRender(true,card,0,0,width,1,font,.35,1,allocated);scenarios++;
   if(!ctx.panel._visible){assert.ok(ctx.panel.statsOmitted);continue;}
   checkFields(width,allocated,card,font);
   if(full<=allocated)assert.strictEqual(ctx.panel.requiredHeight,full);else assert.ok(ctx.panel.requiredHeight<=full,"adaptive shrink must not increase natural height");
   if(full<=allocated)assert.strictEqual(ctx.panel.descriptionOmitted,false);
   if(card.type===8){for(let i=0;i<4;i++)assert.strictEqual(ctx.content['effect'+i].text,ctx.qldIngredientCell(card,i).text);}
   else assert.strictEqual(ctx.content.description.text,ctx.qldCardDescription(card));
 }
 ctx.reportNaturalWidth=false;
}
// The reported viewport has room below y=440.67; grow downward without a 146px body cap.
for(const card of [food,paragraphs]){
 const full=ctx.qldMeasure(card,335,18);assert.ok(full<=279);
 ctx.qldRender(true,card,722.27,440.67,335,1,18,.75,1,full);
 assert.ok(ctx.panel._visible);assert.strictEqual(ctx.content.description.text,card.effectsPlain);
 assert.strictEqual(ctx.panel.descriptionOmitted,false);assert.strictEqual(ctx.panel._y,440.67);
 assert.strictEqual(ctx.content.description.format.size,14.4);assert.ok(ctx.panel._y+full<=720);
 scenarios++;
}
const extended={...food,effectsPlain:food.effectsPlain+'\n追加行を保持する。\nさらに全文を保持する。\n最後の行。'};
const heights=[];
for(const card of [food,extended,food,extended,food]){
 const h=ctx.qldMeasure(card,335,18);ctx.qldRender(true,card,722.27,440.67,335,1,18,.35,1,h);
 assert.ok(ctx.panel._visible);assert.strictEqual(ctx.content.description.text,card.effectsPlain);assert.strictEqual(ctx.panel.descriptionOmitted,false);heights.push(h);scenarios++;
}
assert.ok(heights[1]>heights[0]);assert.strictEqual(heights[0],heights[2]);assert.strictEqual(heights[0],heights[4]);assert.strictEqual(heights[1],heights[3]);
const beyond={...food,effectsPlain:'画面の物理高さを超える長文。\n'.repeat(100)};
const needed=ctx.qldMeasure(beyond,335,18);assert.ok(needed>720);
ctx.qldRender(true,beyond,722.27,440.67,335,1,18,.35,1,279);
assert.ok(ctx.panel._visible);assert.strictEqual(ctx.content.description.text,beyond.effectsPlain);
assert.strictEqual(ctx.panel.descriptionOmitted,true);assert.ok(ctx.content.description._y+ctx.content.description._height<=279-8+.01);
const floorNeeded=ctx.qldMinimumHeight(beyond,335,18);assert.ok(floorNeeded<needed);assert.strictEqual(ctx.panel.requiredHeight,floorNeeded);scenarios++;
ctx.qldRender(false);assert.strictEqual(ctx.content.description.text,'');

// Execute the production render入口 through asynchronous icon state transitions.
function makeIconFixture(){
 const state={requests:[],loadAllowed:true};
 const iconContext={Math,isFinite,stop(){},_global:{},Color:function(target){this.target=target;this.setRGB=v=>{target.tint=v;};},MovieClipLoader:function(){this.addListener=function(listener){this.listener=listener;};this.loadClip=function(source,target){state.requests.push({source,target});return state.loadAllowed;};}};
 iconContext.createEmptyMovieClip=name=>clip();iconContext.TextFormat=function(font,size,color){this.font=font;this.size=size;this.color=color;};
 for(const n of ['qldMarkerEnchant','qldMarkerKnown','qldMarkerSpecial','qldMarkerRead'])iconContext[n]=clip();
 loadProductionAs2(iconContext);iconContext.InitExtensions();iconContext.SetPlatform(1,false);iconContext.QLD_CATEGORY_ICON_ROUTE='owned-svg';
 return {ctx:iconContext,state};
}
function renderIconCard(iconContext,card,width=300){const height=iconContext.qldMeasure(card,width,18);iconContext.qldRender(true,card,0,0,width,1,18,.35,1,height);return height;}
function iconPass(name){console.log(`ICON_ASYNC_CASE_PASS ${name}`);}
const asyncBook={...book,categoryText:'Book',showCategory:true,showIcons:true,iconLabel:'default_book'};

{
 const {ctx:iconCtx,state}=makeIconFixture();renderIconCard(iconCtx,asyncBook);
 assert.strictEqual(state.requests.length,1);assert.strictEqual(state.requests[0].source,'QuickLootDetails_CategoryIcons.swf');assert.strictEqual(iconCtx.categoryIcon._visible,false);
 iconCtx.onLoadInit(iconCtx.categoryIcon);assert.strictEqual(iconCtx.categoryIcon._visible,true);assert.strictEqual(iconCtx.categoryIcon.frameLabel,'default_book');iconPass('normal callback before hide');
}
{
 const {ctx:iconCtx,state}=makeIconFixture();renderIconCard(iconCtx,asyncBook);renderIconCard(iconCtx,{...asyncBook,showCategory:false});
 iconCtx.onLoadInit(iconCtx.categoryIcon);assert.strictEqual(iconCtx.categoryIcon._visible,false);
 renderIconCard(iconCtx,asyncBook);assert.strictEqual(state.requests.length,1);assert.strictEqual(iconCtx.categoryIcon._visible,true);assert.strictEqual(iconCtx.categoryIcon.frameLabel,'default_book');iconPass('hidden while pending, callback while hidden, visible again');
}
{
 const {ctx:iconCtx,state}=makeIconFixture();renderIconCard(iconCtx,asyncBook);renderIconCard(iconCtx,{...asyncBook,showCategory:false});renderIconCard(iconCtx,asyncBook);
 assert.strictEqual(iconCtx.categoryIcon._visible,false);iconCtx.onLoadInit(iconCtx.categoryIcon);
 assert.strictEqual(state.requests.length,1);assert.strictEqual(iconCtx.categoryIcon._visible,true);assert.strictEqual(iconCtx.categoryIcon.frameLabel,'default_book');iconPass('hidden and visible again before callback');
}
for(const entry of [
 ['showIcons=false',{...asyncBook,showIcons:false},300],
 ['showCategory=false',{...asyncBook,showCategory:false},300],
 ['target absent',{},300],
 ['width 87',{...asyncBook},87]
]){
 const {ctx:iconCtx,state}=makeIconFixture();
 if(entry[0]==='target absent')iconCtx.qldRender(true,{},0,0,entry[2],1,18,.35,1,200);
 else renderIconCard(iconCtx,entry[1],entry[2]);
 if(state.requests.length)iconCtx.onLoadInit(iconCtx.categoryIcon);
 assert.strictEqual(iconCtx.categoryIcon._visible,false,entry[0]);
 if(entry[0]!=='width 87')assert.strictEqual(state.requests.length,0,entry[0]);
 iconPass(entry[0]);
}
{
 const {ctx:iconCtx,state}=makeIconFixture();renderIconCard(iconCtx,asyncBook,87);if(state.requests.length)iconCtx.onLoadInit(iconCtx.categoryIcon);
 assert.strictEqual(iconCtx.categoryIcon._visible,false);assert.strictEqual(iconCtx.content.title._x,16);
 const h=renderIconCard(iconCtx,asyncBook,88);assert.strictEqual(state.requests.length,1);iconCtx.onLoadInit(iconCtx.categoryIcon);
 assert.strictEqual(iconCtx.categoryIcon._visible,true);assert.strictEqual(iconCtx.content.title._x,44);assert.strictEqual(iconCtx.content.title._width,28);assert.ok(h>0);iconPass('width boundary 87/88');
}
{
 const {ctx:iconCtx,state}=makeIconFixture();renderIconCard(iconCtx,asyncBook);iconCtx.qldRender(false);assert.strictEqual(iconCtx.categoryIcon._visible,false);
 renderIconCard(iconCtx,asyncBook);iconCtx.onLoadInit(iconCtx.categoryIcon);assert.strictEqual(state.requests.length,1);assert.strictEqual(iconCtx.categoryIcon._visible,true);iconPass('close/reopen while load pending');
}
{
 const {ctx:iconCtx,state}=makeIconFixture();renderIconCard(iconCtx,asyncBook);iconCtx.onLoadInit(iconCtx.categoryIcon);iconCtx.qldRender(false);
 renderIconCard(iconCtx,asyncBook);assert.strictEqual(state.requests.length,1);assert.strictEqual(iconCtx.categoryIcon._visible,true);iconPass('close/reopen after load');
}
{
 const {ctx:iconCtx,state}=makeIconFixture();renderIconCard(iconCtx,asyncBook);iconCtx.QLD_CATEGORY_ICON_ROUTE='text';renderIconCard(iconCtx,asyncBook);
 iconCtx.QLD_CATEGORY_ICON_ROUTE='owned-svg';renderIconCard(iconCtx,asyncBook);assert.strictEqual(iconCtx.categoryIcon._visible,false);
 iconCtx.onLoadInit(iconCtx.categoryIcon);assert.strictEqual(state.requests.length,2);assert.strictEqual(iconCtx.categoryIcon._visible,false);
 iconCtx.onLoadInit(iconCtx.categoryIcon);assert.strictEqual(iconCtx.categoryIcon._visible,true);assert.strictEqual(iconCtx.categoryIcon.frameLabel,'default_book');iconPass('route off/on while old callback pending');
}
{
 const {ctx:iconCtx,state}=makeIconFixture();renderIconCard(iconCtx,asyncBook);iconCtx.QLD_CATEGORY_ICON_ROUTE='text';renderIconCard(iconCtx,asyncBook);
 iconCtx.onLoadInit(iconCtx.categoryIcon);assert.strictEqual(state.requests.length,1);assert.strictEqual(iconCtx.categoryIcon._visible,false);
 iconCtx.QLD_CATEGORY_ICON_ROUTE='owned-svg';renderIconCard(iconCtx,asyncBook);assert.strictEqual(state.requests.length,2);
 iconCtx.onLoadInit(iconCtx.categoryIcon);assert.strictEqual(iconCtx.categoryIcon._visible,true);iconPass('old callback completes while route off, then route recovers');
}
{
 const {ctx:iconCtx,state}=makeIconFixture();renderIconCard(iconCtx,asyncBook);iconCtx.QLD_CATEGORY_ICON_ROUTE='text';renderIconCard(iconCtx,asyncBook);
 iconCtx.QLD_CATEGORY_ICON_ROUTE='owned-svg';renderIconCard(iconCtx,asyncBook);iconCtx.onLoadError(iconCtx.categoryIcon);
 assert.strictEqual(state.requests.length,2);assert.strictEqual(iconCtx.categoryIcon._visible,false);
 iconCtx.onLoadInit(iconCtx.categoryIcon);assert.strictEqual(iconCtx.categoryIcon._visible,true);iconPass('stale load error does not poison current route');
}
{
 const {ctx:iconCtx,state}=makeIconFixture();renderIconCard(iconCtx,asyncBook);renderIconCard(iconCtx,{...asyncBook,iconLabel:'default_food',iconColor:0x123456});
 iconCtx.onLoadInit(iconCtx.categoryIcon);assert.strictEqual(state.requests.length,1);assert.strictEqual(iconCtx.categoryIcon.frameLabel,'default_food');assert.strictEqual(iconCtx.categoryIcon._visible,true);iconPass('selection A to B while pending');
}
{
 const {ctx:iconCtx,state}=makeIconFixture();renderIconCard(iconCtx,{...asyncBook,iconLabel:'supplemental_drink'});iconCtx.onLoadInit(iconCtx.categoryIcon);
 assert.strictEqual(iconCtx.categoryIcon.frameLabel,'default_misc');assert.strictEqual(iconCtx.categoryIcon._visible,true);iconPass('non-active supplemental label falls back to default_misc');
}
{
 const {ctx:iconCtx,state}=makeIconFixture();renderIconCard(iconCtx,asyncBook);iconCtx.onLoadInit(clip());assert.strictEqual(iconCtx.categoryIcon._visible,false);assert.strictEqual(state.requests.length,1);iconPass('invalid callback target ignored');
}
{
 const {ctx:iconCtx,state}=makeIconFixture();state.loadAllowed=false;renderIconCard(iconCtx,asyncBook);renderIconCard(iconCtx,asyncBook);
 assert.strictEqual(state.requests.length,1);assert.strictEqual(iconCtx.categoryIcon._visible,false);iconPass('loadClip failure stays hidden without retry');
}
{
 const {ctx:iconCtx,state}=makeIconFixture();renderIconCard(iconCtx,asyncBook);iconCtx.onLoadError(iconCtx.categoryIcon);renderIconCard(iconCtx,asyncBook);
 assert.strictEqual(state.requests.length,1);assert.strictEqual(iconCtx.categoryIcon._visible,false);iconPass('current load error stays hidden without retry');
}
{
 const {ctx:iconCtx,state}=makeIconFixture();iconCtx.QLD_CATEGORY_ICON_ROUTE='skyui';renderIconCard(iconCtx,{...asyncBook,iconColor:0x123456});
 assert.strictEqual(state.requests[0].source,'skyui/icons_item_psychosteve.swf');iconCtx.onLoadInit(iconCtx.categoryIcon);
 assert.strictEqual(iconCtx.categoryIcon._visible,true);assert.strictEqual(iconCtx.categoryIcon.tint,0x123456);iconPass('SkyUI route and tint preserved');
}
const as2InputKind=process.argv[2].endsWith('panel.as')?'source AS2':'decoded compiled AS2';
console.log(`${as2InputKind} protocol PASS: ${scenarios} geometry/text scenarios plus named icon async cases; synthetic mocks, not game GFx.`);

// Preview geometry derives from executed compiled AS2; this remains a mock, not GFx rendering.
if(process.env.QLD_PREVIEW){
 const previews=[];for(const card of [ingredient,food,longGrid,book]){const width=335,height=Math.min(576,ctx.qldMeasure(card,width,18));ctx.qldRender(true,card,0,0,width,1,18,.35,1,height);const fields=['title','stats','description','effect0','effect1','effect2','effect3'].map(n=>({name:n,...ctx.content[n],format:ctx.content[n].format}));previews.push({name:card.name,width,height,visible:ctx.panel._visible,fields,outer:ctx.border.ops,divider:ctx.divider.ops,kind:'MOCK FROM COMPILED AS2; SYNTHETIC METRICS; NOT GAME GFX'});}fs.writeFileSync(process.env.QLD_PREVIEW,JSON.stringify(previews,null,2));
}
console.log(`${as2InputKind} geometry/text PASS: ${scenarios} scenarios, ${visible} visible; row-major native ingredient slots/all 16 masks, unchanged styling/data; actual-field autosize/grow/shrink/full native strings/physical limits, zeros/long text/scales/switch/close. SYNTHETIC metrics; no game GFx.`);
