#include "qld/World.h"

namespace qld {
void WorldState::clear() {
    if(target_ || selected_){++generation_;++revision_;}
    target_.reset();selected_.reset();refreshDelay_=0;
}
void WorldState::observe(std::optional<WorldTarget> target,bool enabled,const WorldEnvironment& env,double interval,std::uint64_t eventEpoch) {
    if(!enabled || env.blocked() || !target || !target->handle || !target->referenceId || !target->baseId || target->count<=0){clear();eventEpoch_=eventEpoch;return;}
    if(target_!=target || eventEpoch_!=eventEpoch){
        target_=target;selected_.reset();++generation_;++revision_;refreshDelay_=0;eventEpoch_=eventEpoch;
    }else refreshDelay_=std::max(0.0,refreshDelay_-(std::isfinite(interval)?std::clamp(interval,0.0,1.0):0.0));
}
std::optional<WorldTicket> WorldState::requestRefresh() {
    if(!target_ || refreshDelay_>0)return {};
    refreshDelay_=1.0; // Recheck live native information once a second, never once per frame.
    return WorldTicket{generation_,*target_};
}
bool WorldState::publish(const WorldTicket& ticket,std::optional<CardSnapshot> card) {
    if(!target_ || ticket.generation!=generation_ || ticket.target!=*target_)return false;
    if(!card || !validCard(*card)){
        if(selected_){selected_.reset();++revision_;}
        return true;
    }
    if(selected_ && selected_->card.fields==card->fields)return true;
    ++revision_;
    Item item;item.formId=target_->baseId;item.container=target_->handle;item.dropHandle=target_->handle;
    item.count=target_->count;item.stackIdentity=revision_;item.card=std::move(*card);
    selected_=std::move(item);return true;
}
Frame WorldState::frame(const Settings& settings,std::uint64_t settingsRevision) const {
    Frame frame;frame.settings=settings;frame.settings.enabled=settings.world.enabled;
    frame.open=target_.has_value();frame.selected=selected_;frame.generation=generation_;frame.revision=revision_+settingsRevision;
    return frame;
}
}
