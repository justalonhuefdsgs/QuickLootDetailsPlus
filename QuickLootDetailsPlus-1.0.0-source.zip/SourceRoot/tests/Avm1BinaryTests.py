"""Audit the emitted AVM1 bytes, including relative branches and function bodies.
Does not execute GFx, render text, or validate native runtime relocations.
"""
import json,pathlib,struct,sys,zlib
functions={};counters={'actions':0,'branches':0,'push_values':0};strings=set()
def cstring(data,pos):
    end=data.index(0,pos);s=data[pos:end].decode('utf-8');strings.add(s);return s,end+1
def walk(data,pool=(),name='<root>'):
    pos=0;starts=set();branches=[]
    while pos<len(data):
        start=pos;starts.add(start);code=data[pos];pos+=1;counters['actions']+=1
        size=0
        if code>=128:
            assert pos+2<=len(data),(name,'short action length')
            size,=struct.unpack_from('<H',data,pos);pos+=2
        end=pos+size;assert end<=len(data),(name,'action outside block',start)
        record=data[pos:end];pos=end
        if code==0:
            assert pos==len(data),(name,'bytes after ActionEnd')
            break
        assert code not in (0x83,0x9a,0x2d),(name,'unexpected URL/fscommand action')
        if code==0x88:
            count,=struct.unpack_from('<H',record);q=2;values=[]
            for _ in range(count):s,q=cstring(record,q);values.append(s)
            assert q==len(record);pool=tuple(values)
        elif code in (0x99,0x9d):
            assert size==2
            relative,=struct.unpack('<h',record);branches.append((start,pos+relative));counters['branches']+=1
        elif code==0x96:
            q=0
            while q<len(record):
                kind=record[q];q+=1;counters['push_values']+=1
                if kind==0:_,q=cstring(record,q)
                elif kind in (2,3):pass
                elif kind in (4,5):q+=1
                elif kind in (1,7):q+=4
                elif kind==6:q+=8
                elif kind in (8,9):
                    n=1 if kind==8 else 2;assert q+n<=len(record)
                    index=int.from_bytes(record[q:q+n],'little');q+=n
                    assert index<len(pool),(name,'constant pool index',index)
                else:raise AssertionError((name,'unknown Push type',kind))
                assert q<=len(record),(name,'truncated Push')
        elif code in (0x9b,0x8e):
            fn,q=cstring(record,0);count,=struct.unpack_from('<H',record,q);q+=2;params=[]
            if code==0x8e:q+=3 # register count and flags
            for _ in range(count):
                if code==0x8e:q+=1 # argument register
                param,q=cstring(record,q);params.append(param)
            bodySize,=struct.unpack_from('<H',record,q);q+=2
            assert q==len(record),(fn,'function header size')
            assert pos+bodySize<=len(data),(fn,'function outside block')
            if not fn:fn=name+'/anonymous@'+str(start)
            assert fn not in functions,(fn,'duplicate definition')
            functions[fn]={'parameters':params,'body_bytes':bodySize}
            walk(data[pos:pos+bodySize],pool,fn);pos+=bodySize
        elif code==0x94:
            assert size==2;bodySize,=struct.unpack('<H',record)
            assert pos+bodySize<=len(data)
            walk(data[pos:pos+bodySize],pool,name+'/with');pos+=bodySize
    starts.add(len(data))
    assert pos==len(data),(name,'block boundary')
    for start,target in branches:assert target in starts,(name,'branch into operand/function body',start,target)
def main():
    root=pathlib.Path(__file__).resolve().parents[1]
    path=pathlib.Path(sys.argv[1]) if len(sys.argv)>1 else root/'build/assets/Interface/QuickLootDetails.swf'
    data=path.read_bytes()
    sys.path.insert(0,str(root/'tools'))
    from marker_contract import verify_marker_contract
    marker_contract=verify_marker_contract(root,data)
    body=zlib.decompress(data[8:]) if data[:3]==b'CWS' else data[8:]
    n=body[0]>>3;pos=(5+4*n+7)//8+4;actions=[];tags=[];shapes={};placements={}
    while pos<len(body):
        h,=struct.unpack_from('<H',body,pos);pos+=2;size=h&63
        if size==63:size,=struct.unpack_from('<I',body,pos);pos+=4
        payload=body[pos:pos+size];pos+=size
        tag=h>>6;tags.append(tag)
        if tag in (2,22,32,83):shapes[struct.unpack_from('<H',payload)[0]]=len(payload)
        if tag==26:
            flags=payload[0];depth,=struct.unpack_from('<H',payload,1);offset=3;character=None
            if flags&2:character,=struct.unpack_from('<H',payload,offset);offset+=2
            if flags&4:offset+=1
            if flags&8:offset+=4
            if flags&16:offset+=2
            if flags&32:placements[payload[offset:].split(b'\0',1)[0].decode('ascii')]=(character,depth)
        if tag==12:actions.append(payload)
    assert len(actions)==1
    expected_markers={'qldMarkerEnchant':20,'qldMarkerKnown':22,'qldMarkerSpecial':24,'qldMarkerRead':26}
    assert all(name not in placements for name in expected_markers),'Removed marker must not be placed'
    assert all(shape_id not in shapes for shape_id in expected_markers.values()),'Removed marker shapes must not be present'
    assert tags==[69,12,1,0],tags
    walk(actions[0])
    expected=['show','card','x','y','width','scale','fontSize','backgroundOpacity','textOpacity','height']
    assert functions['qldRender']['parameters']==expected
    assert functions['qldProbe']['parameters']==[] and marker_contract['compiled_swf_qldProbe_return']=='QLD_UI_0.1.20-065'
    assert functions['InitExtensions']['parameters']==[]
    assert functions['SetPlatform']['parameters']==['platform','ps3Switch']
    assert functions['qldMeasure']['parameters']==['card','width','fontSize','descriptionFontSize']
    plugin=(root/'src/Plugin.cpp').read_text(encoding='utf-8')
    block=plugin.split('std::array<RE::GFxValue,10> args{',1)[1].split('};',1)[0]
    compact=''.join(block.split())
    expectedBlock='RE::GFxValue(true),card,'+','.join('RE::GFxValue('+e+')' for e in ['panel.x','panel.y','panel.width/renderScale','renderScale','frame.settings.fontSize','frame.settings.backgroundOpacity','frame.settings.textOpacity','panel.height/renderScale'])
    assert 'const auto renderScale=useWorld?qld::worldRenderScale(frame.settings):qld::quickLootRenderScale(frame.settings);' in plugin
    assert 'measureSelectedFont_=fit.fontSize' in plugin,'Native render font must come from the measured fit plan'
    assert 'card.SetMember("descriptionFontSize",RE::GFxValue(measureSelectedFont_))' in plugin
    assert compact==expectedBlock,'Native argument order/types disagree with compiled protocol'
    report={'status':'PASS','runtime':'NOT_TESTED','counts':counters,'functions':functions,'protocol_arguments':expected,
        'marker_contract':marker_contract,
        'forbidden_marker_shape_ids':expected_markers,'marker_shape_payload_bytes':shapes,'marker_instances':placements,
        'limits':'AVM1 structural validation, removed-marker absence, and C++/SWF protocol agreement; no native GFx execution or screen evidence.'}
    if len(sys.argv)>2:
        pathlib.Path(sys.argv[2]).write_text(json.dumps(report,indent=2),encoding='utf-8')
    print('AVM1 BINARY PASS:',counters,'; compiled qldProbe return equals native/AS source; 10 arguments and four removed marker instances absent; runtime not tested.')
if __name__=='__main__':main()
