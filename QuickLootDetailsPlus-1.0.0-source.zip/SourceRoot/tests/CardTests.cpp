#include "qld/Card.h"
#include "qld/IconLabels.h"
#include "qld/Core.h"
#include <cstdlib>
#include <iostream>
#include <limits>
#include <vector>
#define CHECK(x) do {if(!(x)){std::cerr<<__LINE__<<": "<<#x<<'\n';std::exit(1);}}while(false)
int main(){
    using namespace qld;
    CHECK(itemIconLabel(ItemIconCategory::misc)=="default_misc");
    CHECK(itemIconLabel(ItemIconCategory::weapon,ItemIconVariant::sword)=="weapon_sword");
    CHECK(itemIconLabel(ItemIconCategory::weapon,ItemIconVariant::greatsword)=="weapon_greatsword");
    CHECK(itemIconLabel(ItemIconCategory::weapon,ItemIconVariant::dagger)=="weapon_dagger");
    CHECK(itemIconLabel(ItemIconCategory::weapon,ItemIconVariant::warAxe)=="weapon_waraxe");
    CHECK(itemIconLabel(ItemIconCategory::weapon,ItemIconVariant::battleAxe)=="weapon_battleaxe");
    CHECK(itemIconLabel(ItemIconCategory::weapon,ItemIconVariant::mace)=="weapon_mace");
    CHECK(itemIconLabel(ItemIconCategory::weapon,ItemIconVariant::bow)=="weapon_bow");
    CHECK(itemIconLabel(ItemIconCategory::weapon,ItemIconVariant::staff)=="weapon_staff");
    CHECK(itemIconLabel(ItemIconCategory::weapon,ItemIconVariant::crossbow)=="weapon_crossbow");
    CHECK(itemIconLabel(ItemIconCategory::weapon)=="default_weapon");
    CHECK(itemIconLabel(ItemIconCategory::armor)=="default_armor");
    CHECK(itemIconLabel(ItemIconCategory::alchemy)=="default_potion");
    CHECK(itemIconLabel(ItemIconCategory::alchemy,ItemIconVariant::poison)=="potion_poison");
    CHECK(itemIconLabel(ItemIconCategory::alchemy,ItemIconVariant::food)=="default_food");
    CHECK(itemIconLabel(ItemIconCategory::ingredient)=="default_ingredient");
    CHECK(itemIconLabel(ItemIconCategory::book)=="default_book");
    CHECK(itemIconLabel(ItemIconCategory::book,ItemIconVariant::spellTome)=="book_tome");
    CHECK(itemIconLabel(ItemIconCategory::book,ItemIconVariant::note)=="book_note");
    CHECK(itemIconLabel(ItemIconCategory::ammo)=="weapon_arrow");
    CHECK(itemIconLabel(ItemIconCategory::ammo,ItemIconVariant::bolt)=="weapon_bolt");
    CHECK(itemIconLabel(ItemIconCategory::soulGem)=="misc_soulgem");
    CHECK(itemIconLabel(ItemIconCategory::key)=="default_key");
    CHECK(itemIconLabel(ItemIconCategory::scroll)=="default_scroll");
    CHECK(isKnownItemIconLabel("default_misc"));
    CHECK(isKnownItemIconLabel("weapon_sword"));
    CHECK(!isKnownItemIconLabel("invented_frame_label"));
    CHECK(isKnownItemIconLabel("lightarmor_head"));CHECK(isKnownItemIconLabel("soulgem_grandpartial"));
    CHECK(itemIconSpec(ItemIconCategory::weapon,ItemIconVariant::warhammer).tint==0xA4A5BF);
    CHECK(itemIconSpec(ItemIconCategory::armor,ItemIconVariant::lightFeet).tint==0x756000);
    CHECK(itemIconSpec(ItemIconCategory::armor,ItemIconVariant::heavyShield).tint==0x6B7585);
    CHECK(itemIconSpec(ItemIconCategory::alchemy,ItemIconVariant::health).tint==0xDB2E73);
    CHECK(itemIconSpec(ItemIconCategory::scroll,ItemIconVariant::shockResist).tint==0xFFFF00);
    CHECK(itemIconSpec(ItemIconCategory::soulGem,ItemIconVariant::soulFull,SoulGemQuality::grand).tint==0x7569FF);
    CHECK(itemIconSpec(ItemIconCategory::misc,ItemIconVariant::gold).label=="misc_gold");
    CHECK(itemIconSpec(ItemIconCategory::misc,ItemIconVariant::gold).tint==0xCCCC33);
    CHECK(itemIconSpec(ItemIconCategory::misc,ItemIconVariant::gold).gold001);
    CHECK(isGold001Form(0x00000F,0x00000F));CHECK(!isGold001Form(0x00000F,0));CHECK(!isGold001Form(0x000010,0x00000F));
    CHECK(enchantmentMarker(false,false,false)==EnchantmentMarker::none);
    CHECK(enchantmentMarker(true,false,false)==EnchantmentMarker::enchanted);
    CHECK(enchantmentMarker(true,true,false)==EnchantmentMarker::known);
    CHECK(enchantmentMarker(true,true,true)==EnchantmentMarker::special);
    using AW=ArmorWeightClass;using AC=ArmorIconClass;using AP=ArmorPart;
    CHECK(armorIconClass(AW::light,true,true,AP::body)==AC::light);
    CHECK(armorIconClass(AW::heavy,true,true,AP::body)==AC::heavy);
    CHECK(armorIconClass(AW::none,true,true,AP::body)==AC::clothing);
    CHECK(armorIconClass(AW::none,false,true,AP::body)==AC::jewelry);
    CHECK(armorIconClass(AW::none,false,false,AP::body)==AC::clothing);
    CHECK(armorIconClass(AW::none,false,false,AP::amulet)==AC::jewelry);
    CHECK(armorIconClass(AW::none,false,false,AP::ears)==AC::jewelry);
    CHECK(armorIconClass(AW::none,false,false,AP::other)==AC::other);
    CHECK(armorIconClass(AW::none,true,false,AP::circlet,true)==AC::jewelry);
    CHECK(armorIconSpec(AC::light,AP::body).label=="lightarmor_body");
    CHECK(armorIconSpec(AC::heavy,AP::body).label=="armor_body");
    CHECK(armorIconSpec(AC::clothing,AP::body).label=="clothing_body");
    CHECK(armorIconSpec(AC::jewelry,AP::ring).label=="armor_ring");
    CHECK(armorIconSpec(AC::jewelry,AP::other).label=="default_armor");
    CHECK(armorIconSpec(AC::other,AP::body).label=="default_armor");
    CHECK(armorIconSpec(AC::light,AP::amulet).tint==0x756000);
    CHECK(armorIconSpec(AC::heavy,AP::other).tint==0x6B7585);
    // Contract fixtures only. These sentences are NOT embedded in the plugin/UI.
    CardSnapshot book{{{"name",std::string("[Fixture]詳細パネルの検証用冊子")},{"type",4.0},{"weight",0.0},{"value",0.0},
        {"description",std::string("基本的なスカイシャードのオプション設定に使用される。")}}};
    CHECK(validCard(book));auto copy=book;book.fields["description"]=std::string("different runtime text");
    CHECK(std::get<std::string>(copy.fields["description"])=="基本的なスカイシャードのオプション設定に使用される。");
    auto enriched=copy;enriched.fields["categoryPathJa"]=std::string("防具 > 軽装 > 頭・髪");enriched.fields["soulCapacity"]=5.0;enriched.fields["soulCurrent"]=0.0;
    enriched.fields["potionBaseEffectsJa"]=std::string("効果の基礎値");CHECK(validCard(enriched));
    enriched.fields.erase("categoryPathJa");enriched.fields.erase("soulCapacity");enriched.fields.erase("soulCurrent");enriched.fields.erase("potionBaseEffectsJa");CHECK(validCard(enriched));
    auto missing=copy;missing.fields.erase("description");CHECK(!validCard(missing));
    missing=copy;missing.fields["description"]=std::string{};CHECK(validCard(missing));
    missing=copy;missing.fields["value"]=std::numeric_limits<double>::quiet_NaN();CHECK(!validCard(missing));
    missing=copy;missing.fields["weight"]=-1.0;CHECK(!validCard(missing));
    missing=copy;missing.fields["count"]=0.0;CHECK(!validCard(missing));
    missing=copy;missing.fields["count"]=1.5;CHECK(!validCard(missing));
    CardSnapshot food=copy;food.fields["type"]=5.0;food.fields["isFoodOrDrink"]=true;food.fields["potionBaseEffectsEn"]=std::string("not displayed");food.fields["effects"]=std::string("\u691c\u8a3c\u9805\u76ee\u306e\u5272\u5408\u304c2%\u30012\u6642\u9593\u65e9\u304f\u306a\u308b\u3002<br>\u98e2\u3048\u3092\u56de\u5fa9\u3059\u308b\u3002");
    CHECK(validCard(food));CHECK(std::get<std::string>(food.fields["effects"]).find("2\u6642\u9593")!=std::string::npos);
    auto foodRows=buildCardInfoRows(food,CardDisplaySettings{},true);CHECK(foodRows.empty());
    CardSnapshot drink=copy;drink.fields["type"]=5.0;drink.fields["isFoodOrDrink"]=true;drink.fields["potionBaseEffectsJa"]=std::string("非表示の飲料基礎値");drink.fields["effects"]=std::string("飲料の自然言語効果説明");
    CHECK(validCard(drink));CHECK(buildCardInfoRows(drink,CardDisplaySettings{},false).empty());
    CHECK(std::get<std::string>(drink.fields["effects"])=="飲料の自然言語効果説明");
    auto longText=std::string(65000,'a');food.fields["effects"]=longText;CHECK(validCard(food));
    food.fields["effects"]=std::string(65537,'a');CHECK(!validCard(food));food.fields.erase("effects");CHECK(!validCard(food));
    CardSnapshot weapon=copy;weapon.fields["type"]=2.0;weapon.fields["damage"]=34.0;weapon.fields["effects"]=std::string("自作の検証項目は15個です。");
    CHECK(validCard(weapon));auto other=weapon;other.fields["damage"]=80.0;other.fields["effects"]=std::string("別の付呪。");
    CHECK(std::get<double>(weapon.fields["damage"])==34.0 && std::get<double>(other.fields["damage"])==80.0);
    weapon.fields["effects"]=std::string{};CHECK(validCard(weapon));weapon.fields.erase("damage");CHECK(!validCard(weapon));
    CardSnapshot armor=copy;armor.fields["type"]=1.0;armor.fields["armor"]=0.0;armor.fields["effects"]=std::string{};CHECK(validCard(armor));
    CardSnapshot ingredient=copy;ingredient.fields["type"]=8.0;ingredient.fields["numItemEffects"]=4.0;
    for(const char* key:{"itemEffect0","itemEffect1","itemEffect2","itemEffect3"})ingredient.fields[key]=std::string{};
    CHECK(validCard(ingredient));ingredient.fields["numItemEffects"]=5.0;CHECK(!validCard(ingredient));
    std::vector<StackTraits> same{{1,1,1},{1,1,1}},different{{1,1,1},{1.5,1,1}},enchants{{1,1,1},{1,2,1}};
    CHECK(consistentStack(same,2,{1,1,1}));CHECK(!consistentStack(different,2,{1,1,1}));CHECK(!consistentStack(enchants,2,{1,1,1}));
    CHECK(!consistentStack(std::vector<StackTraits>{{1.5,1,1}},2,{1,1,1}));
    CHECK(consistentStack(std::vector<StackTraits>{{1.5,2,1}},1,{1,1,1}));CHECK(!consistentStack(same,1,{1,1,1}));
    State state;state.open(7);Item item;item.formId=1;item.container=7;item.card=copy;state.select(7,item);
    item.card.fields["description"]=std::string("mutated borrowed source");CHECK(std::get<std::string>(state.frame().selected->card.fields["description"])==std::get<std::string>(copy.fields["description"]));
    item.card=other;state.select(7,item);CHECK(std::get<double>(state.frame().selected->card.fields["damage"])==80.0);
    state.select(7,{});CHECK(!state.frame().visible());state.select(7,item);state.invalidate(7);CHECK(!state.frame().visible());
    state.select(7,item);state.close();CHECK(!state.frame().visible());
    // UI workers may change between selection and generation: State uses selection tokens, not threads.
    state.open(7);item.stackIdentity=101;item.card={};state.select(7,item);
    const auto pending=state.frame();CHECK(!validCard(pending.selected->card));
    state.configure({});CHECK(state.publishCard(pending.generation,101,copy));
    CHECK(validCard(state.frame().selected->card));
    item.stackIdentity=102;state.select(7,item);CHECK(!state.publishCard(pending.generation,101,other));
    CHECK(!validCard(state.frame().selected->card));
    state.close();CHECK(!state.publishCard(pending.generation,102,copy));
    state.open(7);state.select(7,item);CHECK(!state.publishCard(pending.generation,102,copy));
    const auto reopened=state.frame();CHECK(!state.publishCard(reopened.generation,102,{}));
    CHECK(state.publishCard(reopened.generation,102,copy));
    state.invalidate(7);CHECK(!state.publishCard(reopened.generation,102,copy));
    std::cout<<"Card contract PASS: BOOK short description, zero values, native text unchanged, effects/weapon/armor, long text, copied individuals, missing vs empty, invalid values, mixed stacks and clearing\n";
}
