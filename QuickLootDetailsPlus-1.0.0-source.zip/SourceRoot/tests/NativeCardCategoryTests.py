from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
native = (ROOT / "src/NativeCard.cpp").read_text(encoding="utf-8")
core = (ROOT / "src/Core.cpp").read_text(encoding="utf-8")

required_native = (
    "category.ja=displayAlchemyCategory(alchemy->IsFood(),alchemy->IsPoison(),false).data();",
    "category.en=displayAlchemyCategory(alchemy->IsFood(),alchemy->IsPoison(),true).data();",
    'card.fields.insert_or_assign("displayKind",std::string(category.kind));',
    "const bool foodOrDrink=alchemy->IsFood();",
    'card.fields.insert_or_assign("isFoodOrDrink",foodOrDrink);',
)
for fragment in required_native:
    if fragment not in native:
        raise SystemExit(f"Native card display classification is missing: {fragment}")

if 'case RE::FormType::AlchemyItem:return {"薬","Potion / Poison","alchemy"};' not in native:
    raise SystemExit("Alchemy internal display kind baseline changed")
if "if(!foodOrDrink){" not in native or "potionBaseEffectsEn" in core or "potionBaseEffectsJa" in core:
    raise SystemExit("Alchemy base-effect rows must be suppressed")

print("Native category contract PASS: Food/Poison/Potion labels use existing flags; alchemy kind and base-effect rows are suppressed.")
