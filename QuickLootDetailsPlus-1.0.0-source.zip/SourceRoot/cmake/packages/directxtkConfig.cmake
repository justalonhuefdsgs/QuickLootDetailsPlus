if(NOT TARGET Microsoft::DirectXTK)
  message(FATAL_ERROR "The pinned local DirectXTK target must be built first")
endif()
set(directxtk_FOUND TRUE)
