"""Audit actual 054 ZIP bytes, manifests, CRCs, exact pair binding, and re-extraction."""
from __future__ import annotations
import argparse
import hashlib
import io
import json
import shutil
import sys
import tempfile
import zipfile
from pathlib import Path, PurePosixPath
from source_manifest import collect_source_files, verify_manifest
from build_identity import read_identity
from marker_contract import verify_dll_binding

BASE_RUNTIME_SHA256 = '85a091a8a6c705708a10e3d76c83531a6dd31d8c5afbaa7a439e15be41cabb6c'
BASE_SOURCE_SHA256 = '60c7371d3f64a4e19a3e832af719aaace21c70ed39b1b6ae83d784b23f291376'
RUNTIME_MANIFEST = 'QuickLootDetails_Docs/manifest.json'
SOURCE_MANIFEST = 'QuickLootDetails/source-manifest.json'
RUNTIME_DLL = 'SKSE/Plugins/QuickLootDetails.dll'
RUNTIME_SWF = 'Interface/QuickLootDetails.swf'
CANDIDATE_DOC = 'QuickLootDetails_Docs/docs/candidate-054.json'
VERIFICATION_DOC = 'QuickLootDetails_Docs/docs/verification.json'
LICENSES = {
    'CommonLib-COPYING.txt', 'CommonLib-EXCEPTIONS.md', 'CommonLib-legacy-MIT.txt',
    'DirectXMath-LICENSE.txt', 'DirectXTK-LICENSE.txt', 'QuickLootIE-API-MIT.txt',
    'QuickLoot-reference-profiles-MIT.txt', 'QuickLootIE-GPL-3.0.txt',
    'QuickLootIE-EXCEPTIONS.md', 'spdlog-LICENSE.txt',
}
FORBIDDEN_SUFFIXES = {'.dll', '.exe', '.lib', '.pdb', '.swf', '.pex', '.esp', '.esl', '.esm', '.bsa', '.ba2'}


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def safe_name(name: str) -> None:
    path = PurePosixPath(name)
    if path.is_absolute() or not path.parts or '..' in path.parts or '\\' in name or name.endswith('/'):
        raise AssertionError(f'unsafe archive member path: {name!r}')


def read_zip(path: Path) -> tuple[list[str], dict[str, bytes]]:
    with zipfile.ZipFile(path) as archive:
        bad = archive.testzip()
        assert bad is None, f'ZIP CRC failure: {bad}'
        names = archive.namelist()
        assert len(names) == len(set(names)), 'duplicate archive names'
        for name in names:
            safe_name(name)
        return names, {name: archive.read(name) for name in names}


def manifest_payload(manifest_bytes: bytes, payload: dict[str, bytes], manifest_name: str) -> dict[str, str]:
    manifest = json.loads(manifest_bytes.decode('utf-8-sig'))
    assert isinstance(manifest, dict), f'{manifest_name} is not a JSON object'
    assert set(manifest) == set(payload), f'{manifest_name} member set mismatch'
    for name, digest in manifest.items():
        assert sha(payload[name]) == digest, f'{manifest_name} hash mismatch: {name}'
    return manifest


def reextract_check(payloads: dict[str, dict[str, bytes]], build_root: Path) -> None:
    temp = tempfile.TemporaryDirectory(prefix='qld054-zip-audit-', dir=build_root)
    try:
        base = Path(temp.name).resolve()
        for label, files in payloads.items():
            area = (base / label).resolve()
            area.mkdir()
            for name, data in files.items():
                safe_name(name)
                target = (area / Path(*PurePosixPath(name).parts)).resolve()
                if not target.is_relative_to(area):
                    raise AssertionError(f're-extraction path escaped: {name}')
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(data)
            for name, data in files.items():
                target = area / Path(*PurePosixPath(name).parts)
                assert target.read_bytes() == data, f're-extraction byte mismatch: {label}/{name}'
    finally:
        temp.cleanup()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--build-root', type=Path, required=True)
    parser.add_argument('--baseline-source', type=Path, required=True)
    parser.add_argument('--baseline-runtime', type=Path, required=True)
    parser.add_argument('--source-zip', type=Path, required=True)
    parser.add_argument('--runtime-zip', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    try:
        root = args.root.resolve()
        build_root = args.build_root.resolve()
        assert sha(args.baseline_source.read_bytes()) == BASE_SOURCE_SHA256, 'baseline source archive hash mismatch'
        source_manifest_sha, source_count = verify_manifest(root)
        swf_path = build_root / 'assets' / 'Interface' / 'QuickLootDetails.swf'
        dll_path = build_root / 'native' / 'plugin' / 'QuickLootDetails.dll'
        swf, dll = swf_path.read_bytes(), dll_path.read_bytes()
        identity = read_identity(root, swf_path)

        source_names, source_all = read_zip(args.source_zip)
        assert SOURCE_MANIFEST in source_all, 'source ZIP is missing its source-manifest'
        source_payload = {name: data for name, data in source_all.items() if name != SOURCE_MANIFEST}
        source_manifest = manifest_payload(source_all[SOURCE_MANIFEST], source_payload, SOURCE_MANIFEST)
        current_payload = {'QuickLootDetails/' + rel: path.read_bytes() for rel, path in collect_source_files(root).items()}
        assert source_payload == current_payload, 'source ZIP bytes differ from current allowlisted source files'
        assert source_manifest == json.loads((root / 'source-manifest.json').read_text(encoding='utf-8-sig'))
        assert sha((root / 'source-manifest.json').read_bytes()) == source_manifest_sha
        assert len(source_manifest) == source_count
        for name, data in source_payload.items():
            assert PurePosixPath(name).suffix.lower() not in FORBIDDEN_SUFFIXES, f'compiled payload in source ZIP: {name}'

        baseline_names, baseline_all = read_zip(args.baseline_runtime)
        assert sha(args.baseline_runtime.read_bytes()) == BASE_RUNTIME_SHA256, 'baseline runtime hash mismatch'
        assert RUNTIME_MANIFEST in baseline_all
        baseline_payload = {name: data for name, data in baseline_all.items() if name != RUNTIME_MANIFEST}
        baseline_manifest = manifest_payload(baseline_all[RUNTIME_MANIFEST], baseline_payload, RUNTIME_MANIFEST)
        runtime_names, runtime_all = read_zip(args.runtime_zip)
        assert RUNTIME_MANIFEST in runtime_all
        runtime_payload = {name: data for name, data in runtime_all.items() if name != RUNTIME_MANIFEST}
        runtime_manifest = manifest_payload(runtime_all[RUNTIME_MANIFEST], runtime_payload, RUNTIME_MANIFEST)
        expected_runtime_names = set(baseline_payload) | {CANDIDATE_DOC}
        assert set(runtime_payload) == expected_runtime_names, 'runtime package allowlist differs from 034 baseline plus 054 identity record'
        assert runtime_payload[RUNTIME_DLL] == dll, 'runtime ZIP DLL differs from exact 054 build output'
        assert runtime_payload[RUNTIME_SWF] == swf, 'runtime ZIP SWF differs from exact tested compiled SWF'
        assert runtime_payload[VERIFICATION_DOC] == runtime_payload[CANDIDATE_DOC], 'runtime verification candidate document mismatch'
        for name in baseline_payload:
            if name not in {RUNTIME_DLL, RUNTIME_SWF, VERIFICATION_DOC}:
                assert runtime_payload[name] == baseline_payload[name], f'unrequested runtime payload changed: {name}'
        assert {name for name in runtime_payload if name.lower().endswith('.dll')} == {RUNTIME_DLL}
        assert not any(name.lower().endswith('.pdb') for name in runtime_payload), 'private PDB must not ship in testpack'
        for license_name in LICENSES:
            assert f'QuickLootDetails_Docs/licenses/{license_name}' in runtime_payload, f'missing runtime license: {license_name}'
        pair = verify_dll_binding(root, runtime_payload[RUNTIME_SWF], runtime_payload[RUNTIME_DLL])
        package_identity = json.loads(runtime_payload[CANDIDATE_DOC].decode('utf-8-sig'))
        for field in ('candidate_name', 'candidate_id', 'lineage_build_id', 'plugin_version', 'category_route',
                      'ui_probe_marker', 'source_manifest_sha256', 'source_manifest_entries'):
            assert package_identity[field] == identity[field], f'runtime candidate document {field} mismatch'
        assert package_identity['runtime_dll_sha256'] == sha(dll)
        assert package_identity['ui_swf_sha256'] == sha(swf)

        dependencies = json.loads((root / 'dependencies.json').read_text(encoding='utf-8-sig'))
        dep_specs = {spec['file']: spec for spec in dependencies.get('archives', [])}
        for filename, spec in dep_specs.items():
            name = 'QuickLootDetails/deps/' + filename
            assert name in source_payload, f'source ZIP missing pinned dependency archive: {filename}'
            data = source_payload[name]
            assert sha(data) == spec['sha256'], f'pinned dependency archive mismatch: {filename}'
            with zipfile.ZipFile(io.BytesIO(data)) as nested:
                assert nested.testzip() is None, f'nested dependency ZIP CRC failure: {filename}'
                assert len(nested.namelist()) == len(set(nested.namelist())), f'duplicate entry in dependency ZIP: {filename}'

        reextract_check({'source': source_payload, 'runtime': runtime_payload}, build_root)
        result = {
            'status': 'PASS', 'candidate_name': identity['candidate_name'], 'candidate_id': identity['candidate_id'],
            'lineage_build_id': identity['lineage_build_id'], 'plugin_version': identity['plugin_version'],
            'category_route': identity['category_route'], 'ui_probe_marker': identity['ui_probe_marker'],
            'source_manifest_sha256': source_manifest_sha, 'source_manifest_entries': source_count,
            'marker_contract': pair['marker_contract'],
            'source_zip': {'name': args.source_zip.name, 'bytes': args.source_zip.stat().st_size,
                           'sha256': sha(args.source_zip.read_bytes()), 'entries_including_manifest': len(source_names)},
            'runtime_zip': {'name': args.runtime_zip.name, 'bytes': args.runtime_zip.stat().st_size,
                            'sha256': sha(args.runtime_zip.read_bytes()), 'entries_including_manifest': len(runtime_names)},
            'source_manifest_file_count': len(source_manifest), 'runtime_manifest_file_count': len(runtime_manifest),
            'nested_dependency_archives': len(dep_specs), 'crc': 'PASS', 'file_hashes': 'PASS',
            'zip_member_allowlists': 'PASS', 'reextraction_byte_check': 'PASS', 'dll_swf_pairing': 'PASS',
            'pdb_in_testpack': False, 'game_load': 'NOT_TESTED', 'Scaleform_execution': 'NOT_TESTED',
            'CTD_resolution': 'UNVERIFIED', 'deployment': 'NOT_PERFORMED', 'publication': 'NOT_PERFORMED',
        }
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
        print('PACKAGE_AUDIT_054_PASS ' + json.dumps(result, ensure_ascii=False, separators=(',', ':')))
        return 0
    except (OSError, AssertionError, ValueError, KeyError, zipfile.BadZipFile) as exc:
        print(f'PACKAGE_AUDIT_054_FAIL {exc}', file=sys.stderr)
        return 1

if __name__ == '__main__':
    raise SystemExit(main())
