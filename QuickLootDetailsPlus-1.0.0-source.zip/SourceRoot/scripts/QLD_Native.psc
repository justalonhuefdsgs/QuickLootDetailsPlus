Scriptname QLD_Native Hidden
Function Configure(bool enabled, int side, float offsetX, float offsetY, float width, float scale, float fontSize, float backgroundOpacity, float textOpacity, int cardScalePercent) global native
Function ConfigureWorld(bool enabled, int anchor, float offsetX, float offsetY, int cardScalePercent) global native
Function ConfigureCardDisplay(bool enabled, bool category, bool valueWeight, bool ownedCount, bool bookRead, bool spellLearned, bool potionDetails, bool ingredientEffects, bool equipmentDetails, bool soulGemDetails, bool itemFlags, bool pluginSource, int maxRows, float fontScale, bool showIcons, bool referenceDps) global native
