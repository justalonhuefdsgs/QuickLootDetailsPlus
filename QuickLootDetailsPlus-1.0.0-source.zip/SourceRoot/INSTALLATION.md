# 0.1.20-r2 text-route candidate (032)

This is a private review/test pair, not an installation release. The text-route appearance has not been selected as final. No Skyrim/MO2 install or launch has been performed.

Candidate runtime archive: `dist/QuickLootDetails-0.1.20-r2-text-032-private-testpack.zip`
Matching corresponding source archive: `dist/QuickLootDetails-0.1.20-r2-text-032-private-source.zip`

Only test this pair after a human chooses to proceed, using a separate MO2 test profile and a disposable save. Record the exact archive hashes, Skyrim/SKSE, QuickLoot provider, and SkyUI versions before starting. Do not treat host tests or package audit as a game-runtime result. See [the human test procedure](docs/HUMAN_TEST_JA.md).
