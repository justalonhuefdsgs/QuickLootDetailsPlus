#pragma once
#include <cstdint>
namespace qld {
// Exact Steam runtimes only; dependency versions use SKSE's packed version format.
constexpr std::uint32_t minimumSKSE(std::uint32_t runtime) noexcept {
    switch(runtime) {
        case 0x01050610:return 0x02000140; // 1.5.97 / 2.0.20
        case 0x01064920:return 0x02020080; // 1.6.1170 / 2.2.8
        case 0x01070680:return 0x02030010; // 1.7.104 / 2.3.1
        default:return 0;
    }
}
constexpr bool runtimeLoadAllowed(std::uint32_t runtime,std::uint32_t skse,bool editor=false) noexcept {
    const auto minimum=minimumSKSE(runtime);
    return !editor && minimum && skse>=minimum;
}
}
