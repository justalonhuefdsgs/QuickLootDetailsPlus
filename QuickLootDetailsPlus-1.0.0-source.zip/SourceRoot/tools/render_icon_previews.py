"""Render candidate-owned SVGs to local PC preview sheets at 16/20/24 px."""
from __future__ import annotations

import argparse
import base64
import hashlib
import html
import json
import os
import stat
import struct
import subprocess
import sys
import xml.etree.ElementTree as ET
import zlib
import uuid
from pathlib import Path

from icon_library import validate_svg


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


# This isolated candidate is the only authorized output boundary.
CANDIDATE_ROOT = Path(__file__).resolve().parents[2]


def _same_path(left: Path, right: Path) -> bool:
    return os.path.normcase(os.path.normpath(str(left))) == os.path.normcase(os.path.normpath(str(right)))


def _within(boundary: Path, path: Path) -> bool:
    base = os.path.normcase(os.path.abspath(str(boundary)))
    target = os.path.normcase(os.path.abspath(str(path)))
    try:
        return target != base and os.path.commonpath((base, target)) == base
    except ValueError:
        return False


def _is_reparse(path: Path) -> bool:
    try:
        info = path.lstat()
    except FileNotFoundError:
        return False
    return stat.S_ISLNK(info.st_mode) or bool(
        getattr(info, "st_file_attributes", 0) & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)
    )


def _no_reparse(path: Path) -> None:
    current = Path(path.anchor)
    if _is_reparse(current):
        raise RuntimeError(f"reparse point in output route: {current}")
    for part in path.parts[1:]:
        current = current.parent if part == ".." else current / part
        if _is_reparse(current):
            raise RuntimeError(f"reparse point in output route: {current}")


def _candidate_root() -> Path:
    script = Path(__file__).absolute()
    expected = CANDIDATE_ROOT / "SourceRoot" / "tools" / "render_icon_previews.py"
    if not _same_path(script, expected):
        raise RuntimeError("renderer must run from the authorized 010 SourceRoot/tools location")
    _no_reparse(script)
    _no_reparse(CANDIDATE_ROOT)
    return CANDIDATE_ROOT.resolve(strict=True)


def _source_root(path: Path, boundary: Path) -> Path:
    expected = boundary / "SourceRoot"
    if not path.is_absolute() or not _same_path(path, expected):
        raise RuntimeError("--root must be the absolute authorized 010 SourceRoot")
    _no_reparse(path)
    if not _same_path(path.resolve(strict=True), expected):
        raise RuntimeError("--root resolves outside the authorized SourceRoot")
    return expected


def _output_path(path: Path, boundary: Path, label: str) -> Path:
    # Reject lexical escapes before inspecting an outside destination.
    if not path.is_absolute() or not _within(boundary, path):
        raise RuntimeError(f"{label} must be an absolute path inside 010: {path}")
    # Inspect the original route too: normalizing '..' must not hide a link.
    _no_reparse(path)
    normalized = path.resolve(strict=False)
    if not _within(boundary, normalized):
        raise RuntimeError(f"{label} resolves outside 010: {normalized}")
    _no_reparse(normalized)
    return normalized


def _output_dir(path: Path, boundary: Path, label: str) -> Path:
    target = _output_path(path, boundary, label)
    if target.exists() and not target.is_dir():
        raise RuntimeError(f"{label} is not a directory: {target}")
    return target


def _output_file(path: Path, boundary: Path, label: str) -> Path:
    target = _output_path(path, boundary, label)
    if target.exists():
        info = target.stat()
        if not stat.S_ISREG(info.st_mode) or info.st_nlink > 1:
            raise RuntimeError(f"{label} must be a regular file with no additional hard links: {target}")
    return target


def _mkdir_inside(path: Path, boundary: Path, label: str) -> Path:
    target = _output_dir(path, boundary, label)
    missing = []
    current = target
    while not current.exists():
        missing.append(current)
        current = current.parent
    if not current.is_dir():
        raise RuntimeError(f"{label} parent is not a directory: {current}")
    for directory in reversed(missing):
        directory = _output_dir(directory, boundary, label)
        if not directory.parent.is_dir():
            raise RuntimeError(f"{label} parent disappeared: {directory.parent}")
        directory.mkdir()
        _output_dir(directory, boundary, label)
    return _output_dir(target, boundary, label)


def _write_bytes_inside(path: Path, data: bytes, boundary: Path, label: str) -> None:
    target = _output_file(path, boundary, label)
    if not target.parent.is_dir():
        raise RuntimeError(f"{label} parent directory is missing: {target.parent}")
    target = _output_file(target, boundary, label)
    target.write_bytes(data)
    _output_file(target, boundary, label)


def _write_text_inside(path: Path, text: str, boundary: Path, label: str) -> None:
    _write_bytes_inside(path, text.encode("utf-8"), boundary, label)


def browser_path(explicit: str | None) -> Path:
    candidates = [Path(explicit)] if explicit else []
    candidates += [
        Path(r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"),
        Path(r"C:\Program Files\Google\Chrome\Application\chrome.exe"),
        Path(r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"),
        Path(r"C:\Program Files\Microsoft\Edge\Application\msedge.exe"),
    ]
    for candidate in candidates:
        if candidate.is_file():
            return candidate.resolve()
    raise RuntimeError("an installed Chrome or Edge executable is required for local SVG pixel previews")


def svg_data_uri(path: Path) -> tuple[str, str]:
    validate_svg(path)
    data = path.read_bytes()
    uri = "data:image/svg+xml;base64," + base64.b64encode(data).decode("ascii")
    return uri, sha(data)


def validate_transparent_canvas(path: Path) -> None:
    root = ET.parse(path).getroot()
    root_fill = root.get("fill")
    if root_fill and root_fill.casefold() not in {"none", "transparent"}:
        raise RuntimeError(f"SVG root paints the canvas background: {path.name}")
    for element in root.iter():
        if element.tag.rsplit("}", 1)[-1] != "rect":
            continue
        if (element.get("x", "0"), element.get("y", "0"),
                element.get("width"), element.get("height")) == ("0", "0", "64", "64"):
            raise RuntimeError(f"SVG contains a full-viewBox background rectangle: {path.name}")


def png_dimensions(path: Path) -> tuple[int, int]:
    data = path.read_bytes()
    if len(data) < 24 or data[:8] != b"\x89PNG\r\n\x1a\n" or data[12:16] != b"IHDR":
        raise RuntimeError(f"browser did not create a valid PNG: {path}")
    return int.from_bytes(data[16:20], "big"), int.from_bytes(data[20:24], "big")


def decode_png_rgb(path: Path) -> tuple[int, int, list[bytes]]:
    data = path.read_bytes()
    width, height = png_dimensions(path)
    bit_depth, color_type = data[24], data[25]
    channels = {2: 3, 6: 4}.get(color_type)
    if bit_depth != 8 or channels is None:
        raise RuntimeError(f"unsupported browser PNG format (depth={bit_depth}, color={color_type})")
    pos = 8
    compressed = bytearray()
    while pos < len(data):
        length = struct.unpack_from(">I", data, pos)[0]
        tag = data[pos + 4:pos + 8]
        payload = data[pos + 8:pos + 8 + length]
        if tag == b"IDAT":
            compressed.extend(payload)
        pos += 12 + length
        if tag == b"IEND":
            break
    decoded = zlib.decompress(bytes(compressed))
    stride = width * channels
    if len(decoded) != height * (stride + 1):
        raise RuntimeError("browser PNG decompressed size is inconsistent")
    rows: list[bytes] = []
    previous = bytearray(stride)
    offset = 0
    for _ in range(height):
        filt = decoded[offset]
        source = decoded[offset + 1:offset + 1 + stride]
        offset += stride + 1
        row = bytearray(stride)
        for index, value in enumerate(source):
            left = row[index - channels] if index >= channels else 0
            above = previous[index]
            upper_left = previous[index - channels] if index >= channels else 0
            if filt == 0:
                predictor = 0
            elif filt == 1:
                predictor = left
            elif filt == 2:
                predictor = above
            elif filt == 3:
                predictor = (left + above) // 2
            elif filt == 4:
                p = left + above - upper_left
                pa, pb, pc = abs(p - left), abs(p - above), abs(p - upper_left)
                predictor = left if pa <= pb and pa <= pc else above if pb <= pc else upper_left
            else:
                raise RuntimeError(f"unsupported PNG filter type {filt}")
            row[index] = (value + predictor) & 0xFF
        rows.append(bytes(row))
        previous = row
    return width, height, rows


def pixel(rows: list[bytes], x: int, y: int, channels: int) -> tuple[int, int, int, int]:
    offset = x * channels
    row = rows[y]
    alpha = row[offset + 3] if channels == 4 else 255
    return row[offset], row[offset + 1], row[offset + 2], alpha


def build_html(title: str, size: int, symbols: list[dict[str, object]], combo_cases: list[dict[str, object]],
               uri_by_symbol: dict[str, str], base_symbol_id: str) -> str:
    cards = []
    for entry in symbols:
        symbol = str(entry["symbol_id"])
        name = str(entry.get("label") or symbol)
        kind = "base" if not entry.get("overlay_only") else "overlay"
        uri = uri_by_symbol[symbol]
        cards.append(
            f'<article class="symbol-card" data-symbol="{html.escape(symbol)}" data-kind="{kind}">'
            f'<div class="glyph"><img width="{size}" height="{size}" alt="" src="{uri}"></div>'
            f'<div class="symbol-name">{html.escape(name)}</div>'
            f'<div class="symbol-id">{html.escape(symbol)}</div></article>'
        )
    combos = []
    for case in combo_cases:
        markers = "".join(
            f'<img class="marker" width="9" height="9" alt="" src="{uri_by_symbol[str(marker)]}">'
            for marker in case["markers"]
        )
        combos.append(
            f'<article class="combo-card" data-state="{html.escape(case["state"])}">'
            f'<div class="combo-icons"><img class="base-glyph" width="{size}" height="{size}" alt="" '
            f'src="{uri_by_symbol[base_symbol_id]}"><span class="marker-strip">{markers}</span></div>'
            f'<div class="combo-label">{html.escape(case["label"])}</div>'
            f'<div class="combo-state">{html.escape(case["state"])}</div></article>'
        )
    return f'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><title>{html.escape(title)}</title>
<style>
* {{ box-sizing:border-box }} html,body {{ margin:0; width:1120px; background:#0E1721; color:#E7EDF4; font-family:Arial,sans-serif }}
body {{ padding:10px 12px 12px }} h1 {{ margin:0 0 2px; font-size:17px; line-height:22px; font-weight:600 }}
.subtitle {{ margin:0 0 8px; color:#B7C5D2; font-size:10px; line-height:14px }}
.symbol-grid {{ display:grid; grid-template-columns:repeat(10,104px); grid-auto-rows:78px; gap:4px }}
.symbol-card {{ width:104px; height:78px; overflow:hidden; border:1px solid #263746; border-radius:4px; background:#14202A; text-align:center; padding:3px 2px }}
.glyph {{ height:34px; display:flex; justify-content:center; align-items:center }} .glyph img {{ display:block; object-fit:contain }}
.symbol-name {{ margin-top:1px; height:15px; overflow:hidden; white-space:nowrap; font-size:9px; line-height:13px }}
.symbol-id {{ color:#96A9BA; font-size:8px; line-height:11px; overflow:hidden; white-space:nowrap }}
h2 {{ margin:8px 0 4px; font-size:12px; line-height:15px; font-weight:600 }}
.combo-grid {{ display:grid; grid-template-columns:repeat(4,270px); grid-auto-rows:60px; gap:4px }}
.combo-card {{ border:1px solid #263746; border-radius:4px; background:#14202A; padding:4px 7px; display:grid; grid-template-columns:72px 1fr; grid-template-rows:26px 13px; align-items:center }}
.combo-icons {{ display:flex; gap:5px; align-items:center; grid-row:1 / span 2 }} .base-glyph {{ display:block; flex:none }}
.marker-strip {{ display:flex; gap:3px; align-items:center; min-width:18px; height:14px }} .marker {{ display:block; flex:none; object-fit:contain }}
.combo-label {{ font-size:10px; line-height:13px; white-space:nowrap }} .combo-state {{ color:#96A9BA; font-size:8px; line-height:11px; white-space:nowrap }}
</style></head><body>
<h1>{html.escape(title)}</h1><p class="subtitle">Each source SVG is rendered at the labeled CSS pixel size; the palette is unmodified and each status remains a separate vector clip.</p>
<section class="symbol-grid">{''.join(cards)}</section>
<h2>Base icon and independent status overlay combinations</h2><section class="combo-grid">{''.join(combos)}</section>
</body></html>'''


def build_probe_html(entries: list[dict[str, object]], sizes: tuple[int, ...], uri_by_symbol: dict[str, str]) -> str:
    sections = []
    for size in sizes:
        cells = []
        for entry in entries:
            symbol = str(entry["symbol_id"])
            cells.append(
                f'<div class="probe-cell" data-symbol="{html.escape(symbol)}">'
                f'<img width="{size}" height="{size}" alt="" src="{uri_by_symbol[symbol]}"></div>'
            )
        sections.append(f'<section class="probe-section"><h3>{size}px transparent-canvas probes</h3>'
                         f'<div class="probe-grid">{"".join(cells)}</div></section>')
    return f'''<!doctype html><html><head><meta charset="utf-8"><style>
*{{box-sizing:border-box}}html,body{{margin:0;width:440px;height:620px;background:#0E1721;color:#E7EDF4;font-family:Arial,sans-serif}}
.probe-section{{height:204px;margin:0 0 0 0;padding:0 0 4px 8px}}h3{{margin:0;height:18px;font-size:11px;line-height:16px;font-weight:600}}
.probe-grid{{display:grid;grid-template-columns:repeat(14,28px);grid-auto-rows:28px;gap:2px}}
.probe-cell{{width:28px;height:28px;background:#0E1721;display:flex;align-items:center;justify-content:center}}
.probe-cell img{{display:block;object-fit:contain}}
</style></head><body>{''.join(sections)}</body></html>'''


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True, help="absolute authorized 010 SourceRoot")
    parser.add_argument("--preview", type=Path, required=True, help="absolute preview directory inside 010")
    parser.add_argument("--temp", type=Path, required=True, help="absolute temporary directory inside 010")
    parser.add_argument("--browser", help="optional installed Chrome/Edge executable")
    args = parser.parse_args()
    boundary = _candidate_root()
    root = _source_root(args.root, boundary)
    preview = _output_dir(args.preview, boundary, "preview")
    temp_root = _output_dir(args.temp, boundary, "temp")
    # Fresh profiles avoid links in a reused browser profile tree.
    temp = _output_dir(temp_root / ("render-" + uuid.uuid4().hex), boundary, "run temp")
    assets = root / "assets" / "category-icons"
    mapping = json.loads((assets / "manifest" / "icon_mapping.json").read_text(encoding="utf-8-sig"))
    overlays = json.loads((assets / "manifest" / "overlay_mapping.json").read_text(encoding="utf-8-sig"))
    entries = list(mapping["items"]) + list(overlays)
    if len(mapping["items"]) != 80 or len(overlays) != 4 or len(entries) != 84:
        raise RuntimeError("preview requires exactly 80 base SVGs and four overlays")
    if len({entry["symbol_id"] for entry in entries}) != 84:
        raise RuntimeError("preview input symbol IDs are not unique")
    uri_by_symbol: dict[str, str] = {}
    hash_by_symbol: dict[str, str] = {}
    for entry in entries:
        path = assets / entry["asset_path"]
        validate_transparent_canvas(path)
        uri, digest = svg_data_uri(path)
        uri_by_symbol[str(entry["symbol_id"])] = uri
        hash_by_symbol[str(entry["symbol_id"])] = digest
    sword_symbol_id = next((str(entry["symbol_id"]) for entry in mapping["items"] if entry.get("label") == "weapon_sword"), None)
    if sword_symbol_id is None:
        raise RuntimeError("existing weapon_sword label is missing from the 061 source mapping")

    by_symbol = {str(entry["symbol_id"]): entry for entry in overlays}
    overlay_ids = {entry["symbol_id"] for entry in overlays}
    expected_overlay_ids = {"enchanted_mark", "known_enchant_mark", "special_enchant_mark", "read_mark"}
    if overlay_ids != expected_overlay_ids:
        raise RuntimeError("overlay mapping IDs differ from the four AS2 marker states")
    cases = [
        {"state": "none", "label": "no enchantment, unread", "markers": []},
        {"state": "enchant", "label": "enchantment present", "markers": ["enchanted_mark"]},
        {"state": "known", "label": "known enchantment", "markers": ["known_enchant_mark"]},
        {"state": "special", "label": "special enchantment", "markers": ["special_enchant_mark"]},
        {"state": "read", "label": "read only", "markers": ["read_mark"]},
        {"state": "enchant+read", "label": "enchantment + read", "markers": ["enchanted_mark", "read_mark"]},
        {"state": "known+read", "label": "known + read", "markers": ["known_enchant_mark", "read_mark"]},
        {"state": "special+read", "label": "special + read", "markers": ["special_enchant_mark", "read_mark"]},
    ]
    if set(by_symbol) != expected_overlay_ids:
        raise RuntimeError("an overlay symbol is absent from the full SVG mapping")

    app_profile = temp / "browser-profile"
    profiles = {str(size): temp / f"profile-{size}" for size in (16, 20, 24)}
    profiles["alpha"] = temp / "profile-alpha-probe"
    directories = [preview, temp_root, temp, app_profile, *profiles.values()]
    files = (
        [temp / f"icons-and-overlays-{size}px.html" for size in (16, 20, 24)]
        + [preview / f"icons-and-overlays-{size}px.png" for size in (16, 20, 24)]
        + [temp / "alpha-probes.html", preview / "alpha-probes-84-symbols.png",
           preview / "pixel_checks_065.json"]
    )
    # Complete preflight before the first directory creation or process.
    for path in directories:
        _output_dir(path, boundary, "planned directory")
    for path in files:
        _output_file(path, boundary, "planned file")
    browser = browser_path(args.browser)
    for path in directories:
        _mkdir_inside(path, boundary, "output directory")
    browser_name = browser.name
    report = {
        "status": "PASS",
        "artwork_review_status": "PROVISIONAL_PENDING_USER_REVIEW",
        "renderer": "local Chromium screenshot",
        "renderer_executable": str(browser),
        "renderer_version": "not queried; executable path is recorded",
        "device_scale_factor": 1,
        "standalone_asset_count": 84,
        "standalone_assets_by_size": {str(size): 84 for size in (16, 20, 24)},
        "source_symbol_ids": [str(entry["symbol_id"]) for entry in entries],
        "source_svg_sha256": hash_by_symbol,
        "transparency": {
            "svg_viewbox": "0 0 64 64",
            "all_source_svgs_have_transparent_canvas": True,
            "evidence": "local browser pixel probes of all 84 exact 061 SVGs at 16/20/24px",
            "inherited_064_review": {
                "status": "NOT_AVAILABLE_NOT_CLAIMED",
                "recorded_path": "evidence/inputs/064/alpha_pixel_review.json",
                "note": "The inherited review was unavailable and was not used; artwork remains provisional pending user review.",
            },
        },
        "external_references_or_fonts": "none; every source SVG is statically validated before rendering",
        "category_tint": "not applied; owned-svg AS2 route does not invoke Color.setRGB",
        "overlay_combinations": [case["state"] for case in cases],
        "native_size_sheets": {},
    }

    env = os.environ.copy()
    env["APPDATA"] = env["LOCALAPPDATA"] = str(app_profile)
    env["TEMP"] = env["TMP"] = str(temp)
    env["TMPDIR"] = str(temp)
    for size in (16, 20, 24):
        stem = f"icons-and-overlays-{size}px"
        html_path = temp / f"{stem}.html"
        png_path = preview / f"{stem}.png"
        _write_text_inside(html_path, build_html(f"065 vector preview · {size}px", size, entries, cases, uri_by_symbol, sword_symbol_id), boundary, f"{size}px HTML")
        command = [
            str(browser), "--headless=new", "--disable-gpu", "--no-sandbox", "--hide-scrollbars",
            "--disable-background-networking", "--disable-default-apps", "--no-first-run",
            "--force-device-scale-factor=1", "--window-size=1120,1030",
            "--user-data-dir=" + str(profiles[str(size)]),
            "--screenshot=" + str(png_path), html_path.as_uri(),
        ]
        _output_dir(temp, boundary, "child cwd")
        _output_dir(profiles[str(size)], boundary, "child profile")
        _output_file(html_path, boundary, "child HTML input")
        _output_file(png_path, boundary, "child screenshot")
        process = subprocess.run(command, cwd=temp, env=env, capture_output=True, text=True,
                                 encoding="utf-8", errors="replace", timeout=90, check=False)
        _output_file(png_path, boundary, "rendered screenshot")
        if process.returncode != 0 or not png_path.is_file():
            raise RuntimeError(f"{browser_name} preview render failed at {size}px (exit {process.returncode}): "
                               f"{process.stdout}{process.stderr}")
        width, height = png_dimensions(png_path)
        if width != 1120 or height < 900 or height > 1030:
            raise RuntimeError(f"unexpected {size}px screenshot dimensions: {width}x{height}")
        report["native_size_sheets"][str(size)] = {
            "sheet": f"{stem}.png", "width": width, "height": height,
            "base_asset_count": 80, "overlay_asset_count": 4,
            "combinations_rendered": len(cases),
            "standalone_pixel_size": size, "marker_pixel_size": 9,
            "sha256": sha(png_path.read_bytes()), "bytes": png_path.stat().st_size,
        }

    probe_html_path = temp / "alpha-probes.html"
    probe_png_path = preview / "alpha-probes-84-symbols.png"
    _write_text_inside(probe_html_path, build_probe_html(entries, (16, 20, 24), uri_by_symbol),
                       boundary, "alpha probe HTML")
    _output_dir(temp, boundary, "child cwd")
    _output_dir(profiles["alpha"], boundary, "child profile")
    _output_file(probe_html_path, boundary, "child HTML input")
    _output_file(probe_png_path, boundary, "child screenshot")
    probe = subprocess.run([
        str(browser), "--headless=new", "--disable-gpu", "--no-sandbox", "--hide-scrollbars",
        "--disable-background-networking", "--disable-default-apps", "--no-first-run",
        "--force-device-scale-factor=1", "--window-size=440,620",
        "--user-data-dir=" + str(profiles["alpha"]),
        "--screenshot=" + str(probe_png_path), probe_html_path.as_uri(),
    ], cwd=temp, env=env, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=90, check=False)
    _output_file(probe_png_path, boundary, "rendered screenshot")
    if probe.returncode != 0 or not probe_png_path.is_file():
        raise RuntimeError(f"{browser_name} transparent-canvas pixel probe failed (exit {probe.returncode}): "
                           f"{probe.stdout}{probe.stderr}")
    probe_width, probe_height, rows = decode_png_rgb(probe_png_path)
    color_type = probe_png_path.read_bytes()[25]
    channels = 4 if color_type == 6 else 3
    if (probe_width, probe_height) != (440, 620):
        raise RuntimeError(f"unexpected alpha-probe screenshot dimensions: {probe_width}x{probe_height}")
    background = (14, 23, 33)
    rendered_pixel_counts: dict[str, dict[str, int]] = {}
    corner_checks = 0
    for size_index, size in enumerate((16, 20, 24)):
        size_counts: dict[str, int] = {}
        for index, entry in enumerate(entries):
            symbol = str(entry["symbol_id"])
            col, row_index = index % 14, index // 14
            left = 8 + col * 30 + (28 - size) // 2
            top = size_index * 204 + 18 + row_index * 30 + (28 - size) // 2
            foreground = 0
            for y in range(top, top + size):
                for x in range(left, left + size):
                    r, g, b, a = pixel(rows, x, y, channels)
                    if a != 0 and (r, g, b) != background:
                        foreground += 1
            corners = [(left, top), (left + size - 1, top),
                       (left, top + size - 1), (left + size - 1, top + size - 1)]
            if any(pixel(rows, x, y, channels) != (*background, 255) for x, y in corners):
                raise RuntimeError(f"{size}px rendered art touched a transparent viewBox corner: {symbol}")
            if foreground <= 0:
                raise RuntimeError(f"{size}px rendering produced no visible art pixels: {symbol}")
            corner_checks += len(corners)
            size_counts[symbol] = foreground
        rendered_pixel_counts[str(size)] = size_counts
    report["rendered_pixel_counts"] = rendered_pixel_counts
    report["transparency"].update({
        "all_84_symbols_rendered_with_visible_pixels_at_each_size": True,
        "transparent_viewbox_corner_samples": corner_checks,
        "alpha_probe_sheet": "alpha-probes-84-symbols.png",
        "alpha_probe_sha256": sha(probe_png_path.read_bytes()),
        "alpha_probe_dimensions": [probe_width, probe_height],
        "background_sample_rgb": list(background),
    })

    _write_text_inside(preview / "pixel_checks_065.json",
                       json.dumps(report, indent=2, ensure_ascii=False) + "\n",
                       boundary, "pixel report")
    print("PC_PIXEL_PREVIEW_PASS symbols=84 sizes=16,20,24 overlay_combinations=8 renderer=" + str(report["renderer_version"]))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, KeyError, json.JSONDecodeError, RuntimeError, subprocess.TimeoutExpired) as exc:
        print(f"PC_PIXEL_PREVIEW_FAIL {exc}", file=sys.stderr)
        raise SystemExit(1)
