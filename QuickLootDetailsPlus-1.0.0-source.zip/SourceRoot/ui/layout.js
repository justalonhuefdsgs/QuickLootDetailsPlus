// Shared AS2-compatible logic. Node tests exercise these exact functions with labelled mock metrics.
function qldCodePoint(text, pos) {
    var first = text.charCodeAt(pos);
    var second = text.charCodeAt(pos + 1);
    if (first >= 0xD800 && first <= 0xDBFF && second >= 0xDC00 && second <= 0xDFFF) return 0x10000 + (first - 0xD800) * 1024 + second - 0xDC00;
    return first;
}
function qldPointLength(cp) { return cp > 0xFFFF ? 2 : 1; }
function qldContinuation(cp) {
    return (cp >= 0x300 && cp <= 0x36F) || (cp >= 0x1AB0 && cp <= 0x1AFF) || (cp >= 0x1DC0 && cp <= 0x1DFF) || (cp >= 0x20D0 && cp <= 0x20FF) || (cp >= 0xFE00 && cp <= 0xFE0F) || (cp >= 0xFE20 && cp <= 0xFE2F) || (cp >= 0xE0100 && cp <= 0xE01EF) || (cp >= 0x1F3FB && cp <= 0x1F3FF) || cp == 0x3099 || cp == 0x309A;
}
function qldTextBoundaries(text) {
    var boundaries = [0];
    var pos = 0;
    while (pos < text.length) {
        var first = qldCodePoint(text, pos);
        pos += qldPointLength(first);
        if (first >= 0x1F1E6 && first <= 0x1F1FF) {
            var next = qldCodePoint(text, pos);
            if (next >= 0x1F1E6 && next <= 0x1F1FF) pos += qldPointLength(next);
        }
        while (pos < text.length) {
            var cp = qldCodePoint(text, pos);
            if (qldContinuation(cp)) pos += qldPointLength(cp);
            else if (cp == 0x200D && pos + 1 < text.length) {
                pos++;
                pos += qldPointLength(qldCodePoint(text, pos));
            } else break;
        }
        boundaries.push(pos);
    }
    return boundaries;
}
function qldFits(metrics, width, height) {
    return metrics != undefined && isFinite(metrics.width) && isFinite(metrics.height) && metrics.width >= 0 && metrics.height >= 0 && metrics.width <= width && metrics.height <= height;
}
function qldFitText(text, width, height, measure) {
    if (text.length == 0) return {text:"", truncated:false, fits:true};
    if (!isFinite(width) || !isFinite(height) || width <= 0 || height <= 0) return {text:"", truncated:true, fits:false};
    if (qldFits(measure(text), width, height)) return {text:text, truncated:false, fits:true};
    var suffix = "…";
    if (!qldFits(measure(suffix), width, height)) return {text:"", truncated:true, fits:false};
    var boundaries = qldTextBoundaries(text);
    var lo = 0;
    var hi = boundaries.length - 1;
    while (lo < hi) {
        var mid = Math.ceil((lo + hi) / 2);
        if (qldFits(measure(text.substr(0, boundaries[mid]) + suffix), width, height)) lo = mid;
        else hi = mid - 1;
    }
    return {text:text.substr(0, boundaries[lo]) + suffix, truncated:true, fits:true};
}
function qldBaseHeight(fontSize) { return 2 * (fontSize + 2) + 22; }
function qldLayout(width, height, requestedFont, hasDetails) {
    if (!isFinite(width) || !isFinite(height) || !isFinite(requestedFont) || width < 60 || height <= 0) return {show:false};
    var font = Math.max(10, Math.min(36, requestedFont));
    var base = qldBaseHeight(font);
    var footer = Math.min(14, font) + 8;
    var detailsHeight = height - base - footer - 8;
    if (detailsHeight < font + 6) return {show:false};
    return {show:true, fontSize:font, titleHeight:2*(font+2), detailTop:base, detailHeight:detailsHeight,
        noticeTop:height-footer, noticeHeight:footer, noticeFont:Math.min(14,font), textWidth:width-28};
}
function qldEquipmentDisplay(detail, comparison) {
    var result = {detail:detail == undefined ? "" : detail, comparison:comparison};
    if (typeof result.detail != "string" || typeof comparison != "string") return result;
    var weaponLabel = "\u53f3\u624b\u88c5\u5099\u3068\u306e\u653b\u6483\u529b\u5dee:";
    var armorLabel = "\u88c5\u5099\u4e2d\u9632\u5177\u3068\u306e\u9632\u5fa1\u529b\u5dee:";
    var oldLabel; var newLabel;
    if (comparison.indexOf(weaponLabel + " ") == 0) {
        oldLabel = weaponLabel; newLabel = "\u653b\u6483\u529b:";
    } else if (comparison.indexOf(armorLabel + " ") == 0) {
        oldLabel = armorLabel; newLabel = "\u9632\u5fa1\u529b:";
    } else if (comparison.indexOf("Main-hand damage difference: ") == 0) {
        oldLabel = "Main-hand damage difference:"; newLabel = oldLabel;
    } else if (comparison.indexOf("Armor difference from equipped: ") == 0) {
        oldLabel = "Armor difference from equipped:"; newLabel = oldLabel;
    } else return result;
    var pos = result.detail.indexOf(comparison);
    if (pos < 0 || result.detail.indexOf(comparison, pos + comparison.length) >= 0) return result;
    var end = pos + comparison.length;
    if ((pos > 0 && result.detail.charAt(pos - 1) != "\n" && result.detail.charAt(pos - 1) != "\r") ||
        (end < result.detail.length && result.detail.charAt(end) != "\n" && result.detail.charAt(end) != "\r")) return result;
    var suffix = comparison.substr(oldLabel.length);
    if (suffix == " +0.00" || suffix == " -0.00") {
        result.comparison = newLabel == oldLabel ? newLabel + " \u30fc" : newLabel.substring(0, newLabel.length - 1) + "\uff1a\u30fc";
    } else {
        result.comparison = newLabel + suffix;
    }
    result.detail = result.detail.substring(0, pos) + result.comparison + result.detail.substring(end);
    return result;
}
function qldEquipmentComparisonRange(detailText, comparisonJa, comparisonEn) {
    if (typeof detailText != "string") return null;
    var line = null; var start = -1;
    if (typeof comparisonJa == "string" && comparisonJa != "") {
        var jaStart = detailText.indexOf(comparisonJa);
        if (jaStart >= 0) {
            if (detailText.indexOf(comparisonJa, jaStart + comparisonJa.length) >= 0) return null;
            line = comparisonJa; start = jaStart;
        }
    }
    if (typeof comparisonEn == "string" && comparisonEn != "" && comparisonEn != comparisonJa) {
        var enStart = detailText.indexOf(comparisonEn);
        if (enStart >= 0) {
            if (detailText.indexOf(comparisonEn, enStart + comparisonEn.length) >= 0 || line != null) return null;
            line = comparisonEn; start = enStart;
        }
    }
    if (line == null || start < 0) return null;
    var lineEnd = start + line.length;
    if ((start > 0 && detailText.charAt(start - 1) != "\n" && detailText.charAt(start - 1) != "\r") ||
        (lineEnd < detailText.length && detailText.charAt(lineEnd) != "\n" && detailText.charAt(lineEnd) != "\r")) return null;
    var separator = line.lastIndexOf(" ");
    if (separator < 0 || separator >= line.length - 1) return null;
    var displayed = line.substr(separator + 1); var dot = displayed.indexOf(".");
    if (dot < 2 || dot != displayed.length - 3) return null;
    var sign = displayed.charAt(0);
    if (sign != "+" && sign != "-") return null;
    var index = 1;
    while (index < dot) {
        var wholeDigit = displayed.charCodeAt(index);
        if (wholeDigit < 48 || wholeDigit > 57) return null;
        index += 1;
    }
    index = dot + 1;
    while (index < displayed.length) {
        var fractionDigit = displayed.charCodeAt(index);
        if (fractionDigit < 48 || fractionDigit > 57) return null;
        index += 1;
    }
    var value = Number(displayed);
    if (!isFinite(value) || value == 0 || ((sign == "+") != (value > 0))) return null;
    return {start:start + separator + 1, end:start + line.length, value:value, color:value > 0 ? 0x66B2FF : 0xFF6B6B};
}
