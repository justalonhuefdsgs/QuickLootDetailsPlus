#pragma once
#include <array>
#include <cstdint>
#include <string_view>
namespace qld {
enum class ProviderKind { none,ie,ee,re,aeReplacement };
enum class SelectionContract { none,ieV20,legacyPdb,legacySourcePending,legacyBinary };
struct ProviderEvidence {std::string_view name,module,hash;ProviderKind kind;SelectionContract selection;std::uint8_t candidateRuntimes;};
inline constexpr std::uint8_t runtimeSE=1,runtime1170=2,runtime1704=4;
inline constexpr std::array<ProviderEvidence,7> providerEvidence{{
 {"IE4.1.2","QuickLootIE.dll","b6cdb74d063dd8889008c2073b347fef7a5cb891c213dddaa5af402aa547d6b5",ProviderKind::ie,SelectionContract::ieV20,3},
 {"IE4.1.3","QuickLootIE.dll","ea030379a1db36bb222d30e9833aadb2bd5ae9a06ec13dfdf50638404ac8625a",ProviderKind::ie,SelectionContract::ieV20,7},
 {"EE1.2.1 package / DLL1.1.0","QuickLootEE.dll","71ffa806a06d21b58f2c1a804cbf80b4884af0c234bd627fd851a2452d5871e4",ProviderKind::ee,SelectionContract::legacyBinary,1},
 {"EE1170 fix1.0 / DLL1.2.0","QuickLootEE.dll","ca746bbed4e752c3853c83eca1599ae965caaa1815969d68821ce74ec9a3bc61",ProviderKind::ee,SelectionContract::legacyPdb,2},
 {"RE2.8.6","QuickLootRE.dll","9ff2fafc0379c7d43a91e1e99d28d1187fc672bcb7ae1f40062656beaba87ecc",ProviderKind::re,SelectionContract::legacyBinary,1},
 {"RE2.15.0","QuickLootRE.dll","97e5968df41b909d5868e5f76976f455047648ab06c8445c4e4fe710354be784",ProviderKind::re,SelectionContract::legacySourcePending,0},
 {"AE3.0.0 RE replacement","QuickLootRE.dll","c99d38c58a3ed60159e7a9f4c10110a04751a8b433cad8fd982d6c3ba960037f",ProviderKind::aeReplacement,SelectionContract::legacyPdb,4},
}};
constexpr std::uint8_t runtimeBit(std::uint32_t v) noexcept {
 return v==0x01050610?runtimeSE:v==0x01064920?runtime1170:v==0x01070680?runtime1704:0;
}
constexpr const ProviderEvidence* identifyProvider(std::string_view module,std::string_view hash) noexcept {
 for(auto& e:providerEvidence)if(e.module==module && e.hash==hash)return &e;
 return nullptr;
}
constexpr bool providerCandidate(const ProviderEvidence& e,std::uint32_t runtime) noexcept {
 return (e.candidateRuntimes & runtimeBit(runtime))!=0;
}
// Exact API/binary/PDB implementations only. Runtime masks are deliberately narrow.
// RE2.15 and unknown runtime/provider combinations remain disabled.
constexpr bool adapterImplemented(const ProviderEvidence& e,std::uint32_t runtime) noexcept {
 return (e.selection==SelectionContract::ieV20 || e.selection==SelectionContract::legacyBinary || e.selection==SelectionContract::legacyPdb) && providerCandidate(e,runtime);
}
}
