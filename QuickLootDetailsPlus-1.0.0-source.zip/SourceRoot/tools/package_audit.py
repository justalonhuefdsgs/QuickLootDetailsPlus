"""Audit actual ZIP bytes recursively and re-extracted payloads. No execution/deploy.
Use explicit package allowlists and exact included dependency archive hashes.
"""
import hashlib,io,json,os,pathlib,re,struct,tempfile,zipfile,zlib
ROOT=pathlib.Path(__file__).resolve().parents[1]
RUNTIME={
 'Interface/QuickLootDetails.swf','Interface/Translations/QuickLootDetails_ENGLISH.txt','Interface/Translations/QuickLootDetails_JAPANESE.txt','MCM/Config/QuickLootDetails/config.json','MCM/Config/QuickLootDetails/settings.ini',
 'QuickLootDetails.esp','SEQ/QuickLootDetails.seq','SKSE/Plugins/QuickLootDetails.dll','Scripts/QLD_MCM.pex','Scripts/QLD_Native.pex'}
PUBLIC_ROOTS={'README.md','BUILD.md','INSTALLATION.md','LICENSE.md','NOTICE.md','THIRD_PARTY.md','COPYING.txt','EXCEPTIONS.md','.gitignore','CMakeLists.txt','dependencies.json'}
PUBLIC_DOCS={'HUMAN_TEST_JA.md','CHANGELOG_JA.md','LICENSE_AUDIT_JA.md','provider-abi-facts.json','license-provenance.json','dependency-source-changes.json','papyrus-imports-required.json','source-delta.json','verification.json','IMPLEMENTATION_STATUS_JA.md','SKYUI_ICONS_JA.md','ICON_AUDIT_0.1.20-r1.md','MARKER_ART_CREDIT_JA.md','SOURCE_MANIFEST_SCOPE_JA.md','REPAIR_EVIDENCE_JA.md','ROUTE_SELECTION_JA.md'}
PUBLIC_TOOLS={'build_assets.py','build.ps1','prepare_deps.py','verify_assets.py','restore_papyrus_import.py','package.py','package_audit.py','restore_inherited_assets.py'}
RUNTIME_DOC_ROOTS={'README.md','INSTALLATION.md','LICENSE.md','NOTICE.md','THIRD_PARTY.md','COPYING.txt','EXCEPTIONS.md'}
RUNTIME_DOCS={'HUMAN_TEST_JA.md','CHANGELOG_JA.md','LICENSE_AUDIT_JA.md','license-provenance.json','source-delta.json','verification.json','IMPLEMENTATION_STATUS_JA.md','SKYUI_ICONS_JA.md','ICON_AUDIT_0.1.20-r1.md','MARKER_ART_CREDIT_JA.md','REPAIR_EVIDENCE_JA.md','ROUTE_SELECTION_JA.md'}
SECRET_PATTERNS=[rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',rb'(?:ghp|gho|github_pat)_[A-Za-z0-9_]{30,}',rb'AKIA[A-Z0-9]{16}',rb'\bsk-[A-Za-z0-9_-]{40,}']
FORBIDDEN_SUFFIXES={'.pex','.esp','.esl','.esm','.bsa','.ba2','.dll','.exe','.lib','.pdb','.swf','.ttf','.otf','.woff','.woff2','.png','.jpg','.jpeg','.dds','.wav','.mp3'}
LICENSES={'CommonLib-COPYING.txt','CommonLib-EXCEPTIONS.md','CommonLib-legacy-MIT.txt','DirectXMath-LICENSE.txt','DirectXTK-LICENSE.txt','QuickLootIE-API-MIT.txt','QuickLoot-reference-profiles-MIT.txt','QuickLootIE-GPL-3.0.txt','QuickLootIE-EXCEPTIONS.md','spdlog-LICENSE.txt'}
SOURCE_LICENSES=LICENSES|{'Caprica.LICENSE','Champollion.LICENSE'}

def sha(b):return hashlib.sha256(b).hexdigest()
def source_allowed(relative):
    p=pathlib.PurePosixPath(relative);parts=p.parts
    if relative in PUBLIC_ROOTS or relative=='source-manifest.json':return True
    if len(parts)==2 and parts[0]=='docs':return parts[1] in PUBLIC_DOCS
    if len(parts)==2 and parts[0]=='tools':return parts[1] in PUBLIC_TOOLS
    if len(parts)==2 and parts[0]=='licenses':return parts[1] in SOURCE_LICENSES
    if parts[0] in {'src','include'}:return p.suffix in {'.cpp','.h'}
    if parts[0]=='tests':return (p.suffix in {'.cpp','.py','.js'} or relative=='tests/normalized-fixtures.json') and '__pycache__' not in parts
    if parts[0]=='cmake':return len(parts)==3 and parts[1]=='packages' and p.suffix=='.cmake'
    if parts[0]=='vendor':return relative=='vendor/QuickLootAPI.h'
    if parts[0]=='ui':return relative in {'ui/panel.as','ui/layout.js'}
    if parts[0]=='scripts':return relative in {'scripts/QLD_Native.psc','scripts/QLD_MCM.psc','scripts/Skyrim.flg'}
    if parts[0]=='assets':
        if relative in {'assets/MCM/Config/QuickLootDetails/config.json','assets/MCM/Config/QuickLootDetails/settings.ini','assets/Interface/Translations/QuickLootDetails_ENGLISH.txt','assets/Interface/Translations/QuickLootDetails_JAPANESE.txt'}:return True
        return len(parts)==3 and parts[1]=='marker-art' and parts[2] in {'20.svg','22.svg','24.svg','26.svg','provenance.json'}
    if parts[0]=='deps':return len(parts)==2 and parts[1] in {'commonlib.zip','spdlog.zip','directxtk.zip','directxmath.zip'}
    return False
def runtime_allowed(name):
    if name in RUNTIME or name=='QuickLootDetails_Docs/manifest.json':return True
    p=pathlib.PurePosixPath(name);parts=p.parts
    if len(parts)==2 and parts[0]=='QuickLootDetails_Docs':return parts[1] in RUNTIME_DOC_ROOTS
    if len(parts)==3 and parts[0]=='QuickLootDetails_Docs':
        return (parts[1]=='docs' and parts[2] in RUNTIME_DOCS) or (parts[1]=='licenses' and parts[2] in LICENSES)
    return False

def identity_patterns():
    values=[os.environ.get('USERNAME',''),os.environ.get('COMPUTERNAME','')]
    # Absolute user profile is only used in-memory and never recorded in reports.
    if os.environ.get('USERPROFILE'):values.append(os.environ['USERPROFILE'])
    return [re.compile(rb'(?<![A-Za-z0-9_])'+re.escape(v.encode())+rb'(?![A-Za-z0-9_])',re.I) for v in values if len(v)>3]
def scan_content(name,data,identities):
    for pattern in SECRET_PATTERNS:
        if re.search(pattern,data):raise AssertionError('Secret-pattern finding in '+name)
    for pattern in identities:
        if pattern.search(data) or pattern.search(data.replace(b'\0',b'')):raise AssertionError('Private identity finding in '+name)
    if re.search(rb'\blibfile_[0-9a-f]{20,}\b',data):raise AssertionError('Private Library identifier in '+name)
    if re.search(rb'(?:[A-Za-z]:[\\/]{1,4}Users[\\/]|/Users/[A-Za-z0-9_. -]+/)',data,re.I):raise AssertionError('User profile path in '+name)
    for word in os.environ.get('QLD_PRIVATE_FORBIDDEN_WORDS','').split(';'):
        if word and word.encode() in data:raise AssertionError('Private project identifier in '+name)

def pex_metadata(data):
    assert data[:8]==b'\xfa\x57\xc0\xde\x03\x02\x00\x01';pos=16;fields=[]
    for _ in range(3):
        n=struct.unpack_from('>H',data,pos)[0];pos+=2;fields.append(data[pos:pos+n].decode('utf-8'));pos+=n
    assert fields[0] in {'QLD_Native.psc','QLD_MCM.psc'} and fields[1:]==['QuickLoot Details contributors','public-build']
    assert data[8:16]==b'\0'*8
    return {'source_file':fields[0],'compiler_user':fields[1],'compiler_machine':fields[2],'timestamp':0,'payload_sha256':sha(data[pos:])}
def dll_metadata(data):
    rsds=[];at=0
    while (at:=data.find(b'RSDS',at))>=0:
        if at+24<len(data):
            end=data.find(b'\0',at+24);p=data[at+24:end]
            if p.lower().endswith(b'.pdb'):rsds.append(p.decode('utf-8'))
        at+=4
    assert rsds==['QuickLootDetails.pdb'], 'DLL debug path is not neutral'
    return {'RSDS_paths':rsds,'PDB_file_shipped':False}
def swf_tags(data):
    body=zlib.decompress(data[8:]) if data[:3]==b'CWS' else data[8:]
    pos=(5+4*(body[0]>>3)+7)//8+4;tags=[];shapes={};placements={}
    while pos<len(body):
        header=struct.unpack_from('<H',body,pos)[0];pos+=2;length=header&63
        if length==63:length=struct.unpack_from('<I',body,pos)[0];pos+=4
        tag=header>>6;payload=body[pos:pos+length];pos+=length;tags.append(tag)
        if tag in (2,22,32,83):shapes[struct.unpack_from('<H',payload)[0]]=length
        if tag==26:
            flags=payload[0];depth=struct.unpack_from('<H',payload,1)[0];offset=3;character=None
            if flags&2:character=struct.unpack_from('<H',payload,offset)[0];offset+=2
            if flags&4:offset+=1
            if flags&8:offset+=4
            if flags&16:offset+=2
            if flags&32:placements[payload[offset:].split(b'\0',1)[0].decode('ascii')]=(character,depth,flags)
    expected={'qldMarkerEnchant':20,'qldMarkerKnown':22,'qldMarkerSpecial':24,'qldMarkerRead':26}
    assert pos==len(body) and tags==[69,2,2,2,2,26,26,26,26,12,1,0]
    assert all(shapes.get(shape_id,0)>8 for shape_id in expected.values())
    assert {name:placements.get(name,(None,None,None))[0] for name in expected}==expected
    assert [placements[name][1] for name in expected]==[1,2,3,4]
    assert all(placements[name][2]==0x22 for name in expected)
    return {'tags':tags,'marker_shape_payload_bytes':shapes,'named_instances':placements}

def audit_archive(path,kind):
    rows=[];identities=identity_patterns();lock=json.loads((ROOT/'dependencies.json').read_text());specs={s['file']:s for s in lock['archives']}
    def audit_nested(data,label,spec):
        assert sha(data)==spec['sha256']
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            assert z.testzip() is None
            names=z.namelist();assert len(names)==len(set(names));expected=set()
            for name in names:
                assert not name.endswith('/') and name.startswith(spec['directory']+'/')
                assert '\\' not in name and '..' not in pathlib.PurePosixPath(name).parts
                assert pathlib.PurePosixPath(name).suffix.lower() not in FORBIDDEN_SUFFIXES
                b=z.read(name);scan_content(label+'::'+name,b,identities)
                if name.endswith('.zip'):raise AssertionError('Unexpected deeper archive '+name)
                expected.add(name)
            assert any('LICENSE' in name.upper() or 'COPYING' in name.upper() for name in names)
            rows.append({'archive':label,'entries':len(names),'sha256':sha(data),'all_files_secret_identity_asset_scan':'PASS','code_license_bytes':'same as upstream except listed removed image assets'})
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None;names=z.namelist();assert len(names)==len(set(names))
        for name in names:
            assert not name.endswith('/') and '..' not in pathlib.PurePosixPath(name).parts and '\\' not in name
            b=z.read(name)
            if kind=='runtime':assert runtime_allowed(name), 'Runtime allowlist: '+name
            else:
                assert name.startswith('QuickLootDetails/') and source_allowed(name[len('QuickLootDetails/'):]),'Source allowlist: '+name
                assert pathlib.PurePosixPath(name).suffix.lower() not in FORBIDDEN_SUFFIXES
            scan_content(name,b,identities)
            if name.endswith('.zip'):audit_nested(b,name,specs[pathlib.PurePosixPath(name).name])
        if kind=='runtime':
            assert RUNTIME.issubset(names)
            assert {n for n in names if n.endswith('.dll')}=={'SKSE/Plugins/QuickLootDetails.dll'}
            assert {n for n in names if n.endswith('.pex')}=={'Scripts/QLD_MCM.pex','Scripts/QLD_Native.pex'}
            meta={name:pex_metadata(z.read(name)) for name in ('Scripts/QLD_MCM.pex','Scripts/QLD_Native.pex')}
            meta['dll']=dll_metadata(z.read('SKSE/Plugins/QuickLootDetails.dll'));meta['swf_tags']=swf_tags(z.read('Interface/QuickLootDetails.swf'))
            manifest=json.loads(z.read('QuickLootDetails_Docs/manifest.json'))
            assert set(names)==set(manifest)|{'QuickLootDetails_Docs/manifest.json'}
            for filename in LICENSES:assert 'QuickLootDetails_Docs/licenses/'+filename in names
        else:
            manifest=json.loads(z.read('QuickLootDetails/source-manifest.json'));assert set(names)==set(manifest)|{'QuickLootDetails/source-manifest.json'}
            root_manifest=json.loads((ROOT/'source-manifest.json').read_text(encoding='utf-8'))
            assert root_manifest==manifest,'Root source-manifest.json must exactly equal the source ZIP file map.'
            meta={'source_binaries_game_imports_provider_assets':'NONE','external_dependency_archives':len(specs)}
            for filename in SOURCE_LICENSES:assert 'QuickLootDetails/licenses/'+filename in names
        assert all(sha(z.read(n))==d for n,d in manifest.items())
        # Re-extract actual finished archive in this candidate build area and verify every file byte.
        extraction=ROOT/'build/package-audit'/kind
        extraction.mkdir(parents=True,exist_ok=True)
        base=extraction.resolve()
        for name in names:
            target=(base/name).resolve();assert target.is_relative_to(base)
            target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z.read(name))
        assert all((base/n).read_bytes()==z.read(n) for n in names)
        rows.append({'archive':path.name,'kind':kind,'entries':len(names),'sha256':sha(path.read_bytes()),'allowlist':'PASS','license_files':'PASS','manifest_hashes':'PASS','secret_private_identity_paths':'PASS','reextraction_byte_check':'PASS','metadata':meta,'files':manifest})
    return rows
def main():
    report=json.loads((ROOT/'dist/package-report.json').read_text(encoding='utf-8'));rows=[]
    verification=json.loads((ROOT/'build/verification.json').read_text(encoding='utf-8'))
    assert report['STATIC']==verification['status'], 'Package STATIC status must match current verification evidence'
    for kind in ('runtime','source'):rows.extend(audit_archive(ROOT/'dist'/report[kind+'_zip']['path'],kind))
    result={'candidate':report.get('candidate','0.1.20-r2'),'BUILD':report['BUILD'],'AUTOMATED_TESTS':report['AUTOMATED_TESTS'],'STATIC':verification['status'],'ARCHIVE_AUDIT':'PASS','RUNTIME':'NOT_TESTED','PUBLICATION':'NOT_PERFORMED','DEPLOY':'NOT_PERFORMED','limitations':'Papyrus sources and PEX are inherited with exact hashes from the verified 0.1.19-r1 build. Installed SkyUI export/frame coverage and in-game rendering/input remain unverified. Archive scans and allowlists are technical evidence, not exhaustive legal/security certification.','archives':rows}
    (ROOT/'dist/package-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    report['ARCHIVE_AUDIT']='PASS'
    (ROOT/'dist/package-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print('Recursive actual ZIP + re-extraction audit PASS:',sum(r['entries'] for r in rows),'entries; STATIC remains',verification['status'],'; LOAD/RUNTIME not tested.')
if __name__=='__main__':main()
