#pragma once
#include <map>
#include <span>
#include <vector>
#include <string>
#include <variant>
#include <cstdint>
#include <string_view>

namespace qld {
using CardValue=std::variant<double,bool,std::string>;
struct CardSnapshot {
    std::map<std::string,CardValue> fields;
};
bool validCard(const CardSnapshot&) noexcept;
struct TextNormalization {
    bool ok{true};
    std::string text,error;
    std::uint32_t unsupportedTags{},unknownEntities{},formattingTags{};
};
// Preserve native words/numbers; flatten presentational markup to the MCM text style.
TextNormalization normalizeNativeText(std::string_view);
struct StackTraits { double health; std::uint64_t enchantment; std::int32_t count; bool operator==(const StackTraits&) const = default; };
bool consistentStack(std::span<const StackTraits>,std::int32_t totalCount,StackTraits base) noexcept;
}
