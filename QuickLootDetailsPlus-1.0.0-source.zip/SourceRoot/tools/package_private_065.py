"""Build private 065 source/runtime ZIPs after dual-SWF and PDB identity gates."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
import zipfile
from pathlib import Path, PurePosixPath

from build_identity import read_identity, verify_binary
from marker_contract import verify_dll_binding
from source_manifest import collect_source_files, verify_manifest

PARENT_SOURCE_SHA256 = "df3171ca14dd355fad47c94340b95ea4c679585bbb38fabd9aa4a4ca2ca3f7c5"
PARENT_RUNTIME_SHA256 = "00cb4f555e22ea3e81c8e85e17441470f113435bbf8f252c20699d64142e8b72"
RUNTIME_DLL = "SKSE/Plugins/QuickLootDetails.dll"
RUNTIME_UI_SWF = "Interface/QuickLootDetails.swf"
RUNTIME_ICON_SWF = "Interface/QuickLootDetails_CategoryIcons.swf"
RUNTIME_MANIFEST = "QuickLootDetails_Docs/manifest.json"
RUNTIME_CANDIDATE = "QuickLootDetails_Docs/docs/candidate-065.json"
RUNTIME_VERIFICATION = "QuickLootDetails_Docs/docs/verification-065.json"
RUNTIME_MARKER_HISTORY = "QuickLootDetails_Docs/docs/MARKER_ART_CREDIT_057_HISTORY.md"
STALE_RUNTIME_DOCS = {
    "QuickLootDetails_Docs/docs/candidate-057.json",
    "QuickLootDetails_Docs/docs/verification.json",
    "QuickLootDetails_Docs/docs/MARKER_ART_CREDIT_JA.md",
}
ROOT_DOCS = {
    "COPYING.txt", "EXCEPTIONS.md", "INSTALLATION.md", "LICENSE.md", "NOTICE.md", "README.md", "THIRD_PARTY.md",
}
LICENSES = {
    "CommonLib-COPYING.txt", "CommonLib-EXCEPTIONS.md", "CommonLib-legacy-MIT.txt",
    "DirectXMath-LICENSE.txt", "DirectXTK-LICENSE.txt", "QuickLootIE-API-MIT.txt",
    "QuickLoot-reference-profiles-MIT.txt", "QuickLootIE-GPL-3.0.txt", "QuickLootIE-EXCEPTIONS.md",
    "spdlog-LICENSE.txt",
}


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def safe_name(name: str) -> None:
    path = PurePosixPath(name)
    if path.is_absolute() or not path.parts or ".." in path.parts or "\\" in name or name.endswith("/"):
        raise ValueError(f"unsafe ZIP member path: {name!r}")


def write_zip(path: Path, payload: dict[str, bytes], manifest_name: str, manifest: dict[str, str]) -> None:
    if path.exists():
        raise FileExistsError(f"refusing to overwrite package: {path}")
    if set(payload) != set(manifest):
        raise ValueError("package manifest keys do not exactly match package payload files")
    for name in payload:
        safe_name(name)
    manifest_bytes = (json.dumps(dict(sorted(manifest.items())), indent=2, ensure_ascii=True) + "\n").encode("utf-8")
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    with zipfile.ZipFile(temporary, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(payload.items()):
            info = zipfile.ZipInfo(name, (2026, 10, 7, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, data)
        info = zipfile.ZipInfo(manifest_name, (2026, 10, 7, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, manifest_bytes)
    os.replace(temporary, path)


def read_parent_runtime(path: Path) -> tuple[dict[str, bytes], dict[str, bytes]]:
    if sha(path.read_bytes()) != PARENT_RUNTIME_SHA256:
        raise ValueError("057 parent runtime testpack SHA-256 does not match the recorded lineage input")
    with zipfile.ZipFile(path) as archive:
        bad = archive.testzip()
        if bad:
            raise ValueError(f"057 parent runtime ZIP CRC failure: {bad}")
        names = archive.namelist()
        if len(names) != len(set(names)) or RUNTIME_MANIFEST not in names:
            raise ValueError("057 parent runtime has duplicate members or no manifest")
        for name in names:
            safe_name(name)
        all_files = {name: archive.read(name) for name in names}
    old_manifest = json.loads(all_files[RUNTIME_MANIFEST].decode("utf-8-sig"))
    payload = {name: data for name, data in all_files.items() if name != RUNTIME_MANIFEST}
    if set(old_manifest) != set(payload):
        raise ValueError("057 parent runtime manifest member set differs")
    for name, expected in old_manifest.items():
        if sha(payload[name]) != expected:
            raise ValueError(f"057 parent runtime manifest hash mismatch: {name}")
    return payload, {name: data for name, data in payload.items() if name.startswith("QuickLootDetails_Docs/licenses/")}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--build-root", type=Path, required=True)
    parser.add_argument("--baseline-source", type=Path, required=True)
    parser.add_argument("--baseline-runtime", type=Path, required=True)
    parser.add_argument("--dist", type=Path, required=True)
    parser.add_argument("--build-result", type=Path, required=True)
    parser.add_argument("--pe-identity", type=Path, required=True)
    parser.add_argument("--verification-result", type=Path, required=True)
    parser.add_argument("--audit-report", type=Path, required=True)
    args = parser.parse_args()
    try:
        root = args.root.resolve()
        build_root = args.build_root.resolve()
        if sha(args.baseline_source.read_bytes()) != PARENT_SOURCE_SHA256:
            raise ValueError("057 parent source ZIP SHA-256 does not match the recorded lineage input")
        manifest_sha, manifest_count = verify_manifest(root)
        build_result = json.loads(args.build_result.read_text(encoding="utf-8-sig"))
        pe_identity = json.loads(args.pe_identity.read_text(encoding="utf-8-sig"))
        verification_result = json.loads(args.verification_result.read_text(encoding="utf-8-sig"))
        if build_result.get("build", {}).get("exit_code") != 0:
            raise ValueError("native build evidence is not successful")
        if build_result.get("build", {}).get("exit_diagnostics") != "ON" or build_result.get("build", {}).get("diagnostic_logging") != "OFF":
            raise ValueError("private testpack must keep bounded exit diagnostics ON and generic diagnostic logging OFF")
        ctest = build_result.get("ctest", {})
        if ctest.get("exit_code") != 0 or ctest.get("failed") != 0 or ctest.get("passed", 0) < 1:
            raise ValueError("candidate full CTest evidence is missing or failed")
        if pe_identity.get("status") != "PASS" or not pe_identity.get("pdb", {}).get("matches_dll_codeview"):
            raise ValueError("candidate DLL/PDB CodeView identity evidence is missing or mismatched")
        tests = verification_result.get("tests", {})
        if not tests or any(value != "PASS" for value in tests.values()):
            raise ValueError("candidate verification evidence has a missing or failed required test")

        swf_path = build_root / "assets" / "Interface" / "QuickLootDetails.swf"
        icon_swf_path = build_root / "assets" / "Interface" / "QuickLootDetails_CategoryIcons.swf"
        dll_path = build_root / "native" / "plugin" / "QuickLootDetails.dll"
        swf, icon_swf, dll = swf_path.read_bytes(), icon_swf_path.read_bytes(), dll_path.read_bytes()
        identity = read_identity(root, swf_path, icon_swf_path)
        verify_binary(dll, identity)
        pair = verify_dll_binding(root, swf, icon_swf, dll)
        if identity["source_manifest_sha256"] != manifest_sha or identity["source_manifest_entries"] != manifest_count:
            raise ValueError("compiled DLL identity differs from the exact source manifest bytes/count")
        if build_result.get("identity", {}).get("candidate_id") != identity["candidate_id"]:
            raise ValueError("native build record candidate ID differs from current source/SWF identity")
        if pe_identity.get("dll", {}).get("sha256") != sha(dll):
            raise ValueError("PDB identity report belongs to a different candidate DLL")

        source_payload = {"QuickLootDetails/" + rel: path.read_bytes() for rel, path in collect_source_files(root).items()}
        source_manifest = json.loads((root / "source-manifest.json").read_text(encoding="utf-8-sig"))
        if source_manifest != {name: sha(data) for name, data in sorted(source_payload.items())}:
            raise ValueError("source manifest does not describe the exact 065 source archive payload")
        source_path = args.dist / "QuickLootDetails-065-private-source.zip"
        source_zip_payload = source_payload
        write_zip(source_path, source_zip_payload, "QuickLootDetails/source-manifest.json", source_manifest)

        runtime_payload, inherited_licenses = read_parent_runtime(args.baseline_runtime)
        if not LICENSES.issubset({name.rsplit("/", 1)[-1] for name in inherited_licenses}):
            raise ValueError("one or more inherited runtime license/notice files are missing")
        for stale in STALE_RUNTIME_DOCS:
            runtime_payload.pop(stale, None)
        runtime_payload[RUNTIME_UI_SWF] = swf
        runtime_payload[RUNTIME_ICON_SWF] = icon_swf
        runtime_payload[RUNTIME_DLL] = dll
        for name in ROOT_DOCS:
            source_doc = root / name
            runtime_payload["QuickLootDetails_Docs/" + name] = source_doc.read_bytes()
        runtime_payload[RUNTIME_MARKER_HISTORY] = (root / "docs" / "MARKER_ART_CREDIT_057_HISTORY.md").read_bytes()

        candidate_template = json.loads((root / "docs" / "candidate-065.json").read_text(encoding="utf-8-sig"))
        candidate_doc = dict(candidate_template)
        candidate_doc.update({
            "candidate_id": identity["candidate_id"],
            "source_manifest_sha256": manifest_sha,
            "source_manifest_entries": manifest_count,
            "ui_swf_sha256": sha(swf),
            "category_icon_swf_sha256": sha(icon_swf),
            "runtime_dll_sha256": sha(dll),
            "runtime_dll_bytes": len(dll),
            "pdb": {
                "private_evidence_only": True,
                "sha256": pe_identity["pdb"]["sha256"],
                "guid": pe_identity["pdb"]["guid"],
                "age": pe_identity["pdb"]["age"],
                "matches_dll_codeview": pe_identity["pdb"]["matches_dll_codeview"],
            },
            "build": {"exit_code": 0, "configuration": build_result["build"].get("configuration"),
                      "exit_diagnostics": build_result["build"].get("exit_diagnostics"),
                      "generic_diagnostic_logging": build_result["build"].get("diagnostic_logging"),
                      "ctest": ctest},
            "tests": tests,
            "status": {"package": "PRIVATE_PROVISIONAL_REVIEW_TESTPACK",
                       "artwork_review": "PROVISIONAL_PENDING_USER_REVIEW", "game_load": "NOT_TESTED",
                       "Scaleform_execution": "NOT_TESTED", "CTD_resolution": "UNVERIFIED",
                       "deployment": "NOT_PERFORMED", "publication": "NOT_PERFORMED"},
        })
        runtime_payload[RUNTIME_CANDIDATE] = (json.dumps(candidate_doc, indent=2, ensure_ascii=False) + "\n").encode("utf-8")

        verification_template = json.loads((root / "docs" / "verification-065.json").read_text(encoding="utf-8-sig"))
        verification_doc = dict(verification_template)
        verification_doc.update({
            "candidate_id": identity["candidate_id"],
            "source_manifest_sha256": manifest_sha,
            "source_manifest_entries": manifest_count,
            "compiled_artifacts": {"ui_swf_sha256": sha(swf), "category_icon_swf_sha256": sha(icon_swf),
                                   "dll_sha256": sha(dll), "pdb_sha256_private_evidence": pe_identity["pdb"]["sha256"]},
            "tests": tests,
            "evidence": {"verification_result": args.verification_result.name,
                         "sha256": sha(args.verification_result.read_bytes())},
            "status": {"candidate": "PRIVATE_PROVISIONAL_INTEGRATION_SCAFFOLD",
                       "artwork_review": "PENDING_USER_REVIEW", "game_load": "NOT_TESTED",
                       "Scaleform_execution": "NOT_TESTED", "deployment": "NOT_PERFORMED",
                       "publication": "NOT_PERFORMED"},
        })
        runtime_payload[RUNTIME_VERIFICATION] = (json.dumps(verification_doc, indent=2, ensure_ascii=False) + "\n").encode("utf-8")
        if set(name.rsplit("/", 1)[-1] for name in inherited_licenses) != LICENSES:
            raise ValueError("runtime license set differs from the inherited parent set")
        for name, data in inherited_licenses.items():
            if runtime_payload.get(name) != data:
                raise ValueError("runtime license text was changed: " + name)

        runtime_manifest = {name: sha(data) for name, data in sorted(runtime_payload.items())}
        runtime_path = args.dist / "QuickLootDetails-065-private-runtime-testpack.zip"
        write_zip(runtime_path, runtime_payload, RUNTIME_MANIFEST, runtime_manifest)

        audit_report = args.audit_report.with_name("package-audit-065.json")
        audit_raw = args.audit_report.with_name("package-audit-065-raw.txt")
        audit = subprocess.run([
            sys.executable, str(root / "tools" / "package_audit_065.py"),
            "--root", str(root), "--build-root", str(build_root),
            "--baseline-source", str(args.baseline_source.resolve()), "--baseline-runtime", str(args.baseline_runtime.resolve()),
            "--source-zip", str(source_path), "--runtime-zip", str(runtime_path),
            "--verification-result", str(args.verification_result.resolve()), "--output", str(audit_report),
        ], cwd=root, capture_output=True, text=True, encoding="utf-8", errors="replace", check=False)
        audit_raw.write_text(audit.stdout + audit.stderr, encoding="utf-8")
        if audit.returncode != 0:
            raise ValueError(f"065 source/runtime ZIP audit failed with exit {audit.returncode}; see {audit_report}")

        metadata = {
            "status": "PASS", "candidate_name": identity["candidate_name"], "candidate_id": identity["candidate_id"],
            "lineage_build_id": identity["lineage_build_id"], "parent_candidate_id": candidate_template["parent_candidate_id"],
            "plugin_version": identity["plugin_version"], "category_route": identity["category_route"],
            "ui_probe_marker": identity["ui_probe_marker"], "source_manifest_sha256": manifest_sha,
            "source_manifest_entries": manifest_count,
            "parent_source_zip_sha256": PARENT_SOURCE_SHA256, "parent_runtime_zip_sha256": PARENT_RUNTIME_SHA256,
            "source_zip": {"path": source_path.name, "bytes": source_path.stat().st_size, "sha256": sha(source_path.read_bytes())},
            "runtime_zip": {"path": runtime_path.name, "bytes": runtime_path.stat().st_size, "sha256": sha(runtime_path.read_bytes())},
            "swf": {"bytes": len(swf), "sha256": sha(swf)},
            "category_icon_swf": {"bytes": len(icon_swf), "sha256": sha(icon_swf)},
            "dll": {"bytes": len(dll), "sha256": sha(dll)},
            "pdb_private_evidence": {"bytes": pe_identity["pdb"]["bytes"], "sha256": pe_identity["pdb"]["sha256"],
                                     "guid": pe_identity["pdb"]["guid"], "age": pe_identity["pdb"]["age"],
                                     "matches_dll_codeview": pe_identity["pdb"]["matches_dll_codeview"]},
            "marker_gate": pair["status"], "zip_audit": "PASS", "tests": tests,
            "artwork_review_status": candidate_template["icon_library"]["artwork_review_status"],
            "verification_state": "TECHNICAL_TESTS_PASS_ART_REVIEW_PENDING",
            "game_load": "NOT_TESTED", "Scaleform_execution": "NOT_TESTED", "CTD_resolution": "UNVERIFIED",
            "deployment": "NOT_PERFORMED", "publication": "NOT_PERFORMED",
        }
        args.audit_report.parent.mkdir(parents=True, exist_ok=True)
        args.audit_report.write_text(json.dumps(metadata, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        print("PACKAGE_065_PASS " + json.dumps(metadata, ensure_ascii=False, separators=(",", ":")))
        return 0
    except (OSError, ValueError, KeyError, json.JSONDecodeError, zipfile.BadZipFile, subprocess.SubprocessError) as exc:
        print(f"PACKAGE_065_FAIL {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
