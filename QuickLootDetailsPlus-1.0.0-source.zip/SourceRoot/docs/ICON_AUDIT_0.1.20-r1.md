# Icon and enchantment audit — 0.1.20-r1

## Source basis

| Source | Pinned evidence | Use |
|---|---|---|
| QuickLoot IE | source archive `quicklootie-source.zip`, SHA-256 `6b64b8e82b508e43c57b12bf08e1c25b1842d34ea4fe5296920630fae8e4e4ae`; commit `e4dc2812c5583dd714f6d7da89e514a232845653` | `ItemStack.SkyUiIcons.cpp` maps native subtype to `iconLabel` and `iconColor`; `ItemStack.SkyUiData.cpp` supplies the subtype; `ListItemRenderer.as` consumes those values and its enchantment booleans. |
| SkyUI | `InventoryIconSetter.as` at commit `835428728e2305865e220fdfc99d791434955eb1` | Standard SkyUI label/tint classifications and default category behavior. |
| QuickLoot IE XFL source | `res/swf/Source/LootMenuIE.fla` inside the pinned source archive | `iconRead`, `iconEnchant`, `iconEnchantKnown`, and `iconEnchantSpecial` are separate vector symbols. `iconRead` is pale yellow (`#FFFFA2`); enchantment markers use blue, white/blue, and red treatments. `ListItemRenderer.as` selects them independently; the ordinary item frame is 24 px, while marker sizing is defined by its XFL stage instance. |

## Standard item-icon map

The label column is the exact string used by the pinned QuickLoot/SkyUI source. Tints are QuickLoot IE's `iconColor` values; absent tint means the base white/unmodified icon. Weapon, armor, book, potion, and gem subtypes come from native item data/keywords/forms, not item names.

| Native classification | Icon label(s) | Tint / source rule |
|---|---|---|
| Weapon | `default_weapon`, `weapon_sword`, `weapon_dagger`, `weapon_waraxe`, `weapon_mace`, `weapon_greatsword`, `weapon_battleaxe`, `weapon_hammer`, `weapon_bow`, `weapon_crossbow`, `weapon_staff`, `weapon_pickaxe`, `weapon_woodaxe` | All `0xA4A5BF`; warhammer uses the `WeapTypeWarhammer` keyword, pickaxe/wood axe use the pinned known-form list. Unknown animation/subtype uses `default_weapon`. |
| Armor, light | `lightarmor_head`, `lightarmor_body`, `lightarmor_hands`, `lightarmor_forearms`, `lightarmor_feet`, `lightarmor_calves`, `lightarmor_shield`; jewelry slots use `armor_amulet`, `armor_ring`, `armor_circlet`; unknown/ears retains `default_armor` | `0x756000`; body-part is selected with SkyUI's part-mask precedence. |
| Armor, heavy | `armor_head`, `armor_body`, `armor_hands`, `armor_forearms`, `armor_feet`, `armor_calves`, `armor_shield`; jewelry slots use `armor_amulet`, `armor_ring`, `armor_circlet`; unknown/ears retains `default_armor` | `0x6B7585`; same part-mask precedence. |
| Armor, clothing | `clothing_head`, `clothing_body`, `clothing_hands`, `clothing_forearms`, `clothing_feet`, `clothing_calves`, `clothing_shield`; unsupported slot retains `default_armor` | Base tint `0xEDDA87`. |
| Armor, jewelry | `armor_amulet`, `armor_ring`, `armor_circlet`; ears/other remains `default_armor` | Base tint `0xEDDA87`. Weight class follows `ArmorType` and `VendorItemClothing`/`VendorItemJewelry` keyword fallbacks in the pinned source. |
| Ammo | `weapon_arrow`, `weapon_bolt` | `0xA89E8C`; bolt is `TESAmmo::IsBolt()`. |
| Book | `book_tome`, `book_note`, `default_book` | Spell-tome and recipe/note keywords/type; `data.read` selects the separate `iconRead` marker, not a replacement base category frame. |
| Scroll | `default_scroll` | `0xC73636` fire, `0xFFFF00` shock, `0x1FFBFF` frost; other resistance leaves default white. |
| Potion / poison / food / drink | `potion_health`, `potion_magic`, `potion_stam`, `potion_fire`, `potion_shock`, `potion_frost`, `potion_poison`, `default_food`, `food_wine`, `default_potion` | Health `0xDB2E73`, magicka `0x2E9FDB`, stamina `0x51DB2E`, fire `0xC73636`, shock `0xEAAB00`, frost `0x1FFBFF`, poison `0xAD00B3`; food/drink use the native food flag and consumption-sound form. Unknown effect is `default_potion`. |
| Ingredient | `default_ingredient` | White/default. |
| Soul gem | `soulgem_empty`, `soulgem_partial`, `soulgem_full`, `soulgem_grandempty`, `soulgem_grandpartial`, `soulgem_grandfull`, `soulgem_azura`, `misc_soulgem` | Petty/lesser/common tint `0xD7D4FF`/`0xC0BAFF`/`0xABA3FF`; greater/grand `0x948BFC`/`0x7569FF`; Azura/Black Star `soulgem_azura`, `0x7569FF`; unknown capacity/status `misc_soulgem`, `0xE3E0FF`. Stack status must be consistent before selecting an empty/partial/full variant. |
| Key / light | `default_key`, `misc_torch` | White/default. |
| Misc: canonical Gold001 | `misc_gold` | `0xCCCC33`; only Skyrim.esm Gold001 (local FormID `0x00000F`), never name-based matching. |
| Misc: gem, claw, artifact, leather, strips, hide, remains, ingot, children clothes, firewood, clutter, lockpick | `misc_gem`, `misc_dragonclaw`, `misc_artifact`, `misc_leather`, `misc_strips`, `misc_hide`, `misc_remains`, `misc_ingot`, `clothing_body`, `misc_wood`, `misc_clutter`, `misc_lockpick` | Gem `0xFFB0D1`, leather/strips `0xBA8D23`, hide `0xDBB36E`, ingot `0x828282`, children's clothing `0xEDDA87`, firewood `0xA89E8C`; others white/default. Keywords and the pinned form list determine special types. |
| Unknown/unsupported form or missing subtype | `default_misc` | Explicit safe fallback; do not invent a label. |

## Enchantment marker rules

QuickLoot IE displays the book-read marker independently from enchantment markers. For enchantment, the row renderer picks one marker in this order: `knownEnchanted` → `specialEnchanted` → `enchanted`. Its data classifier distinguishes `kNone`, `kKnown`, `kCannotDisenchant`, and other enchantments. The FLA source contains the corresponding `iconEnchantKnown`, `iconEnchantSpecial`, and `iconEnchant` shapes. 0.1.20-r1 follows these conditions and keeps the read/enchantment markers in separate title slots. Only a base enchantment or a consistent actual `ExtraEnchantment` qualifies; charge, poison, quest, stolen, favorite, or name state does not.

## Confirmed 0.1.19-r1 divergences

- The native classifier returned only a short set of generic/weapon/book/alchemy labels; all armor used `default_armor`, miscellaneous Gold001 used `default_misc`, and scroll/light/misc/gem status/potion effect variants were not covered.
- Gold was not tagged as the canonical form, so the UI had no safe way to show gold-only placeholders while preserving other zero-weight items.
- The detail title had no enchantment-state input or marker slot.

## Armor-class precedence correction

The independent 0.1.20 acceptance audit found that candidate code let `VendorItemClothing` and slot-derived jewelry/clothing fallbacks override light/heavy armor types. The repair follows the pinned QuickLoot IE order: `ArmorType::kLight` and `kHeavy` take priority; only `kNone` checks `VendorItemClothing`, then `VendorItemJewelry`; only unclassified `kNone` items use the same slot fallback as QuickLoot IE. The `ClothesWeddingWreath` known-form override and Dawnguard Vampire Lord body subtype remain explicit. Regression cases cover mixed keywords, jewelry, slot fallback and unsupported slots.

## Original marker vectors and source terms

The four marker shapes are direct vector exports from the pinned QuickLoot IE movie and are imported into the generated SWF without redrawing. Shape IDs, source symbol names, SVG hashes, commit, source archive hash, source SWF hash, FFDec version, license texts and attribution scope are recorded in `assets/marker-art/provenance.json` and `docs/MARKER_ART_CREDIT_JA.md`. The SVG source files and upstream license/exception texts are included in the matching source archive.

## Verification limits and provider boundaries

- The checked work areas do not contain the installed SkyUI `Interface/skyui/icons_item_psychosteve.swf` binary or its export/frame table. Source labels above are supported by the pinned source call sites, but exact installed SWF frame existence/export coverage is NOT_VERIFIED until that asset is available. Runtime source can fail closed to `default_misc` if a requested label is absent.
- QuickLoot IE's Inventory Interface Information Injector integration can override `iconSource`, `iconLabel`, or `iconColor`. 0.1.20-r1's native form map cannot safely observe that per-provider replacement, and it does not claim to mirror I4/custom reskins. The same caution applies to divergent EE/RE forks unless their exact source contract is inspected.
- The workbench's readable Japanese font configuration is not available in the checked project. Source emits the exact code point U+30FC for Gold001, but glyph rendering is not confirmed without the installed game font/Scaleform runtime.
- Neither Skyrim nor MO2 was launched, and no live profile/save was touched.
