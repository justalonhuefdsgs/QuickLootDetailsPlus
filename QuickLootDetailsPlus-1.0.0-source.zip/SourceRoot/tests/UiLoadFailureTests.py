#!/usr/bin/env python3
"""Static ownership and native/SWF protocol regression check; not a Scaleform runtime test."""

import re
import sys
from pathlib import Path


def check_teardown_order(body: str) -> None:
    begin = body.index("recordDiagnostic(qld::exitdiag::Event::menuDestroy, qld::exitdiag::Phase::begin")
    end = body.index("recordDiagnostic(qld::exitdiag::Event::menuDestroy, qld::exitdiag::Phase::end")
    reset = body.index("qld::resetMovieOwnersInDependencyOrder(uiMovie, movieDefinition_);")
    clear = body.index("clearActiveMenu(diagnosticGeneration_);")
    flushes = [match.start() for match in re.finditer(r"flushDiagnostics\(\);", body)]
    assert len(flushes) == 2, "persist begin before release and end after release"
    assert begin < flushes[0] < reset < end < clear < flushes[1], (
        "end marker must follow explicit owner release; begin must be flushed first"
    )


def main() -> int:
    if len(sys.argv) != 3:
        raise SystemExit("usage: UiLoadFailureTests.py Plugin.cpp panel.as")

    native = Path(sys.argv[1]).read_text(encoding="utf-8")
    ui = Path(sys.argv[2]).read_text(encoding="utf-8")

    expected_match = re.search(
        r'constexpr\s+auto\s+expectedProbe\s*=\s*"([^"]+)"\s*;', native
    )
    ui_match = re.search(
        r'function\s+qldProbe\s*\(\s*\)\s*\{\s*return\s+"([^"]+)"\s*;\s*\}',
        ui,
    )
    assert expected_match, "native UI contract marker is missing"
    assert ui_match, "SWF source probe function is missing"
    expected = expected_match.group(1)
    actual = ui_match.group(1)
    assert expected == actual, f"native/SWF probe mismatch: {expected!r} != {actual!r}"

    function_start = native.index("bool loadMovie(RE::GFxMovieView* lootMovie)")
    function_end = native.index("bool pendingPosition(", function_start)
    load_movie = native[function_start:function_end]
    scope_marker = "// The returned GFxValue is Movie-managed; destroy it before releasing either Movie owner below."
    scope_end_marker = "}  // probe is released while uiMovie and movieDefinition_ are still alive."
    scope_start = load_movie.index(scope_marker)
    probe_decl = load_movie.index("RE::GFxValue probe;", scope_start)
    scope_end = load_movie.index(scope_end_marker, probe_decl)
    failure_gate = load_movie.index("if(!extensions || !render || !probeCall || probeText!=expectedProbe)")
    cleanup = load_movie.index("uiMovie.reset();movieDefinition_.reset();", failure_gate)
    error_log = load_movie.index("UI_LOAD_FAILED stage=script-initialization-or-version", cleanup)
    return_false = load_movie.index("return false;", error_log)
    assert scope_start < probe_decl < scope_end < failure_gate < cleanup, (
        "GFxValue probe must be destroyed before failure cleanup releases its Movie"
    )
    assert "UI_LOAD_FAILED stage=script-initialization-or-version" in load_movie[cleanup:return_false]

    destructor_start = native.index("~DetailsMenu() override {")
    destructor_end = native.index("static RE::IMenu* create()", destructor_start)
    menu_destructor = native[destructor_start:destructor_end]
    helper_header = '#include "qld/MovieOwnerLifetime.h"'
    owner_reset_call = "qld::resetMovieOwnersInDependencyOrder(uiMovie, movieDefinition_);"
    assert helper_header in native, "production plugin must include the lifetime helper"
    assert menu_destructor.count(owner_reset_call) == 1, "DetailsMenu destructor must explicitly release both owners"
    check_teardown_order(menu_destructor)
    end_call = "recordDiagnostic(qld::exitdiag::Event::menuDestroy, qld::exitdiag::Phase::end, 0, true);"
    premature_end = menu_destructor.replace(end_call, "").replace(
        owner_reset_call, end_call + "\n" + owner_reset_call
    )
    try:
        check_teardown_order(premature_end)
    except AssertionError:
        pass
    else:
        raise AssertionError("negative control accepted an end marker before owner release")

    def failed(extensions: bool, render: bool, called: bool, probe: str) -> bool:
        return not extensions or not render or not called or probe != expected

    assert not failed(True, True, True, actual), "the shipped SWF probe must pass the native gate"
    assert failed(True, True, True, "QLD_UI_0.1.19"), "a stale probe must still take the explicit failure path"
    assert failed(False, True, True, actual), "extension initialization failure must remain explicit"
    assert failed(True, False, True, actual), "missing render function must remain explicit"
    assert failed(True, True, False, actual), "failed probe call must remain explicit"

    print("UI load-failure/production movie-owner contract PASS (static source check; no Scaleform runtime).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
