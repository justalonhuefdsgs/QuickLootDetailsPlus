#include "qld/ExitDiagnostics.h"

#include <charconv>
#include <system_error>

namespace qld::exitdiag {
namespace {

constexpr std::size_t maxBatchBytes = 65536;

const char* eventName(Event event) noexcept {
    switch (event) {
    case Event::menuCreate: return "menu-create";
    case Event::menuDestroy: return "menu-destroy";
    case Event::advanceMovie: return "advance";
    case Event::providerOpen: return "on-open";
    case Event::providerClose: return "on-close";
    case Event::showEnqueue: return "show-enqueue";
    case Event::showDispatch: return "show-dispatch";
    case Event::closeDispatch: return "close-dispatch";
    }
    return "unknown";
}

const char* phaseName(const EventRecord& record) noexcept {
    if (record.event == Event::menuDestroy && record.phase == Phase::end) return "derived-destructor-body-exit-marker";
    const auto phase = record.phase;
    return phase == Phase::begin ? "begin" : "end";
}

bool append(std::span<char> output, std::size_t& offset, std::string_view text) noexcept {
    if (text.size() > output.size() - offset) return false;
    for (const char ch : text) output[offset++] = ch;
    return true;
}

bool appendNumber(std::span<char> output, std::size_t& offset, std::uint64_t value, int base = 10) noexcept {
    if (offset >= output.size()) return false;
    const auto result = std::to_chars(output.data() + offset, output.data() + output.size(), value, base);
    if (result.ec != std::errc{}) return false;
    offset = static_cast<std::size_t>(result.ptr - output.data());
    return true;
}

bool appendHex(std::span<char> output, std::size_t& offset, std::uintptr_t value) noexcept {
    return append(output, offset, "0x") && appendNumber(output, offset, static_cast<std::uint64_t>(value), 16);
}

bool appendRecord(std::span<char> output, std::size_t& offset, const EventRecord& record) noexcept {
    return append(output, offset, ";seq=") && appendNumber(output, offset, record.sequence) &&
           append(output, offset, ",tid=") && appendNumber(output, offset, record.threadId) &&
           append(output, offset, ",gen=") && appendNumber(output, offset, record.menuGeneration) &&
           append(output, offset, ",menu=") && appendHex(output, offset, record.menuAddress) &&
           append(output, offset, ",ui=") && appendHex(output, offset, record.uiMovieAddress) &&
           append(output, offset, ",def=") && appendHex(output, offset, record.movieDefinitionAddress) &&
           append(output, offset, ",event=") && append(output, offset, eventName(record.event)) &&
           append(output, offset, ",phase=") && append(output, offset, phaseName(record)) &&
           append(output, offset, ",origin=") && appendNumber(output, offset, record.originCode) &&
           append(output, offset, ",flags=") && appendNumber(output, offset, record.stateFlags);
}

}  // namespace

std::uint64_t EventRecorder::NewMenuGeneration() {
    std::lock_guard lock(mutex_);
    return ++nextMenuGeneration_;
}

bool EventRecorder::Record(EventRecord record, bool terminal) {
    std::lock_guard lock(mutex_);
    record.sequence = ++nextSequence_;
    if ((terminal && terminalStored_ >= reservedTerminalRecords) ||
        (!terminal && normalStored_ >= normalRecordLimit) || stored_ >= capacity) {
        ++dropped_;
        return false;
    }
    records_[stored_++] = record;
    if (terminal) ++terminalStored_;
    else ++normalStored_;
    return true;
}

EventRecorder::Stats EventRecorder::GetStats() const {
    std::lock_guard lock(mutex_);
    return {nextSequence_, dropped_, stored_, normalStored_, terminalStored_, flushed_};
}

std::size_t EventRecorder::CopyRecords(std::span<EventRecord> destination) const {
    std::lock_guard lock(mutex_);
    const auto count = destination.size() < stored_ ? destination.size() : stored_;
    for (std::size_t i = 0; i < count; ++i) destination[i] = records_[i];
    return count;
}

bool EventRecorder::Flush(std::shared_ptr<IEventSink> sink) noexcept {
    if (!sink) return false;
    try {
        std::lock_guard flushLock(flushMutex_);
        std::array<EventRecord, capacity> batch{};
        std::size_t begin{};
        std::size_t count{};
        std::uint64_t dropped{};
        std::uint64_t lastSequence{};
        std::size_t stored{};
        {
            std::lock_guard lock(mutex_);
            begin = flushed_;
            count = stored_ - begin;
            dropped = dropped_;
            lastSequence = nextSequence_;
            stored = stored_;
            if (count == 0 && dropped <= reportedDropped_) return false;
            for (std::size_t i = 0; i < count; ++i) batch[i] = records_[begin + i];
        }

        std::array<char, maxBatchBytes> text{};
        std::size_t offset{};
        if (!append(text, offset, "count=") || !appendNumber(text, offset, count) ||
            !append(text, offset, ",dropped=") || !appendNumber(text, offset, dropped) ||
            !append(text, offset, ",lastSequence=") || !appendNumber(text, offset, lastSequence) ||
            !append(text, offset, ",stored=") || !appendNumber(text, offset, stored)) return false;
        for (std::size_t i = 0; i < count; ++i) {
            if (!appendRecord(text, offset, batch[i])) return false;
        }

        sink->Write(std::string_view(text.data(), offset));
        if (!sink->Flush()) return false;
        {
            std::lock_guard lock(mutex_);
            flushed_ = begin + count;
            reportedDropped_ = dropped;
        }
        return true;
    } catch (...) {
        return false;
    }
}

}  // namespace qld::exitdiag
