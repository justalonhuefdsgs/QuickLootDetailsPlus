#include "qld/NativeCard.h"
#include "qld/IconLabels.h"
#include "qld/EquipmentComparison.h"
#include "qld/ComparisonDiagnostics.h"
#if QLD_COMPARISON_DIAGNOSTICS
#define QLD_CMP_TRACE(...) qld::cmpdiag::comparison(__VA_ARGS__)
#else
#define QLD_CMP_TRACE(...) ((void)0)
#endif
#include <SKSE/SKSE.h>
#include <Windows.h>
#include <RE/A/AlchemyItem.h>
#include <RE/A/ActorValues.h>
#include <RE/B/BGSBipedObjectForm.h>
#include <RE/B/BGSEquipType.h>
#include <RE/B/BGSKeyword.h>
#include <RE/E/ExtraDataList.h>
#include <RE/E/Effect.h>
#include <RE/E/EffectSetting.h>
#include <RE/E/EnchantmentItem.h>
#include <RE/S/ScrollItem.h>
#include <RE/I/INISettingCollection.h>
#include <RE/T/TESDataHandler.h>
#include <RE/T/TESSoulGem.h>
#include <RE/T/TESAmmo.h>
#include <RE/T/TESObjectBOOK.h>
#include <RE/T/TESObjectARMO.h>
#include <RE/T/TESObjectWEAP.h>
#include <RE/I/ItemCard.h>
#include <algorithm>
#include <array>
#include <cctype>
#include <cmath>
#include <format>
#include <optional>
#include <string_view>
#include <tuple>
#include <utility>
#include <vector>

namespace qld {
namespace {
struct CategoryText { const char* ja; const char* en; const char* kind; };
CategoryText categoryText(RE::FormType type) {
    switch(type) {
    case RE::FormType::Weapon:return {"武器","Weapon","weapon"};
    case RE::FormType::Armor:return {"防具","Armor","armor"};
    case RE::FormType::AlchemyItem:return {"薬","Potion / Poison","alchemy"};
    case RE::FormType::Ingredient:return {"錬金素材","Ingredient","ingredient"};
    case RE::FormType::Book:return {"本","Book","book"};
    case RE::FormType::Ammo:return {"矢弾","Ammunition","ammo"};
    case RE::FormType::SoulGem:return {"魂石","Soul Gem","soulgem"};
    case RE::FormType::KeyMaster:return {"鍵","Key","key"};
    case RE::FormType::Scroll:return {"巻物","Scroll","scroll"};
    case RE::FormType::Misc:return {"その他","Miscellaneous","misc"};
    case RE::FormType::Light:return {"光源","Light","light"};
    case RE::FormType::Apparatus:return {"錬金器具","Apparatus","apparatus"};
    default:return {"アイテム","Item","other"};
    }
}
std::optional<RE::SOUL_LEVEL> uniformSoulLevel(RE::InventoryEntryData* selected, RE::TESSoulGem* gem);
bool isPinnedForm(const RE::TESForm* form, RE::FormID localID, std::string_view plugin = "Skyrim.esm") {
    auto* data = RE::TESDataHandler::GetSingleton();
    if (!form || !data) return false;
    const auto resolved = data->LookupFormID(localID, plugin);
    return resolved != 0 && form->GetFormID() == resolved;
}
qld::ArmorPart armorPartForSlot(RE::BGSBipedObjectForm::BipedObjectSlot slot) {
    using Slot = RE::BGSBipedObjectForm::BipedObjectSlot;
    using Part = qld::ArmorPart;
    switch (slot) {
    case Slot::kHead: return Part::head;
    case Slot::kHair: return Part::hair;
    case Slot::kLongHair: return Part::longHair;
    case Slot::kBody: return Part::body;
    case Slot::kHands: return Part::hands;
    case Slot::kForearms: return Part::forearms;
    case Slot::kFeet: return Part::feet;
    case Slot::kCalves: return Part::calves;
    case Slot::kShield: return Part::shield;
    case Slot::kAmulet: return Part::amulet;
    case Slot::kRing: return Part::ring;
    case Slot::kCirclet: return Part::circlet;
    case Slot::kEars: return Part::ears;
    case Slot::kTail: return Part::tail;
    default: return Part::other;
    }
}
qld::ItemIconSpec iconSpecForNativeItem(RE::InventoryEntryData* selected, RE::TESBoundObject* object) {
    using Category = qld::ItemIconCategory;
    using Variant = qld::ItemIconVariant;
    using Spec = qld::ItemIconSpec;
    if (!object) return qld::itemIconSpec(Category::misc);
    if (auto* weapon = object->As<RE::TESObjectWEAP>()) {
        auto variant = Variant::generic;
        switch (weapon->GetWeaponType()) {
        case RE::WEAPON_TYPE::kOneHandSword: variant = Variant::sword; break;
        case RE::WEAPON_TYPE::kTwoHandSword: variant = Variant::greatsword; break;
        case RE::WEAPON_TYPE::kOneHandDagger: variant = Variant::dagger; break;
        case RE::WEAPON_TYPE::kOneHandAxe: variant = Variant::warAxe; break;
        case RE::WEAPON_TYPE::kTwoHandAxe: variant = weapon->HasKeywordByEditorID("WeapTypeWarhammer") ? Variant::warhammer : Variant::battleAxe; break;
        case RE::WEAPON_TYPE::kOneHandMace: variant = Variant::mace; break;
        case RE::WEAPON_TYPE::kBow: variant = Variant::bow; break;
        case RE::WEAPON_TYPE::kStaff: variant = Variant::staff; break;
        case RE::WEAPON_TYPE::kCrossbow: variant = Variant::crossbow; break;
        default: break;
        }
        if (isPinnedForm(object,0x0E3C16) || isPinnedForm(object,0x06A707) || isPinnedForm(object,0x1019D4)) variant=Variant::pickaxe;
        if (isPinnedForm(object,0x02F2F4) || isPinnedForm(object,0x0AE086)) variant=Variant::woodAxe;
        return qld::itemIconSpec(Category::weapon, variant);
    }
    if (auto* armor = object->As<RE::TESObjectARMO>()) {
        using Slot=RE::BGSBipedObjectForm::BipedObjectSlot;
        const auto mask=armor->GetSlotMask();
        constexpr Slot precedence[]={Slot::kBody,Slot::kHair,Slot::kHands,Slot::kForearms,Slot::kFeet,Slot::kCalves,Slot::kShield,Slot::kAmulet,Slot::kRing,Slot::kLongHair,Slot::kEars,Slot::kHead,Slot::kCirclet,Slot::kTail,Slot::kModMouth,Slot::kModNeck,Slot::kModChestPrimary,Slot::kModBack,Slot::kModMisc1,Slot::kModPelvisPrimary,Slot::kDecapitateHead,Slot::kDecapitate,Slot::kModPelvisSecondary,Slot::kModLegRight,Slot::kModLegLeft,Slot::kModFaceJewelry,Slot::kModChestSecondary,Slot::kModShoulder,Slot::kModArmLeft,Slot::kModArmRight,Slot::kModMisc2,Slot::kFX01};
        auto main=Slot::kNone;
        for(const auto slot:precedence)if(mask.all(slot)){main=slot;break;}
        const auto armorType=armor->GetArmorType();
        const auto weight = armorType==RE::BGSBipedObjectForm::ArmorType::kLightArmor ? qld::ArmorWeightClass::light :
                            armorType==RE::BGSBipedObjectForm::ArmorType::kHeavyArmor ? qld::ArmorWeightClass::heavy :
                            qld::ArmorWeightClass::none;
        const auto originalPart=armorPartForSlot(main);
        const auto classification=qld::armorIconClass(weight,armor->HasKeywordByEditorID("VendorItemClothing"),
            armor->HasKeywordByEditorID("VendorItemJewelry"),originalPart,isPinnedForm(object,0x08895A));
        const auto part=isPinnedForm(object,0x011A84,"Dawnguard.esm")?qld::ArmorPart::body:originalPart;
        return qld::armorIconSpec(classification,part);
    }
    if (auto* alchemy = object->As<RE::AlchemyItem>()) {
        Variant variant=Variant::generic;
        if(alchemy->IsFood()){
            const auto* sound=alchemy->data.consumptionSound;
            const auto drinkSound=RE::TESDataHandler::GetSingleton()?RE::TESDataHandler::GetSingleton()->LookupFormID(0x0B6435,"Skyrim.esm"):0;
            variant=sound&&drinkSound&&sound->GetFormID()==drinkSound?Variant::drink:Variant::food;
        }else if(alchemy->IsPoison())variant=Variant::poison;
        else if(const auto* effect=alchemy->GetAVEffect()){
            switch(effect->data.primaryAV){
            case RE::ActorValue::kHealth:case RE::ActorValue::kHealRate:case RE::ActorValue::kHealRateMult:variant=Variant::health;break;
            case RE::ActorValue::kMagicka:case RE::ActorValue::kMagickaRate:case RE::ActorValue::kMagickaRateMult:variant=Variant::magicka;break;
            case RE::ActorValue::kStamina:case RE::ActorValue::kStaminaRate:case RE::ActorValue::kStaminaRateMult:variant=Variant::stamina;break;
            case RE::ActorValue::kResistFire:variant=Variant::fireResist;break;
            case RE::ActorValue::kResistShock:variant=Variant::shockResist;break;
            case RE::ActorValue::kResistFrost:variant=Variant::frostResist;break;
            default:break;
            }
        }
        return qld::itemIconSpec(Category::alchemy, variant);
    }
    if (auto* book = object->As<RE::TESObjectBOOK>()) {
        const auto variant=object->HasKeywordByEditorID("VendorItemSpellTome")?Variant::spellTome:
            object->HasKeywordByEditorID("VendorItemRecipe") || book->IsNoteScroll()?Variant::note:Variant::generic;
        return qld::itemIconSpec(Category::book, variant);
    }
    if (auto* ammo = object->As<RE::TESAmmo>()) {
        return qld::itemIconSpec(Category::ammo, ammo->IsBolt() ? Variant::bolt : Variant::generic);
    }
    switch (object->GetFormType()) {
    case RE::FormType::Ingredient: return qld::itemIconSpec(Category::ingredient);
    case RE::FormType::SoulGem: {
        auto* gem=object->As<RE::TESSoulGem>(); if(!gem)return qld::itemIconSpec(Category::soulGem);
        if(isPinnedForm(object,0x063B27)||isPinnedForm(object,0x063B29))return qld::itemIconSpec(Category::soulGem,Variant::azuraSoul,qld::SoulGemQuality::azura);
        const auto capacity=static_cast<std::uint32_t>(gem->GetMaximumCapacity());
        if(capacity<1||capacity>5)return qld::itemIconSpec(Category::soulGem);
        const auto current=uniformSoulLevel(selected,gem);if(!current)return qld::itemIconSpec(Category::soulGem);
        const auto soul=static_cast<std::uint32_t>(*current);
        auto variant=Variant::soulEmpty;
        if(soul>=capacity)variant=capacity>=4?Variant::grandSoulFull:Variant::soulFull;
        else if(soul>0)variant=capacity>=4?Variant::grandSoulPartial:Variant::soulPartial;
        else variant=capacity>=4?Variant::grandSoulEmpty:Variant::soulEmpty;
        const auto quality=capacity==1?qld::SoulGemQuality::petty:capacity==2?qld::SoulGemQuality::lesser:capacity==3?qld::SoulGemQuality::common:capacity==4?qld::SoulGemQuality::greater:qld::SoulGemQuality::grand;
        return qld::itemIconSpec(Category::soulGem,variant,quality);
    }
    case RE::FormType::KeyMaster: return qld::itemIconSpec(Category::key);
    case RE::FormType::Scroll: {
        Variant tintVariant=Variant::generic;
        if(auto* scroll=object->As<RE::ScrollItem>())if(auto* effect=scroll->GetAVEffect()){
            if(effect->data.primaryAV==RE::ActorValue::kResistFire)tintVariant=Variant::fireResist;
            else if(effect->data.primaryAV==RE::ActorValue::kResistShock)tintVariant=Variant::shockResist;
            else if(effect->data.primaryAV==RE::ActorValue::kResistFrost)tintVariant=Variant::frostResist;
        }
        return qld::itemIconSpec(Category::scroll,tintVariant);
    }
    case RE::FormType::Light: return qld::itemIconSpec(Category::light);
    case RE::FormType::Misc: {
        auto variant=Variant::generic;
        if(isPinnedForm(object,0x00000F))variant=Variant::gold;
        else if(isPinnedForm(object,0x00000A))variant=Variant::lockpick;
        else if(isPinnedForm(object,0x0DB5D2))variant=Variant::leather;
        else if(isPinnedForm(object,0x0800E4))variant=Variant::leatherStrips;
        else if(isPinnedForm(object,0x06851E))variant=Variant::gem;
        else if(object->HasKeywordByEditorID("BYOHAdoptionClothesKeyword"))variant=Variant::childrenClothes;
        else if(object->HasKeywordByEditorID("VendorItemDaedricArtifact"))variant=Variant::artifact;
        else if(object->HasKeywordByEditorID("VendorItemGem"))variant=Variant::gem;
        else if(object->HasKeywordByEditorID("VendorItemAnimalHide"))variant=Variant::hide;
        else if(object->HasKeywordByEditorID("VendorItemAnimalPart"))variant=Variant::remains;
        else if(object->HasKeywordByEditorID("VendorItemOreIngot"))variant=Variant::ingot;
        else if(object->HasKeywordByEditorID("VendorItemClutter"))variant=Variant::clutter;
        else if(object->HasKeywordByEditorID("VendorItemFirewood"))variant=Variant::firewood;
        constexpr RE::FormID claws[]={0x04B56C,0x0AB7BB,0x07C260,0x05AF48,0x0ED417,0x0AB375,0x08CDFA,0x0B634C,0x0999E7,0x0663D7,0x039647};
        for(const auto id:claws)if(isPinnedForm(object,id)){variant=Variant::dragonClaw;break;}
        return qld::itemIconSpec(Category::misc,variant);
    }
    default: return qld::itemIconSpec(Category::misc);
    }
}
qld::EnchantmentMarker enchantmentMarkerForEntry(RE::InventoryEntryData* selected,RE::TESBoundObject* object) {
    if(!selected||!object)return qld::EnchantmentMarker::none;
    auto* enchantable=object->As<RE::TESEnchantableForm>();
    auto* base=enchantable?enchantable->formEnchanting:nullptr;
    auto* enchant=base;
    bool sawExtra=false;
    std::int64_t represented=0;
    if(selected->extraLists)for(auto* extra:*selected->extraLists){
        if(!extra)return qld::EnchantmentMarker::none;
        const auto count=extra->GetCount();if(count<=0||represented+count>selected->countDelta)return qld::EnchantmentMarker::none;
        represented+=count;
        auto* resolved=base;
        if(auto* overrideEnchant=extra->GetByType<RE::ExtraEnchantment>();overrideEnchant&&overrideEnchant->enchantment)resolved=overrideEnchant->enchantment;
        if(!sawExtra){enchant=resolved;sawExtra=true;}
        else if((enchant?enchant->GetFormID():0)!=(resolved?resolved->GetFormID():0))return qld::EnchantmentMarker::none;
    }
    if(represented<selected->countDelta&&sawExtra&&(enchant?enchant->GetFormID():0)!=(base?base->GetFormID():0))return qld::EnchantmentMarker::none;
    auto* item=enchant?enchant->As<RE::EnchantmentItem>():nullptr;
    if(!item)return qld::EnchantmentMarker::none;
    auto* data=RE::TESDataHandler::GetSingleton();
    auto* special=data?data->LookupForm<RE::BGSKeyword>(0x0C27BD,"Skyrim.esm"):nullptr;
    bool cannotDisenchant=special&&item->HasKeyword(special);
    bool known=(item->GetFormFlags()&RE::TESForm::RecordFlags::kKnown)!=0;
    if(item->data.baseEnchantment){
        cannotDisenchant=cannotDisenchant||(special&&item->data.baseEnchantment->HasKeyword(special));
        known=known||((item->data.baseEnchantment->GetFormFlags()&RE::TESForm::RecordFlags::kKnown)!=0);
    }
    return qld::enchantmentMarker(true,known,cannotDisenchant);
}
std::pair<const char*,const char*> schoolText(RE::ActorValue skill) {
    switch(skill) {
    case RE::ActorValue::kAlteration:return {"変性","Alteration"};
    case RE::ActorValue::kConjuration:return {"召喚","Conjuration"};
    case RE::ActorValue::kDestruction:return {"破壊","Destruction"};
    case RE::ActorValue::kIllusion:return {"幻惑","Illusion"};
    case RE::ActorValue::kRestoration:return {"回復","Restoration"};
    default:return {nullptr,nullptr};
    }
}
std::optional<RE::SOUL_LEVEL> uniformSoulLevel(RE::InventoryEntryData* selected,RE::TESSoulGem* gem) {
    if(!selected || !gem || selected->countDelta<=0)return std::nullopt;
    const auto base=gem->GetContainedSoul();
    auto observed=base;
    bool hasValue=false;
    std::int64_t represented=0;
    if(selected->extraLists)for(auto* extra:*selected->extraLists){
        if(!extra)return std::nullopt;
        const auto count=extra->GetCount();
        if(count<=0 || represented+count>selected->countDelta)return std::nullopt;
        auto level=extra->GetSoulLevel();
        if(level==RE::SOUL_LEVEL::kNone)level=base;
        if(!hasValue){observed=level;hasValue=true;}
        else if(level!=observed)return std::nullopt;
        represented+=count;
    }
    if(represented<selected->countDelta){
        if(hasValue && observed!=base)return std::nullopt;
        observed=base;
    }
    return observed;
}
std::string joinedLabels(const std::vector<std::string>& values,std::string_view separator) {
    std::string out;
    for(const auto& value:values){if(!out.empty())out+=separator;out+=value;}
    return out;
}
std::string alchemyBaseEffectSummary(RE::AlchemyItem* item,bool english) {
    if(!item)return {};
    std::vector<std::string> parts;
    std::size_t visited=0;
    for(auto* effect:item->effects){
        if(visited++>=4)break;
        if(!effect || !effect->baseEffect)continue;
        const char* name=effect->baseEffect->GetFullName();
        if(!name || !*name)continue;
        std::string part=cleanText(name,96);
        const auto flags=effect->baseEffect->data.flags;
        bool hasValue=false;
        if(!flags.all(RE::EffectSetting::EffectSettingData::Flag::kNoMagnitude) &&
           std::isfinite(effect->effectItem.magnitude) && std::abs(effect->effectItem.magnitude)<=1.0e6f){
            part+=english?std::format(" (base {:.2f}",effect->effectItem.magnitude):std::format(" (基礎値 {:.2f}",effect->effectItem.magnitude);
            hasValue=true;
        }
        if(!flags.all(RE::EffectSetting::EffectSettingData::Flag::kNoDuration)){
            part+=hasValue?std::string(english?", ":"・"):" (";
            part+=english?std::format("{}s",effect->effectItem.duration):std::format("{}秒",effect->effectItem.duration);
            hasValue=true;
        }
        if(hasValue){part+=")";parts.push_back(std::move(part));}
    }
    return cleanText(joinedLabels(parts,english?"; ":"；"),420);
}
void copyExtraMetadata(CardSnapshot& card,RE::InventoryEntryData* selected,RE::TESBoundObject* object) {
    if(!selected || !object)return;
    auto category=categoryText(object->GetFormType());
    auto* alchemy=object->As<RE::AlchemyItem>();
    if(alchemy){
        category.ja=displayAlchemyCategory(alchemy->IsFood(),alchemy->IsPoison(),false).data();
        category.en=displayAlchemyCategory(alchemy->IsFood(),alchemy->IsPoison(),true).data();
    }
    const auto icon=iconSpecForNativeItem(selected,object);
    card.fields.insert_or_assign("iconLabel",std::string(icon.label));
    card.fields.insert_or_assign("iconColor",static_cast<double>(icon.hasTint?icon.tint:0xFFFFFF));
    card.fields.insert_or_assign("gold001",icon.gold001);
    card.fields.insert_or_assign("enchantMarker",static_cast<double>(static_cast<std::uint8_t>(enchantmentMarkerForEntry(selected,object))));
    card.fields.insert_or_assign("categoryJa",std::string(category.ja));
    card.fields.insert_or_assign("categoryEn",std::string(category.en));
    card.fields.insert_or_assign("displayKind",std::string(category.kind));
    card.fields.insert_or_assign("categoryPathJa",std::string(category.ja));
    card.fields.insert_or_assign("categoryPathEn",std::string(category.en));
    card.fields.insert_or_assign("questItem",selected->IsQuestObject());
    if(auto* player=RE::PlayerCharacter::GetSingleton()) {
        auto inventory=player->GetInventory([object](RE::TESBoundObject& form){return &form==object;},true);
        auto it=inventory.find(object);
        const auto count=it==inventory.end()?0:std::max(0,it->second.first);
        card.fields.insert_or_assign("ownedCount",static_cast<double>(count));
    }
    if(auto* book=object->As<RE::TESObjectBOOK>()) {
        card.fields.insert_or_assign("bookRead",book->IsRead());
        if(book->TeachesSpell()){
            if(auto* spell=book->GetSpell()){
                if(auto* player=RE::PlayerCharacter::GetSingleton())card.fields.insert_or_assign("spellLearned",player->HasSpell(spell));
                const auto [schoolJa,schoolEn]=schoolText(spell->GetAssociatedSkill());
                if(schoolJa&&schoolEn){
                    card.fields.insert_or_assign("categoryPathJa",std::format("本 > 呪文書 > {}",schoolJa));
                    card.fields.insert_or_assign("categoryPathEn",std::format("Book > Spell Tome > {}",schoolEn));
                }else{
                    card.fields.insert_or_assign("categoryPathJa",std::string("本 > 呪文書 > 系統不明"));
                    card.fields.insert_or_assign("categoryPathEn",std::string("Book > Spell Tome > School unknown"));
                }
            }else{
                card.fields.insert_or_assign("categoryPathJa",std::string("本 > 呪文書 > 詳細不明"));
                card.fields.insert_or_assign("categoryPathEn",std::string("Book > Spell Tome > School unknown"));
            }
        }else if(book->TeachesSkill()){
            card.fields.insert_or_assign("categoryPathJa",std::string("本 > 技能書"));
            card.fields.insert_or_assign("categoryPathEn",std::string("Book > Skill book"));
        }
    }
    if(auto* weapon=object->As<RE::TESObjectWEAP>()) {
        const char* ja="";const char* en="";const char* handJa=nullptr;const char* handEn=nullptr;const char* kindJa="種別不明";const char* kindEn="Type unknown";
        switch(weapon->GetWeaponType()) {
        case RE::WEAPON_TYPE::kHandToHandMelee:ja="格闘";en="Hand-to-hand";kindJa="格闘";kindEn="Hand-to-hand";break;
        case RE::WEAPON_TYPE::kOneHandSword:ja="剣";en="Sword";handJa="片手";handEn="One-handed";kindJa="剣";kindEn="Sword";break;
        case RE::WEAPON_TYPE::kOneHandDagger:ja="短剣";en="Dagger";handJa="片手";handEn="One-handed";kindJa="短剣";kindEn="Dagger";break;
        case RE::WEAPON_TYPE::kOneHandAxe:ja="片手斧";en="War axe";handJa="片手";handEn="One-handed";kindJa="斧";kindEn="Axe";break;
        case RE::WEAPON_TYPE::kOneHandMace:ja="メイス";en="Mace";handJa="片手";handEn="One-handed";kindJa="メイス";kindEn="Mace";break;
        case RE::WEAPON_TYPE::kTwoHandSword:ja="両手剣";en="Greatsword";handJa="両手";handEn="Two-handed";kindJa="剣";kindEn="Sword";break;
        case RE::WEAPON_TYPE::kTwoHandAxe:ja="両手斧";en="Battleaxe";handJa="両手";handEn="Two-handed";kindJa="斧";kindEn="Axe";break;
        case RE::WEAPON_TYPE::kBow:ja="弓";en="Bow";kindJa="弓";kindEn="Bow";break;
        case RE::WEAPON_TYPE::kStaff:ja="杖";en="Staff";kindJa="杖";kindEn="Staff";break;
        case RE::WEAPON_TYPE::kCrossbow:ja="クロスボウ";en="Crossbow";kindJa="クロスボウ";kindEn="Crossbow";break;
        default:break;
        }
        if(*ja){card.fields.insert_or_assign("weaponTypeJa",std::string(ja));card.fields.insert_or_assign("weaponTypeEn",std::string(en));}
        const auto pathJa=handJa?std::format("武器 > {} > {}",handJa,kindJa):std::format("武器 > {}",kindJa);
        const auto pathEn=handEn?std::format("Weapon > {} > {}",handEn,kindEn):std::format("Weapon > {}",kindEn);
        card.fields.insert_or_assign("categoryPathJa",pathJa);card.fields.insert_or_assign("categoryPathEn",pathEn);
        const auto weaponType=weapon->GetWeaponType();
        const bool melee=weaponType==RE::WEAPON_TYPE::kOneHandSword||weaponType==RE::WEAPON_TYPE::kOneHandDagger||
            weaponType==RE::WEAPON_TYPE::kOneHandAxe||weaponType==RE::WEAPON_TYPE::kOneHandMace||
            weaponType==RE::WEAPON_TYPE::kTwoHandSword||weaponType==RE::WEAPON_TYPE::kTwoHandAxe;
        card.fields.insert_or_assign("isMeleeWeapon",melee);
        if(std::isfinite(weapon->weaponData.speed)&&weapon->weaponData.speed>=0)
            card.fields.insert_or_assign("weaponSpeed",static_cast<double>(weapon->weaponData.speed));
        if(std::isfinite(weapon->weaponData.reach)&&weapon->weaponData.reach>=0)
            card.fields.insert_or_assign("weaponReach",static_cast<double>(weapon->weaponData.reach));
    }
    if(auto* armor=object->As<RE::TESObjectARMO>()) {
        const char* ja=armor->IsLightArmor()?"軽装":armor->IsHeavyArmor()?"重装":armor->IsClothing()?"衣服":nullptr;
        const char* en=armor->IsLightArmor()?"Light armor":armor->IsHeavyArmor()?"Heavy armor":armor->IsClothing()?"Clothing":nullptr;
        if(ja)card.fields.insert_or_assign("armorClassJa",std::string(ja));
        if(en)card.fields.insert_or_assign("armorClassEn",std::string(en));
        using Slot=RE::BGSBipedObjectForm::BipedObjectSlot;
        struct SlotName { Slot slot;const char* ja;const char* en; };
        constexpr SlotName knownSlots[]={
            {Slot::kHead,"頭","Head"},{Slot::kHair,"髪","Hair"},{Slot::kBody,"胴","Body"},{Slot::kHands,"手","Hands"},
            {Slot::kForearms,"前腕","Forearms"},{Slot::kAmulet,"首飾り","Amulet"},{Slot::kRing,"指輪","Ring"},{Slot::kFeet,"足","Feet"},
            {Slot::kCalves,"ふくらはぎ","Calves"},{Slot::kShield,"盾","Shield"},{Slot::kTail,"尾","Tail"},{Slot::kLongHair,"長髪","Long hair"},
            {Slot::kCirclet,"額飾り","Circlet"},{Slot::kEars,"耳","Ears"}
        };
        const auto mask=armor->GetSlotMask();std::vector<std::string> slotsJa,slotsEn;
        for(const auto& slot:knownSlots)if(mask.all(slot.slot)){slotsJa.emplace_back(slot.ja);slotsEn.emplace_back(slot.en);}
        constexpr Slot unknownSlots[]={Slot::kModMouth,Slot::kModNeck,Slot::kModChestPrimary,Slot::kModBack,Slot::kModMisc1,Slot::kModPelvisPrimary,
            Slot::kDecapitateHead,Slot::kDecapitate,Slot::kModPelvisSecondary,Slot::kModLegRight,Slot::kModLegLeft,Slot::kModFaceJewelry,
            Slot::kModChestSecondary,Slot::kModShoulder,Slot::kModArmLeft,Slot::kModArmRight,Slot::kModMisc2,Slot::kFX01};
        bool unknownSlot=false;
        for(const auto slot:unknownSlots)if(mask.all(slot)){unknownSlot=true;break;}
        if(unknownSlot){slotsJa.emplace_back("その他/不明");slotsEn.emplace_back("Other/unknown");}
        if(slotsJa.empty()){slotsJa.emplace_back("部位不明");slotsEn.emplace_back("Slot unknown");}
        const std::string classJa=ja?ja:"分類不明",classEn=en?en:"Class unknown";
        card.fields.insert_or_assign("categoryPathJa",std::format("防具 > {} > {}",classJa,joinedLabels(slotsJa,"・")));
        card.fields.insert_or_assign("categoryPathEn",std::format("Armor > {} > {}",classEn,joinedLabels(slotsEn," / ")));
    }
    if(alchemy){
        if(alchemy->IsPoison()){
            card.fields.insert_or_assign("categoryPathJa",std::string("薬 > 毒"));card.fields.insert_or_assign("categoryPathEn",std::string("Alchemy > Poison"));
        }else if(alchemy->IsFood()){
            card.fields.insert_or_assign("categoryPathJa",std::string("薬 > 食料"));card.fields.insert_or_assign("categoryPathEn",std::string("Alchemy > Food"));
        }else{
            card.fields.insert_or_assign("categoryPathJa",std::string("薬 > 薬"));card.fields.insert_or_assign("categoryPathEn",std::string("Alchemy > Potion"));
        }
        // Skyrim marks edible food and beverages with the same AlchemyItem food-item flag.
        const bool foodOrDrink=alchemy->IsFood();
        card.fields.insert_or_assign("isFoodOrDrink",foodOrDrink);
        if(!foodOrDrink){
            const auto ja=alchemyBaseEffectSummary(alchemy,false),en=alchemyBaseEffectSummary(alchemy,true);
            if(!ja.empty())card.fields.insert_or_assign("potionBaseEffectsJa",ja);
            if(!en.empty())card.fields.insert_or_assign("potionBaseEffectsEn",en);
        }
    }
    if(auto* ingredient=object->As<RE::IngredientItem>()){
        const auto total=static_cast<std::uint32_t>(std::min<std::size_t>(ingredient->effects.size(),4));
        if(total){
            const auto known=countKnownIngredientEffects(ingredient->gamedata.knownEffectFlags,total);
            card.fields.insert_or_assign("ingredientKnownEffects",static_cast<double>(known));
            card.fields.insert_or_assign("ingredientTotalEffects",static_cast<double>(total));
        }
    }
    if(auto* soulGem=object->As<RE::TESSoulGem>()){
        const auto capacity=static_cast<std::uint32_t>(soulGem->GetMaximumCapacity());
        if(capacity>=1&&capacity<=5){
            card.fields.insert_or_assign("soulCapacity",static_cast<double>(capacity));
            if(const auto current=uniformSoulLevel(selected,soulGem))card.fields.insert_or_assign("soulCurrent",static_cast<double>(static_cast<std::uint32_t>(*current)));
            else card.fields.insert_or_assign("soulMixed",true);
        }
    }
    if(auto* file=object->GetFile()) {
        const auto name=file->GetFilename();
        if(!name.empty()&&name.size()<=260)card.fields.insert_or_assign("pluginSource",cleanText(name,260));
    }
}
bool gameLanguageEnglish() {
    auto* collection=RE::INISettingCollection::GetSingleton();
    auto* setting=collection?collection->GetSetting("sLanguage:General"):nullptr;
    const char* text=setting?setting->GetString():nullptr;
    if(!text)return false;
    std::string language(text);
    std::transform(language.begin(),language.end(),language.begin(),[](unsigned char c){return static_cast<char>(std::tolower(c));});
    return language=="english";
}
std::optional<double> cardNumber(const CardSnapshot& card,const char* key) {
    const auto it=card.fields.find(key);
    if(it==card.fields.end())return {};
    const auto* value=std::get_if<double>(&it->second);
    if(!value || !std::isfinite(*value))return {};
    return *value;
}
std::optional<double> nativeItemCardNumber(RE::InventoryEntryData* entry,RE::GFxMovieView* view,const char* key) {
    if(!entry || !entry->object || !view)return {};
    RE::ItemCard itemCard(view);itemCard.unk28=nullptr;itemCard.unk30=0;itemCard.pad34=0;
    itemCard.SetItem(entry,false);
    if(!itemCard.obj.IsObject())return {};
    RE::GFxValue value;
    if(!itemCard.obj.GetMember(key,&value) || !value.IsNumber())return {};
    const auto number=value.GetNumber();
    if(!std::isfinite(number))return {};
    return number;
}
#if QLD_COMPARISON_DIAGNOSTICS
std::optional<qld::cmpdiag::Kind> diagnosticKindForObject(RE::TESBoundObject* object) noexcept {
    if(!object)return {};
    if(object->Is(RE::FormType::Weapon))return qld::cmpdiag::Kind::weapon;
    if(object->Is(RE::FormType::Armor))return qld::cmpdiag::Kind::armor;
    return {};
}
#endif
bool sameArmorSlotMask(const RE::TESObjectARMO& left,const RE::TESObjectARMO& right) {
    return left.GetSlotMask().underlying()==right.GetSlotMask().underlying();
}
// Only recognized helmets with exclusively head-related slots can relax auxiliary bits.
bool isComparableHeadArmor(RE::TESObjectARMO& armor) {
    using Slot=RE::BGSBipedObjectForm::BipedObjectSlot;
    constexpr auto anchors=static_cast<std::uint32_t>(Slot::kHead)|static_cast<std::uint32_t>(Slot::kHair);
    constexpr auto head=anchors|static_cast<std::uint32_t>(Slot::kLongHair)|static_cast<std::uint32_t>(Slot::kCirclet)|static_cast<std::uint32_t>(Slot::kEars);
    const auto mask=armor.GetSlotMask().underlying();
    return armor.HasKeywordByEditorID("ArmorHelmet") && (mask&anchors)!=0 && (mask&~head)==0;
}
bool sameHeadArmorRegion(RE::TESObjectARMO& left,RE::TESObjectARMO& right) {
    using Slot=RE::BGSBipedObjectForm::BipedObjectSlot;
    constexpr auto anchors=static_cast<std::uint32_t>(Slot::kHead)|static_cast<std::uint32_t>(Slot::kHair);
    return isComparableHeadArmor(left) && isComparableHeadArmor(right) &&
        (left.GetSlotMask().underlying()&right.GetSlotMask().underlying()&anchors)!=0;
}
void setEquipmentComparison(CardSnapshot& card,const char* key,double equippedMetric,std::string_view labelJa,std::string_view labelEn) {
    const auto selected=cardNumber(card,key);
#if QLD_COMPARISON_DIAGNOSTICS
    const auto diagnosticKind=std::string_view(key)=="damage"?qld::cmpdiag::Kind::weapon:qld::cmpdiag::Kind::armor;
#endif
    if(!selected){QLD_CMP_TRACE(diagnosticKind,qld::cmpdiag::Reason::selectedMetric,{},equippedMetric);return;}
    const auto difference=qld::equipmentMetricDifference(*selected,equippedMetric);
    if(!difference){QLD_CMP_TRACE(diagnosticKind,qld::cmpdiag::Reason::nonfiniteDifference,selected,equippedMetric);return;}
    card.fields.insert_or_assign("equipmentCompareJa",qld::formatEquipmentComparisonText(labelJa,*difference));
    card.fields.insert_or_assign("equipmentCompareEn",qld::formatEquipmentComparisonText(labelEn,*difference));
    QLD_CMP_TRACE(diagnosticKind,qld::cmpdiag::Reason::computed,selected,equippedMetric);
}
void addEquipmentComparison(CardSnapshot& card,RE::TESBoundObject* object,RE::GFxMovieView* view) {
    auto* player=RE::PlayerCharacter::GetSingleton();
    if(!player || !object || !view)return;
    if(object->As<RE::TESObjectWEAP>()){
        auto* equippedEntry=player->GetEquippedEntryData(false);  // Main-hand baseline only.
        auto* equippedWeapon=equippedEntry&&equippedEntry->object?equippedEntry->object->As<RE::TESObjectWEAP>():nullptr;
        if(!equippedWeapon){
            QLD_CMP_TRACE(qld::cmpdiag::Kind::weapon,qld::cmpdiag::Reason::noEquipped);return;
        }
        if(const auto metric=nativeItemCardNumber(equippedEntry,view,"damage"))
            setEquipmentComparison(card,"damage",*metric,qld::kWeaponDamageLabelJa,qld::kWeaponDamageLabelEn);
        else QLD_CMP_TRACE(qld::cmpdiag::Kind::weapon,qld::cmpdiag::Reason::equippedMetric);
        return;
    }
    auto* selectedArmor=object->As<RE::TESObjectARMO>();
    if(!selectedArmor)return;
    const auto selectedMask=selectedArmor->GetSlotMask();
    using Slot=RE::BGSBipedObjectForm::BipedObjectSlot;
    RE::TESObjectARMO* equippedArmor=nullptr;
    bool hasSlot=false;
    if(isComparableHeadArmor(*selectedArmor)){
        // Enumerate every competing worn item: a second item or accessory is ambiguous.
        auto worn=player->GetInventory([](RE::TESBoundObject& form){return form.IsArmor();},true);
        for(const auto& [form,data]:worn){
            const auto& [count,entry]=data;
            if(count<=0 || !entry || !entry->IsWorn())continue;
            auto* current=form->As<RE::TESObjectARMO>();
            if(!current || (current->GetSlotMask().underlying()&selectedMask.underlying())==0)continue;
            if(equippedArmor && equippedArmor!=current){
                QLD_CMP_TRACE(qld::cmpdiag::Kind::armor,qld::cmpdiag::Reason::multipleArmor);return;
            }
            if(!sameArmorSlotMask(*selectedArmor,*current) && !sameHeadArmorRegion(*selectedArmor,*current)){
                QLD_CMP_TRACE(qld::cmpdiag::Kind::armor,qld::cmpdiag::Reason::slotMismatch);return;
            }
            equippedArmor=current;
        }
        hasSlot=selectedMask.underlying()!=0;
    }else{
    for(std::uint32_t index=0;index<32;++index){
        const auto slot=static_cast<Slot>(std::uint32_t{1} << index);
        if(!selectedMask.all(slot))continue;
        hasSlot=true;
        auto* current=player->GetWornArmor(slot,true);
        if(!current || (equippedArmor && equippedArmor!=current)){
            QLD_CMP_TRACE(qld::cmpdiag::Kind::armor,current?qld::cmpdiag::Reason::multipleArmor:qld::cmpdiag::Reason::missingSlot);return;
        }
        equippedArmor=current;
    }
    }
    if(!hasSlot){QLD_CMP_TRACE(qld::cmpdiag::Kind::armor,qld::cmpdiag::Reason::emptyMask);return;}
    const bool sameSlots=equippedArmor && (sameArmorSlotMask(*selectedArmor,*equippedArmor) || sameHeadArmorRegion(*selectedArmor,*equippedArmor));
    if(!equippedArmor || !sameSlots){
        QLD_CMP_TRACE(qld::cmpdiag::Kind::armor,!equippedArmor?qld::cmpdiag::Reason::noEquipped:qld::cmpdiag::Reason::slotMismatch);return;
    }
    auto inventory=player->GetInventory([equippedArmor](RE::TESBoundObject& form){return &form==equippedArmor;},true);
    const auto it=inventory.find(equippedArmor);
    if(it==inventory.end() || !it->second.second){QLD_CMP_TRACE(qld::cmpdiag::Kind::armor,qld::cmpdiag::Reason::noInventory);return;}
    auto* entry=it->second.second.get();
    if(!entry->IsWorn()){QLD_CMP_TRACE(qld::cmpdiag::Kind::armor,qld::cmpdiag::Reason::unworn);return;}
    if(!entry->extraLists){QLD_CMP_TRACE(qld::cmpdiag::Kind::armor,qld::cmpdiag::Reason::extraInvalid);return;}
    std::size_t listCount=0;
    for(auto* extra:*entry->extraLists){
        if(++listCount>1 || !extra || !extra->GetWorn()){
            QLD_CMP_TRACE(qld::cmpdiag::Kind::armor,listCount>1?qld::cmpdiag::Reason::extraMultiple:qld::cmpdiag::Reason::extraInvalid);return;
        }
    }
    if(listCount!=1){QLD_CMP_TRACE(qld::cmpdiag::Kind::armor,qld::cmpdiag::Reason::extraInvalid);return;}
    if(const auto metric=nativeItemCardNumber(entry,view,"armor"))
        setEquipmentComparison(card,"armor",*metric,qld::kArmorRatingLabelJa,qld::kArmorRatingLabelEn);
    else QLD_CMP_TRACE(qld::cmpdiag::Kind::armor,qld::cmpdiag::Reason::equippedMetric);
}

}
std::vector<StackTraits> copyStackTraits(RE::InventoryEntryData* entry) {
    std::vector<StackTraits> traits;
    if(!entry || !entry->object)return traits;
    auto* enchantable=entry->object->As<RE::TESEnchantableForm>();auto* base=enchantable?enchantable->formEnchanting:nullptr;
    if(entry->extraLists)for(auto* list:*entry->extraLists){
        if(!list)continue;
        auto* health=list->GetByType<RE::ExtraHealth>();auto* enchant=list->GetByType<RE::ExtraEnchantment>();
        auto* resolved=enchant && enchant->enchantment?enchant->enchantment:base;
        traits.push_back({health?health->health:1.0,resolved?resolved->GetFormID():0,list->GetCount()});
    }
    std::sort(traits.begin(),traits.end(),[](const auto& a,const auto& b){return std::tie(a.health,a.enchantment,a.count)<std::tie(b.health,b.enchantment,b.count);});
    return traits;
}
static std::optional<CardSnapshot> copyNativeCard(RE::InventoryEntryData* entry,RE::ObjectRefHandle drop,RE::GFxMovieView* view) {
    auto fail=[&](const char* stage)->std::optional<CardSnapshot>{SKSE::log::warn("CARD_COPY_FAILED stage={} form={:08x} thread={} context=owned-menu-advance",stage,entry && entry->object?entry->object->GetFormID():0,GetCurrentThreadId());return {};};
    if(!entry || !entry->object || entry->countDelta<=0 || !view)return fail("selection-or-movie");
    // This private helper runs synchronously inside the owning menu's AdvanceMovie.
    // Skyrim can execute consecutive UI updates on different worker threads.
    if(!RE::PlayerCharacter::GetSingleton()){
#if QLD_COMPARISON_DIAGNOSTICS
        if(const auto kind=diagnosticKindForObject(entry->object))QLD_CMP_TRACE(*kind,qld::cmpdiag::Reason::noPlayer);
#endif
        return fail("player");
    }
    auto* object=entry->object;
    auto reference=drop.get();RE::InventoryEntryData droppedEntry(object,entry->countDelta);auto* selected=entry;
    if(drop.native_handle()!=0){
        if(!reference || reference->IsDeleted() || reference->GetObjectReference()!=object)return fail("drop-reference");
        droppedEntry.AddExtraList(&reference->extraList);selected=&droppedEntry;
    }
    if(object->Is(RE::FormType::Weapon) || object->Is(RE::FormType::Armor)){
        auto* enchantable=object->As<RE::TESEnchantableForm>();auto* base=enchantable?enchantable->formEnchanting:nullptr;
        auto traits=copyStackTraits(selected);
        if(!consistentStack(traits,selected->countDelta,{1.0,base?base->GetFormID():0,1}))return fail("ambiguous-individual");
    }
    // Pinned CommonLib ABI: sizeof(ItemCard)==0x40; documented SetItem relocation 51019 (SE).
    // No raw ESP parsing, guessed addresses, magic-effect template expansion, or base-value fallback.
    RE::ItemCard native(view);native.unk28=nullptr;native.unk30=0;native.pad34=0;
    native.SetItem(selected,false);
    if(!native.obj.IsObject())return fail("native-object");
    CardSnapshot card;
    constexpr const char* keys[]={"name","count","type","weight","value","damage","armor","effects","description","skillText","skillName","stolen","poisoned","upperCaseName","negativeEffect","numItemEffects","itemEffect0","itemEffect1","itemEffect2","itemEffect3","soulLVL","usedCharge","charge"};
    for(const auto* key:keys){
        RE::GFxValue value;if(!native.obj.GetMember(key,&value))continue;
        if(value.IsString())card.fields.emplace(key,std::string(value.GetString()?value.GetString():""));
        else if(value.IsStringW()){
            const auto* source=value.GetStringW();if(!source)return fail("null-wide-string");
            const int length=WideCharToMultiByte(CP_UTF8,WC_ERR_INVALID_CHARS,source,-1,nullptr,0,nullptr,nullptr);
            if(length<=0 || length>65537)return fail("wide-string-encoding-or-limit");
            std::string text(length,'\0');
            if(WideCharToMultiByte(CP_UTF8,WC_ERR_INVALID_CHARS,source,-1,text.data(),length,nullptr,nullptr)!=length)return fail("wide-string-copy");
            text.pop_back();card.fields.emplace(key,std::move(text));
        }
        else if(value.IsNumber())card.fields.emplace(key,value.GetNumber());
        else if(value.IsBool())card.fields.emplace(key,value.GetBool());
        else if(!value.IsUndefined() && !value.IsNull())return fail("unexpected-field-type");
    }
    // Native final display-name getter is the same selected InventoryEntryData; no BaseForm lookup.
    if(!card.fields.contains("name")){
        const auto* name=selected->GetDisplayName();if(!name || !*name)return fail("display-name");
        card.fields.emplace("name",std::string(name));
    }
    if(!card.fields.contains("count"))card.fields.emplace("count",double(selected->countDelta));
    // BOOK can omit an empty CNAM; determine true emptiness using the dedicated card field, NEVER DESC.
    if(auto* book=object->As<RE::TESObjectBOOK>();book && !card.fields.contains("description")){
        RE::BSString description;book->itemCardDescription.GetDescription(description,book,'MANC');
        if(description.length()!=0)return fail("book-cnam-not-in-native-card");
        card.fields.emplace("description",std::string{});
    }
    // Optional ingredient slots mean unknown/absent, as in standard card; never read MGEF names ourselves.
    if(auto it=card.fields.find("type");it!=card.fields.end() && std::get_if<double>(&it->second) && std::get<double>(it->second)==8)
        for(const char* key:{"itemEffect0","itemEffect1","itemEffect2","itemEffect3"})if(!card.fields.contains(key))card.fields.emplace(key,std::string{});
    copyExtraMetadata(card,selected,object);
    if(drop.native_handle()==0)addEquipmentComparison(card,object,view);
#if QLD_COMPARISON_DIAGNOSTICS
    else if(const auto kind=diagnosticKindForObject(object))QLD_CMP_TRACE(*kind,qld::cmpdiag::Reason::dropped);
#endif
    if(!validCard(card))return fail("native-field-contract");
    auto bytes=[&](const char* key){auto it=card.fields.find(key);return it!=card.fields.end() && std::get_if<std::string>(&it->second)?std::get<std::string>(it->second).size():0;};
    if(auto it=card.fields.find("effects");it!=card.fields.end() && std::get_if<std::string>(&it->second)){
        const auto normalized=normalizeNativeText(std::get<std::string>(it->second));
        if(!normalized.ok){SKSE::log::warn("CARD_TEXT_FAILED form={:08x} stage={} originalBytes={}",object->GetFormID(),normalized.error,std::get<std::string>(it->second).size());return {};}
        card.fields.emplace("effectsPlain",normalized.text);
        if(normalized.unsupportedTags || normalized.unknownEntities)SKSE::log::warn("CARD_TEXT_WARNING form={:08x} unsupportedTags={} unknownEntities={} native-inner-text-preserved=true",object->GetFormID(),normalized.unsupportedTags,normalized.unknownEntities);
    }
    if(std::get<double>(card.fields.at("type"))==8){
        const auto count=std::get<double>(card.fields.at("numItemEffects"));
        for(int slot=0;slot<4;++slot){
            const auto& text=std::get<std::string>(card.fields.at("itemEffect"+std::to_string(slot)));
            SKSE::log::debug("CARD_INGREDIENT_SLOT slot={} nativeCount={} state={}",slot,count,!text.empty()?"known":slot<count?"unknown":"absent");
        }
    }
    SKSE::log::debug("CARD_COPY_OK route=ItemCard.SetItem type={} descriptionBytes={} effectsBytes={} fields={}",std::get<double>(card.fields.at("type")),bytes("description"),bytes("effects"),card.fields.size());
    // Every GFx/entry/reference pointer dies here. Only owned strings/numbers/bools cross into State.
    return card;
}
std::optional<CardSnapshot> resolveNativeCard(const Item& item,RE::GFxMovieView* view) {
    auto fail=[&](const char* stage)->std::optional<CardSnapshot>{SKSE::log::warn("CARD_RESOLVE_FAILED stage={} form={:08x} selection={}",stage,item.formId,item.stackIdentity);return {};};
    if(!view || !item.formId || item.count<=0)return fail("selection-or-own-movie");
    auto container=RE::TESObjectREFR::LookupByHandle(item.container);
    if(!container || container->IsDeleted())return fail("container-handle");
    auto* object=RE::TESForm::LookupByID<RE::TESBoundObject>(item.formId);if(!object)return fail("form-id");
    auto finish=[&](RE::InventoryEntryData* entry,RE::ObjectRefHandle drop)->std::optional<CardSnapshot>{
        const auto* name=entry->GetDisplayName();
        if(entry->countDelta!=item.count || (name?name:"")!=item.selectedName || copyStackTraits(entry)!=item.selectedTraits)return fail("selection-changed");
        SKSE::log::debug("CARD_RESOLVED form={:08x} selection={} thread={} context=owned-menu-advance",item.formId,item.stackIdentity,GetCurrentThreadId());
        return copyNativeCard(entry,drop,view);
    };
    if(item.dropHandle){
        auto ref=RE::TESObjectREFR::LookupByHandle(item.dropHandle);
        if(!ref || ref->IsDeleted() || ref->IsDisabled() || ref->GetObjectReference()!=object)return fail("drop-handle");
        RE::InventoryEntryData traitsEntry(object,ref->extraList.GetCount());traitsEntry.AddExtraList(&ref->extraList);
        if(copyStackTraits(&traitsEntry)!=item.dropTraits)return fail("drop-individual-changed");
        RE::InventoryEntryData entry(object,ref->extraList.GetCount());
        // IE drop entries intentionally contain no ExtraDataList. Compare that same selector shape;
        // copyNativeCard attaches the freshly resolved reference only for synchronous native generation.
        return finish(&entry,ref->GetHandle());
    }
    // Match IE's changed+base container count. noInit=true avoids initializing/mutating inventory here.
    auto inventory=container->GetInventory([&](RE::TESBoundObject& form){return &form==object;},true);
    auto it=inventory.find(object);if(it==inventory.end() || !it->second.second)return fail("entry-missing");
    auto* entry=it->second.second.get();entry->countDelta=it->second.first;
    return finish(entry,{});
}
std::optional<WorldTarget> inspectWorldTarget(RE::ObjectRefHandle handle) {
    if(!handle)return {};
    auto ref=handle.get();
    if(!ref || ref->IsDeleted() || ref->IsDisabled() || ref->IsActivationBlocked() || !ref->GetParentCell() || !ref->Get3D())return {};
    auto* object=ref->GetBaseObject();if(!object || !object->IsInventoryObject())return {};
    switch(object->GetFormType()){
    case RE::FormType::Weapon: case RE::FormType::Armor:
        if(object->GetFormFlags() & RE::TESForm::RecordFlags::kNonPlayable)return {};
        break;
    case RE::FormType::Light:
        if(!object->As<RE::TESObjectLIGH>()->CanBeCarried())return {};
        break;
    case RE::FormType::Scroll: case RE::FormType::Book: case RE::FormType::Ingredient:
    case RE::FormType::Misc: case RE::FormType::Apparatus: case RE::FormType::Ammo:
    case RE::FormType::KeyMaster: case RE::FormType::AlchemyItem: case RE::FormType::SoulGem:
        break;
    default:return {}; // Never actors/containers/doors/furniture/harvest activators/leveled lists.
    }
    const auto count=ref->extraList.GetCount();if(count<=0)return {};
    // Ownership intentionally does not filter an otherwise normal pickup target.
    return WorldTarget{handle.native_handle(),ref->GetFormID(),object->GetFormID(),count};
}
std::optional<CardSnapshot> resolveWorldCard(const WorldTarget& target,RE::GFxMovieView* view) {
    auto* pick=RE::CrosshairPickData::GetSingleton();
    if(!view || !pick || pick->GetActiveTarget().native_handle()!=target.handle)return {};
    const auto handle=pick->GetActiveTarget();
    if(inspectWorldTarget(handle)!=std::optional<WorldTarget>(target))return {};
    auto ref=handle.get();if(!ref)return {};
    auto* object=ref->GetBaseObject();
    RE::InventoryEntryData entry(object,target.count);
    // The existing dropped-reference path attaches this reference's ExtraDataList
    // synchronously, and deletes only its temporary pointer-list nodes afterwards.
    // No GetInventory, activation, ownership modification, or ExtraData write.
    SKSE::log::debug("WORLD_CARD_RESOLVE reference={:08x} base={:08x} count={} route=reference-extraList thread={}",target.referenceId,target.baseId,target.count,GetCurrentThreadId());
    auto card=copyNativeCard(&entry,handle,view);
    if(pick->GetActiveTarget().native_handle()!=target.handle || inspectWorldTarget(handle)!=std::optional<WorldTarget>(target))return {};
    return card;
}
std::string qldBookReadLabel(const CardSnapshot& card,const CardDisplaySettings& display,bool english) {
    if(!display.enabled || !display.bookRead)return {};
    const auto type=card.fields.find("type");const auto read=card.fields.find("bookRead");
    if(type==card.fields.end() || read==card.fields.end())return {};
    const auto* number=std::get_if<double>(&type->second);const auto* flag=std::get_if<bool>(&read->second);
    if(!number || *number!=4 || !flag)return {};
    return english?(*flag?"Read":"Unread"):(*flag?"既読":"未読");
}
bool makeCardObject(RE::GFxMovieView* view,const CardSnapshot& card,const CardDisplaySettings& requested,RE::GFxValue& out) {
    if(!view || !validCard(card))return false;
    auto display=requested;display.normalize();
    view->CreateObject(&out);if(!out.IsObject())return false;
    for(const auto& [name,value]:card.fields){
        RE::GFxValue member;
        if(auto v=std::get_if<double>(&value))member=RE::GFxValue(*v);
        else if(auto flag=std::get_if<bool>(&value))member=RE::GFxValue(*flag);
        else member=RE::GFxValue(std::get<std::string>(value).c_str());
        if(!out.SetMember(name.c_str(),member))return false;
    }
    std::string category;
    if(display.enabled&&display.category){
        const auto it=card.fields.find(gameLanguageEnglish()?"categoryEn":"categoryJa");
        if(it!=card.fields.end())if(const auto* text=std::get_if<std::string>(&it->second))category=cleanText(*text,80);
    }
    auto detailsDisplay=display;detailsDisplay.category=false;detailsDisplay.bookRead=false;
    const auto bookReadText=qldBookReadLabel(card,display,gameLanguageEnglish());
    std::string details;
    const auto detailRows=buildCardInfoRows(card,detailsDisplay,gameLanguageEnglish());
    for(const auto& row:detailRows){if(!details.empty())details.push_back('\n');details+=row;}
#if QLD_COMPARISON_DIAGNOSTICS
    if(const auto type=cardNumber(card,"type");type && (*type==1 || *type==2)){
        const auto kind=*type==1?qld::cmpdiag::Kind::armor:qld::cmpdiag::Kind::weapon;
        const auto it=card.fields.find(gameLanguageEnglish()?"equipmentCompareEn":"equipmentCompareJa");
        const auto* comparison=it==card.fields.end()?nullptr:std::get_if<std::string>(&it->second);
        const bool hasField=comparison && !comparison->empty();
        const bool included=hasField && std::find(detailRows.begin(),detailRows.end(),*comparison)!=detailRows.end();
        const auto iconIt=card.fields.find("iconLabel");
        const auto* icon=iconIt==card.fields.end()?nullptr:std::get_if<std::string>(&iconIt->second);
        const bool iconKnown=icon && isKnownItemIconLabel(*icon);
        qld::cmpdiag::row(kind,hasField,included,display.enabled,display.equipmentDetails,!category.empty(),display.showIcons,iconKnown,display.maxRows);
    }
#endif
    std::string iconLabel{"default_misc"};
    if(const auto it=card.fields.find("iconLabel");it!=card.fields.end()){
        if(const auto* label=std::get_if<std::string>(&it->second);label&&isKnownItemIconLabel(*label))iconLabel=*label;
    }
    const auto set=[&](const char* name,RE::GFxValue value){return out.SetMember(name,value);};
    if(!set("bookReadText",RE::GFxValue(bookReadText.c_str())) ||
       !set("detailText",RE::GFxValue(details.c_str())) ||
       !set("categoryText",RE::GFxValue(category.c_str())) ||
       !set("showCategory",RE::GFxValue(!category.empty())) ||
       !set("iconLabel",RE::GFxValue(iconLabel.c_str())) ||
       !set("detailFontScale",RE::GFxValue(display.fontScale)) ||
       !set("languageEnglish",RE::GFxValue(gameLanguageEnglish())) ||
       !set("showValueWeight",RE::GFxValue(display.enabled&&display.valueWeight)) ||
       !set("showEquipmentDetails",RE::GFxValue(display.enabled&&display.equipmentDetails)) ||
       !set("showPotionDetails",RE::GFxValue(display.enabled&&display.potionDetails)) ||
       !set("showIngredientEffects",RE::GFxValue(display.enabled&&display.ingredientEffects)) ||
       !set("showIcons",RE::GFxValue(!category.empty()&&display.showIcons)))return false;
    return true;
}
}

namespace qld {
std::optional<CardSnapshot> copyLegacyNativeCard(RE::InventoryEntryData* borrowed,RE::ObjectRefHandle drop,std::int32_t count,RE::GFxMovieView* view) {
    static_assert(sizeof(RE::InventoryEntryData)==0x18 && sizeof(RE::ItemCard)==0x40);
    if(!borrowed || !borrowed->object || count<=0)return {};
    RE::InventoryEntryData owned(*borrowed);
    owned.countDelta=count;
    return copyNativeCard(&owned,drop,view);
}
}
