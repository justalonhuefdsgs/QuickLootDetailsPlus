from __future__ import annotations
import hashlib,json,pathlib,subprocess,sys,zipfile
from package_audit import ROOT,RUNTIME,source_allowed,runtime_allowed,RUNTIME_DOC_ROOTS,RUNTIME_DOCS,LICENSES
DIST=ROOT/'dist'
PRIVATE_RUNTIME='QuickLootDetails-0.1.20-r2-text-032-private-testpack.zip'
PRIVATE_SOURCE='QuickLootDetails-0.1.20-r2-text-032-private-source.zip'

def sha_bytes(data:bytes)->str:return hashlib.sha256(data).hexdigest()
def sha_file(path:pathlib.Path)->str:return sha_bytes(path.read_bytes())
def write_archive(path:pathlib.Path,files:dict[str,pathlib.Path],manifest_name:str)->None:
    manifest={name:sha_file(file) for name,file in sorted(files.items())}
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for name,file in sorted(files.items()):
            info=zipfile.ZipInfo(name,(2026,10,7,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
            archive.writestr(info,file.read_bytes())
        info=zipfile.ZipInfo(manifest_name,(2026,10,7,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
        archive.writestr(info,json.dumps(manifest,indent=2).encode('utf-8'))

def verify_candidate()->dict:
    proof=json.loads((ROOT/'docs/verification.json').read_text(encoding='utf-8'))
    if proof.get('task')!='QLD-TEXT-CANDIDATE-GATE-032':raise RuntimeError('Unexpected candidate task identity')
    static=proof.get('STATIC',{})
    if static.get('status')!='PASS_COMPOSITE_INHERITED_BASE_AND_CURRENT_ROUTE_DELTA':
        raise RuntimeError('Required inherited-base/current-route static evidence is absent')
    if static.get('r2_static_build_id')!='QLD-0.1.20-r2-b3b24d35bd9c9f5c' or static.get('r2_static_check_count')!=130:
        raise RuntimeError('Frozen r2 full static baseline identity is absent')
    for name in ('UI_SOURCE','COMPILED_AS2_PROTOCOL','ROUTE_GENERATION','AVM1_BINARY','MCM_LOCALIZATION'):
        if proof.get('TESTS',{}).get(name,{}).get('status')!='PASS':raise RuntimeError('Current route host check is not PASS: '+name)
    if proof.get('TESTS',{}).get('CTest',{}).get('status')!='INHERITED_PASS_12_OF_12_FROM_028_SOURCE_TREE_NOT_RUN_IN_030_OR_032':
        raise RuntimeError('CTest must remain explicitly inherited, not claimed as a current run')
    if proof.get('route',{}).get('default')!='text':raise RuntimeError('Private testpack is not text-default')
    if proof.get('STATIC',{}).get('current_032_static_components',{}).get('status')!='PASS' or proof['STATIC']['current_032_static_components'].get('checks')!=105:
        raise RuntimeError('Current 032 static component checks are incomplete')
    component_path=ROOT/'build/verification-032-static-components.json'
    if not component_path.is_file() or sha_file(component_path)!=proof['STATIC']['current_032_static_components'].get('evidence_sha256'):
        raise RuntimeError('Current 032 static component evidence hash mismatch')
    for relative,digest in proof.get('artifacts',{}).items():
        path=ROOT/relative
        if not path.is_file() or sha_file(path)!=digest:raise RuntimeError('Candidate artifact hash mismatch: '+relative)
    source_json=json.loads((ROOT/'build/assets/source-manifest.json').read_text(encoding='utf-8'))
    if len(source_json)!=15 or sha_file(ROOT/'build/assets/source-manifest.json')!=proof['BUILD']['build_input_manifest']['sha256']:
        raise RuntimeError('UI build-input manifest mismatch')
    if (ROOT/'build/assets/Interface/QuickLootDetails.swf').stat().st_size!=24494:
        raise RuntimeError('Unexpected current text-route SWF size')
    for key,digest in proof['BUILD']['inherited_runtime_artifacts'].items():
        if proof['artifacts'].get(key)!=digest:raise RuntimeError('Inherited artifact record mismatch: '+key)
    if not (ROOT/'licenses/QuickLootIE-GPL-3.0.txt').is_file() or not (ROOT/'licenses/QuickLootIE-EXCEPTIONS.md').is_file():
        raise RuntimeError('QuickLoot IE GPL/exception corresponding notices are missing')
    return proof

def main()->None:
    proof=verify_candidate()
    DIST.mkdir(exist_ok=True)
    runtime_path=DIST/PRIVATE_RUNTIME;source_path=DIST/PRIVATE_SOURCE
    if runtime_path.exists() or source_path.exists():raise RuntimeError('Refusing to overwrite an existing 032 package output')
    runtime_files={name:(ROOT/'build/native/plugin/QuickLootDetails.dll' if name.endswith('.dll') else ROOT/'build/assets'/name) for name in RUNTIME}
    for name in RUNTIME_DOC_ROOTS:runtime_files['QuickLootDetails_Docs/'+name]=ROOT/name
    for name in RUNTIME_DOCS:runtime_files['QuickLootDetails_Docs/docs/'+name]=ROOT/'docs'/name
    for name in LICENSES:runtime_files['QuickLootDetails_Docs/licenses/'+name]=ROOT/'licenses'/name
    if not all(runtime_allowed(name) and path.is_file() for name,path in runtime_files.items()):
        raise RuntimeError('Runtime package allowlist or required file check failed')
    write_archive(runtime_path,runtime_files,'QuickLootDetails_Docs/manifest.json')
    source_files={}
    for folder in ('src','include','tests','cmake','ui','scripts','assets','docs','licenses','tools','vendor'):
        for path in (ROOT/folder).rglob('*'):
            if path.is_file() and source_allowed(path.relative_to(ROOT).as_posix()):
                source_files['QuickLootDetails/'+path.relative_to(ROOT).as_posix()]=path
    for path in ROOT.iterdir():
        if path.is_file() and path.name!='source-manifest.json' and source_allowed(path.name):
            source_files['QuickLootDetails/'+path.name]=path
    for spec in json.loads((ROOT/'dependencies.json').read_text(encoding='utf-8'))['archives']:
        path=ROOT/'deps'/spec['file']
        if sha_file(path)!=spec['sha256']:raise RuntimeError('Pinned dependency archive hash mismatch: '+path.name)
        source_files['QuickLootDetails/deps/'+path.name]=path
    source_manifest={name:sha_file(path) for name,path in sorted(source_files.items())}
    (ROOT/'source-manifest.json').write_text(json.dumps(source_manifest,indent=2)+'\n',encoding='utf-8')
    if len(source_manifest)!=106:raise RuntimeError('Unexpected source manifest entry count: '+str(len(source_manifest)))
    write_archive(source_path,source_files,'QuickLootDetails/source-manifest.json')
    (ROOT/'build/verification.json').write_text(json.dumps({'status':proof['STATIC']['status'],'check_count':proof['STATIC']['r2_static_check_count'],'artifacts':proof['artifacts']},indent=2)+'\n',encoding='utf-8')
    report={'candidate':'QLD-TEXT-CANDIDATE-GATE-032','package_kind':'private_review_testpack','version':'0.1.20-r2-text-route-032','build_id':proof['build_id'],'runtime_zip':{'path':runtime_path.name,'bytes':runtime_path.stat().st_size,'sha256':sha_file(runtime_path)},'source_zip':{'path':source_path.name,'bytes':source_path.stat().st_size,'sha256':sha_file(source_path)},'BUILD':proof['BUILD']['status'],'AUTOMATED_TESTS':'PASS current UI/source/protocol/route/AVM1/MCM checks; native CTest inherited 12/12 from 028 and NOT_RUN in 030/032','STATIC':proof['STATIC']['status'],'ARCHIVE_AUDIT':'PENDING','LOAD':'NOT_TESTED','RUNTIME':'NOT_TESTED','HUMAN':'NOT_TESTED','DEPLOY':'NOT_PERFORMED','PUBLICATION':'NOT_PERFORMED'}
    (DIST/'package-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    subprocess.run([sys.executable,str(ROOT/'tools/package_audit.py')],check=True,cwd=ROOT)
    report=json.loads((DIST/'package-report.json').read_text(encoding='utf-8'))
    print(json.dumps(report,ensure_ascii=False,indent=2))
if __name__=='__main__':main()