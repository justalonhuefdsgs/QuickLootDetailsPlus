stop();
function InitExtensions() { _global.gfxExtensions = true; }
function SetPlatform(platform, ps3Switch) { }
function qldProbe() { return "QLD_UI_0.1.20-065"; }
// Build-time route selector; AS2 var is mutable, but no runtime/MCM route control is exposed.
// "text" is the permission-independent default. Changing this value requires a rebuild.
var QLD_CATEGORY_ICON_ROUTE = "text";
function qldUsesSkyUIIconRoute() { return QLD_CATEGORY_ICON_ROUTE == "skyui"; }
function qldUsesOwnedIconRoute() { return QLD_CATEGORY_ICON_ROUTE == "owned-svg"; }
function qldUsesCategoryIconRoute() { return qldUsesSkyUIIconRoute() || qldUsesOwnedIconRoute(); }
var panel = this.createEmptyMovieClip("details", 1);
panel._visible = false;
var background = panel.createEmptyMovieClip("background", 1);
var border = panel.createEmptyMovieClip("border", 2);
var content = panel.createEmptyMovieClip("content", 3);
var divider = content.createEmptyMovieClip("divider", 9);
var categoryIcon = content.createEmptyMovieClip("categoryIcon", 12);
categoryIcon._visible = false;
var categoryIconTint = new Color(categoryIcon);
var iconLoader = new MovieClipLoader();
var iconLoadStarted = false;
var iconLoadFailed = false;
var iconLoaded = false;
var iconRequestedVisible = false;
var iconRequestGeneration = 0;
var iconLoadGeneration = -1;
var iconLabel = "default_misc";
var iconAppliedLabel = "";
var iconFailedLabel = "";
var iconColor = 0xFFFFFF;
var currentTitleCard = null;
var currentTitleWidth = 0;
var currentTitleFontSize = 18;
var currentTitleHeight = 0;
var qldLongCardPreferredHeight = 279;
iconLoader.addListener(this);
content.createTextField("title", 1, 16, 12, 268, 48);
content.createTextField("stats", 2, 16, 66, 268, 26);
content.createTextField("description", 3, 16, 106, 268, 100);
var fieldIndex = 0;
while (fieldIndex < 4) {
    content.createTextField("effect" + fieldIndex, 4 + fieldIndex, 16, 106, 126, 26);
    fieldIndex += 1;
}
content.createTextField("measurement", 10, 0, 0, 268, 10);
content.measurement._visible = false;
content.createTextField("detailInfo", 11, 16, 0, 268, 10);
content.detailInfo._visible = false;
content.createTextField("category", 13, 16, 0, 268, 28);
content.category._visible = false;
function qldFormat(size, color) {
    var format = new TextFormat("$EverywhereMediumFont", size, color == undefined ? 0xFFFFFF : color);
    format.leading = 2; format.align = "center";
    return format;
}
function qldMeasureText(text, width, size, wrap) {
    var field = content.measurement;
    field.html = false; field.multiline = true; field.wordWrap = wrap;
    field.autoSize = "none"; field._width = Math.max(1, width);
    var format = qldFormat(size); field.setNewTextFormat(format);
    field.text = text; field.setTextFormat(format); field.autoSize = "left";
    var measured = {width:field.textWidth, height:field.textHeight, fieldHeight:field._height, plain:field.text};
    field.autoSize = "none";
    return measured;
}
function qldFullTextMetrics(field, text, size, width, color) {
    // This is the actual displayed field, with exactly the render font/width/wrapping.
    field.autoSize = "none"; field.html = false; field.multiline = true;
    field.wordWrap = true; field.selectable = false; field._width = width;
    var format = qldFormat(size, color); field.setNewTextFormat(format);
    field.text = text; field.setTextFormat(format); field.autoSize = "left";
    var measured = {width:field.textWidth, height:field.textHeight, fieldHeight:field._height};
    field.autoSize = "none";
    return measured;
}
function qldSetFullText(field, text, size, width, height, color) {
    var measured = qldFullTextMetrics(field, text, size, width, color);
    field._height = height; // The full string stays unchanged; only physical screen space can clip it.
    measured.clipped = measured.fieldHeight > height + 0.01;
    return measured;
}
function qldSetAdaptiveDescriptionText(field, text, size, width, height, color) {
    var minimumSize = qldDescriptionFontFloor(size);
    var selectedSize = size;
    var measured = qldFullTextMetrics(field, text, selectedSize, width, color);
    while (measured.fieldHeight > height + 0.01 && selectedSize > minimumSize) {
        selectedSize = Math.max(minimumSize, selectedSize - 1);
        measured = qldFullTextMetrics(field, text, selectedSize, width, color);
    }
    field._height = height;
    measured.fontSize = selectedSize;
    measured.clipped = measured.fieldHeight > height + 0.01;
    return measured;
}
function qldCardTitle(card) {
    var text = card.name;
    if (card.count > 1) text += " (" + card.count + ")";
    return card.upperCaseName == false ? text : text.toUpperCase();
}
function qldCardStats(card, width) {
    var text = "";
    var narrow = width != undefined && width < 220;
    if (card.showEquipmentDetails != false) {
        if (card.type == 1) text = (card.languageEnglish ? (narrow ? "AR " : "Armor ") : (narrow ? "\u9632" : "\u9632\u5fa1\u529b ")) + card.armor;
        if (card.type == 2) text = (card.languageEnglish ? (narrow ? "DMG " : "Damage ") : (narrow ? "\u653b" : "\u653b\u6483\u529b ")) + card.damage;
    }
    if (card.showValueWeight != false || card.gold001 == true || card.isGold001 == true) {
        var weight = Math.round(card.weight * 100) / 100;
        var weightLabel = card.languageEnglish ? (narrow ? "Wt" : "Weight") : (narrow ? "\u91cd" : "\u91cd\u91cf");
        var valueLabel = card.languageEnglish ? (narrow ? "Val" : "Value") : (narrow ? "\u4fa1" : "\u91d1\u984d");
        if (text != "") text += "  ";
        if (card.gold001 == true || card.isGold001 == true) {
            var colon = card.languageEnglish ? ":" : "\uff1a";
            text += valueLabel + " " + card.value + "  " + weightLabel + colon + " \u30fc  V/W" + colon + " \u30fc";
        } else {
            text += valueLabel + " " + card.value + "  " + weightLabel + " " + weight;
            var ratio = (typeof card.weight == "number" && card.weight == 0) ? "\u30fc" : "\u2014";
            if (isFinite(card.weight) && card.weight > 0 && isFinite(card.value) && card.value >= 0)
                ratio = Math.round((card.value / card.weight) * 100) / 100;
            text += "  V/W " + ratio;
        }
    }
    return text;
}
function qldCardDescription(card) {
    if (card.type == 4) {
        var description = card.description == undefined ? "" : card.description;
        var readText = card.bookReadText;
        if (typeof readText == "string" && readText != "") return readText + (description != "" ? "\n" + description : "");
        return description;
    }
    if ((card.displayKind == "alchemy" || card.type == 3) && card.showPotionDetails == false) return "";
    if (card.type == 8 && card.showIngredientEffects == false) return card.description == undefined ? "" : card.description;
    return card.effectsPlain == undefined ? "" : card.effectsPlain;
}
function qldIngredientCell(card, index) {
    var text = card["itemEffect" + index];
    if (text != undefined && text != "") return {text:text, color:0xFFFFFF, known:true};
    if (index < card.numItemEffects) return {text:card.languageEnglish ? "Unknown" : "不明", color:0x999999, known:false};
    return {text:"", color:0x999999, known:false};
}
function qldHeader(card, width, fontSize) {
    var categoryText = card.categoryText == undefined ? "" : card.categoryText;
    var categoryVisible = card.showCategory != false && categoryText != "";
    var titleIconVisible = qldUsesCategoryIconRoute() && categoryVisible && card.showIcons != false && width >= 88;
    var markerVisible = false;
    var readVisible = false;
    var titleWidth = Math.max(1, width - 32 - (titleIconVisible ? 28 : 0));
    var measured = qldMeasureText(qldCardTitle(card), titleWidth, fontSize, true);
    var titleHeight = Math.min(2 * (fontSize + 2) + 4, Math.max(fontSize + 6, measured.height + 4));
    var dividerY = 12 + titleHeight + 3;
    var majorFont = Math.max(9, fontSize * 0.9); var statsTop = dividerY + 3; var statsHeight = Math.max(majorFont + 4, qldFullTextMetrics(content.measurement, qldCardStats(card, width), majorFont, width - 32).fieldHeight);
    var categoryHeight = categoryVisible ? Math.max(22, majorFont + 8) : 0;
    var categoryTop = statsTop + statsHeight;
    var categoryX = 16;
    var detailTop = categoryVisible ? categoryTop + categoryHeight + 1 : statsTop + statsHeight + 4;
    var detailText = qldEquipmentDisplay(card.detailText, card.languageEnglish ? card.equipmentCompareEn : card.equipmentCompareJa).detail;
    var detailFont = Math.max(8, Math.min(qldSmallFontSize(fontSize), qldSmallFontSize(fontSize) * (card.detailFontScale == undefined ? 1 : card.detailFontScale / 0.9)));
    var detailHeight = 0;
    if (detailText != "") {
        var info = qldFullTextMetrics(content.measurement, detailText, detailFont, width - 32);
        detailHeight = Math.max(detailFont + 4, info.fieldHeight + 4);
    }
    return {titleHeight:titleHeight, titleWidth:titleWidth, titleIconVisible:titleIconVisible, markerVisible:markerVisible, readVisible:readVisible, dividerY:dividerY, statsTop:statsTop, statsHeight:statsHeight, majorFont:majorFont, categoryTop:categoryTop, categoryHeight:categoryHeight, categoryX:categoryX, detailTop:detailTop, detailFont:detailFont, detailHeight:detailHeight, descriptionTop:detailTop + (detailHeight > 0 ? detailHeight + 4 : 4)};
}
function qldGridMetrics(card, width, fontSize) {
    fontSize = qldSmallFontSize(fontSize);
    var columnGap = Math.max(16, fontSize * 0.9);
    var cellWidth = (width - 32 - columnGap) / 2;
    var rowGap = Math.max(8, fontSize * 0.45);
    var row0 = fontSize + 8;
    var row1 = fontSize + 8;
    var index = 0;
    while (index < 4) {
        var cell = qldIngredientCell(card, index);
        var measured = qldFullTextMetrics(content["effect" + index], cell.text, fontSize, cellWidth, cell.color);
        if (index < 2) row0 = Math.max(row0, measured.fieldHeight + 4);
        else row1 = Math.max(row1, measured.fieldHeight + 4);
        index += 1;
    }
    return {columnGap:columnGap, cellWidth:cellWidth, rowGap:rowGap, row0:row0, row1:row1};
}
function qldSmallFontSize(size) { return Math.max(10, size * 0.8); }
function qldDescriptionFontFloor(size) { return Math.max(10, Math.min(12, size)); }
function qldDescriptionMinimumHeight(card, width, fontSize, header, text) {
    if (card.type == 8 && card.showIngredientEffects != false) {
        var grid = qldGridMetrics(card, width, fontSize);
        return grid.rowGap + 2 * (qldSmallFontSize(fontSize) + 8);
    }
    var minimumSize = qldDescriptionFontFloor(fontSize);
    var fullAtMinimum = qldFullTextMetrics(content.measurement, text, minimumSize, width - 32);
    return fullAtMinimum.fieldHeight + 8;
}
function qldMinimumHeight(card, width, fontSize) {
    var header = qldHeader(card, width, fontSize);
    var text = qldCardDescription(card);
    var bodyMinimum = qldDescriptionMinimumHeight(card, width, fontSize, header, text);
    return Math.ceil(Math.max(4 * fontSize + 64, header.descriptionTop + bodyMinimum + 8));
}
function qldMeasure(card, width, fontSize, descriptionFontSize) {
    var header = qldHeader(card, width, fontSize);
    var descriptionHeight;
    var bodySize = isFinite(descriptionFontSize) ? Math.max(qldDescriptionFontFloor(fontSize), Math.min(qldSmallFontSize(fontSize), descriptionFontSize)) : qldSmallFontSize(fontSize);
    if (card.type == 8 && card.showIngredientEffects != false) {
        var grid = qldGridMetrics(card, width, fontSize);
        descriptionHeight = grid.row0 + grid.rowGap + grid.row1;
    } else {
        var measured = qldFullTextMetrics(content.description, qldCardDescription(card), bodySize, width - 32);
        descriptionHeight = Math.max(bodySize + 8, measured.fieldHeight + 4);
    }
    var text = qldCardDescription(card);
    var bodyMinimum = qldDescriptionMinimumHeight(card, width, fontSize, header, text);
    return Math.ceil(Math.max(4 * fontSize + 64, header.descriptionTop + Math.max(bodyMinimum, descriptionHeight) + 8));
}
function qldPreferredHeight(card, width, fontSize) {
    var natural = qldMeasure(card, width, fontSize);
    // Ingredient effects use a fixed grid; other long bodies share this tunable logical-height cap.
    if (card.type == 8 && card.showIngredientEffects != false) return natural;
    return Math.min(natural, qldLongCardPreferredHeight);
}
function qldSetText(field, text, size, width, height, wrap, color) {
    var fitted = qldFitText(text, Math.max(0, width - 4), Math.max(0, height - 4), function(value) {
        return qldMeasureText(value, width - 4, size, wrap);
    });
    field.html = false; field.multiline = wrap; field.wordWrap = wrap; field.selectable = false;
    field._width = width; field._height = height;
    var format = qldFormat(size, color); field.setNewTextFormat(format);
    field.text = fitted.text; field.setTextFormat(format);
    return fitted.truncated;
}
function qldPositionTitle(iconVisible) {
    if (currentTitleCard == null) return false;
    var innerWidth = Math.max(1, currentTitleWidth - 32);
    var useIcon = qldUsesCategoryIconRoute() && iconVisible && currentTitleWidth >= 88 && currentTitleCard.showCategory != false && currentTitleCard.showIcons != false;
    var titleWidth = Math.max(1, innerWidth - (useIcon ? 28 : 0));
    content.title._x = useIcon ? 44 : 16;
    content.title._width = titleWidth;
    var omitted = qldSetText(content.title, qldCardTitle(currentTitleCard), currentTitleFontSize, titleWidth, currentTitleHeight, true);
    if (useIcon) {
        var measured = qldMeasureText(content.title.text, titleWidth, currentTitleFontSize, true);
        var textWidth = Math.min(titleWidth, measured.width);
        var textLeft = content.title._x + (titleWidth - textWidth) / 2;
        categoryIcon._width = 24; categoryIcon._height = 24;
        categoryIcon._x = textLeft - 28;
        categoryIcon._y = content.title._y + Math.max(0, (currentTitleFontSize + 2 - 24) / 2);
    }
    return omitted;
}
function qldFrame(width, height, opacity) {
    background.clear(); background.beginFill(0x000000, opacity * 100);
    background.moveTo(0, 0); background.lineTo(width, 0); background.lineTo(width, height);
    background.lineTo(0, height); background.lineTo(0, 0); background.endFill();
    border.clear(); border.lineStyle(1, 0x000000, 100);
    border.moveTo(0, 0); border.lineTo(width, 0); border.lineTo(width, height);
    border.lineTo(0, height); border.lineTo(0, 0);
}
function qldIsKnownItemIconLabel(label) {
    var labels = ["default_misc","default_weapon","weapon_sword","weapon_greatsword","weapon_dagger","weapon_waraxe","weapon_battleaxe","weapon_mace","weapon_bow","weapon_staff","weapon_crossbow","weapon_hammer","weapon_pickaxe","weapon_woodaxe","weapon_arrow","weapon_bolt","default_armor","lightarmor_head","lightarmor_body","lightarmor_hands","lightarmor_forearms","lightarmor_feet","lightarmor_calves","lightarmor_shield","armor_head","armor_body","armor_hands","armor_forearms","armor_feet","armor_calves","armor_shield","armor_amulet","armor_ring","armor_circlet","clothing_head","clothing_body","clothing_hands","clothing_forearms","clothing_feet","clothing_calves","clothing_shield","default_potion","potion_health","potion_magic","potion_stam","potion_fire","potion_shock","potion_frost","potion_poison","default_food","food_wine","default_ingredient","default_book","book_note","book_tome","misc_soulgem","soulgem_empty","soulgem_partial","soulgem_full","soulgem_grandempty","soulgem_grandpartial","soulgem_grandfull","soulgem_azura","default_key","default_scroll","misc_torch","misc_gem","misc_dragonclaw","misc_artifact","misc_leather","misc_strips","misc_hide","misc_remains","misc_ingot","misc_wood","misc_clutter","misc_lockpick","misc_gold"];
    var i = 0;
    while (i < labels.length) { if (label == labels[i]) return true; i++; }
    return false;
}
function qldSelectCategoryIcon(label) {
    var fallback = "default_misc";
    try {
        categoryIcon.gotoAndStop(fallback);
        var fallbackFrame = categoryIcon._currentframe;
        var totalFrames = categoryIcon._totalframes;
        if (!isFinite(fallbackFrame) || fallbackFrame <= 1 || !isFinite(totalFrames) || fallbackFrame > totalFrames) return false;
        if (label != fallback) {
            categoryIcon.gotoAndStop(label);
            var selectedFrame = categoryIcon._currentframe;
            if (!isFinite(selectedFrame) || selectedFrame <= 1 || selectedFrame > totalFrames || selectedFrame == fallbackFrame) {
                categoryIcon.gotoAndStop(fallback);
            }
        }
        var resolvedFrame = categoryIcon._currentframe;
        return isFinite(resolvedFrame) && resolvedFrame > 1 && resolvedFrame <= categoryIcon._totalframes;
    } catch (e) {
        try { categoryIcon.gotoAndStop(fallback); } catch (fallbackError) { return false; }
        var fallbackFrameAfterError = categoryIcon._currentframe;
        return isFinite(fallbackFrameAfterError) && fallbackFrameAfterError > 1 &&
            fallbackFrameAfterError <= categoryIcon._totalframes;
    }
}
function qldIsCurrentCategoryIconRequest(target) {
    return target == categoryIcon && qldUsesCategoryIconRoute() &&
        iconLoadStarted && iconLoadGeneration == iconRequestGeneration;
}
function qldFinishStaleCategoryIconLoad() {
    iconLoadStarted = false; iconLoaded = false; iconLoadFailed = false; iconLoadGeneration = -1;
    if (iconRequestedVisible && qldUsesCategoryIconRoute()) qldSetCategoryIcon(true, iconLabel, iconColor);
}
function qldApplyCategoryIcon() {
    if (!qldIsCurrentCategoryIconRequest(categoryIcon) || !iconRequestedVisible || !iconLoaded || iconLoadFailed) { categoryIcon._visible = false; qldPositionTitle(false); return; }
    if (iconFailedLabel == iconLabel) { categoryIcon._visible = false; qldPositionTitle(false); return; }
    if (iconAppliedLabel != iconLabel) {
        if (!qldSelectCategoryIcon(iconLabel)) {
            iconAppliedLabel = iconLabel; iconFailedLabel = iconLabel; categoryIcon._visible = false; return;
        }
        categoryIcon._width = 24; categoryIcon._height = 24;
        iconAppliedLabel = iconLabel; iconFailedLabel = "";
    }
    if (qldUsesSkyUIIconRoute()) categoryIconTint.setRGB(iconColor);
    categoryIcon._visible = true;
    qldPositionTitle(true);
}
function onLoadInit(target) {
    if (target != categoryIcon) return;
    if (!qldIsCurrentCategoryIconRequest(target)) {
        target._visible = false; qldPositionTitle(false);
        if (iconLoadStarted && !iconLoaded && iconLoadGeneration != iconRequestGeneration) qldFinishStaleCategoryIconLoad();
        return;
    }
    iconLoaded = true;
    if (!iconRequestedVisible) { target._visible = false; qldPositionTitle(false); return; }
    qldApplyCategoryIcon();
}
function onLoadError(target) {
    if (target != categoryIcon) return;
    if (!qldIsCurrentCategoryIconRequest(target) || iconLoaded) {
        target._visible = false; qldPositionTitle(false);
        if (iconLoadStarted && !iconLoaded && iconLoadGeneration != iconRequestGeneration) qldFinishStaleCategoryIconLoad();
        return;
    }
    iconLoadFailed = true; iconLoaded = false; categoryIcon._visible = false;
    qldPositionTitle(false);
}
function qldInvalidateCategoryIconRequest() {
    if (iconLoadStarted && !iconLoaded && iconLoadGeneration == iconRequestGeneration) iconRequestGeneration++;
    iconRequestedVisible = false; categoryIcon._visible = false;
}
function qldSetCategoryIcon(show, requestedLabel, requestedColor) {
    var routeActive = qldUsesCategoryIconRoute();
    var routeAllowsIcon = routeActive && show;
    iconLabel = qldIsKnownItemIconLabel(requestedLabel) ? requestedLabel : "default_misc";
    iconColor = isFinite(requestedColor) && requestedColor >= 0 && requestedColor <= 0xFFFFFF ? requestedColor : 0xFFFFFF;
    categoryIcon._visible = false;
    if (!routeAllowsIcon) {
        // Hiding this card does not cancel the shared one-shot sidecar load.
        // A disabled route still invalidates the request so stale callbacks cannot apply.
        if (!routeActive) qldInvalidateCategoryIconRequest();
        else iconRequestedVisible = false;
        return;
    }
    iconRequestedVisible = true;
    if (iconLoadFailed) return;
    if (!iconLoadStarted) {
        iconLoadStarted = true;
        iconRequestGeneration++;
        iconLoadGeneration = iconRequestGeneration;
        var iconMoviePath = qldUsesOwnedIconRoute() ? "QuickLootDetails_CategoryIcons.swf" : "skyui/icons_item_psychosteve.swf";
        if (!iconLoader.loadClip(iconMoviePath, categoryIcon)) {
            iconLoadFailed = true; iconRequestedVisible = false; iconRequestGeneration++; return;
        }
    } else if (iconLoadGeneration != iconRequestGeneration) {
        // Keep the latest request pending; the stale loader callback will restart it.
        categoryIcon._visible = false; return;
    }
    qldApplyCategoryIcon();
}
function qldClear() {
    panel._visible = false; iconRequestedVisible = false; categoryIcon._visible = false;
    currentTitleCard = null; currentTitleWidth = 0; currentTitleHeight = 0;
    panel.requiredHeight = 0; panel.descriptionMeasuredHeight = 0; panel.descriptionFontSize = 0;
    panel.titleOmitted = false; panel.statsOmitted = false; panel.detailOmitted = false; panel.descriptionOmitted = false;
    content.title.text = content.stats.text = content.description.text = "";
    content.description._visible = false; content.detailInfo.text = ""; content.detailInfo.setTextFormat(qldFormat(10)); content.detailInfo._visible = false;
    content.category.text = ""; content.category._visible = false; divider.clear();
    var index = 0;
    while (index < 4) {
        content["effect" + index].text = ""; content["effect" + index]._visible = false;
        index += 1;
    }
}
function qldRender(show, card, x, y, width, scale, fontSize, backgroundOpacity, textOpacity, height) {
    qldClear();
    if (!show) return true;
    if (card == undefined || card.name == undefined || card.type == undefined || card.weight == undefined || card.value == undefined) return false;
    if (card.effects != undefined && card.effectsPlain == undefined) return false;
    var header = qldHeader(card, width, fontSize);
    currentTitleCard = card; currentTitleWidth = width; currentTitleFontSize = fontSize; currentTitleHeight = header.titleHeight;
    var descriptionText = qldCardDescription(card);

    var descriptionHeight = height - header.descriptionTop - 8;
    var minimumDescriptionHeight = qldDescriptionMinimumHeight(card, width, fontSize, header, descriptionText);
    // If the viewport cannot satisfy the long-body minimum, still draw the
    // title and stats. The full body remains assigned and is marked clipped;
    // the native renderer logs that limit instead of erasing the whole card.
    if (width < 60) return false;
    if (header.descriptionTop > height - 8) { panel.statsOmitted = true; return false; }
    panel._x = x; panel._y = y; panel._xscale = panel._yscale = scale * 100;
    content.title._y = 12; content.stats._y = header.statsTop; content.detailInfo._y = header.detailTop; content.description._y = header.descriptionTop;
    content.category._x = header.categoryX; content.category._y = header.categoryTop;
    var categoryVisible = header.categoryHeight > 0;
    if (categoryVisible) {
        content.category._visible = true;
        qldSetText(content.category, card.categoryText, header.majorFont, width - 32, header.categoryHeight, false);
    }
    qldSetCategoryIcon(categoryVisible && header.titleIconVisible, card.iconLabel, card.iconColor);
    content._alpha = textOpacity * 100; border._alpha = textOpacity * 100;
    qldFrame(width, height, backgroundOpacity);
    divider.lineStyle(0.7, 0xFFFFFF, 100);
    divider.moveTo(16, header.dividerY); divider.lineTo(width - 16, header.dividerY);
    var titleOmitted = qldPositionTitle(categoryIcon._visible);
    var statsOmitted = qldSetFullText(content.stats, qldCardStats(card, width), header.majorFont, width - 32, header.statsHeight).clipped;
    var detailOmitted = false;
    if (header.detailHeight > 0) {
        content.detailInfo._visible = true;
        var display = qldEquipmentDisplay(card.detailText, card.languageEnglish ? card.equipmentCompareEn : card.equipmentCompareJa);
        var infoMeasured = qldSetFullText(content.detailInfo, display.detail, header.detailFont, width - 32, header.detailHeight);
        var comparisonRange = qldEquipmentComparisonRange(display.detail, display.comparison, card.equipmentCompareEn);
        if (comparisonRange != null) content.detailInfo.setTextFormat(comparisonRange.start, comparisonRange.end, qldFormat(header.detailFont, comparisonRange.color));
        detailOmitted = infoMeasured.clipped;
    }
    var descriptionOmitted = false;
    panel.requiredHeight = Math.ceil(Math.max(4 * fontSize + 64, header.descriptionTop + minimumDescriptionHeight + 8));
    panel.descriptionMeasuredHeight = 0;
    if (card.type == 8 && card.showIngredientEffects != false) {
        if (card.numItemEffects == undefined) return false;
        var grid = qldGridMetrics(card, width, fontSize);
        panel.requiredHeight = Math.ceil(Math.max(4 * fontSize + 64, header.descriptionTop + grid.row0 + grid.rowGap + grid.row1 + 8));
        panel.descriptionMeasuredHeight = grid.row0 + grid.rowGap + grid.row1;
        var available = descriptionHeight - grid.rowGap;
        var effectFont = qldSmallFontSize(fontSize);
        if (available < 2 * (effectFont + 8)) return false;
        var row0 = grid.row0; var row1 = grid.row1;
        if (row0 + row1 > available) {
            row0 = Math.max(effectFont + 8, Math.min(available - effectFont - 8, available * row0 / (row0 + row1)));
            row1 = available - row0;
        }
        var index = 0;
        while (index < 4) {
            var field = content["effect" + index]; var cell = qldIngredientCell(card, index);
            field._x = 16 + (index % 2) * (grid.cellWidth + grid.columnGap);
            field._y = header.descriptionTop + (index < 2 ? 0 : row0 + grid.rowGap);
            field._visible = true;
            var measured = qldSetFullText(field, cell.text, effectFont, grid.cellWidth, index < 2 ? row0 : row1, cell.color);
            descriptionOmitted = descriptionOmitted || measured.clipped;
            index += 1;
        }
    } else {
        content.description._visible = true;
        var bodySize = isFinite(card.descriptionFontSize) ? Math.max(qldDescriptionFontFloor(fontSize), Math.min(qldSmallFontSize(fontSize), card.descriptionFontSize)) : qldSmallFontSize(fontSize);
        var measured = qldSetAdaptiveDescriptionText(content.description, descriptionText, bodySize, width - 32, descriptionHeight);
        panel.descriptionMeasuredHeight = measured.fieldHeight;
        panel.descriptionFontSize = measured.fontSize == undefined ? fontSize : measured.fontSize;
        panel.requiredHeight = Math.ceil(Math.max(4 * fontSize + 64, header.descriptionTop + Math.max(minimumDescriptionHeight, bodySize + 8, measured.fieldHeight + 4) + 8));
        descriptionOmitted = measured.clipped;
    }
    panel.titleOmitted = titleOmitted; panel.statsOmitted = statsOmitted; panel.detailOmitted = detailOmitted; panel.descriptionOmitted = descriptionOmitted;
    if (statsOmitted) return false;
    panel._visible = true;
    return true;
}
