"""Positive and intentional mismatch fixtures for the marker/package gate."""
from __future__ import annotations
import argparse
import json
import sys
import zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
from build_identity import read_identity_data
from marker_contract import MarkerContractError, verify_dll_binding, verify_marker_contract


def mismatch_swf(data: bytes, marker: str) -> bytes:
    changed = marker[:-1] + ('3' if marker[-1] != '3' else '4')
    before = marker.encode('ascii')
    after = changed.encode('ascii')
    if len(before) != len(after):
        raise AssertionError('fixture marker replacement must preserve byte length')
    if data[:3] == b'CWS':
        body = zlib.decompress(data[8:])
        if before not in body:
            raise AssertionError('could not find qldProbe marker in compiled SWF body')
        body = body.replace(before, after)
        return data[:8] + zlib.compress(body, 9)
    if data[:3] == b'FWS':
        if before not in data[8:]:
            raise AssertionError('could not find qldProbe marker in compiled SWF')
        return data[:8] + data[8:].replace(before, after)
    raise AssertionError('unsupported test SWF compression')


def must_reject(label: str, operation) -> str:
    try:
        operation()
    except (MarkerContractError, ValueError, AssertionError) as exc:
        return f'{label}:REJECTED:{exc}'
    raise AssertionError(f'{label} mismatch fixture incorrectly passed')


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--swf', type=Path, required=True)
    parser.add_argument('--icon-swf', type=Path, required=True)
    parser.add_argument('--dll', type=Path, required=True)
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    swf_data = args.swf.read_bytes()
    icon_swf_data = args.icon_swf.read_bytes()
    dll_data = args.dll.read_bytes()
    official = verify_dll_binding(args.root, swf_data, icon_swf_data, dll_data)
    identity = read_identity_data(args.root, swf_data, icon_swf_data)

    wrong_swf = mismatch_swf(swf_data, str(identity['ui_probe_marker']))
    swf_result = must_reject('mismatched_qldProbe_SWF', lambda: verify_dll_binding(args.root, wrong_swf, icon_swf_data, dll_data))

    old_hash = str(identity['ui_swf_sha256']).encode('ascii')
    wrong_hash = b'0' * len(old_hash)
    if old_hash not in dll_data or old_hash == wrong_hash:
        raise AssertionError('could not form stale-DLL binding fixture')
    wrong_dll = dll_data.replace(old_hash, wrong_hash, 1)
    dll_result = must_reject('stale_DLL_SWF_binding', lambda: verify_dll_binding(args.root, swf_data, icon_swf_data, wrong_dll))

    old_icon_hash = str(identity['category_icon_swf_sha256']).encode('ascii')
    wrong_icon_hash = b'0' * len(old_icon_hash)
    if old_icon_hash not in dll_data or old_icon_hash == wrong_icon_hash:
        raise AssertionError('could not form stale-DLL category-icon binding fixture')
    wrong_icon_dll = dll_data.replace(old_icon_hash, wrong_icon_hash, 1)
    icon_result = must_reject('stale_DLL_category_icon_binding',
                              lambda: verify_dll_binding(args.root, swf_data, icon_swf_data, wrong_icon_dll))

    result = {
        'status': 'PASS', 'official_pair': 'PASS', 'candidate_id': identity['candidate_id'],
        'official_marker': official['marker_contract']['marker'],
        'mismatch_fixtures': [swf_result, dll_result, icon_result],
        'limitation': 'Synthetic SWF/DLL mismatch fixtures; no Scaleform or game execution.',
    }
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print('MARKER_MISMATCH_FIXTURE_PASS official_pair=PASS mismatched_qldProbe_SWF=REJECTED stale_DLL_SWF_binding=REJECTED stale_DLL_category_icon_binding=REJECTED')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
