# QuickLoot Details candidate 065

Private, non-deployment integration scaffold using the current 061 SVGs as provisional inputs in the existing 057 route. The 060-v3 approval establishes the design direction only; the 78 individual icons remain pending the user's later review and are not treated as final or adopted. The source build creates a separate 78-label static-vector SWF, keeps the 80 base SVGs and four status overlays with their own source hashes, and preserves the existing category text fallback. Unknown labels still resolve to `default_misc`; the supplemental `drink` art does not create a classification rule.

The `owned-svg` route skips category tinting so the 061 palette is preserved. Enchantment-present, known, special, and read marks remain independently controlled overlay clips. Text sizing, card position, food/read-label behavior, gamepad behavior, native diagnostic handling, and existing marker identity checks inherit from the 057 source.

The SVGs and mapping remain separate, replaceable source inputs; after later art edits, regenerate the manifest, previews, SWFs, native identity, and private package. See `BUILD.md`, `docs/ICON_ART_PROVENANCE_065.md`, and `docs/verification-065.json` for the local build and scope. Skyrim Scaleform and game loading have not been tested; the known 172px long Japanese description clip remains unresolved.
