## 0.1.20-r2 comparison color 031 private candidate - 2026-10-24 UTC

- 既存の右手武器比較と同一スロット防具比較を維持し、表示済みの符号付き比較行を正値は青 (#66B2FF)、負値は赤 (#FF6B6B) で表示。表示値が ±0.00、欠落・不正・曖昧な場合は中立色。
- UIソースのプロトコル回帰テストは合格。独立SWF/ネイティブビルドは、この実行環境にQLD_JAVA/QLD_FFDECがなく、既存の028/030出力内にもFFDec JARが見つからないため未実施。ゲーム内Scaleformの表示も未確認。

## 0.1.20-r2 text-route 032 private test candidate — 2026-10-07 UTC

- Rebuilt the current text-default SWF from source with the already-present pinned FFDec/Java; hash and size exactly match the reviewed 030 output.
- Added route-generation guards for stale category icon callbacks; current compiled AS2 source/protocol/route/AVM1/localization checks PASS.
- Reused native and Papyrus artifacts only after exact source/runtime hash comparison to frozen r2; no native or Papyrus rebuild.
- Reused full r2 static PASS/130-check evidence for unchanged sources/artifacts and recorded current route delta checks separately. Native CTest remains inherited from 028 (12/12), not rerun in 030/032.
- Created a private testpack/source ZIP pair; CRC, per-file hashes, manifests, allowlists and re-extraction audit PASS. No game/MO2/runtime test or publication.
- Final appearance adoption remains undecided; SkyUI author inquiry is pending and no SkyUI BSA/SWF was extracted or bundled.

## 0.1.20-r2 release candidate — 2026-10-06 UTC

- QuickLoot IE vector-icon credit scope corrected: Excited Puppy Energy at project level; Komegaki for thumbnail; Himika for DLL/SWF source. No per-shape creator is asserted.
- Added dated modification notice, explicit GPL/source scope, and matching source ZIP filename.
- Built panel assets from the r2 source ZIP in a fresh isolated directory using existing JPEXS FFDec 26.3.0 and Java 8u461; the build record captures the detected FFDec version and JAR hash.
- DLL and PEX were inherited from r1 without rebuilding. Their hashes are compared and recorded in verification evidence.
- Static verifier: 130 current checks PASS with the existing Champollion 1.3.2; this is static evidence only, not a game runtime test.
- Candidate remains unpublished; Nexus upload and DP conditions remain unresolved. No game or SkyUI asset was touched.

# 変更履歴

## 0.1.20-r1 repair candidate

- 防具クラスの判定順をpinned QuickLoot IEに合わせ、ArmorType優先・Clothing keyword・Jewelry keyword・同一のslot fallbackを回帰テストに追加。
- 既存QuickLoot IE由来の4状態マーカーを元のベクター形状で統合し、SVG source・上流GPL/例外文・クレジットをsource/runtime成果物へ含める。
- root source-manifest.jsonをsource ZIP内manifestと同一ハッシュ表に同期する。
- 既存QuickLoot IE/SkyUI provider overrideとの一致、インストール済みSkyUI SWF frame、Skyrim実機LOAD/RUNTIME/HUMANは未検証。

# 変更履歴

## 0.1.20 candidate

- QuickLoot IE/SkyUI標準アイコン分類と色を追加。未対応分類は安全なdefaultへ戻す。
- Gold001の厳密なForm判定を追加。金額を維持し、重量とV/Wだけに`ー`を表示。
- 既読マークと、通常/既知/特殊エンチャントのマークをカテゴリとは別に表示。
- Papyrusソース、ESP、SEQは変更なし。0.1.19-r1とのハッシュ一致を確認。
- ネイティブbuild、CTest 12/12、Static 127 checksを確認。LOAD/RUNTIME/HUMANは未実施。

## 0.1.19-r1

説明文、翻訳ヘルプ、provenance記録を更新した文書中心のrevision。runtimeバイナリは0.1.19と同一。

## 0.1.19

食料説明の重複抑制、任意の参考DPS、カード情報と表示の検証を追加。詳細は0.1.19の保存済み検証記録を参照。

## QLD040-R1: preferred-height ordering

- Corrected the sizing order so Native uses compiled-AS2 measurements at each candidate font before panel expansion. Long normal/enchantment descriptions start within the provisional 279 logical-pixel preference; short cards retain natural height.
- Added connected regressions for shrink-before-expand, floor-size expansion, viewport hard-cap overflow, language/newline cases, and short-card reset. Full native build/CTest passed with 25/25 cases. Real game runtime remains unverified.


## QLD042: isolated description pipeline repair

Separated body-only adaptive sizing from header fonts; planned from real available placement height with default279 unchanged; synchronized source viewport changes and invalidated height-sensitive fit state. Added header-preservation and actual-small-screen connected regressions. No deployment/runtime validation.


### QLD042-R1 continuation

Same approved QLD041 repair resumed after owner-approved small command-record resubmission. The original042 blocked report and empty ledger remain historical evidence. Final build/test outcomes and individually measured commands are recorded only in EvidenceRoot/development-042-r1. No runtime acceptance is claimed.
