#include "qld/LegacySelection.h"
#include <array>
#include <cmath>
#include <limits>
namespace qld {
namespace {
template<class T> bool read(const MemoryReader& r,std::uint64_t a,T& v) {
    if(!a || a>std::numeric_limits<std::uint64_t>::max()-sizeof(T))return false;
    return r.read(a,std::as_writable_bytes(std::span<T>(&v,1)));
}
bool pointer(std::uint64_t p) {return p>=0x10000 && p<0x0000800000000000 && p%8==0;}
bool vectorRange(const std::array<std::uint64_t,3>& v,std::uint32_t stride,std::uint32_t limit) {
    return pointer(v[0]) && v[0]<=v[1] && v[1]<=v[2] &&
        (v[1]-v[0])%stride==0 && (v[2]-v[0])%stride==0 &&
        (v[2]-v[0])/stride<=limit;
}
}
std::optional<LegacySelection> readLegacySelection(const MemoryReader& r,const LegacyLayout& l,
    std::uint64_t base,std::uint64_t menu,double index,std::uint32_t length) {
    if(!pointer(base) || !pointer(menu) || !std::isfinite(index) || std::floor(index)!=index ||
       index<0 || index>=length || length>16384)return {};
    std::uint64_t vt{};std::array<std::uint64_t,3> v{};LegacySelection out;
    if(!read(r,menu,vt) || vt!=base+l.menuVtable || !read(r,menu+l.sourceOffset,out.container) || !out.container ||
       !read(r,menu+l.vectorOffset,v) || !vectorRange(v,8,16384) || (v[1]-v[0])/8!=length)return {};
    out.index=static_cast<std::int32_t>(index);out.vectorBegin=v[0];out.vectorEnd=v[1];
    if(!read(r,v[0]+out.index*8,out.itemAddress) || !pointer(out.itemAddress) || !read(r,out.itemAddress,vt))return {};
    std::int64_t count{};std::uint8_t which{};
    if(!read(r,out.itemAddress+0x20,count) || count<=0 || count>INT32_MAX || !read(r,out.itemAddress+0x18,which))return {};
    out.count=static_cast<std::int32_t>(count);
    if(vt==base+l.inventoryVtable) {
        std::uint64_t observer{};std::uint32_t container{};
        if(which!=0 || !read(r,out.itemAddress+0x78,out.entryAddress) || !pointer(out.entryAddress) ||
           !read(r,out.itemAddress+8,observer) || observer!=out.entryAddress ||
           !read(r,out.itemAddress+0x80,container) || container!=out.container)return {};
    } else if(vt==base+l.groundVtable) {
        std::array<std::uint64_t,3> ground{};std::array<std::uint64_t,2> span{};
        if(which!=1 || !read(r,out.itemAddress+0x78,ground) || !vectorRange(ground,4,64) ||
           !read(r,out.itemAddress+8,span) || span[0]!=ground[0] || span[1]!=(ground[1]-ground[0])/4 || !span[1])return {};
        out.groundHandles.resize(static_cast<std::size_t>(span[1]));
        if(!r.read(ground[0],std::as_writable_bytes(std::span(out.groundHandles))))return {};
        for(auto handle:out.groundHandles)if(!handle)return {};
    } else return {};
    return out;
}
}
