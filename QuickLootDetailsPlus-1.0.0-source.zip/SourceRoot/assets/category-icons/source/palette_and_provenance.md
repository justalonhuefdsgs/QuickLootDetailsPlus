# 061 palette and provenance

## Source material

- Approved local sample: `[local path removed]`
- Approved sample SHA-256: `3d1366688b13c225ccc15d196673686b3f41a46987c57764f0bd78c24f465ace`
- Current QLD semantic-label source: `[local path removed]`
- Semantic-label source SHA-256: `003533d89b0d59ab7e69f9560f41b5d91f7013d3fa020a292177550592c5ccfb`

The generator reads the 060 SVG symbol groups and copies all 18 approved symbols into the 061 sprite. It preserves the accepted sword, axe, and light-armor geometry and palettes exactly; hash evidence is in `../evidence/vector_checks.json`. The 66 added symbols are original 061 vector shapes authored in `generate_iconset.py`.

The current 057 label list is read only from the string array in `qldIsKnownItemIconLabel`. The mapping covers all 78 names present in that array. A separately named historical 78-label audit file was not found in the task artifact folders; the current 057 list is the coverage source used here.

No SkyUI SWF artwork, bitmap, or path data was extracted or traced. No external icon library was used. The 060-v3 sample symbols are the only reused vector art; all new category and subtype shapes were drawn for this set.

## Palette

- Standard outline: `#C2CBD4`
- Standard outline width: `2.25` units in the `0 0 64 64` viewBox
- The accepted sample colors remain intact, including sword steel `#8FA4B7`, axe steel `#8598A8`, axe wood `#907854`, light armor taupe `#9B836F`, and the original muted food, drink, potion, book, gem, soul-gem, and marker colors.
- New surfaces use muted steel, taupe, warm wood, paper, sage, amber, red, teal, and slate-violet values drawn from the same low-saturation design language. The complete color list is `../manifest/palette.json`.
- Small-scale contrast was reviewed against `#0E1721`. The lowest primary-fill contrast is 4.676:1; the standard pale outline supplies a clear edge. The 2.25-unit outline scales to 0.56 px at 16 px, 0.70 px at 20 px, and 0.84 px at 24 px.

## Authorship and rights scope

This provenance record distinguishes the reused, user-approved 060-v3 sample vectors from the 66 new 061 shapes. It is not a license grant and does not assert Nexus, DP, or other external distribution permission.
