// SPDX-License-Identifier: GPL-3.0-or-later
#include "qld/Crypto.h"
#include <cstdlib>
#include <iostream>
#include <string_view>
int main(){
    const std::pair<std::string_view,std::string_view> vectors[]{
{"","e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"},
{"abc","ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"},
{"abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq","248d6a61d20638b8e5c026930c3e6039a33ce45964ff2167f6ecedd419db06c1"}};
    for(const auto& [text,expected]:vectors){
        auto hash=qld::sha256({reinterpret_cast<const unsigned char*>(text.data()),text.size()});if(!hash)return 1;
        constexpr char hex[]="0123456789abcdef";std::string encoded;for(auto b:*hash){encoded+=hex[b>>4];encoded+=hex[b&15];}if(encoded!=expected)return 2;
    }
    std::cout<<"SHA256 known-vector PASS: empty, abc, multi-block.\n";
}
