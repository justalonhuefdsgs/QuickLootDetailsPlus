#include "qld/Core.h"
#include "qld/Providers.h"
#include "qld/RuntimeContracts.h"
#include "qld/LegacySelection.h"
#include <utility>
#include <cstdlib>
#include <iostream>
using namespace qld;
static void expect(bool b,const char* m){if(!b){std::cerr<<m<<'\n';std::exit(1);}}
int main(){
    const unsigned allowedMasks[]{3,7,1,2,1,0,4};
    unsigned providerIndex{};
    for(auto& e:providerEvidence){
        auto p=identifyProvider(e.module,e.hash);expect(p==&e,"exact module + binary fingerprint");
        expect(!identifyProvider("RenamedProvider.dll",e.hash),"renamed/wrong provider module rejected");
        auto hash=std::string(e.hash);hash[0]=hash[0]=='0'?'1':'0';expect(!identifyProvider(e.module,hash),"one-byte changed binary rejected");
        for(auto runtime:{se1597,0x01064920u,0x01070680u,0x01050700u,0u}){
            bool implemented=(allowedMasks[providerIndex]&runtimeBit(runtime))!=0;
            expect(adapterImplemented(e,runtime)==implemented,"exact reviewed provider/runtime matrix");
            expect(providerAllowed(e.hash,runtime)==implemented,"native guard agrees with adapter registry");
            expect(!providerAllowed(e.hash,runtime,true),"multiple providers always fail closed");
        }
        ++providerIndex;
    }
    expect(providerAllowed(ie412Hash,se1597),"baseline IE4.1.2 still allowed");
    auto ie413=identifyProvider("QuickLootIE.dll","ea030379a1db36bb222d30e9833aadb2bd5ae9a06ec13dfdf50638404ac8625a");
    expect(ie413 && providerAllowed(ie413->hash,se1597),"verified IE4.1.3 API adapter enabled for SE");
    expect(providerCandidate(*ie413,0x01064920) && providerCandidate(*ie413,0x01070680),"AE and1.7 recorded as source-supported candidates, distinct from implementation");
    expect(!providerCandidate(providerEvidence[5],0x01064920),"RE2.15 probably-later statement does not become confirmed1170 candidate");
    expect(!providerCandidate(providerEvidence[2],0x01070680),"EE original does not silently gain1.7 support");
    expect(!providerCandidate(providerEvidence[6],se1597),"AE3.0 replacement is1.7 only");
    expect(!identifyProvider("QuickLootIE.dll","") && !providerAllowed("unknown",se1597),"missing/unknown hashes rejected");
    for(auto pair:{std::pair{0x01050610u,0x02000140u},std::pair{0x01064920u,0x02020080u},std::pair{0x01070680u,0x02030010u}}){
        expect(runtimeLoadAllowed(pair.first,pair.second),"exact runtime with minimum compatible SKSE accepted");
        expect(!runtimeLoadAllowed(pair.first,pair.second-1),"old SKSE rejected before hooks");
        expect(!runtimeLoadAllowed(pair.first,pair.second,true),"editor always rejected");
    }
    for(auto runtime:{0u,0x01090200u,0x01040f10u,0x01062800u,0x01070630u,0x01070690u}){
        expect(!runtimeLoadAllowed(runtime,0x03000000),"LE/VR/unreviewed runtimes rejected even with newer SKSE");
        for(auto& e:providerEvidence)expect(!providerAllowed(e.hash,runtime),"all providers reject unknown runtimes");
    }
    expect(!runtimeLoadAllowed(0x01070680,0x02020080),"SKSE2.2.8 cannot load the1.7.104 path");
    expect(!legacyLayout(providerEvidence[3],se1597),"EE1170 cannot borrow SE native layout");
    std::cout<<"Provider PASS: seven pinned binaries, explicit three-runtime matrix, SKSE minimum/editor checks, unknown/conflict rejection. No game load performed.\n";
}
