#include "qld/ExitDiagnostics.h"

#include <array>
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstdlib>
#include <functional>
#include <iostream>
#include <memory>
#include <string>
#include <thread>
#include <vector>

#if defined(QLD_EXIT_DIAGNOSTICS_SPDLOG_TEST)
#include "qld/ExitDiagnosticsSpdlog.h"
#include <spdlog/sinks/sink.h>
#include <algorithm>
#include <stdexcept>
#endif

#define CHECK(x) do { if (!(x)) { std::cerr << __LINE__ << ": " << #x << '\n'; std::exit(1); } } while (false)

namespace {
using namespace qld::exitdiag;

EventRecord record(Event event, Phase phase, std::uint32_t thread, std::uint64_t generation = 1) {
    EventRecord value;
    value.threadId = thread;
    value.menuGeneration = generation;
    value.menuAddress = 0x1000 + generation;
    value.uiMovieAddress = 0x2000;
    value.movieDefinitionAddress = 0x3000;
    value.event = event;
    value.phase = phase;
    return value;
}

class CaptureSink final : public IEventSink {
public:
    void Write(std::string_view batch) override {
        ++writes;
        last.assign(batch);
        if (onWrite) onWrite();
    }
    bool Flush() override {
        ++flushes;
        return !failFlush;
    }
    std::size_t writes{};
    std::size_t flushes{};
    std::string last;
    bool failFlush{};
    std::function<void()> onWrite;
};

class ThrowingEventSink final : public IEventSink {
public:
    void Write(std::string_view) override { throw std::runtime_error("simulated write failure"); }
    bool Flush() override { return false; }
};

void sequenceAndGeneration() {
    EventRecorder recorder;
    CHECK(recorder.NewMenuGeneration() == 1);
    CHECK(recorder.NewMenuGeneration() == 2);
    CHECK(recorder.Record(record(Event::menuCreate, Phase::begin, 21736, 1)));
    CHECK(recorder.Record(record(Event::menuCreate, Phase::end, 21736, 1)));
    std::array<EventRecord, 4> records{};
    CHECK(recorder.CopyRecords(records) == 2);
    CHECK(records[0].sequence == 1 && records[1].sequence == 2);
    CHECK(records[0].threadId == 21736 && records[0].menuGeneration == 1);
    CHECK(records[0].menuAddress == 0x1001 && records[0].uiMovieAddress == 0x2000);
    CHECK(recorder.GetStats().lastSequence == 2);
}

void overflowAndDropCount() {
    EventRecorder recorder;
    for (std::uint32_t i = 0; i < 300; ++i)
        CHECK(recorder.Record(record(Event::advanceMovie, Phase::begin, 7)) == (i < EventRecorder::normalRecordLimit));
    for (std::uint32_t i = 0; i < EventRecorder::reservedTerminalRecords; ++i)
        CHECK(recorder.Record(record(Event::menuDestroy, Phase::begin, 7), true));
    CHECK(!recorder.Record(record(Event::menuDestroy, Phase::end, 7), true));
    const auto stats = recorder.GetStats();
    CHECK(stats.stored == EventRecorder::capacity);
    CHECK(stats.normalStored == EventRecorder::normalRecordLimit);
    CHECK(stats.terminalStored == EventRecorder::reservedTerminalRecords);
    CHECK(stats.dropped == (300 - EventRecorder::normalRecordLimit + 1));
    auto sink = std::make_shared<CaptureSink>();
    CHECK(recorder.Flush(sink));
    CHECK(sink->writes == 1 && sink->last.find("dropped=61") != std::string::npos);
    CHECK(sink->last.find("lastSequence=317") != std::string::npos);
}

void overflowDoesNotCreateUnboundedLogLines() {
    EventRecorder recorder;
    auto sink = std::make_shared<CaptureSink>();
    for (std::size_t i = 0; i < EventRecorder::normalRecordLimit; ++i)
        CHECK(recorder.Record(record(Event::advanceMovie, Phase::begin, 7)));
    CHECK(recorder.Flush(sink));
    CHECK(sink->writes == 1);

    for (int i = 0; i < 50; ++i)
        CHECK(!recorder.Record(record(Event::advanceMovie, Phase::begin, 7)));
    for (std::size_t i = 0; i < EventRecorder::reservedTerminalRecords; ++i)
        CHECK(recorder.Record(record(Event::menuDestroy, Phase::end, 7), true));
    CHECK(recorder.Flush(sink));
    CHECK(sink->writes == 2);
    CHECK(sink->last.find("dropped=50") != std::string::npos);

    for (int i = 0; i < 100; ++i)
        CHECK(!recorder.Record(record(Event::menuDestroy, Phase::end, 7), true));
    CHECK(recorder.Flush(sink));
    CHECK(sink->writes == 3 && sink->last.find("count=0") != std::string::npos);
    CHECK(sink->last.find("dropped=150") != std::string::npos);
    CHECK(recorder.GetStats().dropped == 150);
}

void failedWritesAndFlushesKeepRecordsPending() {
    EventRecorder recorder;
    CHECK(recorder.Record(record(Event::menuDestroy, Phase::end, 9), true));
    auto sink = std::make_shared<CaptureSink>();
    sink->failFlush = true;
    CHECK(!recorder.Flush(sink));
    CHECK(recorder.GetStats().flushed == 0 && recorder.GetStats().stored == 1);
    CHECK(sink->writes == 1 && sink->flushes == 1);
    sink->failFlush = false;
    CHECK(recorder.Flush(sink));
    CHECK(recorder.GetStats().flushed == 1 && sink->writes == 2 && sink->flushes == 2);
    CHECK(sink->last.find("seq=1") != std::string::npos);
    CHECK(sink->last.find("phase=derived-destructor-body-exit-marker") != std::string::npos);

    EventRecorder throwingRecorder;
    CHECK(throwingRecorder.Record(record(Event::providerClose, Phase::end, 10)));
    CHECK(!throwingRecorder.Flush(std::make_shared<ThrowingEventSink>()));
    CHECK(throwingRecorder.GetStats().flushed == 0 && throwingRecorder.GetStats().stored == 1);
}

void concurrentClose() {
    EventRecorder recorder;
    constexpr std::uint32_t threads = 8;
    constexpr std::uint32_t closesPerThread = 20;
    std::vector<std::thread> workers;
    for (std::uint32_t worker = 0; worker < threads; ++worker) {
        workers.emplace_back([&, worker] {
            for (std::uint32_t i = 0; i < closesPerThread; ++i) {
                (void)recorder.Record(record(Event::providerClose, Phase::begin, 100 + worker));
                (void)recorder.Record(record(Event::providerClose, Phase::end, 100 + worker));
            }
        });
    }
    for (auto& worker : workers) worker.join();
    std::array<EventRecord, EventRecorder::capacity> records{};
    const auto copied = recorder.CopyRecords(records);
    CHECK(copied == EventRecorder::capacity - EventRecorder::reservedTerminalRecords);
    for (std::size_t i = 1; i < copied; ++i) CHECK(records[i - 1].sequence < records[i].sequence);
    const auto stats = recorder.GetStats();
    CHECK(stats.lastSequence == threads * closesPerThread * 2);
    CHECK(stats.dropped == stats.lastSequence - copied);
    auto sink = std::make_shared<CaptureSink>();
    CHECK(recorder.Flush(sink));
    CHECK(sink->last.find("event=on-close") != std::string::npos);
}

void recordWhileFlushInFlight() {
    EventRecorder recorder;
    CHECK(recorder.Record(record(Event::providerClose, Phase::begin, 19)));
    auto sink = std::make_shared<CaptureSink>();
    std::mutex gateMutex;
    std::condition_variable gate;
    bool entered{};
    bool resume{};
    sink->onWrite = [&] {
        std::unique_lock lock(gateMutex);
        entered = true;
        gate.notify_one();
        gate.wait(lock, [&] { return resume; });
    };
    bool flushResult{};
    std::thread flushing([&] { flushResult = recorder.Flush(sink); });
    bool writeEntered{};
    {
        std::unique_lock lock(gateMutex);
        writeEntered = gate.wait_for(lock, std::chrono::seconds(5), [&] { return entered; });
    }
    if (!writeEntered) {
        {
            std::lock_guard lock(gateMutex);
            resume = true;
        }
        gate.notify_one();
        flushing.join();
        CHECK(writeEntered);
    }
    CHECK(recorder.Record(record(Event::providerClose, Phase::end, 19)));
    {
        std::lock_guard lock(gateMutex);
        resume = true;
    }
    gate.notify_one();
    flushing.join();
    CHECK(flushResult && recorder.GetStats().flushed == 1 && recorder.GetStats().stored == 2);
    sink->onWrite = {};
    CHECK(recorder.Flush(sink));
    CHECK(recorder.GetStats().flushed == 2 && sink->writes == 2);
    CHECK(sink->last.find("seq=2") != std::string::npos);
}

void sinkLeaseAndTeardown() {
    EventRecorder recorder;
    CHECK(recorder.Record(record(Event::menuDestroy, Phase::begin, 2), true));
    bool aliveDuringWrite{};
    std::weak_ptr<CaptureSink> weak;
    auto owner = std::make_shared<CaptureSink>();
    weak = owner;
    owner->onWrite = [&] {
        aliveDuringWrite = !weak.expired();
        owner.reset();
    };
    CHECK(recorder.Flush(std::move(owner)));
    CHECK(!owner && aliveDuringWrite && weak.expired());
    CHECK(!recorder.Flush({}));
    CHECK(recorder.GetStats().flushed == 1);

    CHECK(recorder.Record(record(Event::menuDestroy, Phase::end, 2), true));
    CHECK(!recorder.Flush({}));
    CHECK(recorder.GetStats().flushed == 1);
    auto lateSink = std::make_shared<CaptureSink>();
    CHECK(recorder.Flush(lateSink));
    CHECK(lateSink->last.find("event=menu-destroy") != std::string::npos);
}

#if defined(QLD_EXIT_DIAGNOSTICS_SPDLOG_TEST)
class TestSpdlogSink final : public spdlog::sinks::sink {
public:
    void log(const spdlog::details::log_msg& message) override {
        ++attempts;
        const std::string_view payload(message.payload.data(), message.payload.size());
        if (failWrites != 0) {
            --failWrites;
            throw std::runtime_error("simulated spdlog sink write failure");
        }
        if (partialWriteBytes != 0) {
            const auto sequenceAt = payload.find("seq=");
            const auto sequenceEnd = payload.find(',', sequenceAt);
            output += payload.substr(0, std::min(partialWriteBytes, sequenceEnd));
            partialWriteBytes = 0;
            throw std::runtime_error("simulated partial spdlog sink write");
        }
        output.append(payload);
        payloads.emplace_back(payload);
    }
    void flush() override {
        ++flushAttempts;
        if (failFlushes != 0) {
            --failFlushes;
            throw std::runtime_error("simulated spdlog flush failure");
        }
    }
    void set_pattern(const std::string&) override {}
    void set_formatter(std::unique_ptr<spdlog::formatter>) override {}

    std::size_t attempts{};
    std::size_t flushAttempts{};
    std::size_t failWrites{};
    std::size_t failFlushes{};
    std::size_t partialWriteBytes{};
    std::string output;
    std::vector<std::string> payloads;
};

void spdlogFailureReproAndRecovery() {
    EventRecorder recorder;
    CHECK(recorder.Record(record(Event::menuDestroy, Phase::begin, 11), true));
    auto rawSink = std::make_shared<TestSpdlogSink>();
    rawSink->failWrites = 1;
    auto sink = std::make_shared<SpdlogEventSink>(rawSink);
    const bool failed = recorder.Flush(sink);
    const auto failedStats = recorder.GetStats();
    CHECK(!failed && rawSink->attempts == 1 && failedStats.flushed == 0 && failedStats.stored == 1);
    CHECK(rawSink->output.empty() && rawSink->flushAttempts == 0);
    const bool recovered = recorder.Flush(sink);
    const auto recoveredStats = recorder.GetStats();
    CHECK(recovered && recoveredStats.flushed == 1 && rawSink->payloads.size() == 1);
    CHECK(rawSink->payloads[0].find("seq=1") != std::string::npos);
    std::cout << "SPDLOG_FAILURE_REPRO_055 attempts=1 success=0 pending=1 flushed=0 readback_lines=0;"
                 " recovery_success=1 accepted=1 sequence=1 recovery_flushed=1 recovery_readback_lines=1 flush_attempts=1\n";

    EventRecorder partialRecorder;
    CHECK(partialRecorder.Record(record(Event::menuDestroy, Phase::begin, 12), true));
    auto partialSink = std::make_shared<TestSpdlogSink>();
    partialSink->partialWriteBytes = 80;
    auto partialAdapter = std::make_shared<SpdlogEventSink>(partialSink);
    CHECK(!partialRecorder.Flush(partialAdapter));
    CHECK(partialRecorder.GetStats().flushed == 0 && partialRecorder.GetStats().stored == 1);
    CHECK(partialSink->output.find("seq=1") != std::string::npos);

    EventRecorder flushRecorder;
    CHECK(flushRecorder.Record(record(Event::menuDestroy, Phase::begin, 13), true));
    auto flushSink = std::make_shared<TestSpdlogSink>();
    flushSink->failFlushes = 1;
    auto flushAdapter = std::make_shared<SpdlogEventSink>(flushSink);
    CHECK(!flushRecorder.Flush(flushAdapter));
    CHECK(flushRecorder.GetStats().flushed == 0 && flushRecorder.GetStats().stored == 1);
    CHECK(flushRecorder.Flush(flushAdapter));
    CHECK(flushSink->payloads.size() == 2);
    CHECK(flushSink->payloads[0].find("seq=1") != std::string::npos);
    CHECK(flushSink->payloads[1].find("seq=1") != std::string::npos);

    EventRecorder partialRetryRecorder;
    CHECK(partialRetryRecorder.Record(record(Event::menuDestroy, Phase::begin, 14), true));
    auto retrySink = std::make_shared<TestSpdlogSink>();
    retrySink->partialWriteBytes = 80;
    auto retryAdapter = std::make_shared<SpdlogEventSink>(retrySink);
    CHECK(!partialRetryRecorder.Flush(retryAdapter));
    CHECK(retrySink->output.find("seq=1") != std::string::npos);
    CHECK(partialRetryRecorder.GetStats().flushed == 0);
    CHECK(partialRetryRecorder.Flush(retryAdapter));
    CHECK(retrySink->payloads.size() == 1 && retrySink->payloads[0].find("seq=1") != std::string::npos);
}
#endif
}  // namespace

int main() {
    sequenceAndGeneration();
    overflowAndDropCount();
    overflowDoesNotCreateUnboundedLogLines();
    failedWritesAndFlushesKeepRecordsPending();
    concurrentClose();
    recordWhileFlushInFlight();
    sinkLeaseAndTeardown();
#if defined(QLD_EXIT_DIAGNOSTICS_SPDLOG_TEST)
    spdlogFailureReproAndRecovery();
#endif
    std::cout << "ExitDiagnostics PASS: sequence, bounded overflow/drop count, concurrent close, sink lease/teardown\n";
}
