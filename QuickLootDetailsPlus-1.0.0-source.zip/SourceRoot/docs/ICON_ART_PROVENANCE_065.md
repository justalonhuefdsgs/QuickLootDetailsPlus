# 065 icon artwork provenance

## Inputs

This candidate copies the complete 061 mapping (`assets/category-icons/manifest/`) and all 80 individual base SVGs plus four separate overlays. The 064 audit report and its reference mapping/hash/preview records are held in candidate-local `evidence/inputs/064/`. The 061 vector check is included with source as `assets/category-icons/manifest/vector_checks_061.json`.

The 061 set contains 84 unique symbols. Eighteen carry forward the approved 060-v3 shapes and palettes; the other 66 are 061-authored shapes. The 78 active labels are taken in order from `source_labels`. The two non-active base assets are `unknown_fallback` and supplemental `drink`. Runtime input with an unknown label continues to map to `default_misc`; neither a drink-name heuristic nor a new `drink` active label is added. Existing `food_wine` remains the active wineglass route.

The SWF build reads each individual `svg/individual/*.svg` file and each `svg/overlays/*.svg` file. It does not read `category_icons_061.svg` or any contact-sheet/caption SVG. The latter includes rendered captions and a Segoe UI family declaration, so it is excluded from SWF input. All 84 source SVGs are checked for external references, font declarations, text, bitmap, and foreign-object content. The source drawings are transparent and use the palette recorded by 061. No font is embedded and no text is converted to outlines.

The existing 057 AS2 marker slots remain separate clips: `qldMarkerEnchant`, `qldMarkerKnown`, `qldMarkerSpecial`, and `qldMarkerRead`. This copy replaces their four external 057 SVG inputs with the matching 061 overlays, byte-for-byte from the new 061 source directory. The category base icon remains a separate loaded movie clip and is not replaced by an overlay. The route does not tint the 061 base palette.

## User review status and replacement path

The 060-v3 approval covers the design direction only. The current 78-label 061 icon set and its supplemental assets remain provisional pending the user's later per-icon review; this candidate does not treat them as adopted or deployment-ready. The current SVGs, symbol mapping, label mapping, and overlay mapping remain separate inputs. When the user resumes artwork review, replace only the selected source SVGs/mapping records, then run `python tools/source_manifest.py --write`, `python tools/render_icon_previews.py --root . --preview ../../preview --temp ../../temp`, `python tools/build_assets.py --ui-only`, and the full native/ZIP checks. The rebuilt SWFs and native identity will bind the changed source; no 036/062 integration is part of this candidate.

## Rights boundary

This document records source inputs and hashes. It does not grant a license or assert Nexus, DP, or other external publication permission. QuickLoot IE API code, old 057 marker provenance, CommonLib terms, and all inherited GPL notices are documented separately and retained; a marker-art replacement is not treated as a blanket license or notice deletion.

## QLD112 card-icon and package status (2026-10-28)
The latest QLD card presentation specification is no category/item icon in the detail card. SourceRoot/ui/panel.as sets QLD_CATEGORY_ICON_ROUTE to text; the QLD112 result says this no-card-icon behavior remains. QuickLoot IE's top-list icons are unchanged. The main-SWF enchantment/read marker clips are a separate route and are not the category sidecar.
The category sidecar remains physically present and unchanged in the dedicated mod at Interface/QuickLootDetails_CategoryIcons.swf (14,936 bytes, SHA256 F0995B56BE52B7BA3E6B2250EEDCD940F90BC87CB9825969A34ACA795B65AB20). Its presence in the package does not mean the current card route displays or loads those category icons. QLD112 changed only the DLL; main SWF and sidecar identities were preserved.
The 065 provenance records 80 individual base SVGs plus four separate overlays, 84 symbols total; 18 shapes carry forward 060-v3 and 66 are 061-authored. The individual 061 artwork remains provisional pending per-icon user review; local provenance and retained upstream notices do not grant Nexus, donation-point, or other external publication rights. LICENSE_AUDIT_JA.md is scoped to the older QLD-TEXT-CANDIDATE-GATE-032 and is not a clearance for the 065 category sidecar.
If a release package keeps the unused sidecar, its rights/review remain a gate. Omitting it would require a separately recorded package change; it was not removed here.
