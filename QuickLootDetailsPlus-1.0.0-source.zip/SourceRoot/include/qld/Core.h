#pragma once
#include "qld/Card.h"
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <mutex>
#include <optional>
#include <span>
#include <string>
#include <string_view>

namespace qld {
enum class Side { left=0, right=1, below=2 };
enum class WorldAnchor { right=0, left=1 };
struct WorldSettings {
    bool enabled{false};
    WorldAnchor anchor{WorldAnchor::right};
    double offsetX{-220}, offsetY{90};
    int cardScalePercent{100};
    void normalize() noexcept;
};
struct CardDisplaySettings {
    bool enabled{true};
    bool category{true};
    bool valueWeight{true};
    bool ownedCount{true};
    bool bookRead{true};
    bool spellLearned{true};
    bool potionDetails{true};
    bool ingredientEffects{true};
    bool equipmentDetails{true};
    bool soulGemDetails{true};
    bool itemFlags{true};
    bool pluginSource{false};
    int maxRows{4};
    double fontScale{0.9};
    bool showIcons{true};
    bool referenceDps{false};
    void normalize() noexcept;
};
struct Settings {
    bool enabled{true};
    Side side{Side::below};
    double offsetX{0}, offsetY{0}, width{300}, scale{1}, fontSize{18};
    double backgroundOpacity{0.70}, textOpacity{1};
    WorldSettings world;
    int quickLootScalePercent{100};
    CardDisplaySettings cardDisplay;
    void normalize() noexcept;
};
double quickLootRenderScale(const Settings&) noexcept;
double quickLootPanelWidth(const Settings&, double listWidth, double screenWidth) noexcept;
double worldRenderScale(const Settings&) noexcept;
Settings parseSettings(std::string_view ini);
Settings parseSettingsLayers(std::string_view defaults, std::string_view user);
std::optional<double> referenceMeleeDps(double damage,double weaponSpeed) noexcept;
std::string_view displayAlchemyCategory(bool isFoodOrDrink, bool isPoison, bool english) noexcept;
std::vector<std::string> buildCardInfoRows(const CardSnapshot&, const CardDisplaySettings&, bool english);
std::uint32_t countKnownIngredientEffects(std::uint32_t flags, std::uint32_t effectCount) noexcept;
class MovieLoadGate {
public:
    bool shouldAttempt(bool lootVisible, double interval) noexcept;
    std::uint32_t attempts() const noexcept { return attempts_; }
private:
    std::uint32_t attempts_{};
    double delay_{};
};
std::string cleanText(std::string_view text, std::size_t maxBytes = 512);
struct Item {
    std::uint32_t formId{}, container{};
    std::uint64_t stackIdentity{};
    std::string name, category;
    std::int32_t count{1}, value{};
    double weight{};
    std::string details; // legacy core fixture only; never displayed in 0.1.12
    CardSnapshot card;
    std::uint32_t dropHandle{};
    std::string selectedName; // exact native selection name, separate from cleaned legacy fixture
    std::vector<StackTraits> selectedTraits; // values only; never ExtraDataList pointers
    std::vector<StackTraits> dropTraits;
};
struct Frame {
    std::uint64_t revision{}, generation{};
    bool open{};
    Settings settings;
    std::optional<Item> selected;
    bool visible() const noexcept { return open && settings.enabled && selected.has_value(); }
};
class State {
public:
    void open(std::uint32_t container);
    void close();
    void invalidate(std::uint32_t container);
    void select(std::uint32_t container, std::optional<Item> item);
    bool selectCurrent(std::uint64_t generation,std::uint32_t container,Item item);
    void configure(Settings settings);
    void configureLoot(Settings settings);
    void configureWorld(WorldSettings settings);
    void configureCardDisplay(CardDisplaySettings settings);
    bool publishCard(std::uint64_t generation,std::uint64_t selection,CardSnapshot card);
    Frame frame() const;
private:
    mutable std::mutex mutex_;
    Frame frame_;
    std::uint32_t container_{};
};
struct Bounds { double x{}, y{}, width{}, height{}; bool aboveFallback{}; };
struct DescriptionFitCandidate { double fontSize{}, requiredHeight{}; };
struct DescriptionFitPlan { double preferredHeight{}, panelHeight{}, fontSize{}, requiredHeight{}; bool expanded{}, valid{}; };
DescriptionFitPlan planDescriptionFit(double preferredLogicalHeight, std::span<const DescriptionFitCandidate> candidates,double availableLogicalHeight) noexcept;
double availablePanelHeight(Bounds,const Settings&,double screenWidth,double screenHeight);
double availableWorldPanelHeight(const Settings&,double screenWidth,double screenHeight);
Bounds placePanel(Bounds loot, const Settings& settings, double screenWidth, double screenHeight,double desiredLogicalHeight=0,double minimumLogicalHeight=0);
Bounds placeWorldPanel(const Settings&,double screenWidth,double screenHeight,double desiredLogicalHeight,double minimumLogicalHeight=0);
bool providerAllowed(std::string_view sha256, std::uint32_t runtimeVersion, bool conflictingProvider = false) noexcept;
inline constexpr std::string_view ie412Hash = "b6cdb74d063dd8889008c2073b347fef7a5cb891c213dddaa5af402aa547d6b5";
inline constexpr std::uint32_t se1597 = 0x01050610;
}
