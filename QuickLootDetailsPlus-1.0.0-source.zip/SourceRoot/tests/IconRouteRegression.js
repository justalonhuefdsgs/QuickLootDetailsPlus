const fs = require('fs');
const vm = require('vm');

function fail(message) { throw new Error(message); }

function extractFunction(source, name) {
  const pattern = new RegExp('\\bfunction\\s+' + name + '\\s*\\(');
  const match = pattern.exec(source);
  if (!match) fail('compiled AS2 function is missing: ' + name);
  const start = match.index;
  let brace = source.indexOf('{', match.index);
  if (brace < 0) fail('compiled function has no body: ' + name);
  let depth = 0;
  let quote = '';
  let escaped = false;
  let lineComment = false;
  let blockComment = false;
  for (let i = brace; i < source.length; i++) {
    const ch = source[i];
    const next = source[i + 1];
    if (lineComment) {
      if (ch === '\n') lineComment = false;
      continue;
    }
    if (blockComment) {
      if (ch === '*' && next === '/') { blockComment = false; i++; }
      continue;
    }
    if (quote) {
      if (escaped) escaped = false;
      else if (ch === '\\') escaped = true;
      else if (ch === quote) quote = '';
      continue;
    }
    if (ch === '/' && next === '/') { lineComment = true; i++; continue; }
    if (ch === '/' && next === '*') { blockComment = true; i++; continue; }
    if (ch === '"' || ch === "'") { quote = ch; continue; }
    if (ch === '{') depth++;
    else if (ch === '}' && --depth === 0) return source.slice(start, i + 1);
  }
  fail('compiled function body did not close: ' + name);
}

function makeContext(route, frameRecord, functions) {
  const frameMap = frameRecord.frame_labels;
  const categoryIcon = {
    _visible: false, _width: 0, _height: 0, _x: 0, _y: 0,
    _currentframe: 1, _totalframes: frameRecord.frame_count,
    gotoAndStop(label) {
      if (Object.prototype.hasOwnProperty.call(frameMap, label)) this._currentframe = frameMap[label];
    }
  };
  const ctx = {
    QLD_CATEGORY_ICON_ROUTE: route,
    categoryIcon,
    categoryIconTint: { calls: [], setRGB(value) { this.calls.push(value); } },
    iconLoader: { calls: [], loadClip(path, target) { this.calls.push(path); target._currentframe = 1; ctx.iconLoaded = true; return true; } },
    iconLoadStarted: false, iconLoadFailed: false, iconLoaded: false,
    iconRequestedVisible: false, iconRequestGeneration: 0, iconLoadGeneration: -1,
    iconLabel: 'default_misc', iconAppliedLabel: '', iconFailedLabel: '', iconColor: 0xFFFFFF,
    qldPositionTitle() {},
    currentTitleCard: null, currentTitleWidth: 335, currentTitleFontSize: 18, currentTitleHeight: 44,
    content: { _x: 0, _y: 0, title: { _x: 0, _y: 12, _width: 0, text: '' } },
    panel: { _x: 0, _y: 0, _xscale: 100, _yscale: 100 },
    qldCardTitle() { return 'Vector item'; },
    qldMeasureText() { return { width: 88, height: 20 }; },
    qldSetText(field, text) { field.text = text; return false; },
    enchantMarkerIcon: { _visible: false },
    knownEnchantMarkerIcon: { _visible: false },
    specialEnchantMarkerIcon: { _visible: false },
    readMarkerIcon: { _visible: false }
  };
  for (const name of functions) vm.runInNewContext(extractFunction(functions.source, name), ctx);
  return ctx;
}

function check(condition, message) { if (!condition) fail(message); }

const as2Path = process.argv[2];
const recordPath = process.argv[3];
if (!as2Path || !recordPath) fail('expected compiled DoAction.as and category-icon build record paths');
const source = fs.readFileSync(as2Path, 'utf8');
const record = JSON.parse(fs.readFileSync(recordPath, 'utf8'));
const needed = [
  'qldUsesSkyUIIconRoute', 'qldUsesOwnedIconRoute', 'qldUsesCategoryIconRoute',
  'qldIsKnownItemIconLabel', 'qldSelectCategoryIcon', 'qldIsCurrentCategoryIconRequest',
  'qldApplyCategoryIcon', 'qldInvalidateCategoryIconRequest', 'qldSetCategoryIcon',
  'qldPositionTitle'
];
needed.source = source;

// Current full-header/render integration is exercised by UiProtocolTests.
// This unit retains dormant route/fallback/tint checks, with the product default disabled.
check(/var\s+QLD_CATEGORY_ICON_ROUTE\s*=\s*"text"/.test(source), 'approved title icon removal changed');
check(!source.includes('var enchantMarkerIcon') && !source.includes('var readMarkerIcon'), 'removed title marker bindings returned');
const native = makeContext('owned-svg', record, needed);
native.qldSetCategoryIcon(true, 'weapon_sword', 0x995577);
check(native.iconLoader.calls.length === 1 && native.iconLoader.calls[0] === 'QuickLootDetails_CategoryIcons.swf',
  'owned route did not load the candidate category-icon sidecar');
check(native.categoryIcon._visible && native.iconLabel === 'weapon_sword', 'known active label did not draw in the owned route');
check(native.categoryIcon._currentframe === record.frame_labels.weapon_sword, 'known label selected the wrong sidecar frame');
check(native.categoryIconTint.calls.length === 0, 'owned route applied the 057 category tint to source palette colors');

const fallback = makeContext('owned-svg', record, needed);
fallback.qldSetCategoryIcon(true, 'unknown_fallback', 0x123456);
check(fallback.iconLabel === 'default_misc', 'unknown label did not retain the existing default_misc fallback');
check(fallback.categoryIcon._visible && fallback.categoryIcon._currentframe === record.frame_labels.default_misc,
  'default_misc fallback did not draw its active source frame');
check(!Object.prototype.hasOwnProperty.call(record.frame_labels, 'unknown_fallback'),
  'non-active fallback art was exposed as an active frame label');
check(fallback.categoryIconTint.calls.length === 0, 'fallback route changed the source palette');

const drink = makeContext('owned-svg', record, needed);
drink.qldSetCategoryIcon(true, 'drink', 0x445566);
check(drink.iconLabel === 'default_misc', 'supplemental drink art became a name-based category route');
check(!Object.prototype.hasOwnProperty.call(record.frame_labels, 'drink'), 'drink was added to active sidecar labels');
const wine = makeContext('owned-svg', record, needed);
wine.qldSetCategoryIcon(true, 'food_wine', 0x778899);
check(wine.iconLabel === 'food_wine' && wine.categoryIcon._currentframe === record.frame_labels.food_wine,
  'existing food_wine route changed');

const text = makeContext('text', record, needed);
text.qldSetCategoryIcon(true, 'weapon_sword', 0x112233);
check(text.iconLoader.calls.length === 0 && !text.categoryIcon._visible,
  'safe text route should not load the icon sidecar');

const skyui = makeContext('skyui', record, needed);
skyui.qldSetCategoryIcon(true, 'weapon_sword', 0x336699);
check(skyui.iconLoader.calls[0] === 'skyui/icons_item_psychosteve.swf', 'legacy alternate route changed unexpectedly');
check(skyui.categoryIconTint.calls.length === 1 && skyui.categoryIconTint.calls[0] === 0x336699,
  'legacy route tint behavior changed');

const overlayCases = [
  { enchant: 0, read: false, expected: [false, false, false, false] },
  { enchant: 1, read: false, expected: [false, false, false, false] },
  { enchant: 2, read: false, expected: [false, false, false, false] },
  { enchant: 3, read: false, expected: [false, false, false, false] },
  { enchant: 0, read: true, expected: [false, false, false, false] },
  { enchant: 1, read: true, expected: [false, false, false, false] },
  { enchant: 2, read: true, expected: [false, false, false, false] },
  { enchant: 3, read: true, expected: [false, false, false, false] }
];
for (const state of overlayCases) {
  const ctx = makeContext('owned-svg', record, needed);
  ctx.categoryIcon._visible = true;
  ctx.currentTitleCard = { showCategory: true, showIcons: true, enchantMarker: state.enchant, type: 4, bookRead: state.read };
  ctx.enchantMarkerIcon._visible = false;
  ctx.knownEnchantMarkerIcon._visible = false;
  ctx.specialEnchantMarkerIcon._visible = false;
  ctx.readMarkerIcon._visible = false;
  ctx.qldPositionTitle(true);
  const actual = [ctx.enchantMarkerIcon._visible, ctx.knownEnchantMarkerIcon._visible,
    ctx.specialEnchantMarkerIcon._visible, ctx.readMarkerIcon._visible];
  check(JSON.stringify(actual) === JSON.stringify(state.expected),
    'removed title overlays returned for ' + JSON.stringify(state));
  check(ctx.categoryIcon._visible, 'an overlay state hid the base category icon');
}

console.log('AS2_ICON_ROUTE_PASS active=78 unknown=default_misc supplemental_drink=nonactive tint=skipped removed_overlays=8_combinations base_helper_unchanged=true');
