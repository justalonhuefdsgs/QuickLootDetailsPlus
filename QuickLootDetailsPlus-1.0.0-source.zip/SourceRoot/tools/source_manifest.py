"""Canonical allowlist and deterministic source manifest for candidate 065.

Generated build/dist/evidence trees are outside this module's source allowlist.
The manifest file itself is intentionally excluded to avoid self-reference.
"""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path, PurePosixPath

ROOT_FILES = {
    '.gitignore', 'BUILD.md', 'COPYING.txt', 'EXCEPTIONS.md', 'INSTALLATION.md',
    'LICENSE.md', 'NOTICE.md', 'README.md', 'THIRD_PARTY.md', 'CMakeLists.txt',
    'dependencies.json',
}
DOCS = {
    'HUMAN_TEST_JA.md', 'CHANGELOG_JA.md', 'LICENSE_AUDIT_JA.md', 'provider-abi-facts.json',
    'license-provenance.json', 'dependency-source-changes.json', 'papyrus-imports-required.json',
    'source-delta.json', 'verification.json', 'IMPLEMENTATION_STATUS_JA.md', 'SKYUI_ICONS_JA.md',
    'ICON_AUDIT_0.1.20-r1.md', 'REPAIR_EVIDENCE_JA.md',
    'ROUTE_SELECTION_JA.md', 'candidate-049.json', 'candidate-054.json',
    'candidate-057.json', 'candidate-065.json', 'verification-065.json',
    'ICON_ART_PROVENANCE_065.md', 'MARKER_ART_CREDIT_057_HISTORY.md', 'EXIT_DIAGNOSTICS_057_TESTPACK_JA.md',
    'PROJECT_CHARTER.md',
    'MASTER_PLAN.md',
    'CURRENT_STATE.md',
    'DECISIONS.md',
    'HUMAN_QUEUE.md',
    'TEST_MATRIX.md',
    'COMPATIBILITY_MATRIX.md',
    'KNOWN_ISSUES.md',
    'CHANGELOG.md',
    'NEXUS_RELEASE_CHECKLIST.md',
}
TOOLS = {
    'build_assets.py', 'build.ps1', 'prepare_deps.py', 'verify_assets.py', 'restore_papyrus_import.py',
    'package.py', 'package_audit.py', 'restore_inherited_assets.py', 'build_identity.py',
    'source_manifest.py', 'marker_contract.py', 'package_private_049.py', 'package_audit_049.py',
    'package_private_054.py', 'package_audit_054.py',
    'package_private_057.py', 'package_audit_057.py', 'package_private_065.py', 'package_audit_065.py',
    'icon_library.py', 'render_icon_previews.py', 'pe_pdb_identity_065.py',
}
LICENSES = {
    'CommonLib-COPYING.txt', 'CommonLib-EXCEPTIONS.md', 'CommonLib-legacy-MIT.txt',
    'DirectXMath-LICENSE.txt', 'DirectXTK-LICENSE.txt', 'QuickLootIE-API-MIT.txt',
    'QuickLoot-reference-profiles-MIT.txt', 'QuickLootIE-GPL-3.0.txt',
    'QuickLootIE-EXCEPTIONS.md', 'spdlog-LICENSE.txt', 'Caprica.LICENSE', 'Champollion.LICENSE',
}
SOURCE_DIRS = ('src', 'include', 'tests', 'cmake', 'ui', 'scripts', 'assets', 'docs', 'licenses', 'tools', 'vendor', 'deps')


def source_allowed(relative: str) -> bool:
    p = PurePosixPath(relative)
    parts = p.parts
    if relative in ROOT_FILES or relative == 'source-manifest.json':
        return True
    if len(parts) == 2 and parts[0] == 'docs':
        return parts[1] in DOCS
    if len(parts) == 2 and parts[0] == 'tools':
        return parts[1] in TOOLS
    if len(parts) == 2 and parts[0] == 'licenses':
        return parts[1] in LICENSES
    if parts[0] in {'src', 'include'}:
        return p.suffix in {'.cpp', '.h'}
    if parts[0] == 'tests':
        return p.suffix in {'.cpp', '.py', '.js'} or relative in {'tests/normalized-fixtures.json', 'tests/fit-boundary-fixtures.json'}
    if parts[0] == 'cmake':
        return len(parts) == 3 and parts[1] == 'packages' and p.suffix == '.cmake'
    if parts[0] == 'vendor':
        return relative == 'vendor/QuickLootAPI.h'
    if parts[0] == 'ui':
        return relative in {'ui/panel.as', 'ui/layout.js'}
    if parts[0] == 'scripts':
        return relative in {'scripts/QLD_Native.psc', 'scripts/QLD_MCM.psc', 'scripts/Skyrim.flg'}
    if parts[0] == 'assets':
        if relative in {
            'assets/MCM/Config/QuickLootDetails/config.json',
            'assets/MCM/Config/QuickLootDetails/settings.ini',
            'assets/Interface/Translations/QuickLootDetails_ENGLISH.txt',
            'assets/Interface/Translations/QuickLootDetails_JAPANESE.txt',
        }:
            return True
        if len(parts) == 3 and parts[1] == 'marker-art' and parts[2] in {
            '20.svg', '22.svg', '24.svg', '26.svg', 'provenance.json'
        }:
            return True
        if len(parts) == 5 and parts[1] == 'category-icons' and parts[2] == 'svg':
            return parts[3] in {'individual', 'overlays'} and p.suffix == '.svg'
        if len(parts) == 4 and parts[1] == 'category-icons' and parts[2] == 'manifest':
            return parts[3] in {'icon_mapping.csv', 'icon_mapping.json', 'overlay_mapping.json', 'palette.json', 'vector_checks_061.json'}
        if len(parts) == 4 and parts[1] == 'category-icons' and parts[2] == 'source':
            return parts[3] in {'palette_and_provenance.md', 'provenance_065.md'}
    if parts[0] == 'deps':
        return len(parts) == 2 and parts[1] in {'commonlib.zip', 'spdlog.zip', 'directxtk.zip', 'directxmath.zip'}
    return False


def collect_source_files(root: Path) -> dict[str, Path]:
    root = root.resolve()
    files: dict[str, Path] = {}
    for folder in SOURCE_DIRS:
        directory = root / folder
        if not directory.exists():
            continue
        for path in directory.rglob('*'):
            if path.is_symlink():
                if source_allowed(path.relative_to(root).as_posix()):
                    raise ValueError(f'symlink is not allowed in source package: {path.relative_to(root)}')
                continue
            if not path.is_file():
                continue
            rel = path.relative_to(root).as_posix()
            if source_allowed(rel):
                files[rel] = path
    for path in root.iterdir():
        if path.is_symlink():
            if source_allowed(path.name):
                raise ValueError(f'symlink is not allowed in source package: {path.name}')
            continue
        if path.is_file() and path.name != 'source-manifest.json' and source_allowed(path.name):
            files[path.name] = path
    return dict(sorted(files.items()))


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def manifest_entries(root: Path) -> dict[str, str]:
    files = collect_source_files(root)
    return {f'QuickLootDetails/{rel}': sha256_file(path) for rel, path in files.items()}


def render_manifest(root: Path) -> bytes:
    return (json.dumps(manifest_entries(root), indent=2, ensure_ascii=True) + '\n').encode('utf-8')


def write_manifest(root: Path) -> tuple[str, int, bool]:
    root = root.resolve()
    path = root / 'source-manifest.json'
    content = render_manifest(root)
    changed = not path.is_file() or path.read_bytes() != content
    if changed:
        tmp = path.with_name(path.name + '.tmp')
        tmp.write_bytes(content)
        os.replace(tmp, path)
    digest = hashlib.sha256(content).hexdigest()
    count = len(json.loads(content))
    return digest, count, changed


def verify_manifest(root: Path) -> tuple[str, int]:
    root = root.resolve()
    manifest_path = root / 'source-manifest.json'
    if not manifest_path.is_file():
        raise ValueError('source-manifest.json is missing')
    raw = manifest_path.read_bytes()
    try:
        manifest = json.loads(raw.decode('utf-8-sig'))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError(f'source-manifest.json is invalid: {exc}') from exc
    if not isinstance(manifest, dict) or not manifest:
        raise ValueError('source-manifest.json is empty or is not an object')
    expected = manifest_entries(root)
    if manifest != expected:
        missing = sorted(set(expected) - set(manifest))
        extra = sorted(set(manifest) - set(expected))
        changed = sorted(k for k in set(manifest) & set(expected) if manifest[k] != expected[k])
        details = []
        if missing: details.append('unlisted source files: ' + ', '.join(missing[:12]))
        if extra: details.append('stale/extra manifest entries: ' + ', '.join(extra[:12]))
        if changed: details.append('source hash mismatch: ' + ', '.join(changed[:12]))
        raise ValueError('; '.join(details))
    return hashlib.sha256(raw).hexdigest(), len(manifest)


def main() -> int:
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--write', action='store_true')
    group.add_argument('--check', action='store_true')
    args = parser.parse_args()
    try:
        if args.write:
            digest, count, changed = write_manifest(args.root)
            status = 'MANIFEST_UPDATED' if changed else 'MANIFEST_UNCHANGED'
        else:
            digest, count = verify_manifest(args.root)
            status = 'MANIFEST_PASS'
        print(f'{status} source_manifest_sha256={digest} source_manifest_entries={count}')
        return 0
    except (OSError, ValueError) as exc:
        print(f'MANIFEST_FAIL {exc}')
        return 1

if __name__ == '__main__':
    raise SystemExit(main())
